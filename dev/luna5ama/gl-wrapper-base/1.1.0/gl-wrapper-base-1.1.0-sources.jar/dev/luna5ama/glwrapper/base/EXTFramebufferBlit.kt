@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTFramebufferBlit : GLBase {
    public fun glBlitFramebufferEXT(
        srcX0: Int,
        srcY0: Int,
        srcX1: Int,
        srcY1: Int,
        dstX0: Int,
        dstY0: Int,
        dstX1: Int,
        dstY1: Int,
        mask: Int,
        filter: Int,
    )
}

public const val GL_READ_FRAMEBUFFER_EXT: Int = 36_008

public const val GL_DRAW_FRAMEBUFFER_EXT: Int = 36_009

public const val GL_DRAW_FRAMEBUFFER_BINDING_EXT: Int = 36_006

public const val GL_READ_FRAMEBUFFER_BINDING_EXT: Int = 36_010

public inline fun glBlitFramebufferEXT(
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    mask: Int,
    filter: Int,
): Unit = GLWrapper.instance.EXTFramebufferBlit.glBlitFramebufferEXT(srcX0, srcY0, srcX1, srcY1,
        dstX0, dstY0, dstX1, dstY1, mask, filter)
