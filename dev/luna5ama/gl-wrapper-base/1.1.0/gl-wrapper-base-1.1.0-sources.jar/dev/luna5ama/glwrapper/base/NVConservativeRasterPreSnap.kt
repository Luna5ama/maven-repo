@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVConservativeRasterPreSnap : GLBase

public const val GL_CONSERVATIVE_RASTER_MODE_PRE_SNAP_NV: Int = 38_224
