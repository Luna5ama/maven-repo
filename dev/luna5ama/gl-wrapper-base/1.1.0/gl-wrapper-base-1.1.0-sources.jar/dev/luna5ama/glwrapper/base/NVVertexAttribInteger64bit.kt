@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVVertexAttribInteger64bit : GLBase {
    public fun glVertexAttribL1i64NV(index: Int, x: Long)

    public fun glVertexAttribL2i64NV(
        index: Int,
        x: Long,
        y: Long,
    )

    public fun glVertexAttribL3i64NV(
        index: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    public fun glVertexAttribL4i64NV(
        index: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([1])
    public fun glVertexAttribL1i64vNV(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL1i64vNV(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL2i64vNV(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL2i64vNV(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL3i64vNV(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL3i64vNV(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL4i64vNV(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL4i64vNV(index: Int, v: Long)

    public fun glVertexAttribL1ui64NV(index: Int, x: Long)

    public fun glVertexAttribL2ui64NV(
        index: Int,
        x: Long,
        y: Long,
    )

    public fun glVertexAttribL3ui64NV(
        index: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    public fun glVertexAttribL4ui64NV(
        index: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([1])
    public fun glVertexAttribL1ui64vNV(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL1ui64vNV(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL2ui64vNV(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL2ui64vNV(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL3ui64vNV(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL3ui64vNV(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL4ui64vNV(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL4ui64vNV(index: Int, v: Long)

    @PtrParameter([2])
    public fun glGetVertexAttribLi64vNV(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribLi64vNV(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribLui64vNV(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribLui64vNV(
        index: Int,
        pname: Int,
        params: Long,
    )

    public fun glVertexAttribLFormatNV(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
    )
}

public inline fun glVertexAttribL1i64NV(index: Int, x: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL1i64NV(index, x)

public inline fun glVertexAttribL2i64NV(
    index: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL2i64NV(index, x, y)

public inline fun glVertexAttribL3i64NV(
    index: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL3i64NV(index, x, y, z)

public inline fun glVertexAttribL4i64NV(
    index: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL4i64NV(index, x, y, z, w)

public inline fun glVertexAttribL1i64vNV(index: Int, v: Ptr): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL1i64vNV(index, v)

public inline fun glVertexAttribL1i64vNV(index: Int, v: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL1i64vNV(index, v)

public inline fun glVertexAttribL2i64vNV(index: Int, v: Ptr): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL2i64vNV(index, v)

public inline fun glVertexAttribL2i64vNV(index: Int, v: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL2i64vNV(index, v)

public inline fun glVertexAttribL3i64vNV(index: Int, v: Ptr): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL3i64vNV(index, v)

public inline fun glVertexAttribL3i64vNV(index: Int, v: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL3i64vNV(index, v)

public inline fun glVertexAttribL4i64vNV(index: Int, v: Ptr): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL4i64vNV(index, v)

public inline fun glVertexAttribL4i64vNV(index: Int, v: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL4i64vNV(index, v)

public inline fun glVertexAttribL1ui64NV(index: Int, x: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL1ui64NV(index, x)

public inline fun glVertexAttribL2ui64NV(
    index: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL2ui64NV(index, x, y)

public inline fun glVertexAttribL3ui64NV(
    index: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL3ui64NV(index, x, y, z)

public inline fun glVertexAttribL4ui64NV(
    index: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL4ui64NV(index, x, y, z, w)

public inline fun glVertexAttribL1ui64vNV(index: Int, v: Ptr): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL1ui64vNV(index, v)

public inline fun glVertexAttribL1ui64vNV(index: Int, v: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL1ui64vNV(index, v)

public inline fun glVertexAttribL2ui64vNV(index: Int, v: Ptr): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL2ui64vNV(index, v)

public inline fun glVertexAttribL2ui64vNV(index: Int, v: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL2ui64vNV(index, v)

public inline fun glVertexAttribL3ui64vNV(index: Int, v: Ptr): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL3ui64vNV(index, v)

public inline fun glVertexAttribL3ui64vNV(index: Int, v: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL3ui64vNV(index, v)

public inline fun glVertexAttribL4ui64vNV(index: Int, v: Ptr): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL4ui64vNV(index, v)

public inline fun glVertexAttribL4ui64vNV(index: Int, v: Long): Unit =
        GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribL4ui64vNV(index, v)

public inline fun glGetVertexAttribLi64vNV(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glGetVertexAttribLi64vNV(index, pname,
        params)

public inline fun glGetVertexAttribLi64vNV(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glGetVertexAttribLi64vNV(index, pname,
        params)

public inline fun glGetVertexAttribLui64vNV(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glGetVertexAttribLui64vNV(index, pname,
        params)

public inline fun glGetVertexAttribLui64vNV(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glGetVertexAttribLui64vNV(index, pname,
        params)

public inline fun glVertexAttribLFormatNV(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
): Unit = GLWrapper.instance.NVVertexAttribInteger64bit.glVertexAttribLFormatNV(index, size, type,
        stride)
