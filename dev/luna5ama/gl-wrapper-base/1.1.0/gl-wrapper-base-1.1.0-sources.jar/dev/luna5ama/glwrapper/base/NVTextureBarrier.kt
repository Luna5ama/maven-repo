@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Suppress
import kotlin.Unit

public interface NVTextureBarrier : GLBase {
    public fun glTextureBarrierNV()
}

public inline fun glTextureBarrierNV(): Unit =
        GLWrapper.instance.NVTextureBarrier.glTextureBarrierNV()
