@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface KHRBlendEquationAdvanced : GLBase {
    public fun glBlendBarrierKHR()
}

public const val GL_MULTIPLY_KHR: Int = 37_524

public const val GL_SCREEN_KHR: Int = 37_525

public const val GL_OVERLAY_KHR: Int = 37_526

public const val GL_DARKEN_KHR: Int = 37_527

public const val GL_LIGHTEN_KHR: Int = 37_528

public const val GL_COLORDODGE_KHR: Int = 37_529

public const val GL_COLORBURN_KHR: Int = 37_530

public const val GL_HARDLIGHT_KHR: Int = 37_531

public const val GL_SOFTLIGHT_KHR: Int = 37_532

public const val GL_DIFFERENCE_KHR: Int = 37_534

public const val GL_EXCLUSION_KHR: Int = 37_536

public const val GL_HSL_HUE_KHR: Int = 37_549

public const val GL_HSL_SATURATION_KHR: Int = 37_550

public const val GL_HSL_COLOR_KHR: Int = 37_551

public const val GL_HSL_LUMINOSITY_KHR: Int = 37_552

public inline fun glBlendBarrierKHR(): Unit =
        GLWrapper.instance.KHRBlendEquationAdvanced.glBlendBarrierKHR()
