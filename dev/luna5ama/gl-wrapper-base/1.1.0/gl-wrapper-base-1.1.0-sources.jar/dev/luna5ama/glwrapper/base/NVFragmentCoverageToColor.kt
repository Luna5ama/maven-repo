@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVFragmentCoverageToColor : GLBase {
    public fun glFragmentCoverageColorNV(color: Int)
}

public const val GL_FRAGMENT_COVERAGE_TO_COLOR_NV: Int = 37_597

public const val GL_FRAGMENT_COVERAGE_COLOR_NV: Int = 37_598

public inline fun glFragmentCoverageColorNV(color: Int): Unit =
        GLWrapper.instance.NVFragmentCoverageToColor.glFragmentCoverageColorNV(color)
