@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureFilterMinmax : GLBase

public const val GL_TEXTURE_REDUCTION_MODE_EXT: Int = 37_734

public const val GL_WEIGHTED_AVERAGE_EXT: Int = 37_735
