@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Suppress

public interface ARBCLEvent : GLBase {
    public fun glCreateSyncFromCLeventARB(
        context: Long,
        event: Long,
        flags: Int,
    ): Long
}

public const val GL_SYNC_CL_EVENT_ARB: Int = 33_344

public const val GL_SYNC_CL_EVENT_COMPLETE_ARB: Int = 33_345

public inline fun glCreateSyncFromCLeventARB(
    context: Long,
    event: Long,
    flags: Int,
): Long = GLWrapper.instance.ARBCLEvent.glCreateSyncFromCLeventARB(context, event, flags)
