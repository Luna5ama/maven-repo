@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVDrawVulkanImage : GLBase {
    public fun glDrawVkImageNV(
        vkImage: Long,
        sampler: Int,
        x0: Float,
        y0: Float,
        x1: Float,
        y1: Float,
        z: Float,
        s0: Float,
        t0: Float,
        s1: Float,
        t1: Float,
    )

    @PtrParameter([0])
    public fun glGetVkProcAddrNV(name: Ptr): Long

    @Unsafe
    public fun glGetVkProcAddrNV(name: Long): Long

    public fun glWaitVkSemaphoreNV(vkSemaphore: Long)

    public fun glSignalVkSemaphoreNV(vkSemaphore: Long)

    public fun glSignalVkFenceNV(vkFence: Long)
}

public inline fun glDrawVkImageNV(
    vkImage: Long,
    sampler: Int,
    x0: Float,
    y0: Float,
    x1: Float,
    y1: Float,
    z: Float,
    s0: Float,
    t0: Float,
    s1: Float,
    t1: Float,
): Unit = GLWrapper.instance.NVDrawVulkanImage.glDrawVkImageNV(vkImage, sampler, x0, y0, x1, y1, z,
        s0, t0, s1, t1)

public inline fun glGetVkProcAddrNV(name: Ptr): Long =
        GLWrapper.instance.NVDrawVulkanImage.glGetVkProcAddrNV(name)

public inline fun glGetVkProcAddrNV(name: Long): Long =
        GLWrapper.instance.NVDrawVulkanImage.glGetVkProcAddrNV(name)

public inline fun glWaitVkSemaphoreNV(vkSemaphore: Long): Unit =
        GLWrapper.instance.NVDrawVulkanImage.glWaitVkSemaphoreNV(vkSemaphore)

public inline fun glSignalVkSemaphoreNV(vkSemaphore: Long): Unit =
        GLWrapper.instance.NVDrawVulkanImage.glSignalVkSemaphoreNV(vkSemaphore)

public inline fun glSignalVkFenceNV(vkFence: Long): Unit =
        GLWrapper.instance.NVDrawVulkanImage.glSignalVkFenceNV(vkFence)
