@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface AMDStencilOperationExtended : GLBase {
    public fun glStencilOpValueAMD(face: Int, `value`: Int)
}

public const val GL_SET_AMD: Int = 34_634

public const val GL_REPLACE_VALUE_AMD: Int = 34_635

public const val GL_STENCIL_OP_VALUE_AMD: Int = 34_636

public const val GL_STENCIL_BACK_OP_VALUE_AMD: Int = 34_637

public inline fun glStencilOpValueAMD(face: Int, `value`: Int): Unit =
        GLWrapper.instance.AMDStencilOperationExtended.glStencilOpValueAMD(face, `value`)
