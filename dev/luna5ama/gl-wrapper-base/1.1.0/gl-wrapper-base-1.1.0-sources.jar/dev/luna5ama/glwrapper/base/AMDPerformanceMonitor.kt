@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface AMDPerformanceMonitor : GLBase {
    @PtrParameter([0, 2])
    public fun glGetPerfMonitorGroupsAMD(
        numGroups: Ptr,
        groupsSize: Int,
        groups: Ptr,
    )

    @Unsafe
    public fun glGetPerfMonitorGroupsAMD(
        numGroups: Long,
        groupsSize: Int,
        groups: Long,
    )

    @PtrParameter([1, 2, 4])
    public fun glGetPerfMonitorCountersAMD(
        group: Int,
        numCounters: Ptr,
        maxActiveCounters: Ptr,
        counterSize: Int,
        counters: Ptr,
    )

    @Unsafe
    public fun glGetPerfMonitorCountersAMD(
        group: Int,
        numCounters: Long,
        maxActiveCounters: Long,
        counterSize: Int,
        counters: Long,
    )

    @PtrParameter([2, 3])
    public fun glGetPerfMonitorGroupStringAMD(
        group: Int,
        bufSize: Int,
        length: Ptr,
        groupString: Ptr,
    )

    @Unsafe
    public fun glGetPerfMonitorGroupStringAMD(
        group: Int,
        bufSize: Int,
        length: Long,
        groupString: Long,
    )

    @PtrParameter([3, 4])
    public fun glGetPerfMonitorCounterStringAMD(
        group: Int,
        counter: Int,
        bufSize: Int,
        length: Ptr,
        counterString: Ptr,
    )

    @Unsafe
    public fun glGetPerfMonitorCounterStringAMD(
        group: Int,
        counter: Int,
        bufSize: Int,
        length: Long,
        counterString: Long,
    )

    @PtrParameter([3])
    public fun glGetPerfMonitorCounterInfoAMD(
        group: Int,
        counter: Int,
        pname: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetPerfMonitorCounterInfoAMD(
        group: Int,
        counter: Int,
        pname: Int,
        `data`: Long,
    )

    @PtrParameter([1])
    public fun glGenPerfMonitorsAMD(n: Int, monitors: Ptr)

    @Unsafe
    public fun glGenPerfMonitorsAMD(n: Int, monitors: Long)

    @PtrParameter([1])
    public fun glDeletePerfMonitorsAMD(n: Int, monitors: Ptr)

    @Unsafe
    public fun glDeletePerfMonitorsAMD(n: Int, monitors: Long)

    @PtrParameter([4])
    public fun glSelectPerfMonitorCountersAMD(
        monitor: Int,
        enable: Boolean,
        group: Int,
        numCounters: Int,
        counterList: Ptr,
    )

    @Unsafe
    public fun glSelectPerfMonitorCountersAMD(
        monitor: Int,
        enable: Boolean,
        group: Int,
        numCounters: Int,
        counterList: Long,
    )

    public fun glBeginPerfMonitorAMD(monitor: Int)

    public fun glEndPerfMonitorAMD(monitor: Int)

    @PtrParameter([3, 4])
    public fun glGetPerfMonitorCounterDataAMD(
        monitor: Int,
        pname: Int,
        dataSize: Int,
        `data`: Ptr,
        bytesWritten: Ptr,
    )

    @Unsafe
    public fun glGetPerfMonitorCounterDataAMD(
        monitor: Int,
        pname: Int,
        dataSize: Int,
        `data`: Long,
        bytesWritten: Long,
    )
}

public const val GL_COUNTER_TYPE_AMD: Int = 35_776

public const val GL_COUNTER_RANGE_AMD: Int = 35_777

public const val GL_UNSIGNED_INT64_AMD: Int = 35_778

public const val GL_PERCENTAGE_AMD: Int = 35_779

public const val GL_PERFMON_RESULT_AVAILABLE_AMD: Int = 35_780

public const val GL_PERFMON_RESULT_SIZE_AMD: Int = 35_781

public const val GL_PERFMON_RESULT_AMD: Int = 35_782

public inline fun glGetPerfMonitorGroupsAMD(
    numGroups: Ptr,
    groupsSize: Int,
    groups: Ptr,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorGroupsAMD(numGroups, groupsSize,
        groups)

public inline fun glGetPerfMonitorGroupsAMD(
    numGroups: Long,
    groupsSize: Int,
    groups: Long,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorGroupsAMD(numGroups, groupsSize,
        groups)

public inline fun glGetPerfMonitorCountersAMD(
    group: Int,
    numCounters: Ptr,
    maxActiveCounters: Ptr,
    counterSize: Int,
    counters: Ptr,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorCountersAMD(group, numCounters,
        maxActiveCounters, counterSize, counters)

public inline fun glGetPerfMonitorCountersAMD(
    group: Int,
    numCounters: Long,
    maxActiveCounters: Long,
    counterSize: Int,
    counters: Long,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorCountersAMD(group, numCounters,
        maxActiveCounters, counterSize, counters)

public inline fun glGetPerfMonitorGroupStringAMD(
    group: Int,
    bufSize: Int,
    length: Ptr,
    groupString: Ptr,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorGroupStringAMD(group, bufSize,
        length, groupString)

public inline fun glGetPerfMonitorGroupStringAMD(
    group: Int,
    bufSize: Int,
    length: Long,
    groupString: Long,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorGroupStringAMD(group, bufSize,
        length, groupString)

public inline fun glGetPerfMonitorCounterStringAMD(
    group: Int,
    counter: Int,
    bufSize: Int,
    length: Ptr,
    counterString: Ptr,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorCounterStringAMD(group, counter,
        bufSize, length, counterString)

public inline fun glGetPerfMonitorCounterStringAMD(
    group: Int,
    counter: Int,
    bufSize: Int,
    length: Long,
    counterString: Long,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorCounterStringAMD(group, counter,
        bufSize, length, counterString)

public inline fun glGetPerfMonitorCounterInfoAMD(
    group: Int,
    counter: Int,
    pname: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorCounterInfoAMD(group, counter,
        pname, `data`)

public inline fun glGetPerfMonitorCounterInfoAMD(
    group: Int,
    counter: Int,
    pname: Int,
    `data`: Long,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorCounterInfoAMD(group, counter,
        pname, `data`)

public inline fun glGenPerfMonitorsAMD(n: Int, monitors: Ptr): Unit =
        GLWrapper.instance.AMDPerformanceMonitor.glGenPerfMonitorsAMD(n, monitors)

public inline fun glGenPerfMonitorsAMD(n: Int, monitors: Long): Unit =
        GLWrapper.instance.AMDPerformanceMonitor.glGenPerfMonitorsAMD(n, monitors)

public inline fun glDeletePerfMonitorsAMD(n: Int, monitors: Ptr): Unit =
        GLWrapper.instance.AMDPerformanceMonitor.glDeletePerfMonitorsAMD(n, monitors)

public inline fun glDeletePerfMonitorsAMD(n: Int, monitors: Long): Unit =
        GLWrapper.instance.AMDPerformanceMonitor.glDeletePerfMonitorsAMD(n, monitors)

public inline fun glSelectPerfMonitorCountersAMD(
    monitor: Int,
    enable: Boolean,
    group: Int,
    numCounters: Int,
    counterList: Ptr,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glSelectPerfMonitorCountersAMD(monitor, enable,
        group, numCounters, counterList)

public inline fun glSelectPerfMonitorCountersAMD(
    monitor: Int,
    enable: Boolean,
    group: Int,
    numCounters: Int,
    counterList: Long,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glSelectPerfMonitorCountersAMD(monitor, enable,
        group, numCounters, counterList)

public inline fun glBeginPerfMonitorAMD(monitor: Int): Unit =
        GLWrapper.instance.AMDPerformanceMonitor.glBeginPerfMonitorAMD(monitor)

public inline fun glEndPerfMonitorAMD(monitor: Int): Unit =
        GLWrapper.instance.AMDPerformanceMonitor.glEndPerfMonitorAMD(monitor)

public inline fun glGetPerfMonitorCounterDataAMD(
    monitor: Int,
    pname: Int,
    dataSize: Int,
    `data`: Ptr,
    bytesWritten: Ptr,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorCounterDataAMD(monitor, pname,
        dataSize, `data`, bytesWritten)

public inline fun glGetPerfMonitorCounterDataAMD(
    monitor: Int,
    pname: Int,
    dataSize: Int,
    `data`: Long,
    bytesWritten: Long,
): Unit = GLWrapper.instance.AMDPerformanceMonitor.glGetPerfMonitorCounterDataAMD(monitor, pname,
        dataSize, `data`, bytesWritten)
