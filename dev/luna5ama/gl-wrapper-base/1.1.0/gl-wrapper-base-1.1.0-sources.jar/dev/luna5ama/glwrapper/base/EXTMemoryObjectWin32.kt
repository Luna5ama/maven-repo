@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTMemoryObjectWin32 : GLBase {
    @PtrParameter([3])
    public fun glImportMemoryWin32HandleEXT(
        memory: Int,
        size: Long,
        handleType: Int,
        handle: Ptr,
    )

    @Unsafe
    public fun glImportMemoryWin32HandleEXT(
        memory: Int,
        size: Long,
        handleType: Int,
        handle: Long,
    )

    @PtrParameter([3])
    public fun glImportMemoryWin32NameEXT(
        memory: Int,
        size: Long,
        handleType: Int,
        name: Ptr,
    )

    @Unsafe
    public fun glImportMemoryWin32NameEXT(
        memory: Int,
        size: Long,
        handleType: Int,
        name: Long,
    )
}

public const val GL_HANDLE_TYPE_OPAQUE_WIN32_EXT: Int = 38_279

public const val GL_HANDLE_TYPE_OPAQUE_WIN32_KMT_EXT: Int = 38_280

public const val GL_DEVICE_LUID_EXT: Int = 38_297

public const val GL_DEVICE_NODE_MASK_EXT: Int = 38_298

public const val GL_LUID_SIZE_EXT: Int = 8

public const val GL_HANDLE_TYPE_D3D12_TILEPOOL_EXT: Int = 38_281

public const val GL_HANDLE_TYPE_D3D12_RESOURCE_EXT: Int = 38_282

public const val GL_HANDLE_TYPE_D3D11_IMAGE_EXT: Int = 38_283

public const val GL_HANDLE_TYPE_D3D11_IMAGE_KMT_EXT: Int = 38_284

public inline fun glImportMemoryWin32HandleEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    handle: Ptr,
): Unit = GLWrapper.instance.EXTMemoryObjectWin32.glImportMemoryWin32HandleEXT(memory, size,
        handleType, handle)

public inline fun glImportMemoryWin32HandleEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    handle: Long,
): Unit = GLWrapper.instance.EXTMemoryObjectWin32.glImportMemoryWin32HandleEXT(memory, size,
        handleType, handle)

public inline fun glImportMemoryWin32NameEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    name: Ptr,
): Unit = GLWrapper.instance.EXTMemoryObjectWin32.glImportMemoryWin32NameEXT(memory, size,
        handleType, name)

public inline fun glImportMemoryWin32NameEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    name: Long,
): Unit = GLWrapper.instance.EXTMemoryObjectWin32.glImportMemoryWin32NameEXT(memory, size,
        handleType, name)
