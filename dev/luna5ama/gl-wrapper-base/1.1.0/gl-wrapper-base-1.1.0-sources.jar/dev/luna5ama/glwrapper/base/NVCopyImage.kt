@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVCopyImage : GLBase {
    public fun glCopyImageSubDataNV(
        srcName: Int,
        srcTarget: Int,
        srcLevel: Int,
        srcX: Int,
        srcY: Int,
        srcZ: Int,
        dstName: Int,
        dstTarget: Int,
        dstLevel: Int,
        dstX: Int,
        dstY: Int,
        dstZ: Int,
        width: Int,
        height: Int,
        depth: Int,
    )
}

public inline fun glCopyImageSubDataNV(
    srcName: Int,
    srcTarget: Int,
    srcLevel: Int,
    srcX: Int,
    srcY: Int,
    srcZ: Int,
    dstName: Int,
    dstTarget: Int,
    dstLevel: Int,
    dstX: Int,
    dstY: Int,
    dstZ: Int,
    width: Int,
    height: Int,
    depth: Int,
): Unit = GLWrapper.instance.NVCopyImage.glCopyImageSubDataNV(srcName, srcTarget, srcLevel, srcX,
        srcY, srcZ, dstName, dstTarget, dstLevel, dstX, dstY, dstZ, width, height, depth)
