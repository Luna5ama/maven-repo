@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVFillRectangle : GLBase

public const val GL_FILL_RECTANGLE_NV: Int = 37_692
