@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVQueryResourceTag : GLBase {
    @PtrParameter([1])
    public fun glGenQueryResourceTagNV(n: Int, tagIds: Ptr)

    @Unsafe
    public fun glGenQueryResourceTagNV(n: Int, tagIds: Long)

    @PtrParameter([1])
    public fun glDeleteQueryResourceTagNV(n: Int, tagIds: Ptr)

    @Unsafe
    public fun glDeleteQueryResourceTagNV(n: Int, tagIds: Long)

    @PtrParameter([1])
    public fun glQueryResourceTagNV(tagId: Int, tagString: Ptr)

    @Unsafe
    public fun glQueryResourceTagNV(tagId: Int, tagString: Long)
}

public inline fun glGenQueryResourceTagNV(n: Int, tagIds: Ptr): Unit =
        GLWrapper.instance.NVQueryResourceTag.glGenQueryResourceTagNV(n, tagIds)

public inline fun glGenQueryResourceTagNV(n: Int, tagIds: Long): Unit =
        GLWrapper.instance.NVQueryResourceTag.glGenQueryResourceTagNV(n, tagIds)

public inline fun glDeleteQueryResourceTagNV(n: Int, tagIds: Ptr): Unit =
        GLWrapper.instance.NVQueryResourceTag.glDeleteQueryResourceTagNV(n, tagIds)

public inline fun glDeleteQueryResourceTagNV(n: Int, tagIds: Long): Unit =
        GLWrapper.instance.NVQueryResourceTag.glDeleteQueryResourceTagNV(n, tagIds)

public inline fun glQueryResourceTagNV(tagId: Int, tagString: Ptr): Unit =
        GLWrapper.instance.NVQueryResourceTag.glQueryResourceTagNV(tagId, tagString)

public inline fun glQueryResourceTagNV(tagId: Int, tagString: Long): Unit =
        GLWrapper.instance.NVQueryResourceTag.glQueryResourceTagNV(tagId, tagString)
