@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVTextureShader : GLBase

public const val GL_TEXTURE_SHADER_NV: Int = 34_526

public const val GL_RGBA_UNSIGNED_DOT_PRODUCT_MAPPING_NV: Int = 34_521

public const val GL_SHADER_OPERATION_NV: Int = 34_527

public const val GL_OFFSET_TEXTURE_SCALE_NV: Int = 34_530

public const val GL_OFFSET_TEXTURE_BIAS_NV: Int = 34_531

public const val GL_PREVIOUS_TEXTURE_INPUT_NV: Int = 34_532

public const val GL_CULL_MODES_NV: Int = 34_528

public const val GL_OFFSET_TEXTURE_MATRIX_NV: Int = 34_529

public const val GL_CONST_EYE_NV: Int = 34_533

public const val GL_SHADER_CONSISTENT_NV: Int = 34_525

public const val GL_PASS_THROUGH_NV: Int = 34_534

public const val GL_CULL_FRAGMENT_NV: Int = 34_535

public const val GL_OFFSET_TEXTURE_2D_NV: Int = 34_536

public const val GL_OFFSET_TEXTURE_RECTANGLE_NV: Int = 34_380

public const val GL_OFFSET_TEXTURE_RECTANGLE_SCALE_NV: Int = 34_381

public const val GL_DEPENDENT_AR_TEXTURE_2D_NV: Int = 34_537

public const val GL_DEPENDENT_GB_TEXTURE_2D_NV: Int = 34_538

public const val GL_DOT_PRODUCT_NV: Int = 34_540

public const val GL_DOT_PRODUCT_DEPTH_REPLACE_NV: Int = 34_541

public const val GL_DOT_PRODUCT_TEXTURE_2D_NV: Int = 34_542

public const val GL_DOT_PRODUCT_TEXTURE_RECTANGLE_NV: Int = 34_382

public const val GL_DOT_PRODUCT_TEXTURE_CUBE_MAP_NV: Int = 34_544

public const val GL_DOT_PRODUCT_DIFFUSE_CUBE_MAP_NV: Int = 34_545

public const val GL_DOT_PRODUCT_REFLECT_CUBE_MAP_NV: Int = 34_546

public const val GL_DOT_PRODUCT_CONST_EYE_REFLECT_CUBE_MAP_NV: Int = 34_547

public const val GL_HILO_NV: Int = 34_548

public const val GL_DSDT_NV: Int = 34_549

public const val GL_DSDT_MAG_NV: Int = 34_550

public const val GL_DSDT_MAG_VIB_NV: Int = 34_551

public const val GL_UNSIGNED_INT_S8_S8_8_8_NV: Int = 34_522

public const val GL_UNSIGNED_INT_8_8_S8_S8_REV_NV: Int = 34_523

public const val GL_SIGNED_RGBA_NV: Int = 34_555

public const val GL_SIGNED_RGBA8_NV: Int = 34_556

public const val GL_SIGNED_RGB_NV: Int = 34_558

public const val GL_SIGNED_RGB8_NV: Int = 34_559

public const val GL_SIGNED_LUMINANCE_NV: Int = 34_561

public const val GL_SIGNED_LUMINANCE8_NV: Int = 34_562

public const val GL_SIGNED_LUMINANCE_ALPHA_NV: Int = 34_563

public const val GL_SIGNED_LUMINANCE8_ALPHA8_NV: Int = 34_564

public const val GL_SIGNED_ALPHA_NV: Int = 34_565

public const val GL_SIGNED_ALPHA8_NV: Int = 34_566

public const val GL_SIGNED_INTENSITY_NV: Int = 34_567

public const val GL_SIGNED_INTENSITY8_NV: Int = 34_568

public const val GL_SIGNED_RGB_UNSIGNED_ALPHA_NV: Int = 34_572

public const val GL_SIGNED_RGB8_UNSIGNED_ALPHA8_NV: Int = 34_573

public const val GL_HILO16_NV: Int = 34_552

public const val GL_SIGNED_HILO_NV: Int = 34_553

public const val GL_SIGNED_HILO16_NV: Int = 34_554

public const val GL_DSDT8_NV: Int = 34_569

public const val GL_DSDT8_MAG8_NV: Int = 34_570

public const val GL_DSDT_MAG_INTENSITY_NV: Int = 34_524

public const val GL_DSDT8_MAG8_INTENSITY8_NV: Int = 34_571

public const val GL_HI_SCALE_NV: Int = 34_574

public const val GL_LO_SCALE_NV: Int = 34_575

public const val GL_DS_SCALE_NV: Int = 34_576

public const val GL_DT_SCALE_NV: Int = 34_577

public const val GL_MAGNITUDE_SCALE_NV: Int = 34_578

public const val GL_VIBRANCE_SCALE_NV: Int = 34_579

public const val GL_HI_BIAS_NV: Int = 34_580

public const val GL_LO_BIAS_NV: Int = 34_581

public const val GL_DS_BIAS_NV: Int = 34_582

public const val GL_DT_BIAS_NV: Int = 34_583

public const val GL_MAGNITUDE_BIAS_NV: Int = 34_584

public const val GL_VIBRANCE_BIAS_NV: Int = 34_585

public const val GL_TEXTURE_BORDER_VALUES_NV: Int = 34_586

public const val GL_TEXTURE_HI_SIZE_NV: Int = 34_587

public const val GL_TEXTURE_LO_SIZE_NV: Int = 34_588

public const val GL_TEXTURE_DS_SIZE_NV: Int = 34_589

public const val GL_TEXTURE_DT_SIZE_NV: Int = 34_590

public const val GL_TEXTURE_MAG_SIZE_NV: Int = 34_591
