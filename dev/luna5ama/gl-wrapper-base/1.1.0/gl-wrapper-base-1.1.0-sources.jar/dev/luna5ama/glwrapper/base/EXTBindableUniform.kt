@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTBindableUniform : GLBase {
    public fun glUniformBufferEXT(
        program: Int,
        location: Int,
        buffer: Int,
    )

    public fun glGetUniformBufferSizeEXT(program: Int, location: Int): Int

    public fun glGetUniformOffsetEXT(program: Int, location: Int): Long
}

public const val GL_MAX_VERTEX_BINDABLE_UNIFORMS_EXT: Int = 36_322

public const val GL_MAX_FRAGMENT_BINDABLE_UNIFORMS_EXT: Int = 36_323

public const val GL_MAX_GEOMETRY_BINDABLE_UNIFORMS_EXT: Int = 36_324

public const val GL_MAX_BINDABLE_UNIFORM_SIZE_EXT: Int = 36_333

public const val GL_UNIFORM_BUFFER_BINDING_EXT: Int = 36_335

public const val GL_UNIFORM_BUFFER_EXT: Int = 36_334

public inline fun glUniformBufferEXT(
    program: Int,
    location: Int,
    buffer: Int,
): Unit = GLWrapper.instance.EXTBindableUniform.glUniformBufferEXT(program, location, buffer)

public inline fun glGetUniformBufferSizeEXT(program: Int, location: Int): Int =
        GLWrapper.instance.EXTBindableUniform.glGetUniformBufferSizeEXT(program, location)

public inline fun glGetUniformOffsetEXT(program: Int, location: Int): Long =
        GLWrapper.instance.EXTBindableUniform.glGetUniformOffsetEXT(program, location)
