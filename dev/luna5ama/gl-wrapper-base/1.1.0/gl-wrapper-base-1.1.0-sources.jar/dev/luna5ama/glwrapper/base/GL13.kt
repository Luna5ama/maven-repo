@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL13 : GLBase {
    @PtrParameter([8])
    public fun glCompressedTexImage3D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTexImage3D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([7])
    public fun glCompressedTexImage2D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTexImage2D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([6])
    public fun glCompressedTexImage1D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTexImage1D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([10])
    public fun glCompressedTexSubImage3D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTexSubImage3D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([8])
    public fun glCompressedTexSubImage2D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTexSubImage2D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([6])
    public fun glCompressedTexSubImage1D(
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTexSubImage1D(
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([2])
    public fun glGetCompressedTexImage(
        target: Int,
        level: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glGetCompressedTexImage(
        target: Int,
        level: Int,
        pixels: Long,
    )

    public fun glSampleCoverage(`value`: Float, invert: Boolean)

    public fun glActiveTexture(texture: Int)
}

public const val GL_COMPRESSED_RGB: Int = 34_029

public const val GL_COMPRESSED_RGBA: Int = 34_030

public const val GL_TEXTURE_COMPRESSION_HINT: Int = 34_031

public const val GL_TEXTURE_COMPRESSED_IMAGE_SIZE: Int = 34_464

public const val GL_TEXTURE_COMPRESSED: Int = 34_465

public const val GL_NUM_COMPRESSED_TEXTURE_FORMATS: Int = 34_466

public const val GL_COMPRESSED_TEXTURE_FORMATS: Int = 34_467

public const val GL_TEXTURE_CUBE_MAP: Int = 34_067

public const val GL_TEXTURE_BINDING_CUBE_MAP: Int = 34_068

public const val GL_TEXTURE_CUBE_MAP_POSITIVE_X: Int = 34_069

public const val GL_TEXTURE_CUBE_MAP_NEGATIVE_X: Int = 34_070

public const val GL_TEXTURE_CUBE_MAP_POSITIVE_Y: Int = 34_071

public const val GL_TEXTURE_CUBE_MAP_NEGATIVE_Y: Int = 34_072

public const val GL_TEXTURE_CUBE_MAP_POSITIVE_Z: Int = 34_073

public const val GL_TEXTURE_CUBE_MAP_NEGATIVE_Z: Int = 34_074

public const val GL_PROXY_TEXTURE_CUBE_MAP: Int = 34_075

public const val GL_MAX_CUBE_MAP_TEXTURE_SIZE: Int = 34_076

public const val GL_MULTISAMPLE: Int = 32_925

public const val GL_SAMPLE_ALPHA_TO_COVERAGE: Int = 32_926

public const val GL_SAMPLE_ALPHA_TO_ONE: Int = 32_927

public const val GL_SAMPLE_COVERAGE: Int = 32_928

public const val GL_SAMPLE_BUFFERS: Int = 32_936

public const val GL_SAMPLES: Int = 32_937

public const val GL_SAMPLE_COVERAGE_VALUE: Int = 32_938

public const val GL_SAMPLE_COVERAGE_INVERT: Int = 32_939

public const val GL_TEXTURE0: Int = 33_984

public const val GL_TEXTURE1: Int = 33_985

public const val GL_TEXTURE2: Int = 33_986

public const val GL_TEXTURE3: Int = 33_987

public const val GL_TEXTURE4: Int = 33_988

public const val GL_TEXTURE5: Int = 33_989

public const val GL_TEXTURE6: Int = 33_990

public const val GL_TEXTURE7: Int = 33_991

public const val GL_TEXTURE8: Int = 33_992

public const val GL_TEXTURE9: Int = 33_993

public const val GL_TEXTURE10: Int = 33_994

public const val GL_TEXTURE11: Int = 33_995

public const val GL_TEXTURE12: Int = 33_996

public const val GL_TEXTURE13: Int = 33_997

public const val GL_TEXTURE14: Int = 33_998

public const val GL_TEXTURE15: Int = 33_999

public const val GL_TEXTURE16: Int = 34_000

public const val GL_TEXTURE17: Int = 34_001

public const val GL_TEXTURE18: Int = 34_002

public const val GL_TEXTURE19: Int = 34_003

public const val GL_TEXTURE20: Int = 34_004

public const val GL_TEXTURE21: Int = 34_005

public const val GL_TEXTURE22: Int = 34_006

public const val GL_TEXTURE23: Int = 34_007

public const val GL_TEXTURE24: Int = 34_008

public const val GL_TEXTURE25: Int = 34_009

public const val GL_TEXTURE26: Int = 34_010

public const val GL_TEXTURE27: Int = 34_011

public const val GL_TEXTURE28: Int = 34_012

public const val GL_TEXTURE29: Int = 34_013

public const val GL_TEXTURE30: Int = 34_014

public const val GL_TEXTURE31: Int = 34_015

public const val GL_ACTIVE_TEXTURE: Int = 34_016

public const val GL_CLAMP_TO_BORDER: Int = 33_069

public inline fun glCompressedTexImage3D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL13.glCompressedTexImage3D(target, level, internalformat, width,
        height, depth, border, imageSize, `data`)

public inline fun glCompressedTexImage3D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL13.glCompressedTexImage3D(target, level, internalformat, width,
        height, depth, border, imageSize, `data`)

public inline fun glCompressedTexImage2D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL13.glCompressedTexImage2D(target, level, internalformat, width,
        height, border, imageSize, `data`)

public inline fun glCompressedTexImage2D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL13.glCompressedTexImage2D(target, level, internalformat, width,
        height, border, imageSize, `data`)

public inline fun glCompressedTexImage1D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL13.glCompressedTexImage1D(target, level, internalformat, width,
        border, imageSize, `data`)

public inline fun glCompressedTexImage1D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL13.glCompressedTexImage1D(target, level, internalformat, width,
        border, imageSize, `data`)

public inline fun glCompressedTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL13.glCompressedTexSubImage3D(target, level, xoffset, yoffset,
        zoffset, width, height, depth, format, imageSize, `data`)

public inline fun glCompressedTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL13.glCompressedTexSubImage3D(target, level, xoffset, yoffset,
        zoffset, width, height, depth, format, imageSize, `data`)

public inline fun glCompressedTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL13.glCompressedTexSubImage2D(target, level, xoffset, yoffset, width,
        height, format, imageSize, `data`)

public inline fun glCompressedTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL13.glCompressedTexSubImage2D(target, level, xoffset, yoffset, width,
        height, format, imageSize, `data`)

public inline fun glCompressedTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL13.glCompressedTexSubImage1D(target, level, xoffset, width, format,
        imageSize, `data`)

public inline fun glCompressedTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL13.glCompressedTexSubImage1D(target, level, xoffset, width, format,
        imageSize, `data`)

public inline fun glGetCompressedTexImage(
    target: Int,
    level: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL13.glGetCompressedTexImage(target, level, pixels)

public inline fun glGetCompressedTexImage(
    target: Int,
    level: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL13.glGetCompressedTexImage(target, level, pixels)

public inline fun glSampleCoverage(`value`: Float, invert: Boolean): Unit =
        GLWrapper.instance.GL13.glSampleCoverage(`value`, invert)

public inline fun glActiveTexture(texture: Int): Unit =
        GLWrapper.instance.GL13.glActiveTexture(texture)
