@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTShaderImageLoadStore : GLBase {
    public fun glBindImageTextureEXT(
        index: Int,
        texture: Int,
        level: Int,
        layered: Boolean,
        layer: Int,
        access: Int,
        format: Int,
    )

    public fun glMemoryBarrierEXT(barriers: Int)
}

public const val GL_MAX_IMAGE_UNITS_EXT: Int = 36_664

public const val GL_MAX_COMBINED_IMAGE_UNITS_AND_FRAGMENT_OUTPUTS_EXT: Int = 36_665

public const val GL_MAX_IMAGE_SAMPLES_EXT: Int = 36_973

public const val GL_IMAGE_BINDING_NAME_EXT: Int = 36_666

public const val GL_IMAGE_BINDING_LEVEL_EXT: Int = 36_667

public const val GL_IMAGE_BINDING_LAYERED_EXT: Int = 36_668

public const val GL_IMAGE_BINDING_LAYER_EXT: Int = 36_669

public const val GL_IMAGE_BINDING_ACCESS_EXT: Int = 36_670

public const val GL_IMAGE_BINDING_FORMAT_EXT: Int = 36_974

public const val GL_VERTEX_ATTRIB_ARRAY_BARRIER_BIT_EXT: Int = 1

public const val GL_ELEMENT_ARRAY_BARRIER_BIT_EXT: Int = 2

public const val GL_UNIFORM_BARRIER_BIT_EXT: Int = 4

public const val GL_TEXTURE_FETCH_BARRIER_BIT_EXT: Int = 8

public const val GL_SHADER_IMAGE_ACCESS_BARRIER_BIT_EXT: Int = 32

public const val GL_COMMAND_BARRIER_BIT_EXT: Int = 64

public const val GL_PIXEL_BUFFER_BARRIER_BIT_EXT: Int = 128

public const val GL_TEXTURE_UPDATE_BARRIER_BIT_EXT: Int = 256

public const val GL_BUFFER_UPDATE_BARRIER_BIT_EXT: Int = 512

public const val GL_FRAMEBUFFER_BARRIER_BIT_EXT: Int = 1_024

public const val GL_TRANSFORM_FEEDBACK_BARRIER_BIT_EXT: Int = 2_048

public const val GL_ATOMIC_COUNTER_BARRIER_BIT_EXT: Int = 4_096

public const val GL_ALL_BARRIER_BITS_EXT: Int = 1

public const val GL_IMAGE_1D_EXT: Int = 36_940

public const val GL_IMAGE_2D_EXT: Int = 36_941

public const val GL_IMAGE_3D_EXT: Int = 36_942

public const val GL_IMAGE_2D_RECT_EXT: Int = 36_943

public const val GL_IMAGE_CUBE_EXT: Int = 36_944

public const val GL_IMAGE_BUFFER_EXT: Int = 36_945

public const val GL_IMAGE_1D_ARRAY_EXT: Int = 36_946

public const val GL_IMAGE_2D_ARRAY_EXT: Int = 36_947

public const val GL_IMAGE_CUBE_MAP_ARRAY_EXT: Int = 36_948

public const val GL_IMAGE_2D_MULTISAMPLE_EXT: Int = 36_949

public const val GL_IMAGE_2D_MULTISAMPLE_ARRAY_EXT: Int = 36_950

public const val GL_INT_IMAGE_1D_EXT: Int = 36_951

public const val GL_INT_IMAGE_2D_EXT: Int = 36_952

public const val GL_INT_IMAGE_3D_EXT: Int = 36_953

public const val GL_INT_IMAGE_2D_RECT_EXT: Int = 36_954

public const val GL_INT_IMAGE_CUBE_EXT: Int = 36_955

public const val GL_INT_IMAGE_BUFFER_EXT: Int = 36_956

public const val GL_INT_IMAGE_1D_ARRAY_EXT: Int = 36_957

public const val GL_INT_IMAGE_2D_ARRAY_EXT: Int = 36_958

public const val GL_INT_IMAGE_CUBE_MAP_ARRAY_EXT: Int = 36_959

public const val GL_INT_IMAGE_2D_MULTISAMPLE_EXT: Int = 36_960

public const val GL_INT_IMAGE_2D_MULTISAMPLE_ARRAY_EXT: Int = 36_961

public const val GL_UNSIGNED_INT_IMAGE_1D_EXT: Int = 36_962

public const val GL_UNSIGNED_INT_IMAGE_2D_EXT: Int = 36_963

public const val GL_UNSIGNED_INT_IMAGE_3D_EXT: Int = 36_964

public const val GL_UNSIGNED_INT_IMAGE_2D_RECT_EXT: Int = 36_965

public const val GL_UNSIGNED_INT_IMAGE_CUBE_EXT: Int = 36_966

public const val GL_UNSIGNED_INT_IMAGE_BUFFER_EXT: Int = 36_967

public const val GL_UNSIGNED_INT_IMAGE_1D_ARRAY_EXT: Int = 36_968

public const val GL_UNSIGNED_INT_IMAGE_2D_ARRAY_EXT: Int = 36_969

public const val GL_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY_EXT: Int = 36_970

public const val GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_EXT: Int = 36_971

public const val GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_ARRAY_EXT: Int = 36_972

public inline fun glBindImageTextureEXT(
    index: Int,
    texture: Int,
    level: Int,
    layered: Boolean,
    layer: Int,
    access: Int,
    format: Int,
): Unit = GLWrapper.instance.EXTShaderImageLoadStore.glBindImageTextureEXT(index, texture, level,
        layered, layer, access, format)

public inline fun glMemoryBarrierEXT(barriers: Int): Unit =
        GLWrapper.instance.EXTShaderImageLoadStore.glMemoryBarrierEXT(barriers)
