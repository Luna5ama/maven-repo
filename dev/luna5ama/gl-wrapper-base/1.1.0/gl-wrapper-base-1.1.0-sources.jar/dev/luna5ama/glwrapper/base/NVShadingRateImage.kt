@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVShadingRateImage : GLBase {
    public fun glBindShadingRateImageNV(texture: Int)

    @PtrParameter([3])
    public fun glShadingRateImagePaletteNV(
        viewport: Int,
        first: Int,
        count: Int,
        rates: Ptr,
    )

    @Unsafe
    public fun glShadingRateImagePaletteNV(
        viewport: Int,
        first: Int,
        count: Int,
        rates: Long,
    )

    @PtrParameter([2])
    public fun glGetShadingRateImagePaletteNV(
        viewport: Int,
        entry: Int,
        rate: Ptr,
    )

    @Unsafe
    public fun glGetShadingRateImagePaletteNV(
        viewport: Int,
        entry: Int,
        rate: Long,
    )

    public fun glShadingRateImageBarrierNV(synchronize: Boolean)

    public fun glShadingRateSampleOrderNV(order: Int)

    @PtrParameter([2])
    public fun glShadingRateSampleOrderCustomNV(
        rate: Int,
        samples: Int,
        locations: Ptr,
    )

    @Unsafe
    public fun glShadingRateSampleOrderCustomNV(
        rate: Int,
        samples: Int,
        locations: Long,
    )

    @PtrParameter([3])
    public fun glGetShadingRateSampleLocationivNV(
        rate: Int,
        samples: Int,
        index: Int,
        location: Ptr,
    )

    @Unsafe
    public fun glGetShadingRateSampleLocationivNV(
        rate: Int,
        samples: Int,
        index: Int,
        location: Long,
    )
}

public const val GL_SHADING_RATE_IMAGE_NV: Int = 38_243

public const val GL_SHADING_RATE_NO_INVOCATIONS_NV: Int = 38_244

public const val GL_SHADING_RATE_1_INVOCATION_PER_PIXEL_NV: Int = 38_245

public const val GL_SHADING_RATE_1_INVOCATION_PER_1X2_PIXELS_NV: Int = 38_246

public const val GL_SHADING_RATE_1_INVOCATION_PER_2X1_PIXELS_NV: Int = 38_247

public const val GL_SHADING_RATE_1_INVOCATION_PER_2X2_PIXELS_NV: Int = 38_248

public const val GL_SHADING_RATE_1_INVOCATION_PER_2X4_PIXELS_NV: Int = 38_249

public const val GL_SHADING_RATE_1_INVOCATION_PER_4X2_PIXELS_NV: Int = 38_250

public const val GL_SHADING_RATE_1_INVOCATION_PER_4X4_PIXELS_NV: Int = 38_251

public const val GL_SHADING_RATE_2_INVOCATIONS_PER_PIXEL_NV: Int = 38_252

public const val GL_SHADING_RATE_4_INVOCATIONS_PER_PIXEL_NV: Int = 38_253

public const val GL_SHADING_RATE_8_INVOCATIONS_PER_PIXEL_NV: Int = 38_254

public const val GL_SHADING_RATE_16_INVOCATIONS_PER_PIXEL_NV: Int = 38_255

public const val GL_SHADING_RATE_IMAGE_BINDING_NV: Int = 38_235

public const val GL_SHADING_RATE_IMAGE_TEXEL_WIDTH_NV: Int = 38_236

public const val GL_SHADING_RATE_IMAGE_TEXEL_HEIGHT_NV: Int = 38_237

public const val GL_SHADING_RATE_IMAGE_PALETTE_SIZE_NV: Int = 38_238

public const val GL_MAX_COARSE_FRAGMENT_SAMPLES_NV: Int = 38_239

public const val GL_SHADING_RATE_SAMPLE_ORDER_DEFAULT_NV: Int = 38_318

public const val GL_SHADING_RATE_SAMPLE_ORDER_PIXEL_MAJOR_NV: Int = 38_319

public const val GL_SHADING_RATE_SAMPLE_ORDER_SAMPLE_MAJOR_NV: Int = 38_320

public inline fun glBindShadingRateImageNV(texture: Int): Unit =
        GLWrapper.instance.NVShadingRateImage.glBindShadingRateImageNV(texture)

public inline fun glShadingRateImagePaletteNV(
    viewport: Int,
    first: Int,
    count: Int,
    rates: Ptr,
): Unit = GLWrapper.instance.NVShadingRateImage.glShadingRateImagePaletteNV(viewport, first, count,
        rates)

public inline fun glShadingRateImagePaletteNV(
    viewport: Int,
    first: Int,
    count: Int,
    rates: Long,
): Unit = GLWrapper.instance.NVShadingRateImage.glShadingRateImagePaletteNV(viewport, first, count,
        rates)

public inline fun glGetShadingRateImagePaletteNV(
    viewport: Int,
    entry: Int,
    rate: Ptr,
): Unit = GLWrapper.instance.NVShadingRateImage.glGetShadingRateImagePaletteNV(viewport, entry,
        rate)

public inline fun glGetShadingRateImagePaletteNV(
    viewport: Int,
    entry: Int,
    rate: Long,
): Unit = GLWrapper.instance.NVShadingRateImage.glGetShadingRateImagePaletteNV(viewport, entry,
        rate)

public inline fun glShadingRateImageBarrierNV(synchronize: Boolean): Unit =
        GLWrapper.instance.NVShadingRateImage.glShadingRateImageBarrierNV(synchronize)

public inline fun glShadingRateSampleOrderNV(order: Int): Unit =
        GLWrapper.instance.NVShadingRateImage.glShadingRateSampleOrderNV(order)

public inline fun glShadingRateSampleOrderCustomNV(
    rate: Int,
    samples: Int,
    locations: Ptr,
): Unit = GLWrapper.instance.NVShadingRateImage.glShadingRateSampleOrderCustomNV(rate, samples,
        locations)

public inline fun glShadingRateSampleOrderCustomNV(
    rate: Int,
    samples: Int,
    locations: Long,
): Unit = GLWrapper.instance.NVShadingRateImage.glShadingRateSampleOrderCustomNV(rate, samples,
        locations)

public inline fun glGetShadingRateSampleLocationivNV(
    rate: Int,
    samples: Int,
    index: Int,
    location: Ptr,
): Unit = GLWrapper.instance.NVShadingRateImage.glGetShadingRateSampleLocationivNV(rate, samples,
        index, location)

public inline fun glGetShadingRateSampleLocationivNV(
    rate: Int,
    samples: Int,
    index: Int,
    location: Long,
): Unit = GLWrapper.instance.NVShadingRateImage.glGetShadingRateSampleLocationivNV(rate, samples,
        index, location)
