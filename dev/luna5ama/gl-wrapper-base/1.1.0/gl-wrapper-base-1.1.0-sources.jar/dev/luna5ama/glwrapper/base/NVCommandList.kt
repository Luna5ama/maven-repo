@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Short
import kotlin.Suppress
import kotlin.Unit

public interface NVCommandList : GLBase {
    @PtrParameter([1])
    public fun glCreateStatesNV(n: Int, states: Ptr)

    @Unsafe
    public fun glCreateStatesNV(n: Int, states: Long)

    @PtrParameter([1])
    public fun glDeleteStatesNV(n: Int, states: Ptr)

    @Unsafe
    public fun glDeleteStatesNV(n: Int, states: Long)

    public fun glIsStateNV(state: Int): Boolean

    public fun glStateCaptureNV(state: Int, mode: Int)

    public fun glGetCommandHeaderNV(tokenID: Int, size: Int): Int

    public fun glGetStageIndexNV(shadertype: Int): Short

    @PtrParameter([2, 3])
    public fun glDrawCommandsNV(
        primitiveMode: Int,
        buffer: Int,
        indirects: Ptr,
        sizes: Ptr,
        count: Int,
    )

    @Unsafe
    public fun glDrawCommandsNV(
        primitiveMode: Int,
        buffer: Int,
        indirects: Long,
        sizes: Long,
        count: Int,
    )

    @PtrParameter([1, 2])
    public fun glDrawCommandsAddressNV(
        primitiveMode: Int,
        indirects: Ptr,
        sizes: Ptr,
        count: Int,
    )

    @Unsafe
    public fun glDrawCommandsAddressNV(
        primitiveMode: Int,
        indirects: Long,
        sizes: Long,
        count: Int,
    )

    @PtrParameter([1, 2, 3, 4])
    public fun glDrawCommandsStatesNV(
        buffer: Int,
        indirects: Ptr,
        sizes: Ptr,
        states: Ptr,
        fbos: Ptr,
        count: Int,
    )

    @Unsafe
    public fun glDrawCommandsStatesNV(
        buffer: Int,
        indirects: Long,
        sizes: Long,
        states: Long,
        fbos: Long,
        count: Int,
    )

    @PtrParameter([0, 1, 2, 3])
    public fun glDrawCommandsStatesAddressNV(
        indirects: Ptr,
        sizes: Ptr,
        states: Ptr,
        fbos: Ptr,
        count: Int,
    )

    @Unsafe
    public fun glDrawCommandsStatesAddressNV(
        indirects: Long,
        sizes: Long,
        states: Long,
        fbos: Long,
        count: Int,
    )

    @PtrParameter([1])
    public fun glCreateCommandListsNV(n: Int, lists: Ptr)

    @Unsafe
    public fun glCreateCommandListsNV(n: Int, lists: Long)

    @PtrParameter([1])
    public fun glDeleteCommandListsNV(n: Int, lists: Ptr)

    @Unsafe
    public fun glDeleteCommandListsNV(n: Int, lists: Long)

    public fun glIsCommandListNV(list: Int): Boolean

    @PtrParameter([2, 3, 4, 5])
    public fun glListDrawCommandsStatesClientNV(
        list: Int,
        segment: Int,
        indirects: Ptr,
        sizes: Ptr,
        states: Ptr,
        fbos: Ptr,
        count: Int,
    )

    @Unsafe
    public fun glListDrawCommandsStatesClientNV(
        list: Int,
        segment: Int,
        indirects: Long,
        sizes: Long,
        states: Long,
        fbos: Long,
        count: Int,
    )

    public fun glCommandListSegmentsNV(list: Int, segments: Int)

    public fun glCompileCommandListNV(list: Int)

    public fun glCallCommandListNV(list: Int)
}

public const val GL_TERMINATE_SEQUENCE_COMMAND_NV: Int = 0

public const val GL_NOP_COMMAND_NV: Int = 1

public const val GL_DRAW_ELEMENTS_COMMAND_NV: Int = 2

public const val GL_DRAW_ARRAYS_COMMAND_NV: Int = 3

public const val GL_DRAW_ELEMENTS_STRIP_COMMAND_NV: Int = 4

public const val GL_DRAW_ARRAYS_STRIP_COMMAND_NV: Int = 5

public const val GL_DRAW_ELEMENTS_INSTANCED_COMMAND_NV: Int = 6

public const val GL_DRAW_ARRAYS_INSTANCED_COMMAND_NV: Int = 7

public const val GL_ELEMENT_ADDRESS_COMMAND_NV: Int = 8

public const val GL_ATTRIBUTE_ADDRESS_COMMAND_NV: Int = 9

public const val GL_UNIFORM_ADDRESS_COMMAND_NV: Int = 10

public const val GL_BLEND_COLOR_COMMAND_NV: Int = 11

public const val GL_STENCIL_REF_COMMAND_NV: Int = 12

public const val GL_LINE_WIDTH_COMMAND_NV: Int = 13

public const val GL_POLYGON_OFFSET_COMMAND_NV: Int = 14

public const val GL_ALPHA_REF_COMMAND_NV: Int = 15

public const val GL_VIEWPORT_COMMAND_NV: Int = 16

public const val GL_SCISSOR_COMMAND_NV: Int = 17

public const val GL_FRONT_FACE_COMMAND_NV: Int = 18

public inline fun glCreateStatesNV(n: Int, states: Ptr): Unit =
        GLWrapper.instance.NVCommandList.glCreateStatesNV(n, states)

public inline fun glCreateStatesNV(n: Int, states: Long): Unit =
        GLWrapper.instance.NVCommandList.glCreateStatesNV(n, states)

public inline fun glDeleteStatesNV(n: Int, states: Ptr): Unit =
        GLWrapper.instance.NVCommandList.glDeleteStatesNV(n, states)

public inline fun glDeleteStatesNV(n: Int, states: Long): Unit =
        GLWrapper.instance.NVCommandList.glDeleteStatesNV(n, states)

public inline fun glIsStateNV(state: Int): Boolean =
        GLWrapper.instance.NVCommandList.glIsStateNV(state)

public inline fun glStateCaptureNV(state: Int, mode: Int): Unit =
        GLWrapper.instance.NVCommandList.glStateCaptureNV(state, mode)

public inline fun glGetCommandHeaderNV(tokenID: Int, size: Int): Int =
        GLWrapper.instance.NVCommandList.glGetCommandHeaderNV(tokenID, size)

public inline fun glGetStageIndexNV(shadertype: Int): Short =
        GLWrapper.instance.NVCommandList.glGetStageIndexNV(shadertype)

public inline fun glDrawCommandsNV(
    primitiveMode: Int,
    buffer: Int,
    indirects: Ptr,
    sizes: Ptr,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glDrawCommandsNV(primitiveMode, buffer, indirects, sizes,
        count)

public inline fun glDrawCommandsNV(
    primitiveMode: Int,
    buffer: Int,
    indirects: Long,
    sizes: Long,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glDrawCommandsNV(primitiveMode, buffer, indirects, sizes,
        count)

public inline fun glDrawCommandsAddressNV(
    primitiveMode: Int,
    indirects: Ptr,
    sizes: Ptr,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glDrawCommandsAddressNV(primitiveMode, indirects, sizes,
        count)

public inline fun glDrawCommandsAddressNV(
    primitiveMode: Int,
    indirects: Long,
    sizes: Long,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glDrawCommandsAddressNV(primitiveMode, indirects, sizes,
        count)

public inline fun glDrawCommandsStatesNV(
    buffer: Int,
    indirects: Ptr,
    sizes: Ptr,
    states: Ptr,
    fbos: Ptr,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glDrawCommandsStatesNV(buffer, indirects, sizes, states,
        fbos, count)

public inline fun glDrawCommandsStatesNV(
    buffer: Int,
    indirects: Long,
    sizes: Long,
    states: Long,
    fbos: Long,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glDrawCommandsStatesNV(buffer, indirects, sizes, states,
        fbos, count)

public inline fun glDrawCommandsStatesAddressNV(
    indirects: Ptr,
    sizes: Ptr,
    states: Ptr,
    fbos: Ptr,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glDrawCommandsStatesAddressNV(indirects, sizes, states,
        fbos, count)

public inline fun glDrawCommandsStatesAddressNV(
    indirects: Long,
    sizes: Long,
    states: Long,
    fbos: Long,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glDrawCommandsStatesAddressNV(indirects, sizes, states,
        fbos, count)

public inline fun glCreateCommandListsNV(n: Int, lists: Ptr): Unit =
        GLWrapper.instance.NVCommandList.glCreateCommandListsNV(n, lists)

public inline fun glCreateCommandListsNV(n: Int, lists: Long): Unit =
        GLWrapper.instance.NVCommandList.glCreateCommandListsNV(n, lists)

public inline fun glDeleteCommandListsNV(n: Int, lists: Ptr): Unit =
        GLWrapper.instance.NVCommandList.glDeleteCommandListsNV(n, lists)

public inline fun glDeleteCommandListsNV(n: Int, lists: Long): Unit =
        GLWrapper.instance.NVCommandList.glDeleteCommandListsNV(n, lists)

public inline fun glIsCommandListNV(list: Int): Boolean =
        GLWrapper.instance.NVCommandList.glIsCommandListNV(list)

public inline fun glListDrawCommandsStatesClientNV(
    list: Int,
    segment: Int,
    indirects: Ptr,
    sizes: Ptr,
    states: Ptr,
    fbos: Ptr,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glListDrawCommandsStatesClientNV(list, segment,
        indirects, sizes, states, fbos, count)

public inline fun glListDrawCommandsStatesClientNV(
    list: Int,
    segment: Int,
    indirects: Long,
    sizes: Long,
    states: Long,
    fbos: Long,
    count: Int,
): Unit = GLWrapper.instance.NVCommandList.glListDrawCommandsStatesClientNV(list, segment,
        indirects, sizes, states, fbos, count)

public inline fun glCommandListSegmentsNV(list: Int, segments: Int): Unit =
        GLWrapper.instance.NVCommandList.glCommandListSegmentsNV(list, segments)

public inline fun glCompileCommandListNV(list: Int): Unit =
        GLWrapper.instance.NVCommandList.glCompileCommandListNV(list)

public inline fun glCallCommandListNV(list: Int): Unit =
        GLWrapper.instance.NVCommandList.glCallCommandListNV(list)
