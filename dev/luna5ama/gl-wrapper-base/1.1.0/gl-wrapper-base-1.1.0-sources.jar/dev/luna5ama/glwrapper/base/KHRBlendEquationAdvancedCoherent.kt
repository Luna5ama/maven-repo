@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface KHRBlendEquationAdvancedCoherent : GLBase

public const val GL_BLEND_ADVANCED_COHERENT_KHR: Int = 37_509
