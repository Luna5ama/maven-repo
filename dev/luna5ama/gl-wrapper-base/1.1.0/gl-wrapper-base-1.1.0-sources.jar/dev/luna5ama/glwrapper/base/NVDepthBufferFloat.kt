@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Double
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVDepthBufferFloat : GLBase {
    public fun glDepthRangedNV(zNear: Double, zFar: Double)

    public fun glClearDepthdNV(depth: Double)

    public fun glDepthBoundsdNV(zmin: Double, zmax: Double)
}

public const val GL_DEPTH_COMPONENT32F_NV: Int = 36_267

public const val GL_DEPTH32F_STENCIL8_NV: Int = 36_268

public const val GL_FLOAT_32_UNSIGNED_INT_24_8_REV_NV: Int = 36_269

public const val GL_DEPTH_BUFFER_FLOAT_MODE_NV: Int = 36_271

public inline fun glDepthRangedNV(zNear: Double, zFar: Double): Unit =
        GLWrapper.instance.NVDepthBufferFloat.glDepthRangedNV(zNear, zFar)

public inline fun glClearDepthdNV(depth: Double): Unit =
        GLWrapper.instance.NVDepthBufferFloat.glClearDepthdNV(depth)

public inline fun glDepthBoundsdNV(zmin: Double, zmax: Double): Unit =
        GLWrapper.instance.NVDepthBufferFloat.glDepthBoundsdNV(zmin, zmax)
