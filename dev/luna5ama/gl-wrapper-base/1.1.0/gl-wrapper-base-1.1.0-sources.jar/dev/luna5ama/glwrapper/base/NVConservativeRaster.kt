@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVConservativeRaster : GLBase {
    public fun glSubpixelPrecisionBiasNV(xbits: Int, ybits: Int)
}

public const val GL_CONSERVATIVE_RASTERIZATION_NV: Int = 37_702

public const val GL_SUBPIXEL_PRECISION_BIAS_X_BITS_NV: Int = 37_703

public const val GL_SUBPIXEL_PRECISION_BIAS_Y_BITS_NV: Int = 37_704

public const val GL_MAX_SUBPIXEL_PRECISION_BIAS_BITS_NV: Int = 37_705

public inline fun glSubpixelPrecisionBiasNV(xbits: Int, ybits: Int): Unit =
        GLWrapper.instance.NVConservativeRaster.glSubpixelPrecisionBiasNV(xbits, ybits)
