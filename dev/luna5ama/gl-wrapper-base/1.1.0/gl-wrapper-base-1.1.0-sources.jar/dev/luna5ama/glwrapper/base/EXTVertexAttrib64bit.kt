@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Double
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTVertexAttrib64bit : GLBase {
    public fun glVertexAttribL1dEXT(index: Int, x: Double)

    public fun glVertexAttribL2dEXT(
        index: Int,
        x: Double,
        y: Double,
    )

    public fun glVertexAttribL3dEXT(
        index: Int,
        x: Double,
        y: Double,
        z: Double,
    )

    public fun glVertexAttribL4dEXT(
        index: Int,
        x: Double,
        y: Double,
        z: Double,
        w: Double,
    )

    @PtrParameter([1])
    public fun glVertexAttribL1dvEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL1dvEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL2dvEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL2dvEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL3dvEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL3dvEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL4dvEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL4dvEXT(index: Int, v: Long)

    @PtrParameter([4])
    public fun glVertexAttribLPointerEXT(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glVertexAttribLPointerEXT(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribLdvEXT(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribLdvEXT(
        index: Int,
        pname: Int,
        params: Long,
    )
}

public const val GL_DOUBLE_VEC2_EXT: Int = 36_860

public const val GL_DOUBLE_VEC3_EXT: Int = 36_861

public const val GL_DOUBLE_VEC4_EXT: Int = 36_862

public const val GL_DOUBLE_MAT2_EXT: Int = 36_678

public const val GL_DOUBLE_MAT3_EXT: Int = 36_679

public const val GL_DOUBLE_MAT4_EXT: Int = 36_680

public const val GL_DOUBLE_MAT2x3_EXT: Int = 36_681

public const val GL_DOUBLE_MAT2x4_EXT: Int = 36_682

public const val GL_DOUBLE_MAT3x2_EXT: Int = 36_683

public const val GL_DOUBLE_MAT3x4_EXT: Int = 36_684

public const val GL_DOUBLE_MAT4x2_EXT: Int = 36_685

public const val GL_DOUBLE_MAT4x3_EXT: Int = 36_686

public inline fun glVertexAttribL1dEXT(index: Int, x: Double): Unit =
        GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL1dEXT(index, x)

public inline fun glVertexAttribL2dEXT(
    index: Int,
    x: Double,
    y: Double,
): Unit = GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL2dEXT(index, x, y)

public inline fun glVertexAttribL3dEXT(
    index: Int,
    x: Double,
    y: Double,
    z: Double,
): Unit = GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL3dEXT(index, x, y, z)

public inline fun glVertexAttribL4dEXT(
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
): Unit = GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL4dEXT(index, x, y, z, w)

public inline fun glVertexAttribL1dvEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL1dvEXT(index, v)

public inline fun glVertexAttribL1dvEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL1dvEXT(index, v)

public inline fun glVertexAttribL2dvEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL2dvEXT(index, v)

public inline fun glVertexAttribL2dvEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL2dvEXT(index, v)

public inline fun glVertexAttribL3dvEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL3dvEXT(index, v)

public inline fun glVertexAttribL3dvEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL3dvEXT(index, v)

public inline fun glVertexAttribL4dvEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL4dvEXT(index, v)

public inline fun glVertexAttribL4dvEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribL4dvEXT(index, v)

public inline fun glVertexAttribLPointerEXT(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribLPointerEXT(index, size, type,
        stride, pointer)

public inline fun glVertexAttribLPointerEXT(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
): Unit = GLWrapper.instance.EXTVertexAttrib64bit.glVertexAttribLPointerEXT(index, size, type,
        stride, pointer)

public inline fun glGetVertexAttribLdvEXT(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTVertexAttrib64bit.glGetVertexAttribLdvEXT(index, pname, params)

public inline fun glGetVertexAttribLdvEXT(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTVertexAttrib64bit.glGetVertexAttribLdvEXT(index, pname, params)
