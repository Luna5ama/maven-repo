@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTExternalBuffer : GLBase {
    public fun glBufferStorageExternalEXT(
        target: Int,
        offset: Long,
        size: Long,
        clientBuffer: Long,
        flags: Int,
    )

    public fun glNamedBufferStorageExternalEXT(
        buffer: Int,
        offset: Long,
        size: Long,
        clientBuffer: Long,
        flags: Int,
    )
}

public inline fun glBufferStorageExternalEXT(
    target: Int,
    offset: Long,
    size: Long,
    clientBuffer: Long,
    flags: Int,
): Unit = GLWrapper.instance.EXTExternalBuffer.glBufferStorageExternalEXT(target, offset, size,
        clientBuffer, flags)

public inline fun glNamedBufferStorageExternalEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    clientBuffer: Long,
    flags: Int,
): Unit = GLWrapper.instance.EXTExternalBuffer.glNamedBufferStorageExternalEXT(buffer, offset, size,
        clientBuffer, flags)
