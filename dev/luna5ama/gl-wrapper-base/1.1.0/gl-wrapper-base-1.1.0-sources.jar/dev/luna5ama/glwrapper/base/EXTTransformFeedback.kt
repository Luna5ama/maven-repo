@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTTransformFeedback : GLBase {
    public fun glBindBufferRangeEXT(
        target: Int,
        index: Int,
        buffer: Int,
        offset: Long,
        size: Long,
    )

    public fun glBindBufferOffsetEXT(
        target: Int,
        index: Int,
        buffer: Int,
        offset: Long,
    )

    public fun glBindBufferBaseEXT(
        target: Int,
        index: Int,
        buffer: Int,
    )

    public fun glBeginTransformFeedbackEXT(primitiveMode: Int)

    public fun glEndTransformFeedbackEXT()

    @PtrParameter([2])
    public fun glTransformFeedbackVaryingsEXT(
        program: Int,
        count: Int,
        varyings: Ptr,
        bufferMode: Int,
    )

    @Unsafe
    public fun glTransformFeedbackVaryingsEXT(
        program: Int,
        count: Int,
        varyings: Long,
        bufferMode: Int,
    )

    @PtrParameter([3, 4, 5, 6])
    public fun glGetTransformFeedbackVaryingEXT(
        program: Int,
        index: Int,
        bufSize: Int,
        length: Ptr,
        size: Ptr,
        type: Ptr,
        name: Ptr,
    )

    @Unsafe
    public fun glGetTransformFeedbackVaryingEXT(
        program: Int,
        index: Int,
        bufSize: Int,
        length: Long,
        size: Long,
        type: Long,
        name: Long,
    )

    @PtrParameter([2])
    public fun glGetIntegerIndexedvEXT(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetIntegerIndexedvEXT(
        target: Int,
        index: Int,
        `data`: Long,
    )

    @PtrParameter([2])
    public fun glGetBooleanIndexedvEXT(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetBooleanIndexedvEXT(
        target: Int,
        index: Int,
        `data`: Long,
    )
}

public const val GL_TRANSFORM_FEEDBACK_BUFFER_EXT: Int = 35_982

public const val GL_TRANSFORM_FEEDBACK_BUFFER_START_EXT: Int = 35_972

public const val GL_TRANSFORM_FEEDBACK_BUFFER_SIZE_EXT: Int = 35_973

public const val GL_TRANSFORM_FEEDBACK_BUFFER_BINDING_EXT: Int = 35_983

public const val GL_INTERLEAVED_ATTRIBS_EXT: Int = 35_980

public const val GL_SEPARATE_ATTRIBS_EXT: Int = 35_981

public const val GL_PRIMITIVES_GENERATED_EXT: Int = 35_975

public const val GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN_EXT: Int = 35_976

public const val GL_RASTERIZER_DISCARD_EXT: Int = 35_977

public const val GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS_EXT: Int = 35_978

public const val GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS_EXT: Int = 35_979

public const val GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS_EXT: Int = 35_968

public const val GL_TRANSFORM_FEEDBACK_VARYINGS_EXT: Int = 35_971

public const val GL_TRANSFORM_FEEDBACK_BUFFER_MODE_EXT: Int = 35_967

public const val GL_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH_EXT: Int = 35_958

public inline fun glBindBufferRangeEXT(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
    size: Long,
): Unit = GLWrapper.instance.EXTTransformFeedback.glBindBufferRangeEXT(target, index, buffer,
        offset, size)

public inline fun glBindBufferOffsetEXT(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTTransformFeedback.glBindBufferOffsetEXT(target, index, buffer,
        offset)

public inline fun glBindBufferBaseEXT(
    target: Int,
    index: Int,
    buffer: Int,
): Unit = GLWrapper.instance.EXTTransformFeedback.glBindBufferBaseEXT(target, index, buffer)

public inline fun glBeginTransformFeedbackEXT(primitiveMode: Int): Unit =
        GLWrapper.instance.EXTTransformFeedback.glBeginTransformFeedbackEXT(primitiveMode)

public inline fun glEndTransformFeedbackEXT(): Unit =
        GLWrapper.instance.EXTTransformFeedback.glEndTransformFeedbackEXT()

public inline fun glTransformFeedbackVaryingsEXT(
    program: Int,
    count: Int,
    varyings: Ptr,
    bufferMode: Int,
): Unit = GLWrapper.instance.EXTTransformFeedback.glTransformFeedbackVaryingsEXT(program, count,
        varyings, bufferMode)

public inline fun glTransformFeedbackVaryingsEXT(
    program: Int,
    count: Int,
    varyings: Long,
    bufferMode: Int,
): Unit = GLWrapper.instance.EXTTransformFeedback.glTransformFeedbackVaryingsEXT(program, count,
        varyings, bufferMode)

public inline fun glGetTransformFeedbackVaryingEXT(
    program: Int,
    index: Int,
    bufSize: Int,
    length: Ptr,
    size: Ptr,
    type: Ptr,
    name: Ptr,
): Unit = GLWrapper.instance.EXTTransformFeedback.glGetTransformFeedbackVaryingEXT(program, index,
        bufSize, length, size, type, name)

public inline fun glGetTransformFeedbackVaryingEXT(
    program: Int,
    index: Int,
    bufSize: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
): Unit = GLWrapper.instance.EXTTransformFeedback.glGetTransformFeedbackVaryingEXT(program, index,
        bufSize, length, size, type, name)
