@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVDrawTexture : GLBase {
    public fun glDrawTextureNV(
        texture: Int,
        sampler: Int,
        x0: Float,
        y0: Float,
        x1: Float,
        y1: Float,
        z: Float,
        s0: Float,
        t0: Float,
        s1: Float,
        t1: Float,
    )
}

public inline fun glDrawTextureNV(
    texture: Int,
    sampler: Int,
    x0: Float,
    y0: Float,
    x1: Float,
    y1: Float,
    z: Float,
    s0: Float,
    t0: Float,
    s1: Float,
    t1: Float,
): Unit = GLWrapper.instance.NVDrawTexture.glDrawTextureNV(texture, sampler, x0, y0, x1, y1, z, s0,
        t0, s1, t1)
