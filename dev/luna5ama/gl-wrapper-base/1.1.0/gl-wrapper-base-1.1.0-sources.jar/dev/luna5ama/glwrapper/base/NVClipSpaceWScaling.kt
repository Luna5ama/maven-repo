@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVClipSpaceWScaling : GLBase {
    public fun glViewportPositionWScaleNV(
        index: Int,
        xcoeff: Float,
        ycoeff: Float,
    )
}

public const val GL_VIEWPORT_POSITION_W_SCALE_NV: Int = 37_756

public const val GL_VIEWPORT_POSITION_W_SCALE_X_COEFF: Int = 37_757

public const val GL_VIEWPORT_POSITION_W_SCALE_Y_COEFF: Int = 37_758

public inline fun glViewportPositionWScaleNV(
    index: Int,
    xcoeff: Float,
    ycoeff: Float,
): Unit = GLWrapper.instance.NVClipSpaceWScaling.glViewportPositionWScaleNV(index, xcoeff, ycoeff)
