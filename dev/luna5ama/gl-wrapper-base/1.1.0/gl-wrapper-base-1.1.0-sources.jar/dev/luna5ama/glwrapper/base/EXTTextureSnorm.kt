@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureSnorm : GLBase

public const val GL_RED_SNORM: Int = 36_752

public const val GL_RG_SNORM: Int = 36_753

public const val GL_RGB_SNORM: Int = 36_754

public const val GL_RGBA_SNORM: Int = 36_755

public const val GL_ALPHA_SNORM: Int = 36_880

public const val GL_LUMINANCE_SNORM: Int = 36_881

public const val GL_LUMINANCE_ALPHA_SNORM: Int = 36_882

public const val GL_INTENSITY_SNORM: Int = 36_883

public const val GL_ALPHA8_SNORM: Int = 36_884

public const val GL_LUMINANCE8_SNORM: Int = 36_885

public const val GL_LUMINANCE8_ALPHA8_SNORM: Int = 36_886

public const val GL_INTENSITY8_SNORM: Int = 36_887

public const val GL_ALPHA16_SNORM: Int = 36_888

public const val GL_LUMINANCE16_SNORM: Int = 36_889

public const val GL_LUMINANCE16_ALPHA16_SNORM: Int = 36_890

public const val GL_INTENSITY16_SNORM: Int = 36_891
