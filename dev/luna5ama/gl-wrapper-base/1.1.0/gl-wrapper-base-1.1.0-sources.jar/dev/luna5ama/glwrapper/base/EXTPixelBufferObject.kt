@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTPixelBufferObject : GLBase

public const val GL_PIXEL_PACK_BUFFER_EXT: Int = 35_051

public const val GL_PIXEL_UNPACK_BUFFER_EXT: Int = 35_052

public const val GL_PIXEL_PACK_BUFFER_BINDING_EXT: Int = 35_053

public const val GL_PIXEL_UNPACK_BUFFER_BINDING_EXT: Int = 35_055
