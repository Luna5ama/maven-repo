@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBShadingLanguageInclude : GLBase {
    @PtrParameter([2, 4])
    public fun glNamedStringARB(
        type: Int,
        namelen: Int,
        name: Ptr,
        stringlen: Int,
        string: Ptr,
    )

    @Unsafe
    public fun glNamedStringARB(
        type: Int,
        namelen: Int,
        name: Long,
        stringlen: Int,
        string: Long,
    )

    @PtrParameter([1])
    public fun glDeleteNamedStringARB(namelen: Int, name: Ptr)

    @Unsafe
    public fun glDeleteNamedStringARB(namelen: Int, name: Long)

    @PtrParameter([2, 3])
    public fun glCompileShaderIncludeARB(
        shader: Int,
        count: Int,
        path: Ptr,
        length: Ptr,
    )

    @Unsafe
    public fun glCompileShaderIncludeARB(
        shader: Int,
        count: Int,
        path: Long,
        length: Long,
    )

    @PtrParameter([1])
    public fun glIsNamedStringARB(namelen: Int, name: Ptr): Boolean

    @Unsafe
    public fun glIsNamedStringARB(namelen: Int, name: Long): Boolean

    @PtrParameter([1, 3, 4])
    public fun glGetNamedStringARB(
        namelen: Int,
        name: Ptr,
        bufSize: Int,
        stringlen: Ptr,
        string: Ptr,
    )

    @Unsafe
    public fun glGetNamedStringARB(
        namelen: Int,
        name: Long,
        bufSize: Int,
        stringlen: Long,
        string: Long,
    )

    @PtrParameter([1, 3])
    public fun glGetNamedStringivARB(
        namelen: Int,
        name: Ptr,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedStringivARB(
        namelen: Int,
        name: Long,
        pname: Int,
        params: Long,
    )
}

public const val GL_SHADER_INCLUDE_ARB: Int = 36_270

public const val GL_NAMED_STRING_LENGTH_ARB: Int = 36_329

public const val GL_NAMED_STRING_TYPE_ARB: Int = 36_330

public inline fun glNamedStringARB(
    type: Int,
    namelen: Int,
    name: Ptr,
    stringlen: Int,
    string: Ptr,
): Unit = GLWrapper.instance.ARBShadingLanguageInclude.glNamedStringARB(type, namelen, name,
        stringlen, string)

public inline fun glNamedStringARB(
    type: Int,
    namelen: Int,
    name: Long,
    stringlen: Int,
    string: Long,
): Unit = GLWrapper.instance.ARBShadingLanguageInclude.glNamedStringARB(type, namelen, name,
        stringlen, string)

public inline fun glDeleteNamedStringARB(namelen: Int, name: Ptr): Unit =
        GLWrapper.instance.ARBShadingLanguageInclude.glDeleteNamedStringARB(namelen, name)

public inline fun glDeleteNamedStringARB(namelen: Int, name: Long): Unit =
        GLWrapper.instance.ARBShadingLanguageInclude.glDeleteNamedStringARB(namelen, name)

public inline fun glCompileShaderIncludeARB(
    shader: Int,
    count: Int,
    path: Ptr,
    length: Ptr,
): Unit = GLWrapper.instance.ARBShadingLanguageInclude.glCompileShaderIncludeARB(shader, count,
        path, length)

public inline fun glCompileShaderIncludeARB(
    shader: Int,
    count: Int,
    path: Long,
    length: Long,
): Unit = GLWrapper.instance.ARBShadingLanguageInclude.glCompileShaderIncludeARB(shader, count,
        path, length)

public inline fun glIsNamedStringARB(namelen: Int, name: Ptr): Boolean =
        GLWrapper.instance.ARBShadingLanguageInclude.glIsNamedStringARB(namelen, name)

public inline fun glIsNamedStringARB(namelen: Int, name: Long): Boolean =
        GLWrapper.instance.ARBShadingLanguageInclude.glIsNamedStringARB(namelen, name)

public inline fun glGetNamedStringARB(
    namelen: Int,
    name: Ptr,
    bufSize: Int,
    stringlen: Ptr,
    string: Ptr,
): Unit = GLWrapper.instance.ARBShadingLanguageInclude.glGetNamedStringARB(namelen, name, bufSize,
        stringlen, string)

public inline fun glGetNamedStringARB(
    namelen: Int,
    name: Long,
    bufSize: Int,
    stringlen: Long,
    string: Long,
): Unit = GLWrapper.instance.ARBShadingLanguageInclude.glGetNamedStringARB(namelen, name, bufSize,
        stringlen, string)

public inline fun glGetNamedStringivARB(
    namelen: Int,
    name: Ptr,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBShadingLanguageInclude.glGetNamedStringivARB(namelen, name, pname,
        params)

public inline fun glGetNamedStringivARB(
    namelen: Int,
    name: Long,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBShadingLanguageInclude.glGetNamedStringivARB(namelen, name, pname,
        params)
