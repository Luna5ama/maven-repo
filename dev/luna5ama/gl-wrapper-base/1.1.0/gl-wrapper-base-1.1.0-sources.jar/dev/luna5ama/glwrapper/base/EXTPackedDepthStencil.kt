@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTPackedDepthStencil : GLBase

public const val GL_DEPTH_STENCIL_EXT: Int = 34_041

public const val GL_UNSIGNED_INT_24_8_EXT: Int = 34_042

public const val GL_DEPTH24_STENCIL8_EXT: Int = 35_056

public const val GL_TEXTURE_STENCIL_SIZE_EXT: Int = 35_057
