@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBBindlessTexture : GLBase {
    public fun glGetTextureHandleARB(texture: Int): Long

    public fun glGetTextureSamplerHandleARB(texture: Int, sampler: Int): Long

    public fun glMakeTextureHandleResidentARB(handle: Long)

    public fun glMakeTextureHandleNonResidentARB(handle: Long)

    public fun glGetImageHandleARB(
        texture: Int,
        level: Int,
        layered: Boolean,
        layer: Int,
        format: Int,
    ): Long

    public fun glMakeImageHandleResidentARB(handle: Long, access: Int)

    public fun glMakeImageHandleNonResidentARB(handle: Long)

    public fun glUniformHandleui64ARB(location: Int, `value`: Long)

    @PtrParameter([2])
    public fun glUniformHandleui64vARB(
        location: Int,
        count: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glUniformHandleui64vARB(
        location: Int,
        count: Int,
        values: Long,
    )

    public fun glProgramUniformHandleui64ARB(
        program: Int,
        location: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniformHandleui64vARB(
        program: Int,
        location: Int,
        count: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glProgramUniformHandleui64vARB(
        program: Int,
        location: Int,
        count: Int,
        values: Long,
    )

    public fun glIsTextureHandleResidentARB(handle: Long): Boolean

    public fun glIsImageHandleResidentARB(handle: Long): Boolean

    public fun glVertexAttribL1ui64ARB(index: Int, x: Long)

    @PtrParameter([1])
    public fun glVertexAttribL1ui64vARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL1ui64vARB(index: Int, v: Long)

    @PtrParameter([2])
    public fun glGetVertexAttribLui64vARB(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribLui64vARB(
        index: Int,
        pname: Int,
        params: Long,
    )
}

public const val GL_UNSIGNED_INT64_ARB: Int = 5_135

public inline fun glGetTextureHandleARB(texture: Int): Long =
        GLWrapper.instance.ARBBindlessTexture.glGetTextureHandleARB(texture)

public inline fun glGetTextureSamplerHandleARB(texture: Int, sampler: Int): Long =
        GLWrapper.instance.ARBBindlessTexture.glGetTextureSamplerHandleARB(texture, sampler)

public inline fun glMakeTextureHandleResidentARB(handle: Long): Unit =
        GLWrapper.instance.ARBBindlessTexture.glMakeTextureHandleResidentARB(handle)

public inline fun glMakeTextureHandleNonResidentARB(handle: Long): Unit =
        GLWrapper.instance.ARBBindlessTexture.glMakeTextureHandleNonResidentARB(handle)

public inline fun glGetImageHandleARB(
    texture: Int,
    level: Int,
    layered: Boolean,
    layer: Int,
    format: Int,
): Long = GLWrapper.instance.ARBBindlessTexture.glGetImageHandleARB(texture, level, layered, layer,
        format)

public inline fun glMakeImageHandleResidentARB(handle: Long, access: Int): Unit =
        GLWrapper.instance.ARBBindlessTexture.glMakeImageHandleResidentARB(handle, access)

public inline fun glMakeImageHandleNonResidentARB(handle: Long): Unit =
        GLWrapper.instance.ARBBindlessTexture.glMakeImageHandleNonResidentARB(handle)

public inline fun glUniformHandleui64ARB(location: Int, `value`: Long): Unit =
        GLWrapper.instance.ARBBindlessTexture.glUniformHandleui64ARB(location, `value`)

public inline fun glUniformHandleui64vARB(
    location: Int,
    count: Int,
    values: Ptr,
): Unit = GLWrapper.instance.ARBBindlessTexture.glUniformHandleui64vARB(location, count, values)

public inline fun glUniformHandleui64vARB(
    location: Int,
    count: Int,
    values: Long,
): Unit = GLWrapper.instance.ARBBindlessTexture.glUniformHandleui64vARB(location, count, values)

public inline fun glProgramUniformHandleui64ARB(
    program: Int,
    location: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBBindlessTexture.glProgramUniformHandleui64ARB(program, location,
        `value`)

public inline fun glProgramUniformHandleui64vARB(
    program: Int,
    location: Int,
    count: Int,
    values: Ptr,
): Unit = GLWrapper.instance.ARBBindlessTexture.glProgramUniformHandleui64vARB(program, location,
        count, values)

public inline fun glProgramUniformHandleui64vARB(
    program: Int,
    location: Int,
    count: Int,
    values: Long,
): Unit = GLWrapper.instance.ARBBindlessTexture.glProgramUniformHandleui64vARB(program, location,
        count, values)

public inline fun glIsTextureHandleResidentARB(handle: Long): Boolean =
        GLWrapper.instance.ARBBindlessTexture.glIsTextureHandleResidentARB(handle)

public inline fun glIsImageHandleResidentARB(handle: Long): Boolean =
        GLWrapper.instance.ARBBindlessTexture.glIsImageHandleResidentARB(handle)

public inline fun glVertexAttribL1ui64ARB(index: Int, x: Long): Unit =
        GLWrapper.instance.ARBBindlessTexture.glVertexAttribL1ui64ARB(index, x)

public inline fun glVertexAttribL1ui64vARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBBindlessTexture.glVertexAttribL1ui64vARB(index, v)

public inline fun glVertexAttribL1ui64vARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBBindlessTexture.glVertexAttribL1ui64vARB(index, v)

public inline fun glGetVertexAttribLui64vARB(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBBindlessTexture.glGetVertexAttribLui64vARB(index, pname, params)

public inline fun glGetVertexAttribLui64vARB(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBBindlessTexture.glGetVertexAttribLui64vARB(index, pname, params)
