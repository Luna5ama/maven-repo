@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTShaderFramebufferFetch : GLBase

public const val GL_FRAGMENT_SHADER_DISCARDS_SAMPLES_EXT: Int = 35_410
