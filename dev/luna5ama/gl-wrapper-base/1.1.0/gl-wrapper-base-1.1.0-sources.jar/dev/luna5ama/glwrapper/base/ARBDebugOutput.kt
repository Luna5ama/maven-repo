@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBDebugOutput : GLBase {
    @PtrParameter([4])
    public fun glDebugMessageControlARB(
        source: Int,
        type: Int,
        severity: Int,
        count: Int,
        ids: Ptr,
        enabled: Boolean,
    )

    @Unsafe
    public fun glDebugMessageControlARB(
        source: Int,
        type: Int,
        severity: Int,
        count: Int,
        ids: Long,
        enabled: Boolean,
    )

    @PtrParameter([5])
    public fun glDebugMessageInsertARB(
        source: Int,
        type: Int,
        id: Int,
        severity: Int,
        length: Int,
        buf: Ptr,
    )

    @Unsafe
    public fun glDebugMessageInsertARB(
        source: Int,
        type: Int,
        id: Int,
        severity: Int,
        length: Int,
        buf: Long,
    )

    @PtrParameter([1])
    public fun glDebugMessageCallbackARB(callback: Long, userParam: Ptr)

    @Unsafe
    public fun glDebugMessageCallbackARB(callback: Long, userParam: Long)

    @PtrParameter([2, 3, 4, 5, 6, 7])
    public fun glGetDebugMessageLogARB(
        count: Int,
        bufSize: Int,
        sources: Ptr,
        types: Ptr,
        ids: Ptr,
        severities: Ptr,
        lengths: Ptr,
        messageLog: Ptr,
    ): Int

    @Unsafe
    public fun glGetDebugMessageLogARB(
        count: Int,
        bufSize: Int,
        sources: Long,
        types: Long,
        ids: Long,
        severities: Long,
        lengths: Long,
        messageLog: Long,
    ): Int
}

public const val GL_DEBUG_OUTPUT_SYNCHRONOUS_ARB: Int = 33_346

public const val GL_MAX_DEBUG_MESSAGE_LENGTH_ARB: Int = 37_187

public const val GL_MAX_DEBUG_LOGGED_MESSAGES_ARB: Int = 37_188

public const val GL_DEBUG_LOGGED_MESSAGES_ARB: Int = 37_189

public const val GL_DEBUG_NEXT_LOGGED_MESSAGE_LENGTH_ARB: Int = 33_347

public const val GL_DEBUG_CALLBACK_FUNCTION_ARB: Int = 33_348

public const val GL_DEBUG_CALLBACK_USER_PARAM_ARB: Int = 33_349

public const val GL_DEBUG_SOURCE_API_ARB: Int = 33_350

public const val GL_DEBUG_SOURCE_WINDOW_SYSTEM_ARB: Int = 33_351

public const val GL_DEBUG_SOURCE_SHADER_COMPILER_ARB: Int = 33_352

public const val GL_DEBUG_SOURCE_THIRD_PARTY_ARB: Int = 33_353

public const val GL_DEBUG_SOURCE_APPLICATION_ARB: Int = 33_354

public const val GL_DEBUG_SOURCE_OTHER_ARB: Int = 33_355

public const val GL_DEBUG_TYPE_ERROR_ARB: Int = 33_356

public const val GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR_ARB: Int = 33_357

public const val GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR_ARB: Int = 33_358

public const val GL_DEBUG_TYPE_PORTABILITY_ARB: Int = 33_359

public const val GL_DEBUG_TYPE_PERFORMANCE_ARB: Int = 33_360

public const val GL_DEBUG_TYPE_OTHER_ARB: Int = 33_361

public const val GL_DEBUG_SEVERITY_HIGH_ARB: Int = 37_190

public const val GL_DEBUG_SEVERITY_MEDIUM_ARB: Int = 37_191

public const val GL_DEBUG_SEVERITY_LOW_ARB: Int = 37_192

public inline fun glDebugMessageControlARB(
    source: Int,
    type: Int,
    severity: Int,
    count: Int,
    ids: Ptr,
    enabled: Boolean,
): Unit = GLWrapper.instance.ARBDebugOutput.glDebugMessageControlARB(source, type, severity, count,
        ids, enabled)

public inline fun glDebugMessageControlARB(
    source: Int,
    type: Int,
    severity: Int,
    count: Int,
    ids: Long,
    enabled: Boolean,
): Unit = GLWrapper.instance.ARBDebugOutput.glDebugMessageControlARB(source, type, severity, count,
        ids, enabled)

public inline fun glDebugMessageInsertARB(
    source: Int,
    type: Int,
    id: Int,
    severity: Int,
    length: Int,
    buf: Ptr,
): Unit = GLWrapper.instance.ARBDebugOutput.glDebugMessageInsertARB(source, type, id, severity,
        length, buf)

public inline fun glDebugMessageInsertARB(
    source: Int,
    type: Int,
    id: Int,
    severity: Int,
    length: Int,
    buf: Long,
): Unit = GLWrapper.instance.ARBDebugOutput.glDebugMessageInsertARB(source, type, id, severity,
        length, buf)

public inline fun glDebugMessageCallbackARB(callback: Long, userParam: Ptr): Unit =
        GLWrapper.instance.ARBDebugOutput.glDebugMessageCallbackARB(callback, userParam)

public inline fun glDebugMessageCallbackARB(callback: Long, userParam: Long): Unit =
        GLWrapper.instance.ARBDebugOutput.glDebugMessageCallbackARB(callback, userParam)

public inline fun glGetDebugMessageLogARB(
    count: Int,
    bufSize: Int,
    sources: Ptr,
    types: Ptr,
    ids: Ptr,
    severities: Ptr,
    lengths: Ptr,
    messageLog: Ptr,
): Int = GLWrapper.instance.ARBDebugOutput.glGetDebugMessageLogARB(count, bufSize, sources, types,
        ids, severities, lengths, messageLog)

public inline fun glGetDebugMessageLogARB(
    count: Int,
    bufSize: Int,
    sources: Long,
    types: Long,
    ids: Long,
    severities: Long,
    lengths: Long,
    messageLog: Long,
): Int = GLWrapper.instance.ARBDebugOutput.glGetDebugMessageLogARB(count, bufSize, sources, types,
        ids, severities, lengths, messageLog)
