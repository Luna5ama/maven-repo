@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureSRGBDecode : GLBase

public const val GL_TEXTURE_SRGB_DECODE_EXT: Int = 35_400

public const val GL_DECODE_EXT: Int = 35_401

public const val GL_SKIP_DECODE_EXT: Int = 35_402
