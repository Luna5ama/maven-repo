@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTDrawInstanced : GLBase {
    public fun glDrawArraysInstancedEXT(
        mode: Int,
        start: Int,
        count: Int,
        primcount: Int,
    )

    @PtrParameter([3])
    public fun glDrawElementsInstancedEXT(
        mode: Int,
        count: Int,
        type: Int,
        indices: Ptr,
        primcount: Int,
    )

    @Unsafe
    public fun glDrawElementsInstancedEXT(
        mode: Int,
        count: Int,
        type: Int,
        indices: Long,
        primcount: Int,
    )
}

public inline fun glDrawArraysInstancedEXT(
    mode: Int,
    start: Int,
    count: Int,
    primcount: Int,
): Unit = GLWrapper.instance.EXTDrawInstanced.glDrawArraysInstancedEXT(mode, start, count,
        primcount)

public inline fun glDrawElementsInstancedEXT(
    mode: Int,
    count: Int,
    type: Int,
    indices: Ptr,
    primcount: Int,
): Unit = GLWrapper.instance.EXTDrawInstanced.glDrawElementsInstancedEXT(mode, count, type, indices,
        primcount)

public inline fun glDrawElementsInstancedEXT(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
): Unit = GLWrapper.instance.EXTDrawInstanced.glDrawElementsInstancedEXT(mode, count, type, indices,
        primcount)
