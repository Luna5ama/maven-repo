@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL41 : GLBase {
    public fun glReleaseShaderCompiler()

    @PtrParameter([1, 3])
    public fun glShaderBinary(
        count: Int,
        shaders: Ptr,
        binaryformat: Int,
        binary: Ptr,
        length: Int,
    )

    @Unsafe
    public fun glShaderBinary(
        count: Int,
        shaders: Long,
        binaryformat: Int,
        binary: Long,
        length: Int,
    )

    @PtrParameter([2, 3])
    public fun glGetShaderPrecisionFormat(
        shadertype: Int,
        precisiontype: Int,
        range: Ptr,
        precision: Ptr,
    )

    @Unsafe
    public fun glGetShaderPrecisionFormat(
        shadertype: Int,
        precisiontype: Int,
        range: Long,
        precision: Long,
    )

    public fun glDepthRangef(zNear: Float, zFar: Float)

    public fun glClearDepthf(depth: Float)

    @PtrParameter([2, 3, 4])
    public fun glGetProgramBinary(
        program: Int,
        bufSize: Int,
        length: Ptr,
        binaryFormat: Ptr,
        binary: Ptr,
    )

    @Unsafe
    public fun glGetProgramBinary(
        program: Int,
        bufSize: Int,
        length: Long,
        binaryFormat: Long,
        binary: Long,
    )

    @PtrParameter([2])
    public fun glProgramBinary(
        program: Int,
        binaryFormat: Int,
        binary: Ptr,
        length: Int,
    )

    @Unsafe
    public fun glProgramBinary(
        program: Int,
        binaryFormat: Int,
        binary: Long,
        length: Int,
    )

    public fun glProgramParameteri(
        program: Int,
        pname: Int,
        `value`: Int,
    )

    public fun glUseProgramStages(
        pipeline: Int,
        stages: Int,
        program: Int,
    )

    public fun glActiveShaderProgram(pipeline: Int, program: Int)

    @PtrParameter([2])
    public fun glCreateShaderProgramv(
        type: Int,
        count: Int,
        strings: Ptr,
    ): Int

    @Unsafe
    public fun glCreateShaderProgramv(
        type: Int,
        count: Int,
        strings: Long,
    ): Int

    public fun glBindProgramPipeline(pipeline: Int)

    @PtrParameter([1])
    public fun glDeleteProgramPipelines(n: Int, pipelines: Ptr)

    @Unsafe
    public fun glDeleteProgramPipelines(n: Int, pipelines: Long)

    @PtrParameter([1])
    public fun glGenProgramPipelines(n: Int, pipelines: Ptr)

    @Unsafe
    public fun glGenProgramPipelines(n: Int, pipelines: Long)

    public fun glIsProgramPipeline(pipeline: Int): Boolean

    @PtrParameter([2])
    public fun glGetProgramPipelineiv(
        pipeline: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramPipelineiv(
        pipeline: Int,
        pname: Int,
        params: Long,
    )

    public fun glProgramUniform1i(
        program: Int,
        location: Int,
        x: Int,
    )

    public fun glProgramUniform2i(
        program: Int,
        location: Int,
        x: Int,
        y: Int,
    )

    public fun glProgramUniform3i(
        program: Int,
        location: Int,
        x: Int,
        y: Int,
        z: Int,
    )

    public fun glProgramUniform4i(
        program: Int,
        location: Int,
        x: Int,
        y: Int,
        z: Int,
        w: Int,
    )

    public fun glProgramUniform1ui(
        program: Int,
        location: Int,
        x: Int,
    )

    public fun glProgramUniform2ui(
        program: Int,
        location: Int,
        x: Int,
        y: Int,
    )

    public fun glProgramUniform3ui(
        program: Int,
        location: Int,
        x: Int,
        y: Int,
        z: Int,
    )

    public fun glProgramUniform4ui(
        program: Int,
        location: Int,
        x: Int,
        y: Int,
        z: Int,
        w: Int,
    )

    public fun glProgramUniform1f(
        program: Int,
        location: Int,
        x: Float,
    )

    public fun glProgramUniform2f(
        program: Int,
        location: Int,
        x: Float,
        y: Float,
    )

    public fun glProgramUniform3f(
        program: Int,
        location: Int,
        x: Float,
        y: Float,
        z: Float,
    )

    public fun glProgramUniform4f(
        program: Int,
        location: Int,
        x: Float,
        y: Float,
        z: Float,
        w: Float,
    )

    public fun glProgramUniform1d(
        program: Int,
        location: Int,
        x: Double,
    )

    public fun glProgramUniform2d(
        program: Int,
        location: Int,
        x: Double,
        y: Double,
    )

    public fun glProgramUniform3d(
        program: Int,
        location: Int,
        x: Double,
        y: Double,
        z: Double,
    )

    public fun glProgramUniform4d(
        program: Int,
        location: Int,
        x: Double,
        y: Double,
        z: Double,
        w: Double,
    )

    @PtrParameter([3])
    public fun glProgramUniform1iv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1iv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2iv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2iv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3iv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3iv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4iv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4iv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1uiv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1uiv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2uiv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2uiv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3uiv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3uiv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4uiv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4uiv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1fv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1fv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2fv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2fv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3fv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3fv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4fv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4fv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1dv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1dv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2dv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2dv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3dv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3dv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4dv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4dv(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix2fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix2fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix3fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix3fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix4fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix4fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix2dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix2dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix3dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix3dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix4dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix4dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix2x3fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix2x3fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix3x2fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix3x2fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix2x4fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix2x4fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix4x2fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix4x2fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix3x4fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix3x4fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix4x3fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix4x3fv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix2x3dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix2x3dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix3x2dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix3x2dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix2x4dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix2x4dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix4x2dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix4x2dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix3x4dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix3x4dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix4x3dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix4x3dv(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    public fun glValidateProgramPipeline(pipeline: Int)

    @PtrParameter([2, 3])
    public fun glGetProgramPipelineInfoLog(
        pipeline: Int,
        bufSize: Int,
        length: Ptr,
        infoLog: Ptr,
    )

    @Unsafe
    public fun glGetProgramPipelineInfoLog(
        pipeline: Int,
        bufSize: Int,
        length: Long,
        infoLog: Long,
    )

    public fun glVertexAttribL1d(index: Int, x: Double)

    public fun glVertexAttribL2d(
        index: Int,
        x: Double,
        y: Double,
    )

    public fun glVertexAttribL3d(
        index: Int,
        x: Double,
        y: Double,
        z: Double,
    )

    public fun glVertexAttribL4d(
        index: Int,
        x: Double,
        y: Double,
        z: Double,
        w: Double,
    )

    @PtrParameter([1])
    public fun glVertexAttribL1dv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL1dv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL2dv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL2dv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL3dv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL3dv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribL4dv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribL4dv(index: Int, v: Long)

    @PtrParameter([4])
    public fun glVertexAttribLPointer(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glVertexAttribLPointer(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribLdv(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribLdv(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glViewportArrayv(
        first: Int,
        count: Int,
        v: Ptr,
    )

    @Unsafe
    public fun glViewportArrayv(
        first: Int,
        count: Int,
        v: Long,
    )

    public fun glViewportIndexedf(
        index: Int,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
    )

    @PtrParameter([1])
    public fun glViewportIndexedfv(index: Int, v: Ptr)

    @Unsafe
    public fun glViewportIndexedfv(index: Int, v: Long)

    @PtrParameter([2])
    public fun glScissorArrayv(
        first: Int,
        count: Int,
        v: Ptr,
    )

    @Unsafe
    public fun glScissorArrayv(
        first: Int,
        count: Int,
        v: Long,
    )

    public fun glScissorIndexed(
        index: Int,
        left: Int,
        bottom: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([1])
    public fun glScissorIndexedv(index: Int, v: Ptr)

    @Unsafe
    public fun glScissorIndexedv(index: Int, v: Long)

    @PtrParameter([2])
    public fun glDepthRangeArrayv(
        first: Int,
        count: Int,
        v: Ptr,
    )

    @Unsafe
    public fun glDepthRangeArrayv(
        first: Int,
        count: Int,
        v: Long,
    )

    public fun glDepthRangeIndexed(
        index: Int,
        zNear: Double,
        zFar: Double,
    )

    @PtrParameter([2])
    public fun glGetFloati_v(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetFloati_v(
        target: Int,
        index: Int,
        `data`: Long,
    )

    @PtrParameter([2])
    public fun glGetDoublei_v(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetDoublei_v(
        target: Int,
        index: Int,
        `data`: Long,
    )

    public fun glDeleteProgramPipelines(pipeline: Int)
}

public const val GL_SHADER_COMPILER: Int = 36_346

public const val GL_SHADER_BINARY_FORMATS: Int = 36_344

public const val GL_NUM_SHADER_BINARY_FORMATS: Int = 36_345

public const val GL_MAX_VERTEX_UNIFORM_VECTORS: Int = 36_347

public const val GL_MAX_VARYING_VECTORS: Int = 36_348

public const val GL_MAX_FRAGMENT_UNIFORM_VECTORS: Int = 36_349

public const val GL_IMPLEMENTATION_COLOR_READ_TYPE: Int = 35_738

public const val GL_IMPLEMENTATION_COLOR_READ_FORMAT: Int = 35_739

public const val GL_FIXED: Int = 5_132

public const val GL_LOW_FLOAT: Int = 36_336

public const val GL_MEDIUM_FLOAT: Int = 36_337

public const val GL_HIGH_FLOAT: Int = 36_338

public const val GL_LOW_INT: Int = 36_339

public const val GL_MEDIUM_INT: Int = 36_340

public const val GL_HIGH_INT: Int = 36_341

public const val GL_RGB565: Int = 36_194

public const val GL_PROGRAM_BINARY_RETRIEVABLE_HINT: Int = 33_367

public const val GL_PROGRAM_BINARY_LENGTH: Int = 34_625

public const val GL_NUM_PROGRAM_BINARY_FORMATS: Int = 34_814

public const val GL_PROGRAM_BINARY_FORMATS: Int = 34_815

public const val GL_VERTEX_SHADER_BIT: Int = 1

public const val GL_FRAGMENT_SHADER_BIT: Int = 2

public const val GL_GEOMETRY_SHADER_BIT: Int = 4

public const val GL_TESS_CONTROL_SHADER_BIT: Int = 8

public const val GL_TESS_EVALUATION_SHADER_BIT: Int = 16

public const val GL_ALL_SHADER_BITS: Int = 1

public const val GL_PROGRAM_SEPARABLE: Int = 33_368

public const val GL_ACTIVE_PROGRAM: Int = 33_369

public const val GL_PROGRAM_PIPELINE_BINDING: Int = 33_370

public const val GL_MAX_VIEWPORTS: Int = 33_371

public const val GL_VIEWPORT_SUBPIXEL_BITS: Int = 33_372

public const val GL_VIEWPORT_BOUNDS_RANGE: Int = 33_373

public const val GL_LAYER_PROVOKING_VERTEX: Int = 33_374

public const val GL_VIEWPORT_INDEX_PROVOKING_VERTEX: Int = 33_375

public const val GL_UNDEFINED_VERTEX: Int = 33_376

public inline fun glReleaseShaderCompiler(): Unit =
        GLWrapper.instance.GL41.glReleaseShaderCompiler()

public inline fun glShaderBinary(
    count: Int,
    shaders: Ptr,
    binaryformat: Int,
    binary: Ptr,
    length: Int,
): Unit = GLWrapper.instance.GL41.glShaderBinary(count, shaders, binaryformat, binary, length)

public inline fun glShaderBinary(
    count: Int,
    shaders: Long,
    binaryformat: Int,
    binary: Long,
    length: Int,
): Unit = GLWrapper.instance.GL41.glShaderBinary(count, shaders, binaryformat, binary, length)

public inline fun glGetShaderPrecisionFormat(
    shadertype: Int,
    precisiontype: Int,
    range: Ptr,
    precision: Ptr,
): Unit = GLWrapper.instance.GL41.glGetShaderPrecisionFormat(shadertype, precisiontype, range,
        precision)

public inline fun glGetShaderPrecisionFormat(
    shadertype: Int,
    precisiontype: Int,
    range: Long,
    precision: Long,
): Unit = GLWrapper.instance.GL41.glGetShaderPrecisionFormat(shadertype, precisiontype, range,
        precision)

public inline fun glDepthRangef(zNear: Float, zFar: Float): Unit =
        GLWrapper.instance.GL41.glDepthRangef(zNear, zFar)

public inline fun glClearDepthf(depth: Float): Unit = GLWrapper.instance.GL41.glClearDepthf(depth)

public inline fun glGetProgramBinary(
    program: Int,
    bufSize: Int,
    length: Ptr,
    binaryFormat: Ptr,
    binary: Ptr,
): Unit = GLWrapper.instance.GL41.glGetProgramBinary(program, bufSize, length, binaryFormat, binary)

public inline fun glGetProgramBinary(
    program: Int,
    bufSize: Int,
    length: Long,
    binaryFormat: Long,
    binary: Long,
): Unit = GLWrapper.instance.GL41.glGetProgramBinary(program, bufSize, length, binaryFormat, binary)

public inline fun glProgramBinary(
    program: Int,
    binaryFormat: Int,
    binary: Ptr,
    length: Int,
): Unit = GLWrapper.instance.GL41.glProgramBinary(program, binaryFormat, binary, length)

public inline fun glProgramBinary(
    program: Int,
    binaryFormat: Int,
    binary: Long,
    length: Int,
): Unit = GLWrapper.instance.GL41.glProgramBinary(program, binaryFormat, binary, length)

public inline fun glProgramParameteri(
    program: Int,
    pname: Int,
    `value`: Int,
): Unit = GLWrapper.instance.GL41.glProgramParameteri(program, pname, `value`)

public inline fun glUseProgramStages(
    pipeline: Int,
    stages: Int,
    program: Int,
): Unit = GLWrapper.instance.GL41.glUseProgramStages(pipeline, stages, program)

public inline fun glActiveShaderProgram(pipeline: Int, program: Int): Unit =
        GLWrapper.instance.GL41.glActiveShaderProgram(pipeline, program)

public inline fun glCreateShaderProgramv(
    type: Int,
    count: Int,
    strings: Ptr,
): Int = GLWrapper.instance.GL41.glCreateShaderProgramv(type, count, strings)

public inline fun glCreateShaderProgramv(
    type: Int,
    count: Int,
    strings: Long,
): Int = GLWrapper.instance.GL41.glCreateShaderProgramv(type, count, strings)

public inline fun glBindProgramPipeline(pipeline: Int): Unit =
        GLWrapper.instance.GL41.glBindProgramPipeline(pipeline)

public inline fun glDeleteProgramPipelines(n: Int, pipelines: Ptr): Unit =
        GLWrapper.instance.GL41.glDeleteProgramPipelines(n, pipelines)

public inline fun glDeleteProgramPipelines(n: Int, pipelines: Long): Unit =
        GLWrapper.instance.GL41.glDeleteProgramPipelines(n, pipelines)

public inline fun glGenProgramPipelines(n: Int, pipelines: Ptr): Unit =
        GLWrapper.instance.GL41.glGenProgramPipelines(n, pipelines)

public inline fun glGenProgramPipelines(n: Int, pipelines: Long): Unit =
        GLWrapper.instance.GL41.glGenProgramPipelines(n, pipelines)

public inline fun glIsProgramPipeline(pipeline: Int): Boolean =
        GLWrapper.instance.GL41.glIsProgramPipeline(pipeline)

public inline fun glGetProgramPipelineiv(
    pipeline: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL41.glGetProgramPipelineiv(pipeline, pname, params)

public inline fun glGetProgramPipelineiv(
    pipeline: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL41.glGetProgramPipelineiv(pipeline, pname, params)

public inline fun glProgramUniform1i(
    program: Int,
    location: Int,
    x: Int,
): Unit = GLWrapper.instance.GL41.glProgramUniform1i(program, location, x)

public inline fun glProgramUniform2i(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
): Unit = GLWrapper.instance.GL41.glProgramUniform2i(program, location, x, y)

public inline fun glProgramUniform3i(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
    z: Int,
): Unit = GLWrapper.instance.GL41.glProgramUniform3i(program, location, x, y, z)

public inline fun glProgramUniform4i(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
): Unit = GLWrapper.instance.GL41.glProgramUniform4i(program, location, x, y, z, w)

public inline fun glProgramUniform1ui(
    program: Int,
    location: Int,
    x: Int,
): Unit = GLWrapper.instance.GL41.glProgramUniform1ui(program, location, x)

public inline fun glProgramUniform2ui(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
): Unit = GLWrapper.instance.GL41.glProgramUniform2ui(program, location, x, y)

public inline fun glProgramUniform3ui(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
    z: Int,
): Unit = GLWrapper.instance.GL41.glProgramUniform3ui(program, location, x, y, z)

public inline fun glProgramUniform4ui(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
): Unit = GLWrapper.instance.GL41.glProgramUniform4ui(program, location, x, y, z, w)

public inline fun glProgramUniform1f(
    program: Int,
    location: Int,
    x: Float,
): Unit = GLWrapper.instance.GL41.glProgramUniform1f(program, location, x)

public inline fun glProgramUniform2f(
    program: Int,
    location: Int,
    x: Float,
    y: Float,
): Unit = GLWrapper.instance.GL41.glProgramUniform2f(program, location, x, y)

public inline fun glProgramUniform3f(
    program: Int,
    location: Int,
    x: Float,
    y: Float,
    z: Float,
): Unit = GLWrapper.instance.GL41.glProgramUniform3f(program, location, x, y, z)

public inline fun glProgramUniform4f(
    program: Int,
    location: Int,
    x: Float,
    y: Float,
    z: Float,
    w: Float,
): Unit = GLWrapper.instance.GL41.glProgramUniform4f(program, location, x, y, z, w)

public inline fun glProgramUniform1d(
    program: Int,
    location: Int,
    x: Double,
): Unit = GLWrapper.instance.GL41.glProgramUniform1d(program, location, x)

public inline fun glProgramUniform2d(
    program: Int,
    location: Int,
    x: Double,
    y: Double,
): Unit = GLWrapper.instance.GL41.glProgramUniform2d(program, location, x, y)

public inline fun glProgramUniform3d(
    program: Int,
    location: Int,
    x: Double,
    y: Double,
    z: Double,
): Unit = GLWrapper.instance.GL41.glProgramUniform3d(program, location, x, y, z)

public inline fun glProgramUniform4d(
    program: Int,
    location: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
): Unit = GLWrapper.instance.GL41.glProgramUniform4d(program, location, x, y, z, w)

public inline fun glProgramUniform1iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform1iv(program, location, count, `value`)

public inline fun glProgramUniform1iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform1iv(program, location, count, `value`)

public inline fun glProgramUniform2iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform2iv(program, location, count, `value`)

public inline fun glProgramUniform2iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform2iv(program, location, count, `value`)

public inline fun glProgramUniform3iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform3iv(program, location, count, `value`)

public inline fun glProgramUniform3iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform3iv(program, location, count, `value`)

public inline fun glProgramUniform4iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform4iv(program, location, count, `value`)

public inline fun glProgramUniform4iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform4iv(program, location, count, `value`)

public inline fun glProgramUniform1uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform1uiv(program, location, count, `value`)

public inline fun glProgramUniform1uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform1uiv(program, location, count, `value`)

public inline fun glProgramUniform2uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform2uiv(program, location, count, `value`)

public inline fun glProgramUniform2uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform2uiv(program, location, count, `value`)

public inline fun glProgramUniform3uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform3uiv(program, location, count, `value`)

public inline fun glProgramUniform3uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform3uiv(program, location, count, `value`)

public inline fun glProgramUniform4uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform4uiv(program, location, count, `value`)

public inline fun glProgramUniform4uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform4uiv(program, location, count, `value`)

public inline fun glProgramUniform1fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform1fv(program, location, count, `value`)

public inline fun glProgramUniform1fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform1fv(program, location, count, `value`)

public inline fun glProgramUniform2fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform2fv(program, location, count, `value`)

public inline fun glProgramUniform2fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform2fv(program, location, count, `value`)

public inline fun glProgramUniform3fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform3fv(program, location, count, `value`)

public inline fun glProgramUniform3fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform3fv(program, location, count, `value`)

public inline fun glProgramUniform4fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform4fv(program, location, count, `value`)

public inline fun glProgramUniform4fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform4fv(program, location, count, `value`)

public inline fun glProgramUniform1dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform1dv(program, location, count, `value`)

public inline fun glProgramUniform1dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform1dv(program, location, count, `value`)

public inline fun glProgramUniform2dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform2dv(program, location, count, `value`)

public inline fun glProgramUniform2dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform2dv(program, location, count, `value`)

public inline fun glProgramUniform3dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform3dv(program, location, count, `value`)

public inline fun glProgramUniform3dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform3dv(program, location, count, `value`)

public inline fun glProgramUniform4dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniform4dv(program, location, count, `value`)

public inline fun glProgramUniform4dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniform4dv(program, location, count, `value`)

public inline fun glProgramUniformMatrix2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2x3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2x3fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2x3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2x3fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3x2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3x2fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3x2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3x2fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2x4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2x4fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2x4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2x4fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4x2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4x2fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4x2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4x2fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3x4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3x4fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3x4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3x4fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4x3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4x3fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4x3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4x3fv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2x3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2x3dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2x3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2x3dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3x2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3x2dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3x2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3x2dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2x4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2x4dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix2x4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix2x4dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4x2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4x2dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4x2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4x2dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3x4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3x4dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix3x4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix3x4dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4x3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4x3dv(program, location, count, transpose,
        `value`)

public inline fun glProgramUniformMatrix4x3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL41.glProgramUniformMatrix4x3dv(program, location, count, transpose,
        `value`)

public inline fun glValidateProgramPipeline(pipeline: Int): Unit =
        GLWrapper.instance.GL41.glValidateProgramPipeline(pipeline)

public inline fun glGetProgramPipelineInfoLog(
    pipeline: Int,
    bufSize: Int,
    length: Ptr,
    infoLog: Ptr,
): Unit = GLWrapper.instance.GL41.glGetProgramPipelineInfoLog(pipeline, bufSize, length, infoLog)

public inline fun glGetProgramPipelineInfoLog(
    pipeline: Int,
    bufSize: Int,
    length: Long,
    infoLog: Long,
): Unit = GLWrapper.instance.GL41.glGetProgramPipelineInfoLog(pipeline, bufSize, length, infoLog)

public inline fun glVertexAttribL1d(index: Int, x: Double): Unit =
        GLWrapper.instance.GL41.glVertexAttribL1d(index, x)

public inline fun glVertexAttribL2d(
    index: Int,
    x: Double,
    y: Double,
): Unit = GLWrapper.instance.GL41.glVertexAttribL2d(index, x, y)

public inline fun glVertexAttribL3d(
    index: Int,
    x: Double,
    y: Double,
    z: Double,
): Unit = GLWrapper.instance.GL41.glVertexAttribL3d(index, x, y, z)

public inline fun glVertexAttribL4d(
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
): Unit = GLWrapper.instance.GL41.glVertexAttribL4d(index, x, y, z, w)

public inline fun glVertexAttribL1dv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL41.glVertexAttribL1dv(index, v)

public inline fun glVertexAttribL1dv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL41.glVertexAttribL1dv(index, v)

public inline fun glVertexAttribL2dv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL41.glVertexAttribL2dv(index, v)

public inline fun glVertexAttribL2dv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL41.glVertexAttribL2dv(index, v)

public inline fun glVertexAttribL3dv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL41.glVertexAttribL3dv(index, v)

public inline fun glVertexAttribL3dv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL41.glVertexAttribL3dv(index, v)

public inline fun glVertexAttribL4dv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL41.glVertexAttribL4dv(index, v)

public inline fun glVertexAttribL4dv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL41.glVertexAttribL4dv(index, v)

public inline fun glVertexAttribLPointer(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.GL41.glVertexAttribLPointer(index, size, type, stride, pointer)

public inline fun glVertexAttribLPointer(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
): Unit = GLWrapper.instance.GL41.glVertexAttribLPointer(index, size, type, stride, pointer)

public inline fun glGetVertexAttribLdv(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL41.glGetVertexAttribLdv(index, pname, params)

public inline fun glGetVertexAttribLdv(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL41.glGetVertexAttribLdv(index, pname, params)

public inline fun glViewportArrayv(
    first: Int,
    count: Int,
    v: Ptr,
): Unit = GLWrapper.instance.GL41.glViewportArrayv(first, count, v)

public inline fun glViewportArrayv(
    first: Int,
    count: Int,
    v: Long,
): Unit = GLWrapper.instance.GL41.glViewportArrayv(first, count, v)

public inline fun glViewportIndexedf(
    index: Int,
    x: Float,
    y: Float,
    w: Float,
    h: Float,
): Unit = GLWrapper.instance.GL41.glViewportIndexedf(index, x, y, w, h)

public inline fun glViewportIndexedfv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL41.glViewportIndexedfv(index, v)

public inline fun glViewportIndexedfv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL41.glViewportIndexedfv(index, v)

public inline fun glScissorArrayv(
    first: Int,
    count: Int,
    v: Ptr,
): Unit = GLWrapper.instance.GL41.glScissorArrayv(first, count, v)

public inline fun glScissorArrayv(
    first: Int,
    count: Int,
    v: Long,
): Unit = GLWrapper.instance.GL41.glScissorArrayv(first, count, v)

public inline fun glScissorIndexed(
    index: Int,
    left: Int,
    bottom: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL41.glScissorIndexed(index, left, bottom, width, height)

public inline fun glScissorIndexedv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL41.glScissorIndexedv(index, v)

public inline fun glScissorIndexedv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL41.glScissorIndexedv(index, v)

public inline fun glDepthRangeArrayv(
    first: Int,
    count: Int,
    v: Ptr,
): Unit = GLWrapper.instance.GL41.glDepthRangeArrayv(first, count, v)

public inline fun glDepthRangeArrayv(
    first: Int,
    count: Int,
    v: Long,
): Unit = GLWrapper.instance.GL41.glDepthRangeArrayv(first, count, v)

public inline fun glDepthRangeIndexed(
    index: Int,
    zNear: Double,
    zFar: Double,
): Unit = GLWrapper.instance.GL41.glDepthRangeIndexed(index, zNear, zFar)

public inline fun glGetFloati_v(
    target: Int,
    index: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL41.glGetFloati_v(target, index, `data`)

public inline fun glGetFloati_v(
    target: Int,
    index: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL41.glGetFloati_v(target, index, `data`)

public inline fun glGetDoublei_v(
    target: Int,
    index: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL41.glGetDoublei_v(target, index, `data`)

public inline fun glGetDoublei_v(
    target: Int,
    index: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL41.glGetDoublei_v(target, index, `data`)

public inline fun glDeleteProgramPipelines(pipeline: Int): Unit =
        GLWrapper.instance.GL41.glDeleteProgramPipelines(pipeline)
