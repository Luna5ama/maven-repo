@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTGPUProgramParameters : GLBase {
    @PtrParameter([3])
    public fun glProgramEnvParameters4fvEXT(
        target: Int,
        index: Int,
        count: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glProgramEnvParameters4fvEXT(
        target: Int,
        index: Int,
        count: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glProgramLocalParameters4fvEXT(
        target: Int,
        index: Int,
        count: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glProgramLocalParameters4fvEXT(
        target: Int,
        index: Int,
        count: Int,
        params: Long,
    )
}

public inline fun glProgramEnvParameters4fvEXT(
    target: Int,
    index: Int,
    count: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTGPUProgramParameters.glProgramEnvParameters4fvEXT(target, index,
        count, params)

public inline fun glProgramEnvParameters4fvEXT(
    target: Int,
    index: Int,
    count: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTGPUProgramParameters.glProgramEnvParameters4fvEXT(target, index,
        count, params)

public inline fun glProgramLocalParameters4fvEXT(
    target: Int,
    index: Int,
    count: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTGPUProgramParameters.glProgramLocalParameters4fvEXT(target, index,
        count, params)

public inline fun glProgramLocalParameters4fvEXT(
    target: Int,
    index: Int,
    count: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTGPUProgramParameters.glProgramLocalParameters4fvEXT(target, index,
        count, params)
