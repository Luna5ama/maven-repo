@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVTextureShader3 : GLBase

public const val GL_OFFSET_PROJECTIVE_TEXTURE_2D_NV: Int = 34_896

public const val GL_OFFSET_PROJECTIVE_TEXTURE_2D_SCALE_NV: Int = 34_897

public const val GL_OFFSET_PROJECTIVE_TEXTURE_RECTANGLE_NV: Int = 34_898

public const val GL_OFFSET_PROJECTIVE_TEXTURE_RECTANGLE_SCALE_NV: Int = 34_899

public const val GL_OFFSET_HILO_TEXTURE_2D_NV: Int = 34_900

public const val GL_OFFSET_HILO_TEXTURE_RECTANGLE_NV: Int = 34_901

public const val GL_OFFSET_HILO_PROJECTIVE_TEXTURE_2D_NV: Int = 34_902

public const val GL_OFFSET_HILO_PROJECTIVE_TEXTURE_RECTANGLE_NV: Int = 34_903

public const val GL_DEPENDENT_HILO_TEXTURE_2D_NV: Int = 34_904

public const val GL_DEPENDENT_RGB_TEXTURE_3D_NV: Int = 34_905

public const val GL_DEPENDENT_RGB_TEXTURE_CUBE_MAP_NV: Int = 34_906

public const val GL_DOT_PRODUCT_PASS_THROUGH_NV: Int = 34_907

public const val GL_DOT_PRODUCT_TEXTURE_1D_NV: Int = 34_908

public const val GL_DOT_PRODUCT_AFFINE_DEPTH_REPLACE_NV: Int = 34_909

public const val GL_HILO8_NV: Int = 34_910

public const val GL_SIGNED_HILO8_NV: Int = 34_911

public const val GL_FORCE_BLUE_TO_ONE_NV: Int = 34_912
