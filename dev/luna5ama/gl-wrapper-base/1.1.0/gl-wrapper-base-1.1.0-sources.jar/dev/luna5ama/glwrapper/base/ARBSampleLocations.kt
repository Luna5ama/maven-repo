@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBSampleLocations : GLBase {
    @PtrParameter([3])
    public fun glFramebufferSampleLocationsfvARB(
        target: Int,
        start: Int,
        count: Int,
        v: Ptr,
    )

    @Unsafe
    public fun glFramebufferSampleLocationsfvARB(
        target: Int,
        start: Int,
        count: Int,
        v: Long,
    )

    @PtrParameter([3])
    public fun glNamedFramebufferSampleLocationsfvARB(
        framebuffer: Int,
        start: Int,
        count: Int,
        v: Ptr,
    )

    @Unsafe
    public fun glNamedFramebufferSampleLocationsfvARB(
        framebuffer: Int,
        start: Int,
        count: Int,
        v: Long,
    )

    public fun glEvaluateDepthValuesARB()
}

public const val GL_SAMPLE_LOCATION_SUBPIXEL_BITS_ARB: Int = 37_693

public const val GL_SAMPLE_LOCATION_PIXEL_GRID_WIDTH_ARB: Int = 37_694

public const val GL_SAMPLE_LOCATION_PIXEL_GRID_HEIGHT_ARB: Int = 37_695

public const val GL_PROGRAMMABLE_SAMPLE_LOCATION_TABLE_SIZE_ARB: Int = 37_696

public const val GL_FRAMEBUFFER_PROGRAMMABLE_SAMPLE_LOCATIONS_ARB: Int = 37_698

public const val GL_FRAMEBUFFER_SAMPLE_LOCATION_PIXEL_GRID_ARB: Int = 37_699

public inline fun glFramebufferSampleLocationsfvARB(
    target: Int,
    start: Int,
    count: Int,
    v: Ptr,
): Unit = GLWrapper.instance.ARBSampleLocations.glFramebufferSampleLocationsfvARB(target, start,
        count, v)

public inline fun glFramebufferSampleLocationsfvARB(
    target: Int,
    start: Int,
    count: Int,
    v: Long,
): Unit = GLWrapper.instance.ARBSampleLocations.glFramebufferSampleLocationsfvARB(target, start,
        count, v)

public inline fun glNamedFramebufferSampleLocationsfvARB(
    framebuffer: Int,
    start: Int,
    count: Int,
    v: Ptr,
): Unit = GLWrapper.instance.ARBSampleLocations.glNamedFramebufferSampleLocationsfvARB(framebuffer,
        start, count, v)

public inline fun glNamedFramebufferSampleLocationsfvARB(
    framebuffer: Int,
    start: Int,
    count: Int,
    v: Long,
): Unit = GLWrapper.instance.ARBSampleLocations.glNamedFramebufferSampleLocationsfvARB(framebuffer,
        start, count, v)

public inline fun glEvaluateDepthValuesARB(): Unit =
        GLWrapper.instance.ARBSampleLocations.glEvaluateDepthValuesARB()
