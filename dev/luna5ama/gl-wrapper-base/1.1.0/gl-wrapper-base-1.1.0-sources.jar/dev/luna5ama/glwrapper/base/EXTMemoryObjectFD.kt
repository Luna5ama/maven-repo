@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTMemoryObjectFD : GLBase {
    public fun glImportMemoryFdEXT(
        memory: Int,
        size: Long,
        handleType: Int,
        fd: Int,
    )
}

public const val GL_HANDLE_TYPE_OPAQUE_FD_EXT: Int = 38_278

public inline fun glImportMemoryFdEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    fd: Int,
): Unit = GLWrapper.instance.EXTMemoryObjectFD.glImportMemoryFdEXT(memory, size, handleType, fd)
