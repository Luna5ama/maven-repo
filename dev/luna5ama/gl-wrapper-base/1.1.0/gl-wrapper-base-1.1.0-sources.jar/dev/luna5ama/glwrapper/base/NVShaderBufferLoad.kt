@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVShaderBufferLoad : GLBase {
    public fun glMakeBufferResidentNV(target: Int, access: Int)

    public fun glMakeBufferNonResidentNV(target: Int)

    public fun glIsBufferResidentNV(target: Int): Boolean

    public fun glMakeNamedBufferResidentNV(buffer: Int, access: Int)

    public fun glMakeNamedBufferNonResidentNV(buffer: Int)

    public fun glIsNamedBufferResidentNV(buffer: Int): Boolean

    @PtrParameter([2])
    public fun glGetBufferParameterui64vNV(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetBufferParameterui64vNV(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetNamedBufferParameterui64vNV(
        buffer: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedBufferParameterui64vNV(
        buffer: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([1])
    public fun glGetIntegerui64vNV(`value`: Int, result: Ptr)

    @Unsafe
    public fun glGetIntegerui64vNV(`value`: Int, result: Long)

    public fun glUniformui64NV(location: Int, `value`: Long)

    @PtrParameter([2])
    public fun glUniformui64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformui64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformui64vNV(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformui64vNV(
        program: Int,
        location: Int,
        params: Long,
    )

    public fun glProgramUniformui64NV(
        program: Int,
        location: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniformui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )
}

public const val GL_BUFFER_GPU_ADDRESS_NV: Int = 36_637

public const val GL_GPU_ADDRESS_NV: Int = 36_660

public const val GL_MAX_SHADER_BUFFER_ADDRESS_NV: Int = 36_661

public inline fun glMakeBufferResidentNV(target: Int, access: Int): Unit =
        GLWrapper.instance.NVShaderBufferLoad.glMakeBufferResidentNV(target, access)

public inline fun glMakeBufferNonResidentNV(target: Int): Unit =
        GLWrapper.instance.NVShaderBufferLoad.glMakeBufferNonResidentNV(target)

public inline fun glIsBufferResidentNV(target: Int): Boolean =
        GLWrapper.instance.NVShaderBufferLoad.glIsBufferResidentNV(target)

public inline fun glMakeNamedBufferResidentNV(buffer: Int, access: Int): Unit =
        GLWrapper.instance.NVShaderBufferLoad.glMakeNamedBufferResidentNV(buffer, access)

public inline fun glMakeNamedBufferNonResidentNV(buffer: Int): Unit =
        GLWrapper.instance.NVShaderBufferLoad.glMakeNamedBufferNonResidentNV(buffer)

public inline fun glIsNamedBufferResidentNV(buffer: Int): Boolean =
        GLWrapper.instance.NVShaderBufferLoad.glIsNamedBufferResidentNV(buffer)

public inline fun glGetBufferParameterui64vNV(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVShaderBufferLoad.glGetBufferParameterui64vNV(target, pname, params)

public inline fun glGetBufferParameterui64vNV(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVShaderBufferLoad.glGetBufferParameterui64vNV(target, pname, params)

public inline fun glGetNamedBufferParameterui64vNV(
    buffer: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVShaderBufferLoad.glGetNamedBufferParameterui64vNV(buffer, pname,
        params)

public inline fun glGetNamedBufferParameterui64vNV(
    buffer: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVShaderBufferLoad.glGetNamedBufferParameterui64vNV(buffer, pname,
        params)

public inline fun glGetIntegerui64vNV(`value`: Int, result: Ptr): Unit =
        GLWrapper.instance.NVShaderBufferLoad.glGetIntegerui64vNV(`value`, result)

public inline fun glGetIntegerui64vNV(`value`: Int, result: Long): Unit =
        GLWrapper.instance.NVShaderBufferLoad.glGetIntegerui64vNV(`value`, result)

public inline fun glUniformui64NV(location: Int, `value`: Long): Unit =
        GLWrapper.instance.NVShaderBufferLoad.glUniformui64NV(location, `value`)

public inline fun glUniformui64vNV(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVShaderBufferLoad.glUniformui64vNV(location, count, `value`)

public inline fun glUniformui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVShaderBufferLoad.glUniformui64vNV(location, count, `value`)

public inline fun glProgramUniformui64NV(
    program: Int,
    location: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVShaderBufferLoad.glProgramUniformui64NV(program, location, `value`)

public inline fun glProgramUniformui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVShaderBufferLoad.glProgramUniformui64vNV(program, location, count,
        `value`)

public inline fun glProgramUniformui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVShaderBufferLoad.glProgramUniformui64vNV(program, location, count,
        `value`)
