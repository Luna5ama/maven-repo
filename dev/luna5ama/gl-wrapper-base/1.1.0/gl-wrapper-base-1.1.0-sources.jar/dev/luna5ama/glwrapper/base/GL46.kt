@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL46 : GLBase {
    @PtrParameter([1])
    public fun glMultiDrawArraysIndirectCount(
        mode: Int,
        indirect: Ptr,
        drawcount: Long,
        maxdrawcount: Int,
        stride: Int,
    )

    @Unsafe
    public fun glMultiDrawArraysIndirectCount(
        mode: Int,
        indirect: Long,
        drawcount: Long,
        maxdrawcount: Int,
        stride: Int,
    )

    @PtrParameter([2])
    public fun glMultiDrawElementsIndirectCount(
        mode: Int,
        type: Int,
        indirect: Ptr,
        drawcount: Long,
        maxdrawcount: Int,
        stride: Int,
    )

    @Unsafe
    public fun glMultiDrawElementsIndirectCount(
        mode: Int,
        type: Int,
        indirect: Long,
        drawcount: Long,
        maxdrawcount: Int,
        stride: Int,
    )

    public fun glPolygonOffsetClamp(
        factor: Float,
        units: Float,
        clamp: Float,
    )

    @PtrParameter([1, 3, 4])
    public fun glSpecializeShader(
        shader: Int,
        pEntryPoint: Ptr,
        numSpecializationConstants: Int,
        pConstantIndex: Ptr,
        pConstantValue: Ptr,
    )

    @Unsafe
    public fun glSpecializeShader(
        shader: Int,
        pEntryPoint: Long,
        numSpecializationConstants: Int,
        pConstantIndex: Long,
        pConstantValue: Long,
    )
}

public const val GL_PARAMETER_BUFFER: Int = 33_006

public const val GL_PARAMETER_BUFFER_BINDING: Int = 33_007

public const val GL_VERTICES_SUBMITTED: Int = 33_518

public const val GL_PRIMITIVES_SUBMITTED: Int = 33_519

public const val GL_VERTEX_SHADER_INVOCATIONS: Int = 33_520

public const val GL_TESS_CONTROL_SHADER_PATCHES: Int = 33_521

public const val GL_TESS_EVALUATION_SHADER_INVOCATIONS: Int = 33_522

public const val GL_GEOMETRY_SHADER_PRIMITIVES_EMITTED: Int = 33_523

public const val GL_FRAGMENT_SHADER_INVOCATIONS: Int = 33_524

public const val GL_COMPUTE_SHADER_INVOCATIONS: Int = 33_525

public const val GL_CLIPPING_INPUT_PRIMITIVES: Int = 33_526

public const val GL_CLIPPING_OUTPUT_PRIMITIVES: Int = 33_527

public const val GL_POLYGON_OFFSET_CLAMP: Int = 36_379

public const val GL_CONTEXT_FLAG_NO_ERROR_BIT: Int = 8

public const val GL_SHADER_BINARY_FORMAT_SPIR_V: Int = 38_225

public const val GL_SPIR_V_BINARY: Int = 38_226

public const val GL_SPIR_V_EXTENSIONS: Int = 38_227

public const val GL_NUM_SPIR_V_EXTENSIONS: Int = 38_228

public const val GL_TEXTURE_MAX_ANISOTROPY: Int = 34_046

public const val GL_MAX_TEXTURE_MAX_ANISOTROPY: Int = 34_047

public const val GL_TRANSFORM_FEEDBACK_OVERFLOW: Int = 33_516

public const val GL_TRANSFORM_FEEDBACK_STREAM_OVERFLOW: Int = 33_517

public inline fun glMultiDrawArraysIndirectCount(
    mode: Int,
    indirect: Ptr,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.GL46.glMultiDrawArraysIndirectCount(mode, indirect, drawcount,
        maxdrawcount, stride)

public inline fun glMultiDrawArraysIndirectCount(
    mode: Int,
    indirect: Long,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.GL46.glMultiDrawArraysIndirectCount(mode, indirect, drawcount,
        maxdrawcount, stride)

public inline fun glMultiDrawElementsIndirectCount(
    mode: Int,
    type: Int,
    indirect: Ptr,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.GL46.glMultiDrawElementsIndirectCount(mode, type, indirect, drawcount,
        maxdrawcount, stride)

public inline fun glMultiDrawElementsIndirectCount(
    mode: Int,
    type: Int,
    indirect: Long,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.GL46.glMultiDrawElementsIndirectCount(mode, type, indirect, drawcount,
        maxdrawcount, stride)

public inline fun glPolygonOffsetClamp(
    factor: Float,
    units: Float,
    clamp: Float,
): Unit = GLWrapper.instance.GL46.glPolygonOffsetClamp(factor, units, clamp)

public inline fun glSpecializeShader(
    shader: Int,
    pEntryPoint: Ptr,
    numSpecializationConstants: Int,
    pConstantIndex: Ptr,
    pConstantValue: Ptr,
): Unit = GLWrapper.instance.GL46.glSpecializeShader(shader, pEntryPoint,
        numSpecializationConstants, pConstantIndex, pConstantValue)

public inline fun glSpecializeShader(
    shader: Int,
    pEntryPoint: Long,
    numSpecializationConstants: Int,
    pConstantIndex: Long,
    pConstantValue: Long,
): Unit = GLWrapper.instance.GL46.glSpecializeShader(shader, pEntryPoint,
        numSpecializationConstants, pConstantIndex, pConstantValue)
