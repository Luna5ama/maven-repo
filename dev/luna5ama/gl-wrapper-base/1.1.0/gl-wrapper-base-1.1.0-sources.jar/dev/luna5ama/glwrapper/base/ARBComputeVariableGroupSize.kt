@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface ARBComputeVariableGroupSize : GLBase {
    public fun glDispatchComputeGroupSizeARB(
        num_groups_x: Int,
        num_groups_y: Int,
        num_groups_z: Int,
        group_size_x: Int,
        group_size_y: Int,
        group_size_z: Int,
    )
}

public const val GL_MAX_COMPUTE_VARIABLE_GROUP_INVOCATIONS_ARB: Int = 37_700

public const val GL_MAX_COMPUTE_FIXED_GROUP_INVOCATIONS_ARB: Int = 37_099

public const val GL_MAX_COMPUTE_VARIABLE_GROUP_SIZE_ARB: Int = 37_701

public const val GL_MAX_COMPUTE_FIXED_GROUP_SIZE_ARB: Int = 37_311

public inline fun glDispatchComputeGroupSizeARB(
    num_groups_x: Int,
    num_groups_y: Int,
    num_groups_z: Int,
    group_size_x: Int,
    group_size_y: Int,
    group_size_z: Int,
): Unit = GLWrapper.instance.ARBComputeVariableGroupSize.glDispatchComputeGroupSizeARB(num_groups_x,
        num_groups_y, num_groups_z, group_size_x, group_size_y, group_size_z)
