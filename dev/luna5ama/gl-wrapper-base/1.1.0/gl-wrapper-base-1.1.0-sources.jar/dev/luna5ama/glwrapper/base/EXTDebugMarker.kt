@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTDebugMarker : GLBase {
    @PtrParameter([1])
    public fun glInsertEventMarkerEXT(length: Int, marker: Ptr)

    @Unsafe
    public fun glInsertEventMarkerEXT(length: Int, marker: Long)

    @PtrParameter([1])
    public fun glPushGroupMarkerEXT(length: Int, marker: Ptr)

    @Unsafe
    public fun glPushGroupMarkerEXT(length: Int, marker: Long)

    public fun glPopGroupMarkerEXT()
}

public inline fun glInsertEventMarkerEXT(length: Int, marker: Ptr): Unit =
        GLWrapper.instance.EXTDebugMarker.glInsertEventMarkerEXT(length, marker)

public inline fun glInsertEventMarkerEXT(length: Int, marker: Long): Unit =
        GLWrapper.instance.EXTDebugMarker.glInsertEventMarkerEXT(length, marker)

public inline fun glPushGroupMarkerEXT(length: Int, marker: Ptr): Unit =
        GLWrapper.instance.EXTDebugMarker.glPushGroupMarkerEXT(length, marker)

public inline fun glPushGroupMarkerEXT(length: Int, marker: Long): Unit =
        GLWrapper.instance.EXTDebugMarker.glPushGroupMarkerEXT(length, marker)

public inline fun glPopGroupMarkerEXT(): Unit =
        GLWrapper.instance.EXTDebugMarker.glPopGroupMarkerEXT()
