@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface ARBHalfFloatPixel : GLBase

public const val GL_HALF_FLOAT_ARB: Int = 5_131
