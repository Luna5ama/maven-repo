@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL14 : GLBase {
    public fun glBlendColor(
        red: Float,
        green: Float,
        blue: Float,
        alpha: Float,
    )

    public fun glBlendEquation(mode: Int)

    @PtrParameter([1, 2])
    public fun glMultiDrawArrays(
        mode: Int,
        first: Ptr,
        count: Ptr,
        drawcount: Int,
    )

    @Unsafe
    public fun glMultiDrawArrays(
        mode: Int,
        first: Long,
        count: Long,
        drawcount: Int,
    )

    @PtrParameter([1, 3])
    public fun glMultiDrawElements(
        mode: Int,
        count: Ptr,
        type: Int,
        indices: Ptr,
        drawcount: Int,
    )

    @Unsafe
    public fun glMultiDrawElements(
        mode: Int,
        count: Long,
        type: Int,
        indices: Long,
        drawcount: Int,
    )

    public fun glPointParameterf(pname: Int, `param`: Float)

    public fun glPointParameteri(pname: Int, `param`: Int)

    @PtrParameter([1])
    public fun glPointParameterfv(pname: Int, params: Ptr)

    @Unsafe
    public fun glPointParameterfv(pname: Int, params: Long)

    @PtrParameter([1])
    public fun glPointParameteriv(pname: Int, params: Ptr)

    @Unsafe
    public fun glPointParameteriv(pname: Int, params: Long)

    public fun glBlendFuncSeparate(
        sfactorRGB: Int,
        dfactorRGB: Int,
        sfactorAlpha: Int,
        dfactorAlpha: Int,
    )
}

public const val GL_CONSTANT_COLOR: Int = 32_769

public const val GL_ONE_MINUS_CONSTANT_COLOR: Int = 32_770

public const val GL_CONSTANT_ALPHA: Int = 32_771

public const val GL_ONE_MINUS_CONSTANT_ALPHA: Int = 32_772

public const val GL_FUNC_ADD: Int = 32_774

public const val GL_MIN: Int = 32_775

public const val GL_MAX: Int = 32_776

public const val GL_FUNC_SUBTRACT: Int = 32_778

public const val GL_FUNC_REVERSE_SUBTRACT: Int = 32_779

public const val GL_DEPTH_COMPONENT16: Int = 33_189

public const val GL_DEPTH_COMPONENT24: Int = 33_190

public const val GL_DEPTH_COMPONENT32: Int = 33_191

public const val GL_TEXTURE_DEPTH_SIZE: Int = 34_890

public const val GL_TEXTURE_COMPARE_MODE: Int = 34_892

public const val GL_TEXTURE_COMPARE_FUNC: Int = 34_893

public const val GL_POINT_FADE_THRESHOLD_SIZE: Int = 33_064

public const val GL_BLEND_DST_RGB: Int = 32_968

public const val GL_BLEND_SRC_RGB: Int = 32_969

public const val GL_BLEND_DST_ALPHA: Int = 32_970

public const val GL_BLEND_SRC_ALPHA: Int = 32_971

public const val GL_INCR_WRAP: Int = 34_055

public const val GL_DECR_WRAP: Int = 34_056

public const val GL_TEXTURE_LOD_BIAS: Int = 34_049

public const val GL_MAX_TEXTURE_LOD_BIAS: Int = 34_045

public const val GL_MIRRORED_REPEAT: Int = 33_648

public inline fun glBlendColor(
    red: Float,
    green: Float,
    blue: Float,
    alpha: Float,
): Unit = GLWrapper.instance.GL14.glBlendColor(red, green, blue, alpha)

public inline fun glBlendEquation(mode: Int): Unit = GLWrapper.instance.GL14.glBlendEquation(mode)

public inline fun glMultiDrawArrays(
    mode: Int,
    first: Ptr,
    count: Ptr,
    drawcount: Int,
): Unit = GLWrapper.instance.GL14.glMultiDrawArrays(mode, first, count, drawcount)

public inline fun glMultiDrawArrays(
    mode: Int,
    first: Long,
    count: Long,
    drawcount: Int,
): Unit = GLWrapper.instance.GL14.glMultiDrawArrays(mode, first, count, drawcount)

public inline fun glMultiDrawElements(
    mode: Int,
    count: Ptr,
    type: Int,
    indices: Ptr,
    drawcount: Int,
): Unit = GLWrapper.instance.GL14.glMultiDrawElements(mode, count, type, indices, drawcount)

public inline fun glMultiDrawElements(
    mode: Int,
    count: Long,
    type: Int,
    indices: Long,
    drawcount: Int,
): Unit = GLWrapper.instance.GL14.glMultiDrawElements(mode, count, type, indices, drawcount)

public inline fun glPointParameterf(pname: Int, `param`: Float): Unit =
        GLWrapper.instance.GL14.glPointParameterf(pname, `param`)

public inline fun glPointParameteri(pname: Int, `param`: Int): Unit =
        GLWrapper.instance.GL14.glPointParameteri(pname, `param`)

public inline fun glPointParameterfv(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.GL14.glPointParameterfv(pname, params)

public inline fun glPointParameterfv(pname: Int, params: Long): Unit =
        GLWrapper.instance.GL14.glPointParameterfv(pname, params)

public inline fun glPointParameteriv(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.GL14.glPointParameteriv(pname, params)

public inline fun glPointParameteriv(pname: Int, params: Long): Unit =
        GLWrapper.instance.GL14.glPointParameteriv(pname, params)

public inline fun glBlendFuncSeparate(
    sfactorRGB: Int,
    dfactorRGB: Int,
    sfactorAlpha: Int,
    dfactorAlpha: Int,
): Unit = GLWrapper.instance.GL14.glBlendFuncSeparate(sfactorRGB, dfactorRGB, sfactorAlpha,
        dfactorAlpha)
