@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTDirectStateAccess : GLBase {
    public fun glClientAttribDefaultEXT(mask: Int)

    public fun glPushClientAttribDefaultEXT(mask: Int)

    @PtrParameter([1])
    public fun glMatrixLoadfEXT(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixLoadfEXT(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixLoaddEXT(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixLoaddEXT(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixMultfEXT(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixMultfEXT(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixMultdEXT(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixMultdEXT(matrixMode: Int, m: Long)

    public fun glMatrixLoadIdentityEXT(matrixMode: Int)

    public fun glMatrixRotatefEXT(
        matrixMode: Int,
        angle: Float,
        x: Float,
        y: Float,
        z: Float,
    )

    public fun glMatrixRotatedEXT(
        matrixMode: Int,
        angle: Double,
        x: Double,
        y: Double,
        z: Double,
    )

    public fun glMatrixScalefEXT(
        matrixMode: Int,
        x: Float,
        y: Float,
        z: Float,
    )

    public fun glMatrixScaledEXT(
        matrixMode: Int,
        x: Double,
        y: Double,
        z: Double,
    )

    public fun glMatrixTranslatefEXT(
        matrixMode: Int,
        x: Float,
        y: Float,
        z: Float,
    )

    public fun glMatrixTranslatedEXT(
        matrixMode: Int,
        x: Double,
        y: Double,
        z: Double,
    )

    public fun glMatrixOrthoEXT(
        matrixMode: Int,
        l: Double,
        r: Double,
        b: Double,
        t: Double,
        n: Double,
        f: Double,
    )

    public fun glMatrixFrustumEXT(
        matrixMode: Int,
        l: Double,
        r: Double,
        b: Double,
        t: Double,
        n: Double,
        f: Double,
    )

    public fun glMatrixPushEXT(matrixMode: Int)

    public fun glMatrixPopEXT(matrixMode: Int)

    public fun glTextureParameteriEXT(
        texture: Int,
        target: Int,
        pname: Int,
        `param`: Int,
    )

    @PtrParameter([3])
    public fun glTextureParameterivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glTextureParameterivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        `param`: Long,
    )

    public fun glTextureParameterfEXT(
        texture: Int,
        target: Int,
        pname: Int,
        `param`: Float,
    )

    @PtrParameter([3])
    public fun glTextureParameterfvEXT(
        texture: Int,
        target: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glTextureParameterfvEXT(
        texture: Int,
        target: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrParameter([8])
    public fun glTextureImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTextureImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([9])
    public fun glTextureImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTextureImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([7])
    public fun glTextureSubImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTextureSubImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([9])
    public fun glTextureSubImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTextureSubImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    public fun glCopyTextureImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        x: Int,
        y: Int,
        width: Int,
        border: Int,
    )

    public fun glCopyTextureImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        border: Int,
    )

    public fun glCopyTextureSubImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        x: Int,
        y: Int,
        width: Int,
    )

    public fun glCopyTextureSubImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([5])
    public fun glGetTextureImageEXT(
        texture: Int,
        target: Int,
        level: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glGetTextureImageEXT(
        texture: Int,
        target: Int,
        level: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([3])
    public fun glGetTextureParameterfvEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureParameterfvEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetTextureParameterivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureParameterivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([4])
    public fun glGetTextureLevelParameterfvEXT(
        texture: Int,
        target: Int,
        level: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureLevelParameterfvEXT(
        texture: Int,
        target: Int,
        level: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([4])
    public fun glGetTextureLevelParameterivEXT(
        texture: Int,
        target: Int,
        level: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureLevelParameterivEXT(
        texture: Int,
        target: Int,
        level: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([10])
    public fun glTextureImage3DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTextureImage3DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([11])
    public fun glTextureSubImage3DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTextureSubImage3DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    public fun glCopyTextureSubImage3DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    public fun glBindMultiTextureEXT(
        texunit: Int,
        target: Int,
        texture: Int,
    )

    @PtrParameter([4])
    public fun glMultiTexCoordPointerEXT(
        texunit: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glMultiTexCoordPointerEXT(
        texunit: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Long,
    )

    public fun glMultiTexEnvfEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        `param`: Float,
    )

    @PtrParameter([3])
    public fun glMultiTexEnvfvEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMultiTexEnvfvEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glMultiTexEnviEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        `param`: Int,
    )

    @PtrParameter([3])
    public fun glMultiTexEnvivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMultiTexEnvivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glMultiTexGendEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        `param`: Double,
    )

    @PtrParameter([3])
    public fun glMultiTexGendvEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMultiTexGendvEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Long,
    )

    public fun glMultiTexGenfEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        `param`: Float,
    )

    @PtrParameter([3])
    public fun glMultiTexGenfvEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMultiTexGenfvEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Long,
    )

    public fun glMultiTexGeniEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        `param`: Int,
    )

    @PtrParameter([3])
    public fun glMultiTexGenivEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMultiTexGenivEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetMultiTexEnvfvEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexEnvfvEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetMultiTexEnvivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexEnvivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetMultiTexGendvEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexGendvEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetMultiTexGenfvEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexGenfvEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetMultiTexGenivEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexGenivEXT(
        texunit: Int,
        coord: Int,
        pname: Int,
        params: Long,
    )

    public fun glMultiTexParameteriEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        `param`: Int,
    )

    @PtrParameter([3])
    public fun glMultiTexParameterivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glMultiTexParameterivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        `param`: Long,
    )

    public fun glMultiTexParameterfEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        `param`: Float,
    )

    @PtrParameter([3])
    public fun glMultiTexParameterfvEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glMultiTexParameterfvEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrParameter([8])
    public fun glMultiTexImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glMultiTexImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([9])
    public fun glMultiTexImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glMultiTexImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([7])
    public fun glMultiTexSubImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glMultiTexSubImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([9])
    public fun glMultiTexSubImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glMultiTexSubImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    public fun glCopyMultiTexImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        x: Int,
        y: Int,
        width: Int,
        border: Int,
    )

    public fun glCopyMultiTexImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        border: Int,
    )

    public fun glCopyMultiTexSubImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        x: Int,
        y: Int,
        width: Int,
    )

    public fun glCopyMultiTexSubImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([5])
    public fun glGetMultiTexImageEXT(
        texunit: Int,
        target: Int,
        level: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexImageEXT(
        texunit: Int,
        target: Int,
        level: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([3])
    public fun glGetMultiTexParameterfvEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexParameterfvEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetMultiTexParameterivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexParameterivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([4])
    public fun glGetMultiTexLevelParameterfvEXT(
        texunit: Int,
        target: Int,
        level: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexLevelParameterfvEXT(
        texunit: Int,
        target: Int,
        level: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([4])
    public fun glGetMultiTexLevelParameterivEXT(
        texunit: Int,
        target: Int,
        level: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexLevelParameterivEXT(
        texunit: Int,
        target: Int,
        level: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([10])
    public fun glMultiTexImage3DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glMultiTexImage3DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([11])
    public fun glMultiTexSubImage3DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glMultiTexSubImage3DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    public fun glCopyMultiTexSubImage3DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    public fun glEnableClientStateIndexedEXT(array: Int, index: Int)

    public fun glDisableClientStateIndexedEXT(array: Int, index: Int)

    public fun glEnableClientStateiEXT(array: Int, index: Int)

    public fun glDisableClientStateiEXT(array: Int, index: Int)

    @PtrParameter([2])
    public fun glGetFloatIndexedvEXT(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetFloatIndexedvEXT(
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetDoubleIndexedvEXT(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetDoubleIndexedvEXT(
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetPointerIndexedvEXT(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetPointerIndexedvEXT(
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetFloati_vEXT(
        pname: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetFloati_vEXT(
        pname: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetDoublei_vEXT(
        pname: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetDoublei_vEXT(
        pname: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetPointeri_vEXT(
        pname: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetPointeri_vEXT(
        pname: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetIntegerIndexedvEXT(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetIntegerIndexedvEXT(
        target: Int,
        index: Int,
        `data`: Long,
    )

    @PtrParameter([2])
    public fun glGetBooleanIndexedvEXT(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetBooleanIndexedvEXT(
        target: Int,
        index: Int,
        `data`: Long,
    )

    @PtrParameter([4])
    public fun glNamedProgramStringEXT(
        program: Int,
        target: Int,
        format: Int,
        len: Int,
        string: Ptr,
    )

    @Unsafe
    public fun glNamedProgramStringEXT(
        program: Int,
        target: Int,
        format: Int,
        len: Int,
        string: Long,
    )

    public fun glNamedProgramLocalParameter4dEXT(
        program: Int,
        target: Int,
        index: Int,
        x: Double,
        y: Double,
        z: Double,
        w: Double,
    )

    @PtrParameter([3])
    public fun glNamedProgramLocalParameter4dvEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glNamedProgramLocalParameter4dvEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Long,
    )

    public fun glNamedProgramLocalParameter4fEXT(
        program: Int,
        target: Int,
        index: Int,
        x: Float,
        y: Float,
        z: Float,
        w: Float,
    )

    @PtrParameter([3])
    public fun glNamedProgramLocalParameter4fvEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glNamedProgramLocalParameter4fvEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetNamedProgramLocalParameterdvEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedProgramLocalParameterdvEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetNamedProgramLocalParameterfvEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedProgramLocalParameterfvEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetNamedProgramivEXT(
        program: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedProgramivEXT(
        program: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetNamedProgramStringEXT(
        program: Int,
        target: Int,
        pname: Int,
        string: Ptr,
    )

    @Unsafe
    public fun glGetNamedProgramStringEXT(
        program: Int,
        target: Int,
        pname: Int,
        string: Long,
    )

    @PtrParameter([9])
    public fun glCompressedTextureImage3DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTextureImage3DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([8])
    public fun glCompressedTextureImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTextureImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([7])
    public fun glCompressedTextureImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTextureImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([11])
    public fun glCompressedTextureSubImage3DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTextureSubImage3DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([9])
    public fun glCompressedTextureSubImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTextureSubImage2DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([7])
    public fun glCompressedTextureSubImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTextureSubImage1DEXT(
        texture: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([3])
    public fun glGetCompressedTextureImageEXT(
        texture: Int,
        target: Int,
        level: Int,
        img: Ptr,
    )

    @Unsafe
    public fun glGetCompressedTextureImageEXT(
        texture: Int,
        target: Int,
        level: Int,
        img: Long,
    )

    @PtrParameter([9])
    public fun glCompressedMultiTexImage3DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedMultiTexImage3DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([8])
    public fun glCompressedMultiTexImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedMultiTexImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([7])
    public fun glCompressedMultiTexImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedMultiTexImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([11])
    public fun glCompressedMultiTexSubImage3DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedMultiTexSubImage3DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([9])
    public fun glCompressedMultiTexSubImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedMultiTexSubImage2DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([7])
    public fun glCompressedMultiTexSubImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedMultiTexSubImage1DEXT(
        texunit: Int,
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([3])
    public fun glGetCompressedMultiTexImageEXT(
        texunit: Int,
        target: Int,
        level: Int,
        img: Ptr,
    )

    @Unsafe
    public fun glGetCompressedMultiTexImageEXT(
        texunit: Int,
        target: Int,
        level: Int,
        img: Long,
    )

    @PtrParameter([1])
    public fun glMatrixLoadTransposefEXT(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixLoadTransposefEXT(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixLoadTransposedEXT(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixLoadTransposedEXT(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixMultTransposefEXT(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixMultTransposefEXT(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixMultTransposedEXT(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixMultTransposedEXT(matrixMode: Int, m: Long)

    @PtrParameter([2])
    public fun glNamedBufferDataEXT(
        buffer: Int,
        size: Long,
        `data`: Ptr,
        usage: Int,
    )

    @Unsafe
    public fun glNamedBufferDataEXT(
        buffer: Int,
        size: Long,
        `data`: Long,
        usage: Int,
    )

    @PtrParameter([3])
    public fun glNamedBufferSubDataEXT(
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Ptr,
    )

    @Unsafe
    public fun glNamedBufferSubDataEXT(
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Long,
    )

    @PtrReturn
    public fun glMapNamedBufferEXT(buffer: Int, access: Int): Ptr

    public fun glUnmapNamedBufferEXT(buffer: Int): Boolean

    @PtrParameter([2])
    public fun glGetNamedBufferParameterivEXT(
        buffer: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedBufferParameterivEXT(
        buffer: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetNamedBufferSubDataEXT(
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetNamedBufferSubDataEXT(
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Long,
    )

    public fun glProgramUniform1fEXT(
        program: Int,
        location: Int,
        v0: Float,
    )

    public fun glProgramUniform2fEXT(
        program: Int,
        location: Int,
        v0: Float,
        v1: Float,
    )

    public fun glProgramUniform3fEXT(
        program: Int,
        location: Int,
        v0: Float,
        v1: Float,
        v2: Float,
    )

    public fun glProgramUniform4fEXT(
        program: Int,
        location: Int,
        v0: Float,
        v1: Float,
        v2: Float,
        v3: Float,
    )

    public fun glProgramUniform1iEXT(
        program: Int,
        location: Int,
        v0: Int,
    )

    public fun glProgramUniform2iEXT(
        program: Int,
        location: Int,
        v0: Int,
        v1: Int,
    )

    public fun glProgramUniform3iEXT(
        program: Int,
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
    )

    public fun glProgramUniform4iEXT(
        program: Int,
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
        v3: Int,
    )

    @PtrParameter([3])
    public fun glProgramUniform1fvEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1fvEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2fvEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2fvEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3fvEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3fvEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4fvEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4fvEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1ivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1ivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2ivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2ivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3ivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3ivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4ivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4ivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix2fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix2fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix3fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix3fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix4fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix4fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix2x3fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix2x3fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix3x2fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix3x2fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix2x4fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix2x4fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix4x2fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix4x2fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix3x4fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix3x4fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glProgramUniformMatrix4x3fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniformMatrix4x3fvEXT(
        program: Int,
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    public fun glTextureBufferEXT(
        texture: Int,
        target: Int,
        internalformat: Int,
        buffer: Int,
    )

    public fun glMultiTexBufferEXT(
        texunit: Int,
        target: Int,
        internalformat: Int,
        buffer: Int,
    )

    @PtrParameter([3])
    public fun glTextureParameterIivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTextureParameterIivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glTextureParameterIuivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTextureParameterIuivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetTextureParameterIivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureParameterIivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetTextureParameterIuivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureParameterIuivEXT(
        texture: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glMultiTexParameterIivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMultiTexParameterIivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glMultiTexParameterIuivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMultiTexParameterIuivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetMultiTexParameterIivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexParameterIivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetMultiTexParameterIuivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMultiTexParameterIuivEXT(
        texunit: Int,
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glProgramUniform1uiEXT(
        program: Int,
        location: Int,
        v0: Int,
    )

    public fun glProgramUniform2uiEXT(
        program: Int,
        location: Int,
        v0: Int,
        v1: Int,
    )

    public fun glProgramUniform3uiEXT(
        program: Int,
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
    )

    public fun glProgramUniform4uiEXT(
        program: Int,
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
        v3: Int,
    )

    @PtrParameter([3])
    public fun glProgramUniform1uivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1uivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2uivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2uivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3uivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3uivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4uivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4uivEXT(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([4])
    public fun glNamedProgramLocalParameters4fvEXT(
        program: Int,
        target: Int,
        index: Int,
        count: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glNamedProgramLocalParameters4fvEXT(
        program: Int,
        target: Int,
        index: Int,
        count: Int,
        params: Long,
    )

    public fun glNamedProgramLocalParameterI4iEXT(
        program: Int,
        target: Int,
        index: Int,
        x: Int,
        y: Int,
        z: Int,
        w: Int,
    )

    @PtrParameter([3])
    public fun glNamedProgramLocalParameterI4ivEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glNamedProgramLocalParameterI4ivEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([4])
    public fun glNamedProgramLocalParametersI4ivEXT(
        program: Int,
        target: Int,
        index: Int,
        count: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glNamedProgramLocalParametersI4ivEXT(
        program: Int,
        target: Int,
        index: Int,
        count: Int,
        params: Long,
    )

    public fun glNamedProgramLocalParameterI4uiEXT(
        program: Int,
        target: Int,
        index: Int,
        x: Int,
        y: Int,
        z: Int,
        w: Int,
    )

    @PtrParameter([3])
    public fun glNamedProgramLocalParameterI4uivEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glNamedProgramLocalParameterI4uivEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([4])
    public fun glNamedProgramLocalParametersI4uivEXT(
        program: Int,
        target: Int,
        index: Int,
        count: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glNamedProgramLocalParametersI4uivEXT(
        program: Int,
        target: Int,
        index: Int,
        count: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetNamedProgramLocalParameterIivEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedProgramLocalParameterIivEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetNamedProgramLocalParameterIuivEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedProgramLocalParameterIuivEXT(
        program: Int,
        target: Int,
        index: Int,
        params: Long,
    )

    public fun glNamedRenderbufferStorageEXT(
        renderbuffer: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([2])
    public fun glGetNamedRenderbufferParameterivEXT(
        renderbuffer: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedRenderbufferParameterivEXT(
        renderbuffer: Int,
        pname: Int,
        params: Long,
    )

    public fun glNamedRenderbufferStorageMultisampleEXT(
        renderbuffer: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    public fun glNamedRenderbufferStorageMultisampleCoverageEXT(
        renderbuffer: Int,
        coverageSamples: Int,
        colorSamples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    public fun glCheckNamedFramebufferStatusEXT(framebuffer: Int, target: Int): Int

    public fun glNamedFramebufferTexture1DEXT(
        framebuffer: Int,
        attachment: Int,
        textarget: Int,
        texture: Int,
        level: Int,
    )

    public fun glNamedFramebufferTexture2DEXT(
        framebuffer: Int,
        attachment: Int,
        textarget: Int,
        texture: Int,
        level: Int,
    )

    public fun glNamedFramebufferTexture3DEXT(
        framebuffer: Int,
        attachment: Int,
        textarget: Int,
        texture: Int,
        level: Int,
        zoffset: Int,
    )

    public fun glNamedFramebufferRenderbufferEXT(
        framebuffer: Int,
        attachment: Int,
        renderbuffertarget: Int,
        renderbuffer: Int,
    )

    @PtrParameter([3])
    public fun glGetNamedFramebufferAttachmentParameterivEXT(
        framebuffer: Int,
        attachment: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedFramebufferAttachmentParameterivEXT(
        framebuffer: Int,
        attachment: Int,
        pname: Int,
        params: Long,
    )

    public fun glGenerateTextureMipmapEXT(texture: Int, target: Int)

    public fun glGenerateMultiTexMipmapEXT(texunit: Int, target: Int)

    public fun glFramebufferDrawBufferEXT(framebuffer: Int, mode: Int)

    @PtrParameter([2])
    public fun glFramebufferDrawBuffersEXT(
        framebuffer: Int,
        n: Int,
        bufs: Ptr,
    )

    @Unsafe
    public fun glFramebufferDrawBuffersEXT(
        framebuffer: Int,
        n: Int,
        bufs: Long,
    )

    public fun glFramebufferReadBufferEXT(framebuffer: Int, mode: Int)

    @PtrParameter([2])
    public fun glGetFramebufferParameterivEXT(
        framebuffer: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetFramebufferParameterivEXT(
        framebuffer: Int,
        pname: Int,
        `param`: Long,
    )

    public fun glNamedCopyBufferSubDataEXT(
        readBuffer: Int,
        writeBuffer: Int,
        readOffset: Long,
        writeOffset: Long,
        size: Long,
    )

    public fun glNamedFramebufferTextureEXT(
        framebuffer: Int,
        attachment: Int,
        texture: Int,
        level: Int,
    )

    public fun glNamedFramebufferTextureLayerEXT(
        framebuffer: Int,
        attachment: Int,
        texture: Int,
        level: Int,
        layer: Int,
    )

    public fun glNamedFramebufferTextureFaceEXT(
        framebuffer: Int,
        attachment: Int,
        texture: Int,
        level: Int,
        face: Int,
    )

    public fun glTextureRenderbufferEXT(
        texture: Int,
        target: Int,
        renderbuffer: Int,
    )

    public fun glMultiTexRenderbufferEXT(
        texunit: Int,
        target: Int,
        renderbuffer: Int,
    )

    public fun glVertexArrayVertexOffsetEXT(
        vaobj: Int,
        buffer: Int,
        size: Int,
        type: Int,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArrayColorOffsetEXT(
        vaobj: Int,
        buffer: Int,
        size: Int,
        type: Int,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArrayEdgeFlagOffsetEXT(
        vaobj: Int,
        buffer: Int,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArrayIndexOffsetEXT(
        vaobj: Int,
        buffer: Int,
        type: Int,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArrayNormalOffsetEXT(
        vaobj: Int,
        buffer: Int,
        type: Int,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArrayTexCoordOffsetEXT(
        vaobj: Int,
        buffer: Int,
        size: Int,
        type: Int,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArrayMultiTexCoordOffsetEXT(
        vaobj: Int,
        buffer: Int,
        texunit: Int,
        size: Int,
        type: Int,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArrayFogCoordOffsetEXT(
        vaobj: Int,
        buffer: Int,
        type: Int,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArraySecondaryColorOffsetEXT(
        vaobj: Int,
        buffer: Int,
        size: Int,
        type: Int,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArrayVertexAttribOffsetEXT(
        vaobj: Int,
        buffer: Int,
        index: Int,
        size: Int,
        type: Int,
        normalized: Boolean,
        stride: Int,
        offset: Long,
    )

    public fun glVertexArrayVertexAttribIOffsetEXT(
        vaobj: Int,
        buffer: Int,
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
        offset: Long,
    )

    public fun glEnableVertexArrayEXT(vaobj: Int, array: Int)

    public fun glDisableVertexArrayEXT(vaobj: Int, array: Int)

    public fun glEnableVertexArrayAttribEXT(vaobj: Int, index: Int)

    public fun glDisableVertexArrayAttribEXT(vaobj: Int, index: Int)

    @PtrParameter([2])
    public fun glGetVertexArrayIntegervEXT(
        vaobj: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetVertexArrayIntegervEXT(
        vaobj: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexArrayPointervEXT(
        vaobj: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetVertexArrayPointervEXT(
        vaobj: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrParameter([3])
    public fun glGetVertexArrayIntegeri_vEXT(
        vaobj: Int,
        index: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetVertexArrayIntegeri_vEXT(
        vaobj: Int,
        index: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrParameter([3])
    public fun glGetVertexArrayPointeri_vEXT(
        vaobj: Int,
        index: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetVertexArrayPointeri_vEXT(
        vaobj: Int,
        index: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrReturn
    public fun glMapNamedBufferRangeEXT(
        buffer: Int,
        offset: Long,
        length: Long,
        access: Int,
    ): Ptr

    public fun glFlushMappedNamedBufferRangeEXT(
        buffer: Int,
        offset: Long,
        length: Long,
    )
}

public const val GL_PROGRAM_MATRIX_EXT: Int = 36_397

public const val GL_TRANSPOSE_PROGRAM_MATRIX_EXT: Int = 36_398

public const val GL_PROGRAM_MATRIX_STACK_DEPTH_EXT: Int = 36_399

public inline fun glClientAttribDefaultEXT(mask: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glClientAttribDefaultEXT(mask)

public inline fun glPushClientAttribDefaultEXT(mask: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glPushClientAttribDefaultEXT(mask)

public inline fun glMatrixLoadfEXT(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixLoadfEXT(matrixMode, m)

public inline fun glMatrixLoadfEXT(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixLoadfEXT(matrixMode, m)

public inline fun glMatrixLoaddEXT(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixLoaddEXT(matrixMode, m)

public inline fun glMatrixLoaddEXT(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixLoaddEXT(matrixMode, m)

public inline fun glMatrixMultfEXT(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixMultfEXT(matrixMode, m)

public inline fun glMatrixMultfEXT(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixMultfEXT(matrixMode, m)

public inline fun glMatrixMultdEXT(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixMultdEXT(matrixMode, m)

public inline fun glMatrixMultdEXT(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixMultdEXT(matrixMode, m)

public inline fun glMatrixLoadIdentityEXT(matrixMode: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixLoadIdentityEXT(matrixMode)

public inline fun glMatrixRotatefEXT(
    matrixMode: Int,
    angle: Float,
    x: Float,
    y: Float,
    z: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMatrixRotatefEXT(matrixMode, angle, x, y, z)

public inline fun glMatrixRotatedEXT(
    matrixMode: Int,
    angle: Double,
    x: Double,
    y: Double,
    z: Double,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMatrixRotatedEXT(matrixMode, angle, x, y, z)

public inline fun glMatrixScalefEXT(
    matrixMode: Int,
    x: Float,
    y: Float,
    z: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMatrixScalefEXT(matrixMode, x, y, z)

public inline fun glMatrixScaledEXT(
    matrixMode: Int,
    x: Double,
    y: Double,
    z: Double,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMatrixScaledEXT(matrixMode, x, y, z)

public inline fun glMatrixTranslatefEXT(
    matrixMode: Int,
    x: Float,
    y: Float,
    z: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMatrixTranslatefEXT(matrixMode, x, y, z)

public inline fun glMatrixTranslatedEXT(
    matrixMode: Int,
    x: Double,
    y: Double,
    z: Double,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMatrixTranslatedEXT(matrixMode, x, y, z)

public inline fun glMatrixOrthoEXT(
    matrixMode: Int,
    l: Double,
    r: Double,
    b: Double,
    t: Double,
    n: Double,
    f: Double,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMatrixOrthoEXT(matrixMode, l, r, b, t, n, f)

public inline fun glMatrixFrustumEXT(
    matrixMode: Int,
    l: Double,
    r: Double,
    b: Double,
    t: Double,
    n: Double,
    f: Double,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMatrixFrustumEXT(matrixMode, l, r, b, t, n, f)

public inline fun glMatrixPushEXT(matrixMode: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixPushEXT(matrixMode)

public inline fun glMatrixPopEXT(matrixMode: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixPopEXT(matrixMode)

public inline fun glTextureParameteriEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameteriEXT(texture, target, pname,
        `param`)

public inline fun glTextureParameterivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameterivEXT(texture, target, pname,
        `param`)

public inline fun glTextureParameterivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameterivEXT(texture, target, pname,
        `param`)

public inline fun glTextureParameterfEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameterfEXT(texture, target, pname,
        `param`)

public inline fun glTextureParameterfvEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameterfvEXT(texture, target, pname,
        `param`)

public inline fun glTextureParameterfvEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameterfvEXT(texture, target, pname,
        `param`)

public inline fun glTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureImage1DEXT(texture, target, level,
        internalformat, width, border, format, type, pixels)

public inline fun glTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureImage1DEXT(texture, target, level,
        internalformat, width, border, format, type, pixels)

public inline fun glTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureImage2DEXT(texture, target, level,
        internalformat, width, height, border, format, type, pixels)

public inline fun glTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureImage2DEXT(texture, target, level,
        internalformat, width, height, border, format, type, pixels)

public inline fun glTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureSubImage1DEXT(texture, target, level,
        xoffset, width, format, type, pixels)

public inline fun glTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureSubImage1DEXT(texture, target, level,
        xoffset, width, format, type, pixels)

public inline fun glTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureSubImage2DEXT(texture, target, level,
        xoffset, yoffset, width, height, format, type, pixels)

public inline fun glTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureSubImage2DEXT(texture, target, level,
        xoffset, yoffset, width, height, format, type, pixels)

public inline fun glCopyTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    border: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyTextureImage1DEXT(texture, target, level,
        internalformat, x, y, width, border)

public inline fun glCopyTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    border: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyTextureImage2DEXT(texture, target, level,
        internalformat, x, y, width, height, border)

public inline fun glCopyTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    x: Int,
    y: Int,
    width: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyTextureSubImage1DEXT(texture, target, level,
        xoffset, x, y, width)

public inline fun glCopyTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyTextureSubImage2DEXT(texture, target, level,
        xoffset, yoffset, x, y, width, height)

public inline fun glGetTextureImageEXT(
    texture: Int,
    target: Int,
    level: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureImageEXT(texture, target, level,
        format, type, pixels)

public inline fun glGetTextureImageEXT(
    texture: Int,
    target: Int,
    level: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureImageEXT(texture, target, level,
        format, type, pixels)

public inline fun glGetTextureParameterfvEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureParameterfvEXT(texture, target, pname,
        params)

public inline fun glGetTextureParameterfvEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureParameterfvEXT(texture, target, pname,
        params)

public inline fun glGetTextureParameterivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureParameterivEXT(texture, target, pname,
        params)

public inline fun glGetTextureParameterivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureParameterivEXT(texture, target, pname,
        params)

public inline fun glGetTextureLevelParameterfvEXT(
    texture: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureLevelParameterfvEXT(texture, target,
        level, pname, params)

public inline fun glGetTextureLevelParameterfvEXT(
    texture: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureLevelParameterfvEXT(texture, target,
        level, pname, params)

public inline fun glGetTextureLevelParameterivEXT(
    texture: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureLevelParameterivEXT(texture, target,
        level, pname, params)

public inline fun glGetTextureLevelParameterivEXT(
    texture: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureLevelParameterivEXT(texture, target,
        level, pname, params)

public inline fun glTextureImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureImage3DEXT(texture, target, level,
        internalformat, width, height, depth, border, format, type, pixels)

public inline fun glTextureImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureImage3DEXT(texture, target, level,
        internalformat, width, height, depth, border, format, type, pixels)

public inline fun glTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureSubImage3DEXT(texture, target, level,
        xoffset, yoffset, zoffset, width, height, depth, format, type, pixels)

public inline fun glTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureSubImage3DEXT(texture, target, level,
        xoffset, yoffset, zoffset, width, height, depth, format, type, pixels)

public inline fun glCopyTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyTextureSubImage3DEXT(texture, target, level,
        xoffset, yoffset, zoffset, x, y, width, height)

public inline fun glBindMultiTextureEXT(
    texunit: Int,
    target: Int,
    texture: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glBindMultiTextureEXT(texunit, target, texture)

public inline fun glMultiTexCoordPointerEXT(
    texunit: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexCoordPointerEXT(texunit, size, type,
        stride, pointer)

public inline fun glMultiTexCoordPointerEXT(
    texunit: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexCoordPointerEXT(texunit, size, type,
        stride, pointer)

public inline fun glMultiTexEnvfEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexEnvfEXT(texunit, target, pname, `param`)

public inline fun glMultiTexEnvfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexEnvfvEXT(texunit, target, pname, params)

public inline fun glMultiTexEnvfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexEnvfvEXT(texunit, target, pname, params)

public inline fun glMultiTexEnviEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexEnviEXT(texunit, target, pname, `param`)

public inline fun glMultiTexEnvivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexEnvivEXT(texunit, target, pname, params)

public inline fun glMultiTexEnvivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexEnvivEXT(texunit, target, pname, params)

public inline fun glMultiTexGendEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `param`: Double,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexGendEXT(texunit, coord, pname, `param`)

public inline fun glMultiTexGendvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexGendvEXT(texunit, coord, pname, params)

public inline fun glMultiTexGendvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexGendvEXT(texunit, coord, pname, params)

public inline fun glMultiTexGenfEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `param`: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexGenfEXT(texunit, coord, pname, `param`)

public inline fun glMultiTexGenfvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexGenfvEXT(texunit, coord, pname, params)

public inline fun glMultiTexGenfvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexGenfvEXT(texunit, coord, pname, params)

public inline fun glMultiTexGeniEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexGeniEXT(texunit, coord, pname, `param`)

public inline fun glMultiTexGenivEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexGenivEXT(texunit, coord, pname, params)

public inline fun glMultiTexGenivEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexGenivEXT(texunit, coord, pname, params)

public inline fun glGetMultiTexEnvfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexEnvfvEXT(texunit, target, pname,
        params)

public inline fun glGetMultiTexEnvfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexEnvfvEXT(texunit, target, pname,
        params)

public inline fun glGetMultiTexEnvivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexEnvivEXT(texunit, target, pname,
        params)

public inline fun glGetMultiTexEnvivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexEnvivEXT(texunit, target, pname,
        params)

public inline fun glGetMultiTexGendvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexGendvEXT(texunit, coord, pname,
        params)

public inline fun glGetMultiTexGendvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexGendvEXT(texunit, coord, pname,
        params)

public inline fun glGetMultiTexGenfvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexGenfvEXT(texunit, coord, pname,
        params)

public inline fun glGetMultiTexGenfvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexGenfvEXT(texunit, coord, pname,
        params)

public inline fun glGetMultiTexGenivEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexGenivEXT(texunit, coord, pname,
        params)

public inline fun glGetMultiTexGenivEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexGenivEXT(texunit, coord, pname,
        params)

public inline fun glMultiTexParameteriEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameteriEXT(texunit, target, pname,
        `param`)

public inline fun glMultiTexParameterivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameterivEXT(texunit, target, pname,
        `param`)

public inline fun glMultiTexParameterivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameterivEXT(texunit, target, pname,
        `param`)

public inline fun glMultiTexParameterfEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameterfEXT(texunit, target, pname,
        `param`)

public inline fun glMultiTexParameterfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameterfvEXT(texunit, target, pname,
        `param`)

public inline fun glMultiTexParameterfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameterfvEXT(texunit, target, pname,
        `param`)

public inline fun glMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexImage1DEXT(texunit, target, level,
        internalformat, width, border, format, type, pixels)

public inline fun glMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexImage1DEXT(texunit, target, level,
        internalformat, width, border, format, type, pixels)

public inline fun glMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexImage2DEXT(texunit, target, level,
        internalformat, width, height, border, format, type, pixels)

public inline fun glMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexImage2DEXT(texunit, target, level,
        internalformat, width, height, border, format, type, pixels)

public inline fun glMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexSubImage1DEXT(texunit, target, level,
        xoffset, width, format, type, pixels)

public inline fun glMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexSubImage1DEXT(texunit, target, level,
        xoffset, width, format, type, pixels)

public inline fun glMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexSubImage2DEXT(texunit, target, level,
        xoffset, yoffset, width, height, format, type, pixels)

public inline fun glMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexSubImage2DEXT(texunit, target, level,
        xoffset, yoffset, width, height, format, type, pixels)

public inline fun glCopyMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    border: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyMultiTexImage1DEXT(texunit, target, level,
        internalformat, x, y, width, border)

public inline fun glCopyMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    border: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyMultiTexImage2DEXT(texunit, target, level,
        internalformat, x, y, width, height, border)

public inline fun glCopyMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    x: Int,
    y: Int,
    width: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyMultiTexSubImage1DEXT(texunit, target,
        level, xoffset, x, y, width)

public inline fun glCopyMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyMultiTexSubImage2DEXT(texunit, target,
        level, xoffset, yoffset, x, y, width, height)

public inline fun glGetMultiTexImageEXT(
    texunit: Int,
    target: Int,
    level: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexImageEXT(texunit, target, level,
        format, type, pixels)

public inline fun glGetMultiTexImageEXT(
    texunit: Int,
    target: Int,
    level: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexImageEXT(texunit, target, level,
        format, type, pixels)

public inline fun glGetMultiTexParameterfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexParameterfvEXT(texunit, target,
        pname, params)

public inline fun glGetMultiTexParameterfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexParameterfvEXT(texunit, target,
        pname, params)

public inline fun glGetMultiTexParameterivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexParameterivEXT(texunit, target,
        pname, params)

public inline fun glGetMultiTexParameterivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexParameterivEXT(texunit, target,
        pname, params)

public inline fun glGetMultiTexLevelParameterfvEXT(
    texunit: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexLevelParameterfvEXT(texunit, target,
        level, pname, params)

public inline fun glGetMultiTexLevelParameterfvEXT(
    texunit: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexLevelParameterfvEXT(texunit, target,
        level, pname, params)

public inline fun glGetMultiTexLevelParameterivEXT(
    texunit: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexLevelParameterivEXT(texunit, target,
        level, pname, params)

public inline fun glGetMultiTexLevelParameterivEXT(
    texunit: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexLevelParameterivEXT(texunit, target,
        level, pname, params)

public inline fun glMultiTexImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexImage3DEXT(texunit, target, level,
        internalformat, width, height, depth, border, format, type, pixels)

public inline fun glMultiTexImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexImage3DEXT(texunit, target, level,
        internalformat, width, height, depth, border, format, type, pixels)

public inline fun glMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexSubImage3DEXT(texunit, target, level,
        xoffset, yoffset, zoffset, width, height, depth, format, type, pixels)

public inline fun glMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexSubImage3DEXT(texunit, target, level,
        xoffset, yoffset, zoffset, width, height, depth, format, type, pixels)

public inline fun glCopyMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCopyMultiTexSubImage3DEXT(texunit, target,
        level, xoffset, yoffset, zoffset, x, y, width, height)

public inline fun glEnableClientStateIndexedEXT(array: Int, index: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glEnableClientStateIndexedEXT(array, index)

public inline fun glDisableClientStateIndexedEXT(array: Int, index: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glDisableClientStateIndexedEXT(array, index)

public inline fun glEnableClientStateiEXT(array: Int, index: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glEnableClientStateiEXT(array, index)

public inline fun glDisableClientStateiEXT(array: Int, index: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glDisableClientStateiEXT(array, index)

public inline fun glGetFloatIndexedvEXT(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetFloatIndexedvEXT(target, index, params)

public inline fun glGetFloatIndexedvEXT(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetFloatIndexedvEXT(target, index, params)

public inline fun glGetDoubleIndexedvEXT(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetDoubleIndexedvEXT(target, index, params)

public inline fun glGetDoubleIndexedvEXT(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetDoubleIndexedvEXT(target, index, params)

public inline fun glGetPointerIndexedvEXT(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetPointerIndexedvEXT(target, index, params)

public inline fun glGetPointerIndexedvEXT(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetPointerIndexedvEXT(target, index, params)

public inline fun glGetFloati_vEXT(
    pname: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetFloati_vEXT(pname, index, params)

public inline fun glGetFloati_vEXT(
    pname: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetFloati_vEXT(pname, index, params)

public inline fun glGetDoublei_vEXT(
    pname: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetDoublei_vEXT(pname, index, params)

public inline fun glGetDoublei_vEXT(
    pname: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetDoublei_vEXT(pname, index, params)

public inline fun glGetPointeri_vEXT(
    pname: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetPointeri_vEXT(pname, index, params)

public inline fun glGetPointeri_vEXT(
    pname: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetPointeri_vEXT(pname, index, params)

public inline fun glGetIntegerIndexedvEXT(
    target: Int,
    index: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetIntegerIndexedvEXT(target, index, `data`)

public inline fun glGetIntegerIndexedvEXT(
    target: Int,
    index: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetIntegerIndexedvEXT(target, index, `data`)

public inline fun glGetBooleanIndexedvEXT(
    target: Int,
    index: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetBooleanIndexedvEXT(target, index, `data`)

public inline fun glGetBooleanIndexedvEXT(
    target: Int,
    index: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetBooleanIndexedvEXT(target, index, `data`)

public inline fun glNamedProgramStringEXT(
    program: Int,
    target: Int,
    format: Int,
    len: Int,
    string: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramStringEXT(program, target, format,
        len, string)

public inline fun glNamedProgramStringEXT(
    program: Int,
    target: Int,
    format: Int,
    len: Int,
    string: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramStringEXT(program, target, format,
        len, string)

public inline fun glNamedProgramLocalParameter4dEXT(
    program: Int,
    target: Int,
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameter4dEXT(program, target,
        index, x, y, z, w)

public inline fun glNamedProgramLocalParameter4dvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameter4dvEXT(program,
        target, index, params)

public inline fun glNamedProgramLocalParameter4dvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameter4dvEXT(program,
        target, index, params)

public inline fun glNamedProgramLocalParameter4fEXT(
    program: Int,
    target: Int,
    index: Int,
    x: Float,
    y: Float,
    z: Float,
    w: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameter4fEXT(program, target,
        index, x, y, z, w)

public inline fun glNamedProgramLocalParameter4fvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameter4fvEXT(program,
        target, index, params)

public inline fun glNamedProgramLocalParameter4fvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameter4fvEXT(program,
        target, index, params)

public inline fun glGetNamedProgramLocalParameterdvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramLocalParameterdvEXT(program,
        target, index, params)

public inline fun glGetNamedProgramLocalParameterdvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramLocalParameterdvEXT(program,
        target, index, params)

public inline fun glGetNamedProgramLocalParameterfvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramLocalParameterfvEXT(program,
        target, index, params)

public inline fun glGetNamedProgramLocalParameterfvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramLocalParameterfvEXT(program,
        target, index, params)

public inline fun glGetNamedProgramivEXT(
    program: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramivEXT(program, target, pname,
        params)

public inline fun glGetNamedProgramivEXT(
    program: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramivEXT(program, target, pname,
        params)

public inline fun glGetNamedProgramStringEXT(
    program: Int,
    target: Int,
    pname: Int,
    string: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramStringEXT(program, target, pname,
        string)

public inline fun glGetNamedProgramStringEXT(
    program: Int,
    target: Int,
    pname: Int,
    string: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramStringEXT(program, target, pname,
        string)

public inline fun glCompressedTextureImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureImage3DEXT(texture, target,
        level, internalformat, width, height, depth, border, imageSize, `data`)

public inline fun glCompressedTextureImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureImage3DEXT(texture, target,
        level, internalformat, width, height, depth, border, imageSize, `data`)

public inline fun glCompressedTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureImage2DEXT(texture, target,
        level, internalformat, width, height, border, imageSize, `data`)

public inline fun glCompressedTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureImage2DEXT(texture, target,
        level, internalformat, width, height, border, imageSize, `data`)

public inline fun glCompressedTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureImage1DEXT(texture, target,
        level, internalformat, width, border, imageSize, `data`)

public inline fun glCompressedTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureImage1DEXT(texture, target,
        level, internalformat, width, border, imageSize, `data`)

public inline fun glCompressedTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureSubImage3DEXT(texture, target,
        level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize, `data`)

public inline fun glCompressedTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureSubImage3DEXT(texture, target,
        level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize, `data`)

public inline fun glCompressedTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureSubImage2DEXT(texture, target,
        level, xoffset, yoffset, width, height, format, imageSize, `data`)

public inline fun glCompressedTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureSubImage2DEXT(texture, target,
        level, xoffset, yoffset, width, height, format, imageSize, `data`)

public inline fun glCompressedTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureSubImage1DEXT(texture, target,
        level, xoffset, width, format, imageSize, `data`)

public inline fun glCompressedTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedTextureSubImage1DEXT(texture, target,
        level, xoffset, width, format, imageSize, `data`)

public inline fun glGetCompressedTextureImageEXT(
    texture: Int,
    target: Int,
    level: Int,
    img: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetCompressedTextureImageEXT(texture, target,
        level, img)

public inline fun glGetCompressedTextureImageEXT(
    texture: Int,
    target: Int,
    level: Int,
    img: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetCompressedTextureImageEXT(texture, target,
        level, img)

public inline fun glCompressedMultiTexImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexImage3DEXT(texunit, target,
        level, internalformat, width, height, depth, border, imageSize, `data`)

public inline fun glCompressedMultiTexImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexImage3DEXT(texunit, target,
        level, internalformat, width, height, depth, border, imageSize, `data`)

public inline fun glCompressedMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexImage2DEXT(texunit, target,
        level, internalformat, width, height, border, imageSize, `data`)

public inline fun glCompressedMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexImage2DEXT(texunit, target,
        level, internalformat, width, height, border, imageSize, `data`)

public inline fun glCompressedMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexImage1DEXT(texunit, target,
        level, internalformat, width, border, imageSize, `data`)

public inline fun glCompressedMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexImage1DEXT(texunit, target,
        level, internalformat, width, border, imageSize, `data`)

public inline fun glCompressedMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexSubImage3DEXT(texunit, target,
        level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize, `data`)

public inline fun glCompressedMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexSubImage3DEXT(texunit, target,
        level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize, `data`)

public inline fun glCompressedMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexSubImage2DEXT(texunit, target,
        level, xoffset, yoffset, width, height, format, imageSize, `data`)

public inline fun glCompressedMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexSubImage2DEXT(texunit, target,
        level, xoffset, yoffset, width, height, format, imageSize, `data`)

public inline fun glCompressedMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexSubImage1DEXT(texunit, target,
        level, xoffset, width, format, imageSize, `data`)

public inline fun glCompressedMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glCompressedMultiTexSubImage1DEXT(texunit, target,
        level, xoffset, width, format, imageSize, `data`)

public inline fun glGetCompressedMultiTexImageEXT(
    texunit: Int,
    target: Int,
    level: Int,
    img: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetCompressedMultiTexImageEXT(texunit, target,
        level, img)

public inline fun glGetCompressedMultiTexImageEXT(
    texunit: Int,
    target: Int,
    level: Int,
    img: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetCompressedMultiTexImageEXT(texunit, target,
        level, img)

public inline fun glMatrixLoadTransposefEXT(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixLoadTransposefEXT(matrixMode, m)

public inline fun glMatrixLoadTransposefEXT(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixLoadTransposefEXT(matrixMode, m)

public inline fun glMatrixLoadTransposedEXT(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixLoadTransposedEXT(matrixMode, m)

public inline fun glMatrixLoadTransposedEXT(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixLoadTransposedEXT(matrixMode, m)

public inline fun glMatrixMultTransposefEXT(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixMultTransposefEXT(matrixMode, m)

public inline fun glMatrixMultTransposefEXT(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixMultTransposefEXT(matrixMode, m)

public inline fun glMatrixMultTransposedEXT(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixMultTransposedEXT(matrixMode, m)

public inline fun glMatrixMultTransposedEXT(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glMatrixMultTransposedEXT(matrixMode, m)

public inline fun glNamedBufferDataEXT(
    buffer: Int,
    size: Long,
    `data`: Ptr,
    usage: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedBufferDataEXT(buffer, size, `data`, usage)

public inline fun glNamedBufferDataEXT(
    buffer: Int,
    size: Long,
    `data`: Long,
    usage: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedBufferDataEXT(buffer, size, `data`, usage)

public inline fun glNamedBufferSubDataEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedBufferSubDataEXT(buffer, offset, size,
        `data`)

public inline fun glNamedBufferSubDataEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedBufferSubDataEXT(buffer, offset, size,
        `data`)

public inline fun glMapNamedBufferEXT(buffer: Int, access: Int): Ptr =
        GLWrapper.instance.EXTDirectStateAccess.glMapNamedBufferEXT(buffer, access)

public inline fun glUnmapNamedBufferEXT(buffer: Int): Boolean =
        GLWrapper.instance.EXTDirectStateAccess.glUnmapNamedBufferEXT(buffer)

public inline fun glGetNamedBufferParameterivEXT(
    buffer: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedBufferParameterivEXT(buffer, pname,
        params)

public inline fun glGetNamedBufferParameterivEXT(
    buffer: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedBufferParameterivEXT(buffer, pname,
        params)

public inline fun glGetNamedBufferSubDataEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedBufferSubDataEXT(buffer, offset, size,
        `data`)

public inline fun glGetNamedBufferSubDataEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedBufferSubDataEXT(buffer, offset, size,
        `data`)

public inline fun glProgramUniform1fEXT(
    program: Int,
    location: Int,
    v0: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform1fEXT(program, location, v0)

public inline fun glProgramUniform2fEXT(
    program: Int,
    location: Int,
    v0: Float,
    v1: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform2fEXT(program, location, v0, v1)

public inline fun glProgramUniform3fEXT(
    program: Int,
    location: Int,
    v0: Float,
    v1: Float,
    v2: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform3fEXT(program, location, v0, v1,
        v2)

public inline fun glProgramUniform4fEXT(
    program: Int,
    location: Int,
    v0: Float,
    v1: Float,
    v2: Float,
    v3: Float,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform4fEXT(program, location, v0, v1,
        v2, v3)

public inline fun glProgramUniform1iEXT(
    program: Int,
    location: Int,
    v0: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform1iEXT(program, location, v0)

public inline fun glProgramUniform2iEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform2iEXT(program, location, v0, v1)

public inline fun glProgramUniform3iEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform3iEXT(program, location, v0, v1,
        v2)

public inline fun glProgramUniform4iEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform4iEXT(program, location, v0, v1,
        v2, v3)

public inline fun glProgramUniform1fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform1fvEXT(program, location, count,
        `value`)

public inline fun glProgramUniform1fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform1fvEXT(program, location, count,
        `value`)

public inline fun glProgramUniform2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform2fvEXT(program, location, count,
        `value`)

public inline fun glProgramUniform2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform2fvEXT(program, location, count,
        `value`)

public inline fun glProgramUniform3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform3fvEXT(program, location, count,
        `value`)

public inline fun glProgramUniform3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform3fvEXT(program, location, count,
        `value`)

public inline fun glProgramUniform4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform4fvEXT(program, location, count,
        `value`)

public inline fun glProgramUniform4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform4fvEXT(program, location, count,
        `value`)

public inline fun glProgramUniform1ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform1ivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform1ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform1ivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform2ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform2ivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform2ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform2ivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform3ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform3ivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform3ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform3ivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform4ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform4ivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform4ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform4ivEXT(program, location, count,
        `value`)

public inline fun glProgramUniformMatrix2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix2fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix2fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix3fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix3fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix4fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix4fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix2x3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix2x3fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix2x3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix2x3fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix3x2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix3x2fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix3x2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix3x2fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix2x4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix2x4fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix2x4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix2x4fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix4x2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix4x2fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix4x2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix4x2fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix3x4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix3x4fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix3x4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix3x4fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix4x3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix4x3fvEXT(program, location,
        count, transpose, `value`)

public inline fun glProgramUniformMatrix4x3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniformMatrix4x3fvEXT(program, location,
        count, transpose, `value`)

public inline fun glTextureBufferEXT(
    texture: Int,
    target: Int,
    internalformat: Int,
    buffer: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureBufferEXT(texture, target,
        internalformat, buffer)

public inline fun glMultiTexBufferEXT(
    texunit: Int,
    target: Int,
    internalformat: Int,
    buffer: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexBufferEXT(texunit, target,
        internalformat, buffer)

public inline fun glTextureParameterIivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameterIivEXT(texture, target, pname,
        params)

public inline fun glTextureParameterIivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameterIivEXT(texture, target, pname,
        params)

public inline fun glTextureParameterIuivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameterIuivEXT(texture, target, pname,
        params)

public inline fun glTextureParameterIuivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureParameterIuivEXT(texture, target, pname,
        params)

public inline fun glGetTextureParameterIivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureParameterIivEXT(texture, target,
        pname, params)

public inline fun glGetTextureParameterIivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureParameterIivEXT(texture, target,
        pname, params)

public inline fun glGetTextureParameterIuivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureParameterIuivEXT(texture, target,
        pname, params)

public inline fun glGetTextureParameterIuivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetTextureParameterIuivEXT(texture, target,
        pname, params)

public inline fun glMultiTexParameterIivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameterIivEXT(texunit, target, pname,
        params)

public inline fun glMultiTexParameterIivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameterIivEXT(texunit, target, pname,
        params)

public inline fun glMultiTexParameterIuivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameterIuivEXT(texunit, target, pname,
        params)

public inline fun glMultiTexParameterIuivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexParameterIuivEXT(texunit, target, pname,
        params)

public inline fun glGetMultiTexParameterIivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexParameterIivEXT(texunit, target,
        pname, params)

public inline fun glGetMultiTexParameterIivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexParameterIivEXT(texunit, target,
        pname, params)

public inline fun glGetMultiTexParameterIuivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexParameterIuivEXT(texunit, target,
        pname, params)

public inline fun glGetMultiTexParameterIuivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetMultiTexParameterIuivEXT(texunit, target,
        pname, params)

public inline fun glProgramUniform1uiEXT(
    program: Int,
    location: Int,
    v0: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform1uiEXT(program, location, v0)

public inline fun glProgramUniform2uiEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform2uiEXT(program, location, v0, v1)

public inline fun glProgramUniform3uiEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform3uiEXT(program, location, v0, v1,
        v2)

public inline fun glProgramUniform4uiEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform4uiEXT(program, location, v0, v1,
        v2, v3)

public inline fun glProgramUniform1uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform1uivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform1uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform1uivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform2uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform2uivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform2uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform2uivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform3uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform3uivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform3uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform3uivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform4uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform4uivEXT(program, location, count,
        `value`)

public inline fun glProgramUniform4uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glProgramUniform4uivEXT(program, location, count,
        `value`)

public inline fun glNamedProgramLocalParameters4fvEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameters4fvEXT(program,
        target, index, count, params)

public inline fun glNamedProgramLocalParameters4fvEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameters4fvEXT(program,
        target, index, count, params)

public inline fun glNamedProgramLocalParameterI4iEXT(
    program: Int,
    target: Int,
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameterI4iEXT(program,
        target, index, x, y, z, w)

public inline fun glNamedProgramLocalParameterI4ivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameterI4ivEXT(program,
        target, index, params)

public inline fun glNamedProgramLocalParameterI4ivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameterI4ivEXT(program,
        target, index, params)

public inline fun glNamedProgramLocalParametersI4ivEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParametersI4ivEXT(program,
        target, index, count, params)

public inline fun glNamedProgramLocalParametersI4ivEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParametersI4ivEXT(program,
        target, index, count, params)

public inline fun glNamedProgramLocalParameterI4uiEXT(
    program: Int,
    target: Int,
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameterI4uiEXT(program,
        target, index, x, y, z, w)

public inline fun glNamedProgramLocalParameterI4uivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameterI4uivEXT(program,
        target, index, params)

public inline fun glNamedProgramLocalParameterI4uivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParameterI4uivEXT(program,
        target, index, params)

public inline fun glNamedProgramLocalParametersI4uivEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParametersI4uivEXT(program,
        target, index, count, params)

public inline fun glNamedProgramLocalParametersI4uivEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedProgramLocalParametersI4uivEXT(program,
        target, index, count, params)

public inline fun glGetNamedProgramLocalParameterIivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramLocalParameterIivEXT(program,
        target, index, params)

public inline fun glGetNamedProgramLocalParameterIivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramLocalParameterIivEXT(program,
        target, index, params)

public inline fun glGetNamedProgramLocalParameterIuivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramLocalParameterIuivEXT(program,
        target, index, params)

public inline fun glGetNamedProgramLocalParameterIuivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedProgramLocalParameterIuivEXT(program,
        target, index, params)

public inline fun glNamedRenderbufferStorageEXT(
    renderbuffer: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedRenderbufferStorageEXT(renderbuffer,
        internalformat, width, height)

public inline fun glGetNamedRenderbufferParameterivEXT(
    renderbuffer: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedRenderbufferParameterivEXT(renderbuffer,
        pname, params)

public inline fun glGetNamedRenderbufferParameterivEXT(
    renderbuffer: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetNamedRenderbufferParameterivEXT(renderbuffer,
        pname, params)

public inline fun glNamedRenderbufferStorageMultisampleEXT(
    renderbuffer: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glNamedRenderbufferStorageMultisampleEXT(renderbuffer,
        samples, internalformat, width, height)

public inline fun glNamedRenderbufferStorageMultisampleCoverageEXT(
    renderbuffer: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glNamedRenderbufferStorageMultisampleCoverageEXT(renderbuffer,
        coverageSamples, colorSamples, internalformat, width, height)

public inline fun glCheckNamedFramebufferStatusEXT(framebuffer: Int, target: Int): Int =
        GLWrapper.instance.EXTDirectStateAccess.glCheckNamedFramebufferStatusEXT(framebuffer,
        target)

public inline fun glNamedFramebufferTexture1DEXT(
    framebuffer: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedFramebufferTexture1DEXT(framebuffer,
        attachment, textarget, texture, level)

public inline fun glNamedFramebufferTexture2DEXT(
    framebuffer: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedFramebufferTexture2DEXT(framebuffer,
        attachment, textarget, texture, level)

public inline fun glNamedFramebufferTexture3DEXT(
    framebuffer: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
    zoffset: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedFramebufferTexture3DEXT(framebuffer,
        attachment, textarget, texture, level, zoffset)

public inline fun glNamedFramebufferRenderbufferEXT(
    framebuffer: Int,
    attachment: Int,
    renderbuffertarget: Int,
    renderbuffer: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedFramebufferRenderbufferEXT(framebuffer,
        attachment, renderbuffertarget, renderbuffer)

public inline fun glGetNamedFramebufferAttachmentParameterivEXT(
    framebuffer: Int,
    attachment: Int,
    pname: Int,
    params: Ptr,
): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glGetNamedFramebufferAttachmentParameterivEXT(framebuffer,
        attachment, pname, params)

public inline fun glGetNamedFramebufferAttachmentParameterivEXT(
    framebuffer: Int,
    attachment: Int,
    pname: Int,
    params: Long,
): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glGetNamedFramebufferAttachmentParameterivEXT(framebuffer,
        attachment, pname, params)

public inline fun glGenerateTextureMipmapEXT(texture: Int, target: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glGenerateTextureMipmapEXT(texture, target)

public inline fun glGenerateMultiTexMipmapEXT(texunit: Int, target: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glGenerateMultiTexMipmapEXT(texunit, target)

public inline fun glFramebufferDrawBufferEXT(framebuffer: Int, mode: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glFramebufferDrawBufferEXT(framebuffer, mode)

public inline fun glFramebufferDrawBuffersEXT(
    framebuffer: Int,
    n: Int,
    bufs: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glFramebufferDrawBuffersEXT(framebuffer, n, bufs)

public inline fun glFramebufferDrawBuffersEXT(
    framebuffer: Int,
    n: Int,
    bufs: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glFramebufferDrawBuffersEXT(framebuffer, n, bufs)

public inline fun glFramebufferReadBufferEXT(framebuffer: Int, mode: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glFramebufferReadBufferEXT(framebuffer, mode)

public inline fun glGetFramebufferParameterivEXT(
    framebuffer: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetFramebufferParameterivEXT(framebuffer, pname,
        `param`)

public inline fun glGetFramebufferParameterivEXT(
    framebuffer: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetFramebufferParameterivEXT(framebuffer, pname,
        `param`)

public inline fun glNamedCopyBufferSubDataEXT(
    readBuffer: Int,
    writeBuffer: Int,
    readOffset: Long,
    writeOffset: Long,
    size: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedCopyBufferSubDataEXT(readBuffer,
        writeBuffer, readOffset, writeOffset, size)

public inline fun glNamedFramebufferTextureEXT(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedFramebufferTextureEXT(framebuffer,
        attachment, texture, level)

public inline fun glNamedFramebufferTextureLayerEXT(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    layer: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedFramebufferTextureLayerEXT(framebuffer,
        attachment, texture, level, layer)

public inline fun glNamedFramebufferTextureFaceEXT(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    face: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glNamedFramebufferTextureFaceEXT(framebuffer,
        attachment, texture, level, face)

public inline fun glTextureRenderbufferEXT(
    texture: Int,
    target: Int,
    renderbuffer: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glTextureRenderbufferEXT(texture, target,
        renderbuffer)

public inline fun glMultiTexRenderbufferEXT(
    texunit: Int,
    target: Int,
    renderbuffer: Int,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glMultiTexRenderbufferEXT(texunit, target,
        renderbuffer)

public inline fun glVertexArrayVertexOffsetEXT(
    vaobj: Int,
    buffer: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayVertexOffsetEXT(vaobj, buffer, size,
        type, stride, offset)

public inline fun glVertexArrayColorOffsetEXT(
    vaobj: Int,
    buffer: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayColorOffsetEXT(vaobj, buffer, size,
        type, stride, offset)

public inline fun glVertexArrayEdgeFlagOffsetEXT(
    vaobj: Int,
    buffer: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayEdgeFlagOffsetEXT(vaobj, buffer,
        stride, offset)

public inline fun glVertexArrayIndexOffsetEXT(
    vaobj: Int,
    buffer: Int,
    type: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayIndexOffsetEXT(vaobj, buffer, type,
        stride, offset)

public inline fun glVertexArrayNormalOffsetEXT(
    vaobj: Int,
    buffer: Int,
    type: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayNormalOffsetEXT(vaobj, buffer, type,
        stride, offset)

public inline fun glVertexArrayTexCoordOffsetEXT(
    vaobj: Int,
    buffer: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayTexCoordOffsetEXT(vaobj, buffer,
        size, type, stride, offset)

public inline fun glVertexArrayMultiTexCoordOffsetEXT(
    vaobj: Int,
    buffer: Int,
    texunit: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayMultiTexCoordOffsetEXT(vaobj, buffer,
        texunit, size, type, stride, offset)

public inline fun glVertexArrayFogCoordOffsetEXT(
    vaobj: Int,
    buffer: Int,
    type: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayFogCoordOffsetEXT(vaobj, buffer,
        type, stride, offset)

public inline fun glVertexArraySecondaryColorOffsetEXT(
    vaobj: Int,
    buffer: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArraySecondaryColorOffsetEXT(vaobj,
        buffer, size, type, stride, offset)

public inline fun glVertexArrayVertexAttribOffsetEXT(
    vaobj: Int,
    buffer: Int,
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayVertexAttribOffsetEXT(vaobj, buffer,
        index, size, type, normalized, stride, offset)

public inline fun glVertexArrayVertexAttribIOffsetEXT(
    vaobj: Int,
    buffer: Int,
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glVertexArrayVertexAttribIOffsetEXT(vaobj, buffer,
        index, size, type, stride, offset)

public inline fun glEnableVertexArrayEXT(vaobj: Int, array: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glEnableVertexArrayEXT(vaobj, array)

public inline fun glDisableVertexArrayEXT(vaobj: Int, array: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glDisableVertexArrayEXT(vaobj, array)

public inline fun glEnableVertexArrayAttribEXT(vaobj: Int, index: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glEnableVertexArrayAttribEXT(vaobj, index)

public inline fun glDisableVertexArrayAttribEXT(vaobj: Int, index: Int): Unit =
        GLWrapper.instance.EXTDirectStateAccess.glDisableVertexArrayAttribEXT(vaobj, index)

public inline fun glGetVertexArrayIntegervEXT(
    vaobj: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetVertexArrayIntegervEXT(vaobj, pname, `param`)

public inline fun glGetVertexArrayIntegervEXT(
    vaobj: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetVertexArrayIntegervEXT(vaobj, pname, `param`)

public inline fun glGetVertexArrayPointervEXT(
    vaobj: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetVertexArrayPointervEXT(vaobj, pname, `param`)

public inline fun glGetVertexArrayPointervEXT(
    vaobj: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetVertexArrayPointervEXT(vaobj, pname, `param`)

public inline fun glGetVertexArrayIntegeri_vEXT(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetVertexArrayIntegeri_vEXT(vaobj, index, pname,
        `param`)

public inline fun glGetVertexArrayIntegeri_vEXT(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetVertexArrayIntegeri_vEXT(vaobj, index, pname,
        `param`)

public inline fun glGetVertexArrayPointeri_vEXT(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetVertexArrayPointeri_vEXT(vaobj, index, pname,
        `param`)

public inline fun glGetVertexArrayPointeri_vEXT(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glGetVertexArrayPointeri_vEXT(vaobj, index, pname,
        `param`)

public inline fun glMapNamedBufferRangeEXT(
    buffer: Int,
    offset: Long,
    length: Long,
    access: Int,
): Ptr = GLWrapper.instance.EXTDirectStateAccess.glMapNamedBufferRangeEXT(buffer, offset, length,
        access)

public inline fun glFlushMappedNamedBufferRangeEXT(
    buffer: Int,
    offset: Long,
    length: Long,
): Unit = GLWrapper.instance.EXTDirectStateAccess.glFlushMappedNamedBufferRangeEXT(buffer, offset,
        length)
