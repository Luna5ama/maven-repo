@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface AMDFramebufferMultisampleAdvanced : GLBase {
    public fun glRenderbufferStorageMultisampleAdvancedAMD(
        target: Int,
        samples: Int,
        storageSamples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    public fun glNamedRenderbufferStorageMultisampleAdvancedAMD(
        renderbuffer: Int,
        samples: Int,
        storageSamples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )
}

public const val GL_RENDERBUFFER_STORAGE_SAMPLES_AMD: Int = 37_298

public const val GL_MAX_COLOR_FRAMEBUFFER_SAMPLES_AMD: Int = 37_299

public const val GL_MAX_COLOR_FRAMEBUFFER_STORAGE_SAMPLES_AMD: Int = 37_300

public const val GL_MAX_DEPTH_STENCIL_FRAMEBUFFER_SAMPLES_AMD: Int = 37_301

public const val GL_NUM_SUPPORTED_MULTISAMPLE_MODES_AMD: Int = 37_302

public const val GL_SUPPORTED_MULTISAMPLE_MODES_AMD: Int = 37_303

public inline fun glRenderbufferStorageMultisampleAdvancedAMD(
    target: Int,
    samples: Int,
    storageSamples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit =
        GLWrapper.instance.AMDFramebufferMultisampleAdvanced.glRenderbufferStorageMultisampleAdvancedAMD(target,
        samples, storageSamples, internalformat, width, height)

public inline fun glNamedRenderbufferStorageMultisampleAdvancedAMD(
    renderbuffer: Int,
    samples: Int,
    storageSamples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit =
        GLWrapper.instance.AMDFramebufferMultisampleAdvanced.glNamedRenderbufferStorageMultisampleAdvancedAMD(renderbuffer,
        samples, storageSamples, internalformat, width, height)
