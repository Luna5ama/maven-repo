@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTBlendEquationSeparate : GLBase {
    public fun glBlendEquationSeparateEXT(modeRGB: Int, modeAlpha: Int)
}

public const val GL_BLEND_EQUATION_RGB_EXT: Int = 32_777

public const val GL_BLEND_EQUATION_ALPHA_EXT: Int = 34_877

public inline fun glBlendEquationSeparateEXT(modeRGB: Int, modeAlpha: Int): Unit =
        GLWrapper.instance.EXTBlendEquationSeparate.glBlendEquationSeparateEXT(modeRGB, modeAlpha)
