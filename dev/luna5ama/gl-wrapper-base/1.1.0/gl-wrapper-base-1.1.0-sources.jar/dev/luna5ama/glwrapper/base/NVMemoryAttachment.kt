@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVMemoryAttachment : GLBase {
    @PtrParameter([4])
    public fun glGetMemoryObjectDetachedResourcesuivNV(
        memory: Int,
        pname: Int,
        first: Int,
        count: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMemoryObjectDetachedResourcesuivNV(
        memory: Int,
        pname: Int,
        first: Int,
        count: Int,
        params: Long,
    )

    public fun glResetMemoryObjectParameterNV(memory: Int, pname: Int)

    public fun glTexAttachMemoryNV(
        target: Int,
        memory: Int,
        offset: Long,
    )

    public fun glBufferAttachMemoryNV(
        target: Int,
        memory: Int,
        offset: Long,
    )

    public fun glTextureAttachMemoryNV(
        texture: Int,
        memory: Int,
        offset: Long,
    )

    public fun glNamedBufferAttachMemoryNV(
        buffer: Int,
        memory: Int,
        offset: Long,
    )
}

public const val GL_ATTACHED_MEMORY_OBJECT_NV: Int = 38_308

public const val GL_ATTACHED_MEMORY_OFFSET_NV: Int = 38_309

public const val GL_MEMORY_ATTACHABLE_ALIGNMENT_NV: Int = 38_310

public const val GL_MEMORY_ATTACHABLE_SIZE_NV: Int = 38_311

public const val GL_MEMORY_ATTACHABLE_NV: Int = 38_312

public const val GL_DETACHED_MEMORY_INCARNATION_NV: Int = 38_313

public const val GL_DETACHED_TEXTURES_NV: Int = 38_314

public const val GL_DETACHED_BUFFERS_NV: Int = 38_315

public const val GL_MAX_DETACHED_TEXTURES_NV: Int = 38_316

public const val GL_MAX_DETACHED_BUFFERS_NV: Int = 38_317

public inline fun glGetMemoryObjectDetachedResourcesuivNV(
    memory: Int,
    pname: Int,
    first: Int,
    count: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVMemoryAttachment.glGetMemoryObjectDetachedResourcesuivNV(memory,
        pname, first, count, params)

public inline fun glGetMemoryObjectDetachedResourcesuivNV(
    memory: Int,
    pname: Int,
    first: Int,
    count: Int,
    params: Long,
): Unit = GLWrapper.instance.NVMemoryAttachment.glGetMemoryObjectDetachedResourcesuivNV(memory,
        pname, first, count, params)

public inline fun glResetMemoryObjectParameterNV(memory: Int, pname: Int): Unit =
        GLWrapper.instance.NVMemoryAttachment.glResetMemoryObjectParameterNV(memory, pname)

public inline fun glTexAttachMemoryNV(
    target: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.NVMemoryAttachment.glTexAttachMemoryNV(target, memory, offset)

public inline fun glBufferAttachMemoryNV(
    target: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.NVMemoryAttachment.glBufferAttachMemoryNV(target, memory, offset)

public inline fun glTextureAttachMemoryNV(
    texture: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.NVMemoryAttachment.glTextureAttachMemoryNV(texture, memory, offset)

public inline fun glNamedBufferAttachMemoryNV(
    buffer: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.NVMemoryAttachment.glNamedBufferAttachMemoryNV(buffer, memory, offset)
