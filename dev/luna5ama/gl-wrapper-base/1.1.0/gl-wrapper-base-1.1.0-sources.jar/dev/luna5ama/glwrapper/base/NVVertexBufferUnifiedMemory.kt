@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVVertexBufferUnifiedMemory : GLBase {
    public fun glBufferAddressRangeNV(
        pname: Int,
        index: Int,
        address: Long,
        length: Long,
    )

    public fun glVertexFormatNV(
        size: Int,
        type: Int,
        stride: Int,
    )

    public fun glNormalFormatNV(type: Int, stride: Int)

    public fun glColorFormatNV(
        size: Int,
        type: Int,
        stride: Int,
    )

    public fun glIndexFormatNV(type: Int, stride: Int)

    public fun glTexCoordFormatNV(
        size: Int,
        type: Int,
        stride: Int,
    )

    public fun glEdgeFlagFormatNV(stride: Int)

    public fun glSecondaryColorFormatNV(
        size: Int,
        type: Int,
        stride: Int,
    )

    public fun glFogCoordFormatNV(type: Int, stride: Int)

    public fun glVertexAttribFormatNV(
        index: Int,
        size: Int,
        type: Int,
        normalized: Boolean,
        stride: Int,
    )

    public fun glVertexAttribIFormatNV(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
    )

    @PtrParameter([2])
    public fun glGetIntegerui64i_vNV(
        `value`: Int,
        index: Int,
        result: Ptr,
    )

    @Unsafe
    public fun glGetIntegerui64i_vNV(
        `value`: Int,
        index: Int,
        result: Long,
    )
}

public const val GL_VERTEX_ATTRIB_ARRAY_UNIFIED_NV: Int = 36_638

public const val GL_ELEMENT_ARRAY_UNIFIED_NV: Int = 36_639

public const val GL_VERTEX_ATTRIB_ARRAY_ADDRESS_NV: Int = 36_640

public const val GL_TEXTURE_COORD_ARRAY_ADDRESS_NV: Int = 36_645

public const val GL_VERTEX_ARRAY_ADDRESS_NV: Int = 36_641

public const val GL_NORMAL_ARRAY_ADDRESS_NV: Int = 36_642

public const val GL_COLOR_ARRAY_ADDRESS_NV: Int = 36_643

public const val GL_INDEX_ARRAY_ADDRESS_NV: Int = 36_644

public const val GL_EDGE_FLAG_ARRAY_ADDRESS_NV: Int = 36_646

public const val GL_SECONDARY_COLOR_ARRAY_ADDRESS_NV: Int = 36_647

public const val GL_FOG_COORD_ARRAY_ADDRESS_NV: Int = 36_648

public const val GL_ELEMENT_ARRAY_ADDRESS_NV: Int = 36_649

public const val GL_VERTEX_ATTRIB_ARRAY_LENGTH_NV: Int = 36_650

public const val GL_TEXTURE_COORD_ARRAY_LENGTH_NV: Int = 36_655

public const val GL_VERTEX_ARRAY_LENGTH_NV: Int = 36_651

public const val GL_NORMAL_ARRAY_LENGTH_NV: Int = 36_652

public const val GL_COLOR_ARRAY_LENGTH_NV: Int = 36_653

public const val GL_INDEX_ARRAY_LENGTH_NV: Int = 36_654

public const val GL_EDGE_FLAG_ARRAY_LENGTH_NV: Int = 36_656

public const val GL_SECONDARY_COLOR_ARRAY_LENGTH_NV: Int = 36_657

public const val GL_FOG_COORD_ARRAY_LENGTH_NV: Int = 36_658

public const val GL_ELEMENT_ARRAY_LENGTH_NV: Int = 36_659

public inline fun glBufferAddressRangeNV(
    pname: Int,
    index: Int,
    address: Long,
    length: Long,
): Unit = GLWrapper.instance.NVVertexBufferUnifiedMemory.glBufferAddressRangeNV(pname, index,
        address, length)

public inline fun glVertexFormatNV(
    size: Int,
    type: Int,
    stride: Int,
): Unit = GLWrapper.instance.NVVertexBufferUnifiedMemory.glVertexFormatNV(size, type, stride)

public inline fun glNormalFormatNV(type: Int, stride: Int): Unit =
        GLWrapper.instance.NVVertexBufferUnifiedMemory.glNormalFormatNV(type, stride)

public inline fun glColorFormatNV(
    size: Int,
    type: Int,
    stride: Int,
): Unit = GLWrapper.instance.NVVertexBufferUnifiedMemory.glColorFormatNV(size, type, stride)

public inline fun glIndexFormatNV(type: Int, stride: Int): Unit =
        GLWrapper.instance.NVVertexBufferUnifiedMemory.glIndexFormatNV(type, stride)

public inline fun glTexCoordFormatNV(
    size: Int,
    type: Int,
    stride: Int,
): Unit = GLWrapper.instance.NVVertexBufferUnifiedMemory.glTexCoordFormatNV(size, type, stride)

public inline fun glEdgeFlagFormatNV(stride: Int): Unit =
        GLWrapper.instance.NVVertexBufferUnifiedMemory.glEdgeFlagFormatNV(stride)

public inline fun glSecondaryColorFormatNV(
    size: Int,
    type: Int,
    stride: Int,
): Unit = GLWrapper.instance.NVVertexBufferUnifiedMemory.glSecondaryColorFormatNV(size, type,
        stride)

public inline fun glFogCoordFormatNV(type: Int, stride: Int): Unit =
        GLWrapper.instance.NVVertexBufferUnifiedMemory.glFogCoordFormatNV(type, stride)

public inline fun glVertexAttribFormatNV(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
): Unit = GLWrapper.instance.NVVertexBufferUnifiedMemory.glVertexAttribFormatNV(index, size, type,
        normalized, stride)

public inline fun glVertexAttribIFormatNV(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
): Unit = GLWrapper.instance.NVVertexBufferUnifiedMemory.glVertexAttribIFormatNV(index, size, type,
        stride)

public inline fun glGetIntegerui64i_vNV(
    `value`: Int,
    index: Int,
    result: Ptr,
): Unit = GLWrapper.instance.NVVertexBufferUnifiedMemory.glGetIntegerui64i_vNV(`value`, index,
        result)

public inline fun glGetIntegerui64i_vNV(
    `value`: Int,
    index: Int,
    result: Long,
): Unit = GLWrapper.instance.NVVertexBufferUnifiedMemory.glGetIntegerui64i_vNV(`value`, index,
        result)
