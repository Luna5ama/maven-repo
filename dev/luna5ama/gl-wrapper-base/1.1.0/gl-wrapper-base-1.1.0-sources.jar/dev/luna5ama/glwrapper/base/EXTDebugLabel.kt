@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTDebugLabel : GLBase {
    @PtrParameter([3])
    public fun glLabelObjectEXT(
        type: Int,
        `object`: Int,
        length: Int,
        label: Ptr,
    )

    @Unsafe
    public fun glLabelObjectEXT(
        type: Int,
        `object`: Int,
        length: Int,
        label: Long,
    )

    @PtrParameter([3, 4])
    public fun glGetObjectLabelEXT(
        type: Int,
        `object`: Int,
        bufSize: Int,
        length: Ptr,
        label: Ptr,
    )

    @Unsafe
    public fun glGetObjectLabelEXT(
        type: Int,
        `object`: Int,
        bufSize: Int,
        length: Long,
        label: Long,
    )
}

public const val GL_BUFFER_OBJECT_EXT: Int = 37_201

public const val GL_SHADER_OBJECT_EXT: Int = 35_656

public const val GL_PROGRAM_OBJECT_EXT: Int = 35_648

public const val GL_VERTEX_ARRAY_OBJECT_EXT: Int = 37_204

public const val GL_QUERY_OBJECT_EXT: Int = 37_203

public const val GL_PROGRAM_PIPELINE_OBJECT_EXT: Int = 35_407

public inline fun glLabelObjectEXT(
    type: Int,
    `object`: Int,
    length: Int,
    label: Ptr,
): Unit = GLWrapper.instance.EXTDebugLabel.glLabelObjectEXT(type, `object`, length, label)

public inline fun glLabelObjectEXT(
    type: Int,
    `object`: Int,
    length: Int,
    label: Long,
): Unit = GLWrapper.instance.EXTDebugLabel.glLabelObjectEXT(type, `object`, length, label)

public inline fun glGetObjectLabelEXT(
    type: Int,
    `object`: Int,
    bufSize: Int,
    length: Ptr,
    label: Ptr,
): Unit = GLWrapper.instance.EXTDebugLabel.glGetObjectLabelEXT(type, `object`, bufSize, length,
        label)

public inline fun glGetObjectLabelEXT(
    type: Int,
    `object`: Int,
    bufSize: Int,
    length: Long,
    label: Long,
): Unit = GLWrapper.instance.EXTDebugLabel.glGetObjectLabelEXT(type, `object`, bufSize, length,
        label)
