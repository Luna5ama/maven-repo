@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface AMDVertexShaderTessellator : GLBase {
    public fun glTessellationFactorAMD(factor: Float)

    public fun glTessellationModeAMD(mode: Int)
}

public const val GL_SAMPLER_BUFFER_AMD: Int = 36_865

public const val GL_INT_SAMPLER_BUFFER_AMD: Int = 36_866

public const val GL_UNSIGNED_INT_SAMPLER_BUFFER_AMD: Int = 36_867

public const val GL_DISCRETE_AMD: Int = 36_870

public const val GL_CONTINUOUS_AMD: Int = 36_871

public const val GL_TESSELLATION_MODE_AMD: Int = 36_868

public const val GL_TESSELLATION_FACTOR_AMD: Int = 36_869

public inline fun glTessellationFactorAMD(factor: Float): Unit =
        GLWrapper.instance.AMDVertexShaderTessellator.glTessellationFactorAMD(factor)

public inline fun glTessellationModeAMD(mode: Int): Unit =
        GLWrapper.instance.AMDVertexShaderTessellator.glTessellationModeAMD(mode)
