@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVInternalformatSampleQuery : GLBase {
    @PtrParameter([5])
    public fun glGetInternalformatSampleivNV(
        target: Int,
        internalformat: Int,
        samples: Int,
        pname: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetInternalformatSampleivNV(
        target: Int,
        internalformat: Int,
        samples: Int,
        pname: Int,
        bufSize: Int,
        params: Long,
    )
}

public const val GL_MULTISAMPLES_NV: Int = 37_745

public const val GL_SUPERSAMPLE_SCALE_X_NV: Int = 37_746

public const val GL_SUPERSAMPLE_SCALE_Y_NV: Int = 37_747

public const val GL_CONFORMANT_NV: Int = 37_748

public inline fun glGetInternalformatSampleivNV(
    target: Int,
    internalformat: Int,
    samples: Int,
    pname: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVInternalformatSampleQuery.glGetInternalformatSampleivNV(target,
        internalformat, samples, pname, bufSize, params)

public inline fun glGetInternalformatSampleivNV(
    target: Int,
    internalformat: Int,
    samples: Int,
    pname: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.NVInternalformatSampleQuery.glGetInternalformatSampleivNV(target,
        internalformat, samples, pname, bufSize, params)
