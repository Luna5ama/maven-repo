@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import dev.luna5ama.kmogus.ensureCapacity
import kotlin.Boolean
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit

public interface GL11 : GLBase {
    public fun glEnable(target: Int)

    public fun glDisable(target: Int)

    public fun glBindTexture(target: Int, texture: Int)

    public fun glBlendFunc(sfactor: Int, dfactor: Int)

    public fun glClear(mask: Int)

    public fun glClearColor(
        red: Float,
        green: Float,
        blue: Float,
        alpha: Float,
    )

    public fun glClearDepth(depth: Double)

    public fun glClearStencil(s: Int)

    public fun glColorMask(
        red: Boolean,
        green: Boolean,
        blue: Boolean,
        alpha: Boolean,
    )

    public fun glCullFace(mode: Int)

    public fun glDepthFunc(func: Int)

    public fun glDepthMask(flag: Boolean)

    public fun glDepthRange(zNear: Double, zFar: Double)

    public fun glDrawArrays(
        mode: Int,
        first: Int,
        count: Int,
    )

    public fun glDrawBuffer(buf: Int)

    @PtrParameter([3])
    public fun glDrawElements(
        mode: Int,
        count: Int,
        type: Int,
        indices: Ptr,
    )

    @Unsafe
    public fun glDrawElements(
        mode: Int,
        count: Int,
        type: Int,
        indices: Long,
    )

    public fun glFinish()

    public fun glFlush()

    public fun glFrontFace(dir: Int)

    @PtrParameter([1])
    public fun glGenTextures(n: Int, textures: Ptr)

    @Unsafe
    public fun glGenTextures(n: Int, textures: Long)

    @PtrParameter([1])
    public fun glDeleteTextures(n: Int, textures: Ptr)

    @Unsafe
    public fun glDeleteTextures(n: Int, textures: Long)

    @PtrParameter([1])
    public fun glGetBooleanv(pname: Int, params: Ptr)

    @Unsafe
    public fun glGetBooleanv(pname: Int, params: Long)

    @PtrParameter([1])
    public fun glGetFloatv(pname: Int, params: Ptr)

    @Unsafe
    public fun glGetFloatv(pname: Int, params: Long)

    @PtrParameter([1])
    public fun glGetIntegerv(pname: Int, params: Ptr)

    @Unsafe
    public fun glGetIntegerv(pname: Int, params: Long)

    @PtrParameter([1])
    public fun glGetDoublev(pname: Int, params: Ptr)

    @Unsafe
    public fun glGetDoublev(pname: Int, params: Long)

    public fun glGetError(): Int

    @PtrParameter([1])
    public fun glGetPointerv(pname: Int, params: Ptr)

    @Unsafe
    public fun glGetPointerv(pname: Int, params: Long)

    @PtrParameter([4])
    public fun glGetTexImage(
        tex: Int,
        level: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glGetTexImage(
        tex: Int,
        level: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([3])
    public fun glGetTexLevelParameteriv(
        target: Int,
        level: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTexLevelParameteriv(
        target: Int,
        level: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetTexLevelParameterfv(
        target: Int,
        level: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTexLevelParameterfv(
        target: Int,
        level: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetTexParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTexParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetTexParameterfv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTexParameterfv(
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glHint(target: Int, hint: Int)

    public fun glIsEnabled(cap: Int): Boolean

    public fun glIsTexture(texture: Int): Boolean

    public fun glLineWidth(width: Float)

    public fun glLogicOp(op: Int)

    public fun glPixelStorei(pname: Int, `param`: Int)

    public fun glPixelStoref(pname: Int, `param`: Float)

    public fun glPointSize(size: Float)

    public fun glPolygonMode(face: Int, mode: Int)

    public fun glPolygonOffset(factor: Float, units: Float)

    public fun glReadBuffer(src: Int)

    @PtrParameter([6])
    public fun glReadPixels(
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glReadPixels(
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    public fun glScissor(
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    public fun glStencilFunc(
        func: Int,
        ref: Int,
        mask: Int,
    )

    public fun glStencilMask(mask: Int)

    public fun glStencilOp(
        sfail: Int,
        dpfail: Int,
        dppass: Int,
    )

    @PtrParameter([7])
    public fun glTexImage1D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTexImage1D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([8])
    public fun glTexImage2D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTexImage2D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    public fun glCopyTexImage1D(
        target: Int,
        level: Int,
        internalFormat: Int,
        x: Int,
        y: Int,
        width: Int,
        border: Int,
    )

    public fun glCopyTexImage2D(
        target: Int,
        level: Int,
        internalFormat: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        border: Int,
    )

    public fun glCopyTexSubImage1D(
        target: Int,
        level: Int,
        xoffset: Int,
        x: Int,
        y: Int,
        width: Int,
    )

    public fun glCopyTexSubImage2D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    public fun glTexParameteri(
        target: Int,
        pname: Int,
        `param`: Int,
    )

    @PtrParameter([2])
    public fun glTexParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTexParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glTexParameterf(
        target: Int,
        pname: Int,
        `param`: Float,
    )

    @PtrParameter([2])
    public fun glTexParameterfv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTexParameterfv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([6])
    public fun glTexSubImage1D(
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTexSubImage1D(
        target: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([8])
    public fun glTexSubImage2D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTexSubImage2D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    public fun glViewport(
        x: Int,
        y: Int,
        w: Int,
        h: Int,
    )

    @CoreOverload
    public fun glGetBoolean(pname: Int): Boolean {
        tempArr.ensureCapacity(4, false)
        glGetBooleanv(pname, tempArr.ptr)
        return tempArr.ptr.getInt() != 0
    }

    @CoreOverload
    public fun glGetInteger(pname: Int): Int {
        tempArr.ensureCapacity(4, false)
        glGetIntegerv(pname, tempArr.ptr)
        return tempArr.ptr.getInt()
    }

    @CoreOverload
    public fun glGetFloat(pname: Int): Float {
        tempArr.ensureCapacity(4, false)
        glGetFloatv(pname, tempArr.ptr)
        return tempArr.ptr.getFloat()
    }

    @CoreOverload
    public fun glGetDouble(pname: Int): Double {
        tempArr.ensureCapacity(8, false)
        glGetDoublev(pname, tempArr.ptr)
        return tempArr.ptr.getDouble()
    }

    @CoreOverload
    @PtrReturn
    public fun glGetPointer(pname: Int): Ptr {
        tempArr.ensureCapacity(8, false)
        glGetPointerv(pname, tempArr.ptr)
        return Ptr(tempArr.ptr.getLong())
    }

    @NullableReturn
    public fun glGetString(name: Int): String?

    public fun glGenTextures(): Int

    public fun glDeleteTextures(texture: Int)
}

public const val GL_NEVER: Int = 512

public const val GL_LESS: Int = 513

public const val GL_EQUAL: Int = 514

public const val GL_LEQUAL: Int = 515

public const val GL_GREATER: Int = 516

public const val GL_NOTEQUAL: Int = 517

public const val GL_GEQUAL: Int = 518

public const val GL_ALWAYS: Int = 519

public const val GL_DEPTH_BUFFER_BIT: Int = 256

public const val GL_STENCIL_BUFFER_BIT: Int = 1_024

public const val GL_COLOR_BUFFER_BIT: Int = 16_384

public const val GL_POINTS: Int = 0

public const val GL_LINES: Int = 1

public const val GL_LINE_LOOP: Int = 2

public const val GL_LINE_STRIP: Int = 3

public const val GL_TRIANGLES: Int = 4

public const val GL_TRIANGLE_STRIP: Int = 5

public const val GL_TRIANGLE_FAN: Int = 6

public const val GL_QUADS: Int = 7

public const val GL_ZERO: Int = 0

public const val GL_ONE: Int = 1

public const val GL_SRC_COLOR: Int = 768

public const val GL_ONE_MINUS_SRC_COLOR: Int = 769

public const val GL_SRC_ALPHA: Int = 770

public const val GL_ONE_MINUS_SRC_ALPHA: Int = 771

public const val GL_DST_ALPHA: Int = 772

public const val GL_ONE_MINUS_DST_ALPHA: Int = 773

public const val GL_DST_COLOR: Int = 774

public const val GL_ONE_MINUS_DST_COLOR: Int = 775

public const val GL_SRC_ALPHA_SATURATE: Int = 776

public const val GL_TRUE: Int = 1

public const val GL_FALSE: Int = 0

public const val GL_BYTE: Int = 5_120

public const val GL_UNSIGNED_BYTE: Int = 5_121

public const val GL_SHORT: Int = 5_122

public const val GL_UNSIGNED_SHORT: Int = 5_123

public const val GL_INT: Int = 5_124

public const val GL_UNSIGNED_INT: Int = 5_125

public const val GL_FLOAT: Int = 5_126

public const val GL_DOUBLE: Int = 5_130

public const val GL_NONE: Int = 0

public const val GL_FRONT_LEFT: Int = 1_024

public const val GL_FRONT_RIGHT: Int = 1_025

public const val GL_BACK_LEFT: Int = 1_026

public const val GL_BACK_RIGHT: Int = 1_027

public const val GL_FRONT: Int = 1_028

public const val GL_BACK: Int = 1_029

public const val GL_LEFT: Int = 1_030

public const val GL_RIGHT: Int = 1_031

public const val GL_FRONT_AND_BACK: Int = 1_032

public const val GL_NO_ERROR: Int = 0

public const val GL_INVALID_ENUM: Int = 1_280

public const val GL_INVALID_VALUE: Int = 1_281

public const val GL_INVALID_OPERATION: Int = 1_282

public const val GL_STACK_OVERFLOW: Int = 1_283

public const val GL_STACK_UNDERFLOW: Int = 1_284

public const val GL_OUT_OF_MEMORY: Int = 1_285

public const val GL_CW: Int = 2_304

public const val GL_CCW: Int = 2_305

public const val GL_POINT_SIZE: Int = 2_833

public const val GL_POINT_SIZE_RANGE: Int = 2_834

public const val GL_POINT_SIZE_GRANULARITY: Int = 2_835

public const val GL_LINE_SMOOTH: Int = 2_848

public const val GL_LINE_WIDTH: Int = 2_849

public const val GL_LINE_WIDTH_RANGE: Int = 2_850

public const val GL_LINE_WIDTH_GRANULARITY: Int = 2_851

public const val GL_POLYGON_MODE: Int = 2_880

public const val GL_POLYGON_SMOOTH: Int = 2_881

public const val GL_CULL_FACE: Int = 2_884

public const val GL_CULL_FACE_MODE: Int = 2_885

public const val GL_FRONT_FACE: Int = 2_886

public const val GL_DEPTH_RANGE: Int = 2_928

public const val GL_DEPTH_TEST: Int = 2_929

public const val GL_DEPTH_WRITEMASK: Int = 2_930

public const val GL_DEPTH_CLEAR_VALUE: Int = 2_931

public const val GL_DEPTH_FUNC: Int = 2_932

public const val GL_STENCIL_TEST: Int = 2_960

public const val GL_STENCIL_CLEAR_VALUE: Int = 2_961

public const val GL_STENCIL_FUNC: Int = 2_962

public const val GL_STENCIL_VALUE_MASK: Int = 2_963

public const val GL_STENCIL_FAIL: Int = 2_964

public const val GL_STENCIL_PASS_DEPTH_FAIL: Int = 2_965

public const val GL_STENCIL_PASS_DEPTH_PASS: Int = 2_966

public const val GL_STENCIL_REF: Int = 2_967

public const val GL_STENCIL_WRITEMASK: Int = 2_968

public const val GL_VIEWPORT: Int = 2_978

public const val GL_DITHER: Int = 3_024

public const val GL_BLEND_DST: Int = 3_040

public const val GL_BLEND_SRC: Int = 3_041

public const val GL_BLEND: Int = 3_042

public const val GL_LOGIC_OP_MODE: Int = 3_056

public const val GL_COLOR_LOGIC_OP: Int = 3_058

public const val GL_DRAW_BUFFER: Int = 3_073

public const val GL_READ_BUFFER: Int = 3_074

public const val GL_SCISSOR_BOX: Int = 3_088

public const val GL_SCISSOR_TEST: Int = 3_089

public const val GL_COLOR_CLEAR_VALUE: Int = 3_106

public const val GL_COLOR_WRITEMASK: Int = 3_107

public const val GL_DOUBLEBUFFER: Int = 3_122

public const val GL_STEREO: Int = 3_123

public const val GL_LINE_SMOOTH_HINT: Int = 3_154

public const val GL_POLYGON_SMOOTH_HINT: Int = 3_155

public const val GL_UNPACK_SWAP_BYTES: Int = 3_312

public const val GL_UNPACK_LSB_FIRST: Int = 3_313

public const val GL_UNPACK_ROW_LENGTH: Int = 3_314

public const val GL_UNPACK_SKIP_ROWS: Int = 3_315

public const val GL_UNPACK_SKIP_PIXELS: Int = 3_316

public const val GL_UNPACK_ALIGNMENT: Int = 3_317

public const val GL_PACK_SWAP_BYTES: Int = 3_328

public const val GL_PACK_LSB_FIRST: Int = 3_329

public const val GL_PACK_ROW_LENGTH: Int = 3_330

public const val GL_PACK_SKIP_ROWS: Int = 3_331

public const val GL_PACK_SKIP_PIXELS: Int = 3_332

public const val GL_PACK_ALIGNMENT: Int = 3_333

public const val GL_MAX_TEXTURE_SIZE: Int = 3_379

public const val GL_MAX_VIEWPORT_DIMS: Int = 3_386

public const val GL_SUBPIXEL_BITS: Int = 3_408

public const val GL_TEXTURE_1D: Int = 3_552

public const val GL_TEXTURE_2D: Int = 3_553

public const val GL_TEXTURE_WIDTH: Int = 4_096

public const val GL_TEXTURE_HEIGHT: Int = 4_097

public const val GL_TEXTURE_INTERNAL_FORMAT: Int = 4_099

public const val GL_TEXTURE_BORDER_COLOR: Int = 4_100

public const val GL_DONT_CARE: Int = 4_352

public const val GL_FASTEST: Int = 4_353

public const val GL_NICEST: Int = 4_354

public const val GL_CLEAR: Int = 5_376

public const val GL_AND: Int = 5_377

public const val GL_AND_REVERSE: Int = 5_378

public const val GL_COPY: Int = 5_379

public const val GL_AND_INVERTED: Int = 5_380

public const val GL_NOOP: Int = 5_381

public const val GL_XOR: Int = 5_382

public const val GL_OR: Int = 5_383

public const val GL_NOR: Int = 5_384

public const val GL_EQUIV: Int = 5_385

public const val GL_INVERT: Int = 5_386

public const val GL_OR_REVERSE: Int = 5_387

public const val GL_COPY_INVERTED: Int = 5_388

public const val GL_OR_INVERTED: Int = 5_389

public const val GL_NAND: Int = 5_390

public const val GL_SET: Int = 5_391

public const val GL_TEXTURE: Int = 5_890

public const val GL_COLOR: Int = 6_144

public const val GL_DEPTH: Int = 6_145

public const val GL_STENCIL: Int = 6_146

public const val GL_STENCIL_INDEX: Int = 6_401

public const val GL_DEPTH_COMPONENT: Int = 6_402

public const val GL_RED: Int = 6_403

public const val GL_GREEN: Int = 6_404

public const val GL_BLUE: Int = 6_405

public const val GL_ALPHA: Int = 6_406

public const val GL_RGB: Int = 6_407

public const val GL_RGBA: Int = 6_408

public const val GL_POINT: Int = 6_912

public const val GL_LINE: Int = 6_913

public const val GL_FILL: Int = 6_914

public const val GL_KEEP: Int = 7_680

public const val GL_REPLACE: Int = 7_681

public const val GL_INCR: Int = 7_682

public const val GL_DECR: Int = 7_683

public const val GL_VENDOR: Int = 7_936

public const val GL_RENDERER: Int = 7_937

public const val GL_VERSION: Int = 7_938

public const val GL_EXTENSIONS: Int = 7_939

public const val GL_NEAREST: Int = 9_728

public const val GL_LINEAR: Int = 9_729

public const val GL_NEAREST_MIPMAP_NEAREST: Int = 9_984

public const val GL_LINEAR_MIPMAP_NEAREST: Int = 9_985

public const val GL_NEAREST_MIPMAP_LINEAR: Int = 9_986

public const val GL_LINEAR_MIPMAP_LINEAR: Int = 9_987

public const val GL_TEXTURE_MAG_FILTER: Int = 10_240

public const val GL_TEXTURE_MIN_FILTER: Int = 10_241

public const val GL_TEXTURE_WRAP_S: Int = 10_242

public const val GL_TEXTURE_WRAP_T: Int = 10_243

public const val GL_REPEAT: Int = 10_497

public const val GL_POLYGON_OFFSET_FACTOR: Int = 32_824

public const val GL_POLYGON_OFFSET_UNITS: Int = 10_752

public const val GL_POLYGON_OFFSET_POINT: Int = 10_753

public const val GL_POLYGON_OFFSET_LINE: Int = 10_754

public const val GL_POLYGON_OFFSET_FILL: Int = 32_823

public const val GL_R3_G3_B2: Int = 10_768

public const val GL_RGB4: Int = 32_847

public const val GL_RGB5: Int = 32_848

public const val GL_RGB8: Int = 32_849

public const val GL_RGB10: Int = 32_850

public const val GL_RGB12: Int = 32_851

public const val GL_RGB16: Int = 32_852

public const val GL_RGBA2: Int = 32_853

public const val GL_RGBA4: Int = 32_854

public const val GL_RGB5_A1: Int = 32_855

public const val GL_RGBA8: Int = 32_856

public const val GL_RGB10_A2: Int = 32_857

public const val GL_RGBA12: Int = 32_858

public const val GL_RGBA16: Int = 32_859

public const val GL_TEXTURE_RED_SIZE: Int = 32_860

public const val GL_TEXTURE_GREEN_SIZE: Int = 32_861

public const val GL_TEXTURE_BLUE_SIZE: Int = 32_862

public const val GL_TEXTURE_ALPHA_SIZE: Int = 32_863

public const val GL_PROXY_TEXTURE_1D: Int = 32_867

public const val GL_PROXY_TEXTURE_2D: Int = 32_868

public const val GL_TEXTURE_BINDING_1D: Int = 32_872

public const val GL_TEXTURE_BINDING_2D: Int = 32_873

public const val GL_VERTEX_ARRAY: Int = 32_884

public inline fun glEnable(target: Int): Unit = GLWrapper.instance.GL11.glEnable(target)

public inline fun glDisable(target: Int): Unit = GLWrapper.instance.GL11.glDisable(target)

public inline fun glBindTexture(target: Int, texture: Int): Unit =
        GLWrapper.instance.GL11.glBindTexture(target, texture)

public inline fun glBlendFunc(sfactor: Int, dfactor: Int): Unit =
        GLWrapper.instance.GL11.glBlendFunc(sfactor, dfactor)

public inline fun glClear(mask: Int): Unit = GLWrapper.instance.GL11.glClear(mask)

public inline fun glClearColor(
    red: Float,
    green: Float,
    blue: Float,
    alpha: Float,
): Unit = GLWrapper.instance.GL11.glClearColor(red, green, blue, alpha)

public inline fun glClearDepth(depth: Double): Unit = GLWrapper.instance.GL11.glClearDepth(depth)

public inline fun glClearStencil(s: Int): Unit = GLWrapper.instance.GL11.glClearStencil(s)

public inline fun glColorMask(
    red: Boolean,
    green: Boolean,
    blue: Boolean,
    alpha: Boolean,
): Unit = GLWrapper.instance.GL11.glColorMask(red, green, blue, alpha)

public inline fun glCullFace(mode: Int): Unit = GLWrapper.instance.GL11.glCullFace(mode)

public inline fun glDepthFunc(func: Int): Unit = GLWrapper.instance.GL11.glDepthFunc(func)

public inline fun glDepthMask(flag: Boolean): Unit = GLWrapper.instance.GL11.glDepthMask(flag)

public inline fun glDepthRange(zNear: Double, zFar: Double): Unit =
        GLWrapper.instance.GL11.glDepthRange(zNear, zFar)

public inline fun glDrawArrays(
    mode: Int,
    first: Int,
    count: Int,
): Unit = GLWrapper.instance.GL11.glDrawArrays(mode, first, count)

public inline fun glDrawBuffer(buf: Int): Unit = GLWrapper.instance.GL11.glDrawBuffer(buf)

public inline fun glDrawElements(
    mode: Int,
    count: Int,
    type: Int,
    indices: Ptr,
): Unit = GLWrapper.instance.GL11.glDrawElements(mode, count, type, indices)

public inline fun glDrawElements(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
): Unit = GLWrapper.instance.GL11.glDrawElements(mode, count, type, indices)

public inline fun glFinish(): Unit = GLWrapper.instance.GL11.glFinish()

public inline fun glFlush(): Unit = GLWrapper.instance.GL11.glFlush()

public inline fun glFrontFace(dir: Int): Unit = GLWrapper.instance.GL11.glFrontFace(dir)

public inline fun glGenTextures(n: Int, textures: Ptr): Unit =
        GLWrapper.instance.GL11.glGenTextures(n, textures)

public inline fun glGenTextures(n: Int, textures: Long): Unit =
        GLWrapper.instance.GL11.glGenTextures(n, textures)

public inline fun glDeleteTextures(n: Int, textures: Ptr): Unit =
        GLWrapper.instance.GL11.glDeleteTextures(n, textures)

public inline fun glDeleteTextures(n: Int, textures: Long): Unit =
        GLWrapper.instance.GL11.glDeleteTextures(n, textures)

public inline fun glGetBooleanv(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.GL11.glGetBooleanv(pname, params)

public inline fun glGetBooleanv(pname: Int, params: Long): Unit =
        GLWrapper.instance.GL11.glGetBooleanv(pname, params)

public inline fun glGetFloatv(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.GL11.glGetFloatv(pname, params)

public inline fun glGetFloatv(pname: Int, params: Long): Unit =
        GLWrapper.instance.GL11.glGetFloatv(pname, params)

public inline fun glGetIntegerv(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.GL11.glGetIntegerv(pname, params)

public inline fun glGetIntegerv(pname: Int, params: Long): Unit =
        GLWrapper.instance.GL11.glGetIntegerv(pname, params)

public inline fun glGetDoublev(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.GL11.glGetDoublev(pname, params)

public inline fun glGetDoublev(pname: Int, params: Long): Unit =
        GLWrapper.instance.GL11.glGetDoublev(pname, params)

public inline fun glGetError(): Int = GLWrapper.instance.GL11.glGetError()

public inline fun glGetPointerv(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.GL11.glGetPointerv(pname, params)

public inline fun glGetPointerv(pname: Int, params: Long): Unit =
        GLWrapper.instance.GL11.glGetPointerv(pname, params)

public inline fun glGetTexImage(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL11.glGetTexImage(tex, level, format, type, pixels)

public inline fun glGetTexImage(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL11.glGetTexImage(tex, level, format, type, pixels)

public inline fun glGetTexLevelParameteriv(
    target: Int,
    level: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL11.glGetTexLevelParameteriv(target, level, pname, params)

public inline fun glGetTexLevelParameteriv(
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL11.glGetTexLevelParameteriv(target, level, pname, params)

public inline fun glGetTexLevelParameterfv(
    target: Int,
    level: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL11.glGetTexLevelParameterfv(target, level, pname, params)

public inline fun glGetTexLevelParameterfv(
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL11.glGetTexLevelParameterfv(target, level, pname, params)

public inline fun glGetTexParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL11.glGetTexParameteriv(target, pname, params)

public inline fun glGetTexParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL11.glGetTexParameteriv(target, pname, params)

public inline fun glGetTexParameterfv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL11.glGetTexParameterfv(target, pname, params)

public inline fun glGetTexParameterfv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL11.glGetTexParameterfv(target, pname, params)

public inline fun glHint(target: Int, hint: Int): Unit = GLWrapper.instance.GL11.glHint(target,
        hint)

public inline fun glIsEnabled(cap: Int): Boolean = GLWrapper.instance.GL11.glIsEnabled(cap)

public inline fun glIsTexture(texture: Int): Boolean = GLWrapper.instance.GL11.glIsTexture(texture)

public inline fun glLineWidth(width: Float): Unit = GLWrapper.instance.GL11.glLineWidth(width)

public inline fun glLogicOp(op: Int): Unit = GLWrapper.instance.GL11.glLogicOp(op)

public inline fun glPixelStorei(pname: Int, `param`: Int): Unit =
        GLWrapper.instance.GL11.glPixelStorei(pname, `param`)

public inline fun glPixelStoref(pname: Int, `param`: Float): Unit =
        GLWrapper.instance.GL11.glPixelStoref(pname, `param`)

public inline fun glPointSize(size: Float): Unit = GLWrapper.instance.GL11.glPointSize(size)

public inline fun glPolygonMode(face: Int, mode: Int): Unit =
        GLWrapper.instance.GL11.glPolygonMode(face, mode)

public inline fun glPolygonOffset(factor: Float, units: Float): Unit =
        GLWrapper.instance.GL11.glPolygonOffset(factor, units)

public inline fun glReadBuffer(src: Int): Unit = GLWrapper.instance.GL11.glReadBuffer(src)

public inline fun glReadPixels(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL11.glReadPixels(x, y, width, height, format, type, pixels)

public inline fun glReadPixels(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL11.glReadPixels(x, y, width, height, format, type, pixels)

public inline fun glScissor(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL11.glScissor(x, y, width, height)

public inline fun glStencilFunc(
    func: Int,
    ref: Int,
    mask: Int,
): Unit = GLWrapper.instance.GL11.glStencilFunc(func, ref, mask)

public inline fun glStencilMask(mask: Int): Unit = GLWrapper.instance.GL11.glStencilMask(mask)

public inline fun glStencilOp(
    sfail: Int,
    dpfail: Int,
    dppass: Int,
): Unit = GLWrapper.instance.GL11.glStencilOp(sfail, dpfail, dppass)

public inline fun glTexImage1D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL11.glTexImage1D(target, level, internalformat, width, border, format,
        type, pixels)

public inline fun glTexImage1D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL11.glTexImage1D(target, level, internalformat, width, border, format,
        type, pixels)

public inline fun glTexImage2D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL11.glTexImage2D(target, level, internalformat, width, height, border,
        format, type, pixels)

public inline fun glTexImage2D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL11.glTexImage2D(target, level, internalformat, width, height, border,
        format, type, pixels)

public inline fun glCopyTexImage1D(
    target: Int,
    level: Int,
    internalFormat: Int,
    x: Int,
    y: Int,
    width: Int,
    border: Int,
): Unit = GLWrapper.instance.GL11.glCopyTexImage1D(target, level, internalFormat, x, y, width,
        border)

public inline fun glCopyTexImage2D(
    target: Int,
    level: Int,
    internalFormat: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    border: Int,
): Unit = GLWrapper.instance.GL11.glCopyTexImage2D(target, level, internalFormat, x, y, width,
        height, border)

public inline fun glCopyTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    x: Int,
    y: Int,
    width: Int,
): Unit = GLWrapper.instance.GL11.glCopyTexSubImage1D(target, level, xoffset, x, y, width)

public inline fun glCopyTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL11.glCopyTexSubImage2D(target, level, xoffset, yoffset, x, y, width,
        height)

public inline fun glTexParameteri(
    target: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.GL11.glTexParameteri(target, pname, `param`)

public inline fun glTexParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL11.glTexParameteriv(target, pname, params)

public inline fun glTexParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL11.glTexParameteriv(target, pname, params)

public inline fun glTexParameterf(
    target: Int,
    pname: Int,
    `param`: Float,
): Unit = GLWrapper.instance.GL11.glTexParameterf(target, pname, `param`)

public inline fun glTexParameterfv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL11.glTexParameterfv(target, pname, params)

public inline fun glTexParameterfv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL11.glTexParameterfv(target, pname, params)

public inline fun glTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL11.glTexSubImage1D(target, level, xoffset, width, format, type,
        pixels)

public inline fun glTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL11.glTexSubImage1D(target, level, xoffset, width, format, type,
        pixels)

public inline fun glTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL11.glTexSubImage2D(target, level, xoffset, yoffset, width, height,
        format, type, pixels)

public inline fun glTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL11.glTexSubImage2D(target, level, xoffset, yoffset, width, height,
        format, type, pixels)

public inline fun glViewport(
    x: Int,
    y: Int,
    w: Int,
    h: Int,
): Unit = GLWrapper.instance.GL11.glViewport(x, y, w, h)

public inline fun glGetBoolean(pname: Int): Boolean = GLWrapper.instance.GL11.glGetBoolean(pname)

public inline fun glGetInteger(pname: Int): Int = GLWrapper.instance.GL11.glGetInteger(pname)

public inline fun glGetFloat(pname: Int): Float = GLWrapper.instance.GL11.glGetFloat(pname)

public inline fun glGetDouble(pname: Int): Double = GLWrapper.instance.GL11.glGetDouble(pname)

public inline fun glGetPointer(pname: Int): Ptr = GLWrapper.instance.GL11.glGetPointer(pname)

@NullableReturn
public inline fun glGetString(name: Int): String? = GLWrapper.instance.GL11.glGetString(name)

public inline fun glGenTextures(): Int = GLWrapper.instance.GL11.glGenTextures()

public inline fun glDeleteTextures(texture: Int): Unit =
        GLWrapper.instance.GL11.glDeleteTextures(texture)
