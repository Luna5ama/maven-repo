@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTMemoryObject : GLBase {
    @PtrParameter([1])
    public fun glGetUnsignedBytevEXT(pname: Int, `data`: Ptr)

    @Unsafe
    public fun glGetUnsignedBytevEXT(pname: Int, `data`: Long)

    @PtrParameter([2])
    public fun glGetUnsignedBytei_vEXT(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetUnsignedBytei_vEXT(
        target: Int,
        index: Int,
        `data`: Long,
    )

    @PtrParameter([1])
    public fun glDeleteMemoryObjectsEXT(n: Int, memoryObjects: Ptr)

    @Unsafe
    public fun glDeleteMemoryObjectsEXT(n: Int, memoryObjects: Long)

    public fun glIsMemoryObjectEXT(memoryObject: Int): Boolean

    @PtrParameter([1])
    public fun glCreateMemoryObjectsEXT(n: Int, memoryObjects: Ptr)

    @Unsafe
    public fun glCreateMemoryObjectsEXT(n: Int, memoryObjects: Long)

    @PtrParameter([2])
    public fun glMemoryObjectParameterivEXT(
        memoryObject: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMemoryObjectParameterivEXT(
        memoryObject: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetMemoryObjectParameterivEXT(
        memoryObject: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMemoryObjectParameterivEXT(
        memoryObject: Int,
        pname: Int,
        params: Long,
    )

    public fun glTexStorageMem2DEXT(
        target: Int,
        levels: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        memory: Int,
        offset: Long,
    )

    public fun glTexStorageMem2DMultisampleEXT(
        target: Int,
        samples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        fixedSampleLocations: Boolean,
        memory: Int,
        offset: Long,
    )

    public fun glTexStorageMem3DEXT(
        target: Int,
        levels: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        depth: Int,
        memory: Int,
        offset: Long,
    )

    public fun glTexStorageMem3DMultisampleEXT(
        target: Int,
        samples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        depth: Int,
        fixedSampleLocations: Boolean,
        memory: Int,
        offset: Long,
    )

    public fun glBufferStorageMemEXT(
        target: Int,
        size: Long,
        memory: Int,
        offset: Long,
    )

    public fun glTextureStorageMem2DEXT(
        texture: Int,
        levels: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        memory: Int,
        offset: Long,
    )

    public fun glTextureStorageMem2DMultisampleEXT(
        texture: Int,
        samples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        fixedSampleLocations: Boolean,
        memory: Int,
        offset: Long,
    )

    public fun glTextureStorageMem3DEXT(
        texture: Int,
        levels: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        depth: Int,
        memory: Int,
        offset: Long,
    )

    public fun glTextureStorageMem3DMultisampleEXT(
        texture: Int,
        samples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        depth: Int,
        fixedSampleLocations: Boolean,
        memory: Int,
        offset: Long,
    )

    public fun glNamedBufferStorageMemEXT(
        buffer: Int,
        size: Long,
        memory: Int,
        offset: Long,
    )

    public fun glTexStorageMem1DEXT(
        target: Int,
        levels: Int,
        internalFormat: Int,
        width: Int,
        memory: Int,
        offset: Long,
    )

    public fun glTextureStorageMem1DEXT(
        texture: Int,
        levels: Int,
        internalFormat: Int,
        width: Int,
        memory: Int,
        offset: Long,
    )
}

public const val GL_TEXTURE_TILING_EXT: Int = 38_272

public const val GL_DEDICATED_MEMORY_OBJECT_EXT: Int = 38_273

public const val GL_NUM_TILING_TYPES_EXT: Int = 38_274

public const val GL_TILING_TYPES_EXT: Int = 38_275

public const val GL_OPTIMAL_TILING_EXT: Int = 38_276

public const val GL_LINEAR_TILING_EXT: Int = 38_277

public const val GL_NUM_DEVICE_UUIDS_EXT: Int = 38_294

public const val GL_DEVICE_UUID_EXT: Int = 38_295

public const val GL_DRIVER_UUID_EXT: Int = 38_296

public const val GL_UUID_SIZE_EXT: Int = 16

public inline fun glGetUnsignedBytevEXT(pname: Int, `data`: Ptr): Unit =
        GLWrapper.instance.EXTMemoryObject.glGetUnsignedBytevEXT(pname, `data`)

public inline fun glGetUnsignedBytevEXT(pname: Int, `data`: Long): Unit =
        GLWrapper.instance.EXTMemoryObject.glGetUnsignedBytevEXT(pname, `data`)

public inline fun glGetUnsignedBytei_vEXT(
    target: Int,
    index: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.EXTMemoryObject.glGetUnsignedBytei_vEXT(target, index, `data`)

public inline fun glGetUnsignedBytei_vEXT(
    target: Int,
    index: Int,
    `data`: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glGetUnsignedBytei_vEXT(target, index, `data`)

public inline fun glDeleteMemoryObjectsEXT(n: Int, memoryObjects: Ptr): Unit =
        GLWrapper.instance.EXTMemoryObject.glDeleteMemoryObjectsEXT(n, memoryObjects)

public inline fun glDeleteMemoryObjectsEXT(n: Int, memoryObjects: Long): Unit =
        GLWrapper.instance.EXTMemoryObject.glDeleteMemoryObjectsEXT(n, memoryObjects)

public inline fun glIsMemoryObjectEXT(memoryObject: Int): Boolean =
        GLWrapper.instance.EXTMemoryObject.glIsMemoryObjectEXT(memoryObject)

public inline fun glCreateMemoryObjectsEXT(n: Int, memoryObjects: Ptr): Unit =
        GLWrapper.instance.EXTMemoryObject.glCreateMemoryObjectsEXT(n, memoryObjects)

public inline fun glCreateMemoryObjectsEXT(n: Int, memoryObjects: Long): Unit =
        GLWrapper.instance.EXTMemoryObject.glCreateMemoryObjectsEXT(n, memoryObjects)

public inline fun glMemoryObjectParameterivEXT(
    memoryObject: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTMemoryObject.glMemoryObjectParameterivEXT(memoryObject, pname,
        params)

public inline fun glMemoryObjectParameterivEXT(
    memoryObject: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glMemoryObjectParameterivEXT(memoryObject, pname,
        params)

public inline fun glGetMemoryObjectParameterivEXT(
    memoryObject: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTMemoryObject.glGetMemoryObjectParameterivEXT(memoryObject, pname,
        params)

public inline fun glGetMemoryObjectParameterivEXT(
    memoryObject: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glGetMemoryObjectParameterivEXT(memoryObject, pname,
        params)

public inline fun glTexStorageMem2DEXT(
    target: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTexStorageMem2DEXT(target, levels, internalFormat,
        width, height, memory, offset)

public inline fun glTexStorageMem2DMultisampleEXT(
    target: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTexStorageMem2DMultisampleEXT(target, samples,
        internalFormat, width, height, fixedSampleLocations, memory, offset)

public inline fun glTexStorageMem3DEXT(
    target: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTexStorageMem3DEXT(target, levels, internalFormat,
        width, height, depth, memory, offset)

public inline fun glTexStorageMem3DMultisampleEXT(
    target: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTexStorageMem3DMultisampleEXT(target, samples,
        internalFormat, width, height, depth, fixedSampleLocations, memory, offset)

public inline fun glBufferStorageMemEXT(
    target: Int,
    size: Long,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glBufferStorageMemEXT(target, size, memory, offset)

public inline fun glTextureStorageMem2DEXT(
    texture: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTextureStorageMem2DEXT(texture, levels,
        internalFormat, width, height, memory, offset)

public inline fun glTextureStorageMem2DMultisampleEXT(
    texture: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTextureStorageMem2DMultisampleEXT(texture, samples,
        internalFormat, width, height, fixedSampleLocations, memory, offset)

public inline fun glTextureStorageMem3DEXT(
    texture: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTextureStorageMem3DEXT(texture, levels,
        internalFormat, width, height, depth, memory, offset)

public inline fun glTextureStorageMem3DMultisampleEXT(
    texture: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTextureStorageMem3DMultisampleEXT(texture, samples,
        internalFormat, width, height, depth, fixedSampleLocations, memory, offset)

public inline fun glNamedBufferStorageMemEXT(
    buffer: Int,
    size: Long,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glNamedBufferStorageMemEXT(buffer, size, memory,
        offset)

public inline fun glTexStorageMem1DEXT(
    target: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTexStorageMem1DEXT(target, levels, internalFormat,
        width, memory, offset)

public inline fun glTextureStorageMem1DEXT(
    texture: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    memory: Int,
    offset: Long,
): Unit = GLWrapper.instance.EXTMemoryObject.glTextureStorageMem1DEXT(texture, levels,
        internalFormat, width, memory, offset)
