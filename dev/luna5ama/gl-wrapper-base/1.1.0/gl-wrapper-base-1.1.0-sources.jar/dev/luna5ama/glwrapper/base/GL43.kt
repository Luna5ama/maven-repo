@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.CharSequence
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL43 : GLBase {
    @PtrParameter([4])
    public fun glClearBufferData(
        target: Int,
        internalformat: Int,
        format: Int,
        type: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glClearBufferData(
        target: Int,
        internalformat: Int,
        format: Int,
        type: Int,
        `data`: Long,
    )

    @PtrParameter([6])
    public fun glClearBufferSubData(
        target: Int,
        internalformat: Int,
        offset: Long,
        size: Long,
        format: Int,
        type: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glClearBufferSubData(
        target: Int,
        internalformat: Int,
        offset: Long,
        size: Long,
        format: Int,
        type: Int,
        `data`: Long,
    )

    public fun glDispatchCompute(
        num_groups_x: Int,
        num_groups_y: Int,
        num_groups_z: Int,
    )

    public fun glDispatchComputeIndirect(indirect: Long)

    public fun glCopyImageSubData(
        srcName: Int,
        srcTarget: Int,
        srcLevel: Int,
        srcX: Int,
        srcY: Int,
        srcZ: Int,
        dstName: Int,
        dstTarget: Int,
        dstLevel: Int,
        dstX: Int,
        dstY: Int,
        dstZ: Int,
        srcWidth: Int,
        srcHeight: Int,
        srcDepth: Int,
    )

    @PtrParameter([4])
    public fun glDebugMessageControl(
        source: Int,
        type: Int,
        severity: Int,
        count: Int,
        ids: Ptr,
        enabled: Boolean,
    )

    @Unsafe
    public fun glDebugMessageControl(
        source: Int,
        type: Int,
        severity: Int,
        count: Int,
        ids: Long,
        enabled: Boolean,
    )

    @PtrParameter([5])
    public fun glDebugMessageInsert(
        source: Int,
        type: Int,
        id: Int,
        severity: Int,
        length: Int,
        message: Ptr,
    )

    @Unsafe
    public fun glDebugMessageInsert(
        source: Int,
        type: Int,
        id: Int,
        severity: Int,
        length: Int,
        message: Long,
    )

    @PtrParameter([1])
    public fun glDebugMessageCallback(callback: Long, userParam: Ptr)

    @Unsafe
    public fun glDebugMessageCallback(callback: Long, userParam: Long)

    @PtrParameter([2, 3, 4, 5, 6, 7])
    public fun glGetDebugMessageLog(
        count: Int,
        bufsize: Int,
        sources: Ptr,
        types: Ptr,
        ids: Ptr,
        severities: Ptr,
        lengths: Ptr,
        messageLog: Ptr,
    ): Int

    @Unsafe
    public fun glGetDebugMessageLog(
        count: Int,
        bufsize: Int,
        sources: Long,
        types: Long,
        ids: Long,
        severities: Long,
        lengths: Long,
        messageLog: Long,
    ): Int

    @PtrParameter([3])
    public fun glPushDebugGroup(
        source: Int,
        id: Int,
        length: Int,
        message: Ptr,
    )

    @Unsafe
    public fun glPushDebugGroup(
        source: Int,
        id: Int,
        length: Int,
        message: Long,
    )

    public fun glPopDebugGroup()

    @PtrParameter([3])
    public fun glObjectLabel(
        identifier: Int,
        name: Int,
        length: Int,
        label: Ptr,
    )

    @Unsafe
    public fun glObjectLabel(
        identifier: Int,
        name: Int,
        length: Int,
        label: Long,
    )

    @PtrParameter([3, 4])
    public fun glGetObjectLabel(
        identifier: Int,
        name: Int,
        bufSize: Int,
        length: Ptr,
        label: Ptr,
    )

    @Unsafe
    public fun glGetObjectLabel(
        identifier: Int,
        name: Int,
        bufSize: Int,
        length: Long,
        label: Long,
    )

    @PtrParameter([0, 2])
    public fun glObjectPtrLabel(
        ptr: Ptr,
        length: Int,
        label: Ptr,
    )

    @Unsafe
    public fun glObjectPtrLabel(
        ptr: Long,
        length: Int,
        label: Long,
    )

    @PtrParameter([0, 2, 3])
    public fun glGetObjectPtrLabel(
        ptr: Ptr,
        bufSize: Int,
        length: Ptr,
        label: Ptr,
    )

    @Unsafe
    public fun glGetObjectPtrLabel(
        ptr: Long,
        bufSize: Int,
        length: Long,
        label: Long,
    )

    public fun glFramebufferParameteri(
        target: Int,
        pname: Int,
        `param`: Int,
    )

    @PtrParameter([2])
    public fun glGetFramebufferParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetFramebufferParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([4])
    public fun glGetInternalformati64v(
        target: Int,
        internalformat: Int,
        pname: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetInternalformati64v(
        target: Int,
        internalformat: Int,
        pname: Int,
        bufSize: Int,
        params: Long,
    )

    public fun glInvalidateTexSubImage(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
    )

    public fun glInvalidateTexImage(texture: Int, level: Int)

    public fun glInvalidateBufferSubData(
        buffer: Int,
        offset: Long,
        length: Long,
    )

    public fun glInvalidateBufferData(buffer: Int)

    @PtrParameter([2])
    public fun glInvalidateFramebuffer(
        target: Int,
        numAttachments: Int,
        attachments: Ptr,
    )

    @Unsafe
    public fun glInvalidateFramebuffer(
        target: Int,
        numAttachments: Int,
        attachments: Long,
    )

    @PtrParameter([2])
    public fun glInvalidateSubFramebuffer(
        target: Int,
        numAttachments: Int,
        attachments: Ptr,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    @Unsafe
    public fun glInvalidateSubFramebuffer(
        target: Int,
        numAttachments: Int,
        attachments: Long,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([1])
    public fun glMultiDrawArraysIndirect(
        mode: Int,
        indirect: Ptr,
        drawcount: Int,
        stride: Int,
    )

    @Unsafe
    public fun glMultiDrawArraysIndirect(
        mode: Int,
        indirect: Long,
        drawcount: Int,
        stride: Int,
    )

    @PtrParameter([2])
    public fun glMultiDrawElementsIndirect(
        mode: Int,
        type: Int,
        indirect: Ptr,
        drawcount: Int,
        stride: Int,
    )

    @Unsafe
    public fun glMultiDrawElementsIndirect(
        mode: Int,
        type: Int,
        indirect: Long,
        drawcount: Int,
        stride: Int,
    )

    @PtrParameter([3])
    public fun glGetProgramInterfaceiv(
        program: Int,
        programInterface: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramInterfaceiv(
        program: Int,
        programInterface: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetProgramResourceIndex(
        program: Int,
        programInterface: Int,
        name: Ptr,
    ): Int

    @Unsafe
    public fun glGetProgramResourceIndex(
        program: Int,
        programInterface: Int,
        name: Long,
    ): Int

    @PtrParameter([4, 5])
    public fun glGetProgramResourceName(
        program: Int,
        programInterface: Int,
        index: Int,
        bufSize: Int,
        length: Ptr,
        name: Ptr,
    )

    @Unsafe
    public fun glGetProgramResourceName(
        program: Int,
        programInterface: Int,
        index: Int,
        bufSize: Int,
        length: Long,
        name: Long,
    )

    @PtrParameter([4, 6, 7])
    public fun glGetProgramResourceiv(
        program: Int,
        programInterface: Int,
        index: Int,
        propCount: Int,
        props: Ptr,
        bufSize: Int,
        length: Ptr,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramResourceiv(
        program: Int,
        programInterface: Int,
        index: Int,
        propCount: Int,
        props: Long,
        bufSize: Int,
        length: Long,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetProgramResourceLocation(
        program: Int,
        programInterface: Int,
        name: Ptr,
    ): Int

    @Unsafe
    public fun glGetProgramResourceLocation(
        program: Int,
        programInterface: Int,
        name: Long,
    ): Int

    @PtrParameter([2])
    public fun glGetProgramResourceLocationIndex(
        program: Int,
        programInterface: Int,
        name: Ptr,
    ): Int

    @Unsafe
    public fun glGetProgramResourceLocationIndex(
        program: Int,
        programInterface: Int,
        name: Long,
    ): Int

    public fun glShaderStorageBlockBinding(
        program: Int,
        storageBlockIndex: Int,
        storageBlockBinding: Int,
    )

    public fun glTexBufferRange(
        target: Int,
        internalformat: Int,
        buffer: Int,
        offset: Long,
        size: Long,
    )

    public fun glTexStorage2DMultisample(
        target: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        fixedsamplelocations: Boolean,
    )

    public fun glTexStorage3DMultisample(
        target: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        fixedsamplelocations: Boolean,
    )

    public fun glTextureView(
        texture: Int,
        target: Int,
        origtexture: Int,
        internalformat: Int,
        minlevel: Int,
        numlevels: Int,
        minlayer: Int,
        numlayers: Int,
    )

    public fun glBindVertexBuffer(
        bindingindex: Int,
        buffer: Int,
        offset: Long,
        stride: Int,
    )

    public fun glVertexAttribFormat(
        attribindex: Int,
        size: Int,
        type: Int,
        normalized: Boolean,
        relativeoffset: Int,
    )

    public fun glVertexAttribIFormat(
        attribindex: Int,
        size: Int,
        type: Int,
        relativeoffset: Int,
    )

    public fun glVertexAttribLFormat(
        attribindex: Int,
        size: Int,
        type: Int,
        relativeoffset: Int,
    )

    public fun glVertexAttribBinding(attribindex: Int, bindingindex: Int)

    public fun glVertexBindingDivisor(bindingindex: Int, divisor: Int)

    public fun glObjectLabel(
        identifier: Int,
        name: Int,
        label: CharSequence,
    )

    public fun glGetProgramResourceIndex(
        program: Int,
        programInterface: Int,
        name: CharSequence,
    ): Int

    public fun glPushDebugGroup(
        source: Int,
        id: Int,
        message: CharSequence,
    )
}

public const val GL_NUM_SHADING_LANGUAGE_VERSIONS: Int = 33_513

public const val GL_VERTEX_ATTRIB_ARRAY_LONG: Int = 34_638

public const val GL_COMPRESSED_RGB8_ETC2: Int = 37_492

public const val GL_COMPRESSED_SRGB8_ETC2: Int = 37_493

public const val GL_COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2: Int = 37_494

public const val GL_COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2: Int = 37_495

public const val GL_COMPRESSED_RGBA8_ETC2_EAC: Int = 37_496

public const val GL_COMPRESSED_SRGB8_ALPHA8_ETC2_EAC: Int = 37_497

public const val GL_COMPRESSED_R11_EAC: Int = 37_488

public const val GL_COMPRESSED_SIGNED_R11_EAC: Int = 37_489

public const val GL_COMPRESSED_RG11_EAC: Int = 37_490

public const val GL_COMPRESSED_SIGNED_RG11_EAC: Int = 37_491

public const val GL_PRIMITIVE_RESTART_FIXED_INDEX: Int = 36_201

public const val GL_ANY_SAMPLES_PASSED_CONSERVATIVE: Int = 36_202

public const val GL_MAX_ELEMENT_INDEX: Int = 36_203

public const val GL_TEXTURE_IMMUTABLE_LEVELS: Int = 33_503

public const val GL_COMPUTE_SHADER: Int = 37_305

public const val GL_MAX_COMPUTE_UNIFORM_BLOCKS: Int = 37_307

public const val GL_MAX_COMPUTE_TEXTURE_IMAGE_UNITS: Int = 37_308

public const val GL_MAX_COMPUTE_IMAGE_UNIFORMS: Int = 37_309

public const val GL_MAX_COMPUTE_SHARED_MEMORY_SIZE: Int = 33_378

public const val GL_MAX_COMPUTE_UNIFORM_COMPONENTS: Int = 33_379

public const val GL_MAX_COMPUTE_ATOMIC_COUNTER_BUFFERS: Int = 33_380

public const val GL_MAX_COMPUTE_ATOMIC_COUNTERS: Int = 33_381

public const val GL_MAX_COMBINED_COMPUTE_UNIFORM_COMPONENTS: Int = 33_382

public const val GL_MAX_COMPUTE_WORK_GROUP_INVOCATIONS: Int = 37_099

public const val GL_MAX_COMPUTE_WORK_GROUP_COUNT: Int = 37_310

public const val GL_MAX_COMPUTE_WORK_GROUP_SIZE: Int = 37_311

public const val GL_COMPUTE_WORK_GROUP_SIZE: Int = 33_383

public const val GL_UNIFORM_BLOCK_REFERENCED_BY_COMPUTE_SHADER: Int = 37_100

public const val GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_COMPUTE_SHADER: Int = 37_101

public const val GL_DISPATCH_INDIRECT_BUFFER: Int = 37_102

public const val GL_DISPATCH_INDIRECT_BUFFER_BINDING: Int = 37_103

public const val GL_COMPUTE_SHADER_BIT: Int = 32

public const val GL_DEBUG_OUTPUT: Int = 37_600

public const val GL_DEBUG_OUTPUT_SYNCHRONOUS: Int = 33_346

public const val GL_CONTEXT_FLAG_DEBUG_BIT: Int = 2

public const val GL_MAX_DEBUG_MESSAGE_LENGTH: Int = 37_187

public const val GL_MAX_DEBUG_LOGGED_MESSAGES: Int = 37_188

public const val GL_DEBUG_LOGGED_MESSAGES: Int = 37_189

public const val GL_DEBUG_NEXT_LOGGED_MESSAGE_LENGTH: Int = 33_347

public const val GL_MAX_DEBUG_GROUP_STACK_DEPTH: Int = 33_388

public const val GL_DEBUG_GROUP_STACK_DEPTH: Int = 33_389

public const val GL_MAX_LABEL_LENGTH: Int = 33_512

public const val GL_DEBUG_CALLBACK_FUNCTION: Int = 33_348

public const val GL_DEBUG_CALLBACK_USER_PARAM: Int = 33_349

public const val GL_DEBUG_SOURCE_API: Int = 33_350

public const val GL_DEBUG_SOURCE_WINDOW_SYSTEM: Int = 33_351

public const val GL_DEBUG_SOURCE_SHADER_COMPILER: Int = 33_352

public const val GL_DEBUG_SOURCE_THIRD_PARTY: Int = 33_353

public const val GL_DEBUG_SOURCE_APPLICATION: Int = 33_354

public const val GL_DEBUG_SOURCE_OTHER: Int = 33_355

public const val GL_DEBUG_TYPE_ERROR: Int = 33_356

public const val GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR: Int = 33_357

public const val GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR: Int = 33_358

public const val GL_DEBUG_TYPE_PORTABILITY: Int = 33_359

public const val GL_DEBUG_TYPE_PERFORMANCE: Int = 33_360

public const val GL_DEBUG_TYPE_OTHER: Int = 33_361

public const val GL_DEBUG_TYPE_MARKER: Int = 33_384

public const val GL_DEBUG_TYPE_PUSH_GROUP: Int = 33_385

public const val GL_DEBUG_TYPE_POP_GROUP: Int = 33_386

public const val GL_DEBUG_SEVERITY_HIGH: Int = 37_190

public const val GL_DEBUG_SEVERITY_MEDIUM: Int = 37_191

public const val GL_DEBUG_SEVERITY_LOW: Int = 37_192

public const val GL_DEBUG_SEVERITY_NOTIFICATION: Int = 33_387

public const val GL_BUFFER: Int = 33_504

public const val GL_SHADER: Int = 33_505

public const val GL_PROGRAM: Int = 33_506

public const val GL_QUERY: Int = 33_507

public const val GL_PROGRAM_PIPELINE: Int = 33_508

public const val GL_SAMPLER: Int = 33_510

public const val GL_MAX_UNIFORM_LOCATIONS: Int = 33_390

public const val GL_FRAMEBUFFER_DEFAULT_WIDTH: Int = 37_648

public const val GL_FRAMEBUFFER_DEFAULT_HEIGHT: Int = 37_649

public const val GL_FRAMEBUFFER_DEFAULT_LAYERS: Int = 37_650

public const val GL_FRAMEBUFFER_DEFAULT_SAMPLES: Int = 37_651

public const val GL_FRAMEBUFFER_DEFAULT_FIXED_SAMPLE_LOCATIONS: Int = 37_652

public const val GL_MAX_FRAMEBUFFER_WIDTH: Int = 37_653

public const val GL_MAX_FRAMEBUFFER_HEIGHT: Int = 37_654

public const val GL_MAX_FRAMEBUFFER_LAYERS: Int = 37_655

public const val GL_MAX_FRAMEBUFFER_SAMPLES: Int = 37_656

public const val GL_INTERNALFORMAT_SUPPORTED: Int = 33_391

public const val GL_INTERNALFORMAT_PREFERRED: Int = 33_392

public const val GL_INTERNALFORMAT_RED_SIZE: Int = 33_393

public const val GL_INTERNALFORMAT_GREEN_SIZE: Int = 33_394

public const val GL_INTERNALFORMAT_BLUE_SIZE: Int = 33_395

public const val GL_INTERNALFORMAT_ALPHA_SIZE: Int = 33_396

public const val GL_INTERNALFORMAT_DEPTH_SIZE: Int = 33_397

public const val GL_INTERNALFORMAT_STENCIL_SIZE: Int = 33_398

public const val GL_INTERNALFORMAT_SHARED_SIZE: Int = 33_399

public const val GL_INTERNALFORMAT_RED_TYPE: Int = 33_400

public const val GL_INTERNALFORMAT_GREEN_TYPE: Int = 33_401

public const val GL_INTERNALFORMAT_BLUE_TYPE: Int = 33_402

public const val GL_INTERNALFORMAT_ALPHA_TYPE: Int = 33_403

public const val GL_INTERNALFORMAT_DEPTH_TYPE: Int = 33_404

public const val GL_INTERNALFORMAT_STENCIL_TYPE: Int = 33_405

public const val GL_MAX_WIDTH: Int = 33_406

public const val GL_MAX_HEIGHT: Int = 33_407

public const val GL_MAX_DEPTH: Int = 33_408

public const val GL_MAX_LAYERS: Int = 33_409

public const val GL_MAX_COMBINED_DIMENSIONS: Int = 33_410

public const val GL_COLOR_COMPONENTS: Int = 33_411

public const val GL_DEPTH_COMPONENTS: Int = 33_412

public const val GL_STENCIL_COMPONENTS: Int = 33_413

public const val GL_COLOR_RENDERABLE: Int = 33_414

public const val GL_DEPTH_RENDERABLE: Int = 33_415

public const val GL_STENCIL_RENDERABLE: Int = 33_416

public const val GL_FRAMEBUFFER_RENDERABLE: Int = 33_417

public const val GL_FRAMEBUFFER_RENDERABLE_LAYERED: Int = 33_418

public const val GL_FRAMEBUFFER_BLEND: Int = 33_419

public const val GL_READ_PIXELS: Int = 33_420

public const val GL_READ_PIXELS_FORMAT: Int = 33_421

public const val GL_READ_PIXELS_TYPE: Int = 33_422

public const val GL_TEXTURE_IMAGE_FORMAT: Int = 33_423

public const val GL_TEXTURE_IMAGE_TYPE: Int = 33_424

public const val GL_GET_TEXTURE_IMAGE_FORMAT: Int = 33_425

public const val GL_GET_TEXTURE_IMAGE_TYPE: Int = 33_426

public const val GL_MIPMAP: Int = 33_427

public const val GL_MANUAL_GENERATE_MIPMAP: Int = 33_428

public const val GL_AUTO_GENERATE_MIPMAP: Int = 33_429

public const val GL_COLOR_ENCODING: Int = 33_430

public const val GL_SRGB_READ: Int = 33_431

public const val GL_SRGB_WRITE: Int = 33_432

public const val GL_FILTER: Int = 33_434

public const val GL_VERTEX_TEXTURE: Int = 33_435

public const val GL_TESS_CONTROL_TEXTURE: Int = 33_436

public const val GL_TESS_EVALUATION_TEXTURE: Int = 33_437

public const val GL_GEOMETRY_TEXTURE: Int = 33_438

public const val GL_FRAGMENT_TEXTURE: Int = 33_439

public const val GL_COMPUTE_TEXTURE: Int = 33_440

public const val GL_TEXTURE_SHADOW: Int = 33_441

public const val GL_TEXTURE_GATHER: Int = 33_442

public const val GL_TEXTURE_GATHER_SHADOW: Int = 33_443

public const val GL_SHADER_IMAGE_LOAD: Int = 33_444

public const val GL_SHADER_IMAGE_STORE: Int = 33_445

public const val GL_SHADER_IMAGE_ATOMIC: Int = 33_446

public const val GL_IMAGE_TEXEL_SIZE: Int = 33_447

public const val GL_IMAGE_COMPATIBILITY_CLASS: Int = 33_448

public const val GL_IMAGE_PIXEL_FORMAT: Int = 33_449

public const val GL_IMAGE_PIXEL_TYPE: Int = 33_450

public const val GL_SIMULTANEOUS_TEXTURE_AND_DEPTH_TEST: Int = 33_452

public const val GL_SIMULTANEOUS_TEXTURE_AND_STENCIL_TEST: Int = 33_453

public const val GL_SIMULTANEOUS_TEXTURE_AND_DEPTH_WRITE: Int = 33_454

public const val GL_SIMULTANEOUS_TEXTURE_AND_STENCIL_WRITE: Int = 33_455

public const val GL_TEXTURE_COMPRESSED_BLOCK_WIDTH: Int = 33_457

public const val GL_TEXTURE_COMPRESSED_BLOCK_HEIGHT: Int = 33_458

public const val GL_TEXTURE_COMPRESSED_BLOCK_SIZE: Int = 33_459

public const val GL_CLEAR_BUFFER: Int = 33_460

public const val GL_TEXTURE_VIEW: Int = 33_461

public const val GL_VIEW_COMPATIBILITY_CLASS: Int = 33_462

public const val GL_FULL_SUPPORT: Int = 33_463

public const val GL_CAVEAT_SUPPORT: Int = 33_464

public const val GL_IMAGE_CLASS_4_X_32: Int = 33_465

public const val GL_IMAGE_CLASS_2_X_32: Int = 33_466

public const val GL_IMAGE_CLASS_1_X_32: Int = 33_467

public const val GL_IMAGE_CLASS_4_X_16: Int = 33_468

public const val GL_IMAGE_CLASS_2_X_16: Int = 33_469

public const val GL_IMAGE_CLASS_1_X_16: Int = 33_470

public const val GL_IMAGE_CLASS_4_X_8: Int = 33_471

public const val GL_IMAGE_CLASS_2_X_8: Int = 33_472

public const val GL_IMAGE_CLASS_1_X_8: Int = 33_473

public const val GL_IMAGE_CLASS_11_11_10: Int = 33_474

public const val GL_IMAGE_CLASS_10_10_10_2: Int = 33_475

public const val GL_VIEW_CLASS_128_BITS: Int = 33_476

public const val GL_VIEW_CLASS_96_BITS: Int = 33_477

public const val GL_VIEW_CLASS_64_BITS: Int = 33_478

public const val GL_VIEW_CLASS_48_BITS: Int = 33_479

public const val GL_VIEW_CLASS_32_BITS: Int = 33_480

public const val GL_VIEW_CLASS_24_BITS: Int = 33_481

public const val GL_VIEW_CLASS_16_BITS: Int = 33_482

public const val GL_VIEW_CLASS_8_BITS: Int = 33_483

public const val GL_VIEW_CLASS_S3TC_DXT1_RGB: Int = 33_484

public const val GL_VIEW_CLASS_S3TC_DXT1_RGBA: Int = 33_485

public const val GL_VIEW_CLASS_S3TC_DXT3_RGBA: Int = 33_486

public const val GL_VIEW_CLASS_S3TC_DXT5_RGBA: Int = 33_487

public const val GL_VIEW_CLASS_RGTC1_RED: Int = 33_488

public const val GL_VIEW_CLASS_RGTC2_RG: Int = 33_489

public const val GL_VIEW_CLASS_BPTC_UNORM: Int = 33_490

public const val GL_VIEW_CLASS_BPTC_FLOAT: Int = 33_491

public const val GL_UNIFORM: Int = 37_601

public const val GL_UNIFORM_BLOCK: Int = 37_602

public const val GL_PROGRAM_INPUT: Int = 37_603

public const val GL_PROGRAM_OUTPUT: Int = 37_604

public const val GL_BUFFER_VARIABLE: Int = 37_605

public const val GL_SHADER_STORAGE_BLOCK: Int = 37_606

public const val GL_VERTEX_SUBROUTINE: Int = 37_608

public const val GL_TESS_CONTROL_SUBROUTINE: Int = 37_609

public const val GL_TESS_EVALUATION_SUBROUTINE: Int = 37_610

public const val GL_GEOMETRY_SUBROUTINE: Int = 37_611

public const val GL_FRAGMENT_SUBROUTINE: Int = 37_612

public const val GL_COMPUTE_SUBROUTINE: Int = 37_613

public const val GL_VERTEX_SUBROUTINE_UNIFORM: Int = 37_614

public const val GL_TESS_CONTROL_SUBROUTINE_UNIFORM: Int = 37_615

public const val GL_TESS_EVALUATION_SUBROUTINE_UNIFORM: Int = 37_616

public const val GL_GEOMETRY_SUBROUTINE_UNIFORM: Int = 37_617

public const val GL_FRAGMENT_SUBROUTINE_UNIFORM: Int = 37_618

public const val GL_COMPUTE_SUBROUTINE_UNIFORM: Int = 37_619

public const val GL_TRANSFORM_FEEDBACK_VARYING: Int = 37_620

public const val GL_ACTIVE_RESOURCES: Int = 37_621

public const val GL_MAX_NAME_LENGTH: Int = 37_622

public const val GL_MAX_NUM_ACTIVE_VARIABLES: Int = 37_623

public const val GL_MAX_NUM_COMPATIBLE_SUBROUTINES: Int = 37_624

public const val GL_NAME_LENGTH: Int = 37_625

public const val GL_TYPE: Int = 37_626

public const val GL_ARRAY_SIZE: Int = 37_627

public const val GL_OFFSET: Int = 37_628

public const val GL_BLOCK_INDEX: Int = 37_629

public const val GL_ARRAY_STRIDE: Int = 37_630

public const val GL_MATRIX_STRIDE: Int = 37_631

public const val GL_IS_ROW_MAJOR: Int = 37_632

public const val GL_ATOMIC_COUNTER_BUFFER_INDEX: Int = 37_633

public const val GL_BUFFER_BINDING: Int = 37_634

public const val GL_BUFFER_DATA_SIZE: Int = 37_635

public const val GL_NUM_ACTIVE_VARIABLES: Int = 37_636

public const val GL_ACTIVE_VARIABLES: Int = 37_637

public const val GL_REFERENCED_BY_VERTEX_SHADER: Int = 37_638

public const val GL_REFERENCED_BY_TESS_CONTROL_SHADER: Int = 37_639

public const val GL_REFERENCED_BY_TESS_EVALUATION_SHADER: Int = 37_640

public const val GL_REFERENCED_BY_GEOMETRY_SHADER: Int = 37_641

public const val GL_REFERENCED_BY_FRAGMENT_SHADER: Int = 37_642

public const val GL_REFERENCED_BY_COMPUTE_SHADER: Int = 37_643

public const val GL_TOP_LEVEL_ARRAY_SIZE: Int = 37_644

public const val GL_TOP_LEVEL_ARRAY_STRIDE: Int = 37_645

public const val GL_LOCATION: Int = 37_646

public const val GL_LOCATION_INDEX: Int = 37_647

public const val GL_IS_PER_PATCH: Int = 37_607

public const val GL_SHADER_STORAGE_BUFFER: Int = 37_074

public const val GL_SHADER_STORAGE_BUFFER_BINDING: Int = 37_075

public const val GL_SHADER_STORAGE_BUFFER_START: Int = 37_076

public const val GL_SHADER_STORAGE_BUFFER_SIZE: Int = 37_077

public const val GL_MAX_VERTEX_SHADER_STORAGE_BLOCKS: Int = 37_078

public const val GL_MAX_GEOMETRY_SHADER_STORAGE_BLOCKS: Int = 37_079

public const val GL_MAX_TESS_CONTROL_SHADER_STORAGE_BLOCKS: Int = 37_080

public const val GL_MAX_TESS_EVALUATION_SHADER_STORAGE_BLOCKS: Int = 37_081

public const val GL_MAX_FRAGMENT_SHADER_STORAGE_BLOCKS: Int = 37_082

public const val GL_MAX_COMPUTE_SHADER_STORAGE_BLOCKS: Int = 37_083

public const val GL_MAX_COMBINED_SHADER_STORAGE_BLOCKS: Int = 37_084

public const val GL_MAX_SHADER_STORAGE_BUFFER_BINDINGS: Int = 37_085

public const val GL_MAX_SHADER_STORAGE_BLOCK_SIZE: Int = 37_086

public const val GL_SHADER_STORAGE_BUFFER_OFFSET_ALIGNMENT: Int = 37_087

public const val GL_SHADER_STORAGE_BARRIER_BIT: Int = 8_192

public const val GL_MAX_COMBINED_SHADER_OUTPUT_RESOURCES: Int = 36_665

public const val GL_DEPTH_STENCIL_TEXTURE_MODE: Int = 37_098

public const val GL_TEXTURE_BUFFER_OFFSET: Int = 37_277

public const val GL_TEXTURE_BUFFER_SIZE: Int = 37_278

public const val GL_TEXTURE_BUFFER_OFFSET_ALIGNMENT: Int = 37_279

public const val GL_TEXTURE_VIEW_MIN_LEVEL: Int = 33_499

public const val GL_TEXTURE_VIEW_NUM_LEVELS: Int = 33_500

public const val GL_TEXTURE_VIEW_MIN_LAYER: Int = 33_501

public const val GL_TEXTURE_VIEW_NUM_LAYERS: Int = 33_502

public const val GL_VERTEX_ATTRIB_BINDING: Int = 33_492

public const val GL_VERTEX_ATTRIB_RELATIVE_OFFSET: Int = 33_493

public const val GL_VERTEX_BINDING_DIVISOR: Int = 33_494

public const val GL_VERTEX_BINDING_OFFSET: Int = 33_495

public const val GL_VERTEX_BINDING_STRIDE: Int = 33_496

public const val GL_VERTEX_BINDING_BUFFER: Int = 36_687

public const val GL_MAX_VERTEX_ATTRIB_RELATIVE_OFFSET: Int = 33_497

public const val GL_MAX_VERTEX_ATTRIB_BINDINGS: Int = 33_498

public inline fun glClearBufferData(
    target: Int,
    internalformat: Int,
    format: Int,
    type: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL43.glClearBufferData(target, internalformat, format, type, `data`)

public inline fun glClearBufferData(
    target: Int,
    internalformat: Int,
    format: Int,
    type: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL43.glClearBufferData(target, internalformat, format, type, `data`)

public inline fun glClearBufferSubData(
    target: Int,
    internalformat: Int,
    offset: Long,
    size: Long,
    format: Int,
    type: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL43.glClearBufferSubData(target, internalformat, offset, size, format,
        type, `data`)

public inline fun glClearBufferSubData(
    target: Int,
    internalformat: Int,
    offset: Long,
    size: Long,
    format: Int,
    type: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL43.glClearBufferSubData(target, internalformat, offset, size, format,
        type, `data`)

public inline fun glDispatchCompute(
    num_groups_x: Int,
    num_groups_y: Int,
    num_groups_z: Int,
): Unit = GLWrapper.instance.GL43.glDispatchCompute(num_groups_x, num_groups_y, num_groups_z)

public inline fun glDispatchComputeIndirect(indirect: Long): Unit =
        GLWrapper.instance.GL43.glDispatchComputeIndirect(indirect)

public inline fun glCopyImageSubData(
    srcName: Int,
    srcTarget: Int,
    srcLevel: Int,
    srcX: Int,
    srcY: Int,
    srcZ: Int,
    dstName: Int,
    dstTarget: Int,
    dstLevel: Int,
    dstX: Int,
    dstY: Int,
    dstZ: Int,
    srcWidth: Int,
    srcHeight: Int,
    srcDepth: Int,
): Unit = GLWrapper.instance.GL43.glCopyImageSubData(srcName, srcTarget, srcLevel, srcX, srcY, srcZ,
        dstName, dstTarget, dstLevel, dstX, dstY, dstZ, srcWidth, srcHeight, srcDepth)

public inline fun glDebugMessageControl(
    source: Int,
    type: Int,
    severity: Int,
    count: Int,
    ids: Ptr,
    enabled: Boolean,
): Unit = GLWrapper.instance.GL43.glDebugMessageControl(source, type, severity, count, ids, enabled)

public inline fun glDebugMessageControl(
    source: Int,
    type: Int,
    severity: Int,
    count: Int,
    ids: Long,
    enabled: Boolean,
): Unit = GLWrapper.instance.GL43.glDebugMessageControl(source, type, severity, count, ids, enabled)

public inline fun glDebugMessageInsert(
    source: Int,
    type: Int,
    id: Int,
    severity: Int,
    length: Int,
    message: Ptr,
): Unit = GLWrapper.instance.GL43.glDebugMessageInsert(source, type, id, severity, length, message)

public inline fun glDebugMessageInsert(
    source: Int,
    type: Int,
    id: Int,
    severity: Int,
    length: Int,
    message: Long,
): Unit = GLWrapper.instance.GL43.glDebugMessageInsert(source, type, id, severity, length, message)

public inline fun glDebugMessageCallback(callback: Long, userParam: Ptr): Unit =
        GLWrapper.instance.GL43.glDebugMessageCallback(callback, userParam)

public inline fun glDebugMessageCallback(callback: Long, userParam: Long): Unit =
        GLWrapper.instance.GL43.glDebugMessageCallback(callback, userParam)

public inline fun glGetDebugMessageLog(
    count: Int,
    bufsize: Int,
    sources: Ptr,
    types: Ptr,
    ids: Ptr,
    severities: Ptr,
    lengths: Ptr,
    messageLog: Ptr,
): Int = GLWrapper.instance.GL43.glGetDebugMessageLog(count, bufsize, sources, types, ids,
        severities, lengths, messageLog)

public inline fun glGetDebugMessageLog(
    count: Int,
    bufsize: Int,
    sources: Long,
    types: Long,
    ids: Long,
    severities: Long,
    lengths: Long,
    messageLog: Long,
): Int = GLWrapper.instance.GL43.glGetDebugMessageLog(count, bufsize, sources, types, ids,
        severities, lengths, messageLog)

public inline fun glPushDebugGroup(
    source: Int,
    id: Int,
    length: Int,
    message: Ptr,
): Unit = GLWrapper.instance.GL43.glPushDebugGroup(source, id, length, message)

public inline fun glPushDebugGroup(
    source: Int,
    id: Int,
    length: Int,
    message: Long,
): Unit = GLWrapper.instance.GL43.glPushDebugGroup(source, id, length, message)

public inline fun glPopDebugGroup(): Unit = GLWrapper.instance.GL43.glPopDebugGroup()

public inline fun glObjectLabel(
    identifier: Int,
    name: Int,
    length: Int,
    label: Ptr,
): Unit = GLWrapper.instance.GL43.glObjectLabel(identifier, name, length, label)

public inline fun glObjectLabel(
    identifier: Int,
    name: Int,
    length: Int,
    label: Long,
): Unit = GLWrapper.instance.GL43.glObjectLabel(identifier, name, length, label)

public inline fun glGetObjectLabel(
    identifier: Int,
    name: Int,
    bufSize: Int,
    length: Ptr,
    label: Ptr,
): Unit = GLWrapper.instance.GL43.glGetObjectLabel(identifier, name, bufSize, length, label)

public inline fun glGetObjectLabel(
    identifier: Int,
    name: Int,
    bufSize: Int,
    length: Long,
    label: Long,
): Unit = GLWrapper.instance.GL43.glGetObjectLabel(identifier, name, bufSize, length, label)

public inline fun glObjectPtrLabel(
    ptr: Ptr,
    length: Int,
    label: Ptr,
): Unit = GLWrapper.instance.GL43.glObjectPtrLabel(ptr, length, label)

public inline fun glObjectPtrLabel(
    ptr: Long,
    length: Int,
    label: Long,
): Unit = GLWrapper.instance.GL43.glObjectPtrLabel(ptr, length, label)

public inline fun glGetObjectPtrLabel(
    ptr: Ptr,
    bufSize: Int,
    length: Ptr,
    label: Ptr,
): Unit = GLWrapper.instance.GL43.glGetObjectPtrLabel(ptr, bufSize, length, label)

public inline fun glGetObjectPtrLabel(
    ptr: Long,
    bufSize: Int,
    length: Long,
    label: Long,
): Unit = GLWrapper.instance.GL43.glGetObjectPtrLabel(ptr, bufSize, length, label)

public inline fun glFramebufferParameteri(
    target: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.GL43.glFramebufferParameteri(target, pname, `param`)

public inline fun glGetFramebufferParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL43.glGetFramebufferParameteriv(target, pname, params)

public inline fun glGetFramebufferParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL43.glGetFramebufferParameteriv(target, pname, params)

public inline fun glGetInternalformati64v(
    target: Int,
    internalformat: Int,
    pname: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL43.glGetInternalformati64v(target, internalformat, pname, bufSize,
        params)

public inline fun glGetInternalformati64v(
    target: Int,
    internalformat: Int,
    pname: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.GL43.glGetInternalformati64v(target, internalformat, pname, bufSize,
        params)

public inline fun glInvalidateTexSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
): Unit = GLWrapper.instance.GL43.glInvalidateTexSubImage(texture, level, xoffset, yoffset, zoffset,
        width, height, depth)

public inline fun glInvalidateTexImage(texture: Int, level: Int): Unit =
        GLWrapper.instance.GL43.glInvalidateTexImage(texture, level)

public inline fun glInvalidateBufferSubData(
    buffer: Int,
    offset: Long,
    length: Long,
): Unit = GLWrapper.instance.GL43.glInvalidateBufferSubData(buffer, offset, length)

public inline fun glInvalidateBufferData(buffer: Int): Unit =
        GLWrapper.instance.GL43.glInvalidateBufferData(buffer)

public inline fun glInvalidateFramebuffer(
    target: Int,
    numAttachments: Int,
    attachments: Ptr,
): Unit = GLWrapper.instance.GL43.glInvalidateFramebuffer(target, numAttachments, attachments)

public inline fun glInvalidateFramebuffer(
    target: Int,
    numAttachments: Int,
    attachments: Long,
): Unit = GLWrapper.instance.GL43.glInvalidateFramebuffer(target, numAttachments, attachments)

public inline fun glInvalidateSubFramebuffer(
    target: Int,
    numAttachments: Int,
    attachments: Ptr,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL43.glInvalidateSubFramebuffer(target, numAttachments, attachments, x,
        y, width, height)

public inline fun glInvalidateSubFramebuffer(
    target: Int,
    numAttachments: Int,
    attachments: Long,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL43.glInvalidateSubFramebuffer(target, numAttachments, attachments, x,
        y, width, height)

public inline fun glMultiDrawArraysIndirect(
    mode: Int,
    indirect: Ptr,
    drawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.GL43.glMultiDrawArraysIndirect(mode, indirect, drawcount, stride)

public inline fun glMultiDrawArraysIndirect(
    mode: Int,
    indirect: Long,
    drawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.GL43.glMultiDrawArraysIndirect(mode, indirect, drawcount, stride)

public inline fun glMultiDrawElementsIndirect(
    mode: Int,
    type: Int,
    indirect: Ptr,
    drawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.GL43.glMultiDrawElementsIndirect(mode, type, indirect, drawcount,
        stride)

public inline fun glMultiDrawElementsIndirect(
    mode: Int,
    type: Int,
    indirect: Long,
    drawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.GL43.glMultiDrawElementsIndirect(mode, type, indirect, drawcount,
        stride)

public inline fun glGetProgramInterfaceiv(
    program: Int,
    programInterface: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL43.glGetProgramInterfaceiv(program, programInterface, pname, params)

public inline fun glGetProgramInterfaceiv(
    program: Int,
    programInterface: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL43.glGetProgramInterfaceiv(program, programInterface, pname, params)

public inline fun glGetProgramResourceIndex(
    program: Int,
    programInterface: Int,
    name: Ptr,
): Int = GLWrapper.instance.GL43.glGetProgramResourceIndex(program, programInterface, name)

public inline fun glGetProgramResourceIndex(
    program: Int,
    programInterface: Int,
    name: Long,
): Int = GLWrapper.instance.GL43.glGetProgramResourceIndex(program, programInterface, name)

public inline fun glGetProgramResourceName(
    program: Int,
    programInterface: Int,
    index: Int,
    bufSize: Int,
    length: Ptr,
    name: Ptr,
): Unit = GLWrapper.instance.GL43.glGetProgramResourceName(program, programInterface, index,
        bufSize, length, name)

public inline fun glGetProgramResourceName(
    program: Int,
    programInterface: Int,
    index: Int,
    bufSize: Int,
    length: Long,
    name: Long,
): Unit = GLWrapper.instance.GL43.glGetProgramResourceName(program, programInterface, index,
        bufSize, length, name)

public inline fun glGetProgramResourceiv(
    program: Int,
    programInterface: Int,
    index: Int,
    propCount: Int,
    props: Ptr,
    bufSize: Int,
    length: Ptr,
    params: Ptr,
): Unit = GLWrapper.instance.GL43.glGetProgramResourceiv(program, programInterface, index,
        propCount, props, bufSize, length, params)

public inline fun glGetProgramResourceiv(
    program: Int,
    programInterface: Int,
    index: Int,
    propCount: Int,
    props: Long,
    bufSize: Int,
    length: Long,
    params: Long,
): Unit = GLWrapper.instance.GL43.glGetProgramResourceiv(program, programInterface, index,
        propCount, props, bufSize, length, params)

public inline fun glGetProgramResourceLocation(
    program: Int,
    programInterface: Int,
    name: Ptr,
): Int = GLWrapper.instance.GL43.glGetProgramResourceLocation(program, programInterface, name)

public inline fun glGetProgramResourceLocation(
    program: Int,
    programInterface: Int,
    name: Long,
): Int = GLWrapper.instance.GL43.glGetProgramResourceLocation(program, programInterface, name)

public inline fun glGetProgramResourceLocationIndex(
    program: Int,
    programInterface: Int,
    name: Ptr,
): Int = GLWrapper.instance.GL43.glGetProgramResourceLocationIndex(program, programInterface, name)

public inline fun glGetProgramResourceLocationIndex(
    program: Int,
    programInterface: Int,
    name: Long,
): Int = GLWrapper.instance.GL43.glGetProgramResourceLocationIndex(program, programInterface, name)

public inline fun glShaderStorageBlockBinding(
    program: Int,
    storageBlockIndex: Int,
    storageBlockBinding: Int,
): Unit = GLWrapper.instance.GL43.glShaderStorageBlockBinding(program, storageBlockIndex,
        storageBlockBinding)

public inline fun glTexBufferRange(
    target: Int,
    internalformat: Int,
    buffer: Int,
    offset: Long,
    size: Long,
): Unit = GLWrapper.instance.GL43.glTexBufferRange(target, internalformat, buffer, offset, size)

public inline fun glTexStorage2DMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    fixedsamplelocations: Boolean,
): Unit = GLWrapper.instance.GL43.glTexStorage2DMultisample(target, samples, internalformat, width,
        height, fixedsamplelocations)

public inline fun glTexStorage3DMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedsamplelocations: Boolean,
): Unit = GLWrapper.instance.GL43.glTexStorage3DMultisample(target, samples, internalformat, width,
        height, depth, fixedsamplelocations)

public inline fun glTextureView(
    texture: Int,
    target: Int,
    origtexture: Int,
    internalformat: Int,
    minlevel: Int,
    numlevels: Int,
    minlayer: Int,
    numlayers: Int,
): Unit = GLWrapper.instance.GL43.glTextureView(texture, target, origtexture, internalformat,
        minlevel, numlevels, minlayer, numlayers)

public inline fun glBindVertexBuffer(
    bindingindex: Int,
    buffer: Int,
    offset: Long,
    stride: Int,
): Unit = GLWrapper.instance.GL43.glBindVertexBuffer(bindingindex, buffer, offset, stride)

public inline fun glVertexAttribFormat(
    attribindex: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    relativeoffset: Int,
): Unit = GLWrapper.instance.GL43.glVertexAttribFormat(attribindex, size, type, normalized,
        relativeoffset)

public inline fun glVertexAttribIFormat(
    attribindex: Int,
    size: Int,
    type: Int,
    relativeoffset: Int,
): Unit = GLWrapper.instance.GL43.glVertexAttribIFormat(attribindex, size, type, relativeoffset)

public inline fun glVertexAttribLFormat(
    attribindex: Int,
    size: Int,
    type: Int,
    relativeoffset: Int,
): Unit = GLWrapper.instance.GL43.glVertexAttribLFormat(attribindex, size, type, relativeoffset)

public inline fun glVertexAttribBinding(attribindex: Int, bindingindex: Int): Unit =
        GLWrapper.instance.GL43.glVertexAttribBinding(attribindex, bindingindex)

public inline fun glVertexBindingDivisor(bindingindex: Int, divisor: Int): Unit =
        GLWrapper.instance.GL43.glVertexBindingDivisor(bindingindex, divisor)

public inline fun glObjectLabel(
    identifier: Int,
    name: Int,
    label: CharSequence,
): Unit = GLWrapper.instance.GL43.glObjectLabel(identifier, name, label)

public inline fun glGetProgramResourceIndex(
    program: Int,
    programInterface: Int,
    name: CharSequence,
): Int = GLWrapper.instance.GL43.glGetProgramResourceIndex(program, programInterface, name)

public inline fun glPushDebugGroup(
    source: Int,
    id: Int,
    message: CharSequence,
): Unit = GLWrapper.instance.GL43.glPushDebugGroup(source, id, message)
