@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVPrimitiveShadingRate : GLBase

public const val GL_SHADING_RATE_IMAGE_PER_PRIMITIVE_NV: Int = 38_321

public const val GL_SHADING_RATE_IMAGE_PALETTE_COUNT_NV: Int = 38_322
