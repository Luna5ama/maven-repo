@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTCompiledVertexArray : GLBase {
    public fun glLockArraysEXT(first: Int, count: Int)

    public fun glUnlockArraysEXT()
}

public const val GL_ARRAY_ELEMENT_LOCK_FIRST_EXT: Int = 33_192

public const val GL_ARRAY_ELEMENT_LOCK_COUNT_EXT: Int = 33_193

public inline fun glLockArraysEXT(first: Int, count: Int): Unit =
        GLWrapper.instance.EXTCompiledVertexArray.glLockArraysEXT(first, count)

public inline fun glUnlockArraysEXT(): Unit =
        GLWrapper.instance.EXTCompiledVertexArray.glUnlockArraysEXT()
