@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL12 : GLBase {
    @PtrParameter([9])
    public fun glTexImage3D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTexImage3D(
        target: Int,
        level: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        border: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([10])
    public fun glTexSubImage3D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTexSubImage3D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    public fun glCopyTexSubImage3D(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([5])
    public fun glDrawRangeElements(
        mode: Int,
        start: Int,
        end: Int,
        count: Int,
        type: Int,
        indices: Ptr,
    )

    @Unsafe
    public fun glDrawRangeElements(
        mode: Int,
        start: Int,
        end: Int,
        count: Int,
        type: Int,
        indices: Long,
    )
}

public const val GL_ALIASED_LINE_WIDTH_RANGE: Int = 33_902

public const val GL_SMOOTH_POINT_SIZE_RANGE: Int = 2_834

public const val GL_SMOOTH_POINT_SIZE_GRANULARITY: Int = 2_835

public const val GL_SMOOTH_LINE_WIDTH_RANGE: Int = 2_850

public const val GL_SMOOTH_LINE_WIDTH_GRANULARITY: Int = 2_851

public const val GL_TEXTURE_BINDING_3D: Int = 32_874

public const val GL_PACK_SKIP_IMAGES: Int = 32_875

public const val GL_PACK_IMAGE_HEIGHT: Int = 32_876

public const val GL_UNPACK_SKIP_IMAGES: Int = 32_877

public const val GL_UNPACK_IMAGE_HEIGHT: Int = 32_878

public const val GL_TEXTURE_3D: Int = 32_879

public const val GL_PROXY_TEXTURE_3D: Int = 32_880

public const val GL_TEXTURE_DEPTH: Int = 32_881

public const val GL_TEXTURE_WRAP_R: Int = 32_882

public const val GL_MAX_3D_TEXTURE_SIZE: Int = 32_883

public const val GL_BGR: Int = 32_992

public const val GL_BGRA: Int = 32_993

public const val GL_UNSIGNED_BYTE_3_3_2: Int = 32_818

public const val GL_UNSIGNED_BYTE_2_3_3_REV: Int = 33_634

public const val GL_UNSIGNED_SHORT_5_6_5: Int = 33_635

public const val GL_UNSIGNED_SHORT_5_6_5_REV: Int = 33_636

public const val GL_UNSIGNED_SHORT_4_4_4_4: Int = 32_819

public const val GL_UNSIGNED_SHORT_4_4_4_4_REV: Int = 33_637

public const val GL_UNSIGNED_SHORT_5_5_5_1: Int = 32_820

public const val GL_UNSIGNED_SHORT_1_5_5_5_REV: Int = 33_638

public const val GL_UNSIGNED_INT_8_8_8_8: Int = 32_821

public const val GL_UNSIGNED_INT_8_8_8_8_REV: Int = 33_639

public const val GL_UNSIGNED_INT_10_10_10_2: Int = 32_822

public const val GL_UNSIGNED_INT_2_10_10_10_REV: Int = 33_640

public const val GL_CLAMP_TO_EDGE: Int = 33_071

public const val GL_TEXTURE_MIN_LOD: Int = 33_082

public const val GL_TEXTURE_MAX_LOD: Int = 33_083

public const val GL_TEXTURE_BASE_LEVEL: Int = 33_084

public const val GL_TEXTURE_MAX_LEVEL: Int = 33_085

public const val GL_MAX_ELEMENTS_VERTICES: Int = 33_000

public const val GL_MAX_ELEMENTS_INDICES: Int = 33_001

public inline fun glTexImage3D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL12.glTexImage3D(target, level, internalformat, width, height, depth,
        border, format, type, pixels)

public inline fun glTexImage3D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL12.glTexImage3D(target, level, internalformat, width, height, depth,
        border, format, type, pixels)

public inline fun glTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL12.glTexSubImage3D(target, level, xoffset, yoffset, zoffset, width,
        height, depth, format, type, pixels)

public inline fun glTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL12.glTexSubImage3D(target, level, xoffset, yoffset, zoffset, width,
        height, depth, format, type, pixels)

public inline fun glCopyTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL12.glCopyTexSubImage3D(target, level, xoffset, yoffset, zoffset, x,
        y, width, height)

public inline fun glDrawRangeElements(
    mode: Int,
    start: Int,
    end: Int,
    count: Int,
    type: Int,
    indices: Ptr,
): Unit = GLWrapper.instance.GL12.glDrawRangeElements(mode, start, end, count, type, indices)

public inline fun glDrawRangeElements(
    mode: Int,
    start: Int,
    end: Int,
    count: Int,
    type: Int,
    indices: Long,
): Unit = GLWrapper.instance.GL12.glDrawRangeElements(mode, start, end, count, type, indices)
