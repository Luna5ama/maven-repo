@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBImaging : GLBase {
    @PtrParameter([5])
    public fun glColorTable(
        target: Int,
        internalformat: Int,
        width: Int,
        format: Int,
        type: Int,
        table: Ptr,
    )

    @Unsafe
    public fun glColorTable(
        target: Int,
        internalformat: Int,
        width: Int,
        format: Int,
        type: Int,
        table: Long,
    )

    public fun glCopyColorTable(
        target: Int,
        internalformat: Int,
        x: Int,
        y: Int,
        width: Int,
    )

    @PtrParameter([2])
    public fun glColorTableParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glColorTableParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glColorTableParameterfv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glColorTableParameterfv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetColorTable(
        target: Int,
        format: Int,
        type: Int,
        table: Ptr,
    )

    @Unsafe
    public fun glGetColorTable(
        target: Int,
        format: Int,
        type: Int,
        table: Long,
    )

    @PtrParameter([2])
    public fun glGetColorTableParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetColorTableParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetColorTableParameterfv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetColorTableParameterfv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([5])
    public fun glColorSubTable(
        target: Int,
        start: Int,
        count: Int,
        format: Int,
        type: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glColorSubTable(
        target: Int,
        start: Int,
        count: Int,
        format: Int,
        type: Int,
        `data`: Long,
    )

    public fun glCopyColorSubTable(
        target: Int,
        start: Int,
        x: Int,
        y: Int,
        width: Int,
    )

    @PtrParameter([5])
    public fun glConvolutionFilter1D(
        target: Int,
        internalformat: Int,
        width: Int,
        format: Int,
        type: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glConvolutionFilter1D(
        target: Int,
        internalformat: Int,
        width: Int,
        format: Int,
        type: Int,
        `data`: Long,
    )

    @PtrParameter([6])
    public fun glConvolutionFilter2D(
        target: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glConvolutionFilter2D(
        target: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        `data`: Long,
    )

    public fun glCopyConvolutionFilter1D(
        target: Int,
        internalformat: Int,
        x: Int,
        y: Int,
        width: Int,
    )

    public fun glCopyConvolutionFilter2D(
        target: Int,
        internalformat: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([3])
    public fun glGetConvolutionFilter(
        target: Int,
        format: Int,
        type: Int,
        image: Ptr,
    )

    @Unsafe
    public fun glGetConvolutionFilter(
        target: Int,
        format: Int,
        type: Int,
        image: Long,
    )

    @PtrParameter([6, 7])
    public fun glSeparableFilter2D(
        target: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        row: Ptr,
        column: Ptr,
    )

    @Unsafe
    public fun glSeparableFilter2D(
        target: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        row: Long,
        column: Long,
    )

    @PtrParameter([3, 4, 5])
    public fun glGetSeparableFilter(
        target: Int,
        format: Int,
        type: Int,
        row: Ptr,
        column: Ptr,
        span: Ptr,
    )

    @Unsafe
    public fun glGetSeparableFilter(
        target: Int,
        format: Int,
        type: Int,
        row: Long,
        column: Long,
        span: Long,
    )

    public fun glConvolutionParameteri(
        target: Int,
        pname: Int,
        `param`: Int,
    )

    @PtrParameter([2])
    public fun glConvolutionParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glConvolutionParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glConvolutionParameterf(
        target: Int,
        pname: Int,
        `param`: Float,
    )

    @PtrParameter([2])
    public fun glConvolutionParameterfv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glConvolutionParameterfv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetConvolutionParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetConvolutionParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetConvolutionParameterfv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetConvolutionParameterfv(
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glHistogram(
        target: Int,
        width: Int,
        internalformat: Int,
        sink: Boolean,
    )

    public fun glResetHistogram(target: Int)

    @PtrParameter([4])
    public fun glGetHistogram(
        target: Int,
        reset: Boolean,
        format: Int,
        type: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glGetHistogram(
        target: Int,
        reset: Boolean,
        format: Int,
        type: Int,
        values: Long,
    )

    @PtrParameter([2])
    public fun glGetHistogramParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetHistogramParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetHistogramParameterfv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetHistogramParameterfv(
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glMinmax(
        target: Int,
        internalformat: Int,
        sink: Boolean,
    )

    public fun glResetMinmax(target: Int)

    @PtrParameter([4])
    public fun glGetMinmax(
        target: Int,
        reset: Boolean,
        format: Int,
        type: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glGetMinmax(
        target: Int,
        reset: Boolean,
        format: Int,
        type: Int,
        values: Long,
    )

    @PtrParameter([2])
    public fun glGetMinmaxParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMinmaxParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetMinmaxParameterfv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetMinmaxParameterfv(
        target: Int,
        pname: Int,
        params: Long,
    )
}

public const val GL_COLOR_TABLE: Int = 32_976

public const val GL_POST_CONVOLUTION_COLOR_TABLE: Int = 32_977

public const val GL_POST_COLOR_MATRIX_COLOR_TABLE: Int = 32_978

public const val GL_PROXY_COLOR_TABLE: Int = 32_979

public const val GL_PROXY_POST_CONVOLUTION_COLOR_TABLE: Int = 32_980

public const val GL_PROXY_POST_COLOR_MATRIX_COLOR_TABLE: Int = 32_981

public const val GL_COLOR_TABLE_SCALE: Int = 32_982

public const val GL_COLOR_TABLE_BIAS: Int = 32_983

public const val GL_COLOR_TABLE_FORMAT: Int = 32_984

public const val GL_COLOR_TABLE_WIDTH: Int = 32_985

public const val GL_COLOR_TABLE_RED_SIZE: Int = 32_986

public const val GL_COLOR_TABLE_GREEN_SIZE: Int = 32_987

public const val GL_COLOR_TABLE_BLUE_SIZE: Int = 32_988

public const val GL_COLOR_TABLE_ALPHA_SIZE: Int = 32_989

public const val GL_COLOR_TABLE_LUMINANCE_SIZE: Int = 32_990

public const val GL_COLOR_TABLE_INTENSITY_SIZE: Int = 32_991

public const val GL_TABLE_TOO_LARGE: Int = 32_817

public const val GL_CONVOLUTION_1D: Int = 32_784

public const val GL_CONVOLUTION_2D: Int = 32_785

public const val GL_SEPARABLE_2D: Int = 32_786

public const val GL_CONVOLUTION_BORDER_MODE: Int = 32_787

public const val GL_CONVOLUTION_FILTER_SCALE: Int = 32_788

public const val GL_CONVOLUTION_FILTER_BIAS: Int = 32_789

public const val GL_REDUCE: Int = 32_790

public const val GL_CONVOLUTION_FORMAT: Int = 32_791

public const val GL_CONVOLUTION_WIDTH: Int = 32_792

public const val GL_CONVOLUTION_HEIGHT: Int = 32_793

public const val GL_MAX_CONVOLUTION_WIDTH: Int = 32_794

public const val GL_MAX_CONVOLUTION_HEIGHT: Int = 32_795

public const val GL_POST_CONVOLUTION_RED_SCALE: Int = 32_796

public const val GL_POST_CONVOLUTION_GREEN_SCALE: Int = 32_797

public const val GL_POST_CONVOLUTION_BLUE_SCALE: Int = 32_798

public const val GL_POST_CONVOLUTION_ALPHA_SCALE: Int = 32_799

public const val GL_POST_CONVOLUTION_RED_BIAS: Int = 32_800

public const val GL_POST_CONVOLUTION_GREEN_BIAS: Int = 32_801

public const val GL_POST_CONVOLUTION_BLUE_BIAS: Int = 32_802

public const val GL_POST_CONVOLUTION_ALPHA_BIAS: Int = 32_803

public const val GL_CONSTANT_BORDER: Int = 33_105

public const val GL_REPLICATE_BORDER: Int = 33_107

public const val GL_CONVOLUTION_BORDER_COLOR: Int = 33_108

public const val GL_COLOR_MATRIX: Int = 32_945

public const val GL_COLOR_MATRIX_STACK_DEPTH: Int = 32_946

public const val GL_MAX_COLOR_MATRIX_STACK_DEPTH: Int = 32_947

public const val GL_POST_COLOR_MATRIX_RED_SCALE: Int = 32_948

public const val GL_POST_COLOR_MATRIX_GREEN_SCALE: Int = 32_949

public const val GL_POST_COLOR_MATRIX_BLUE_SCALE: Int = 32_950

public const val GL_POST_COLOR_MATRIX_ALPHA_SCALE: Int = 32_951

public const val GL_POST_COLOR_MATRIX_RED_BIAS: Int = 32_952

public const val GL_POST_COLOR_MATRIX_GREEN_BIAS: Int = 32_953

public const val GL_POST_COLOR_MATRIX_BLUE_BIAS: Int = 32_954

public const val GL_POST_COLOR_MATRIX_ALPHA_BIAS: Int = 32_955

public const val GL_HISTOGRAM: Int = 32_804

public const val GL_PROXY_HISTOGRAM: Int = 32_805

public const val GL_HISTOGRAM_WIDTH: Int = 32_806

public const val GL_HISTOGRAM_FORMAT: Int = 32_807

public const val GL_HISTOGRAM_RED_SIZE: Int = 32_808

public const val GL_HISTOGRAM_GREEN_SIZE: Int = 32_809

public const val GL_HISTOGRAM_BLUE_SIZE: Int = 32_810

public const val GL_HISTOGRAM_ALPHA_SIZE: Int = 32_811

public const val GL_HISTOGRAM_LUMINANCE_SIZE: Int = 32_812

public const val GL_HISTOGRAM_SINK: Int = 32_813

public const val GL_MINMAX: Int = 32_814

public const val GL_MINMAX_FORMAT: Int = 32_815

public const val GL_MINMAX_SINK: Int = 32_816

public const val GL_BLEND_COLOR: Int = 32_773

public const val GL_BLEND_EQUATION: Int = 32_777

public inline fun glColorTable(
    target: Int,
    internalformat: Int,
    width: Int,
    format: Int,
    type: Int,
    table: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glColorTable(target, internalformat, width, format, type,
        table)

public inline fun glColorTable(
    target: Int,
    internalformat: Int,
    width: Int,
    format: Int,
    type: Int,
    table: Long,
): Unit = GLWrapper.instance.ARBImaging.glColorTable(target, internalformat, width, format, type,
        table)

public inline fun glCopyColorTable(
    target: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
): Unit = GLWrapper.instance.ARBImaging.glCopyColorTable(target, internalformat, x, y, width)

public inline fun glColorTableParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glColorTableParameteriv(target, pname, params)

public inline fun glColorTableParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glColorTableParameteriv(target, pname, params)

public inline fun glColorTableParameterfv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glColorTableParameterfv(target, pname, params)

public inline fun glColorTableParameterfv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glColorTableParameterfv(target, pname, params)

public inline fun glGetColorTable(
    target: Int,
    format: Int,
    type: Int,
    table: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetColorTable(target, format, type, table)

public inline fun glGetColorTable(
    target: Int,
    format: Int,
    type: Int,
    table: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetColorTable(target, format, type, table)

public inline fun glGetColorTableParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetColorTableParameteriv(target, pname, params)

public inline fun glGetColorTableParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetColorTableParameteriv(target, pname, params)

public inline fun glGetColorTableParameterfv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetColorTableParameterfv(target, pname, params)

public inline fun glGetColorTableParameterfv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetColorTableParameterfv(target, pname, params)

public inline fun glColorSubTable(
    target: Int,
    start: Int,
    count: Int,
    format: Int,
    type: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glColorSubTable(target, start, count, format, type, `data`)

public inline fun glColorSubTable(
    target: Int,
    start: Int,
    count: Int,
    format: Int,
    type: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBImaging.glColorSubTable(target, start, count, format, type, `data`)

public inline fun glCopyColorSubTable(
    target: Int,
    start: Int,
    x: Int,
    y: Int,
    width: Int,
): Unit = GLWrapper.instance.ARBImaging.glCopyColorSubTable(target, start, x, y, width)

public inline fun glConvolutionFilter1D(
    target: Int,
    internalformat: Int,
    width: Int,
    format: Int,
    type: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionFilter1D(target, internalformat, width, format,
        type, `data`)

public inline fun glConvolutionFilter1D(
    target: Int,
    internalformat: Int,
    width: Int,
    format: Int,
    type: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionFilter1D(target, internalformat, width, format,
        type, `data`)

public inline fun glConvolutionFilter2D(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionFilter2D(target, internalformat, width, height,
        format, type, `data`)

public inline fun glConvolutionFilter2D(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionFilter2D(target, internalformat, width, height,
        format, type, `data`)

public inline fun glCopyConvolutionFilter1D(
    target: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
): Unit = GLWrapper.instance.ARBImaging.glCopyConvolutionFilter1D(target, internalformat, x, y,
        width)

public inline fun glCopyConvolutionFilter2D(
    target: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.ARBImaging.glCopyConvolutionFilter2D(target, internalformat, x, y,
        width, height)

public inline fun glGetConvolutionFilter(
    target: Int,
    format: Int,
    type: Int,
    image: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetConvolutionFilter(target, format, type, image)

public inline fun glGetConvolutionFilter(
    target: Int,
    format: Int,
    type: Int,
    image: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetConvolutionFilter(target, format, type, image)

public inline fun glSeparableFilter2D(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    row: Ptr,
    column: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glSeparableFilter2D(target, internalformat, width, height,
        format, type, row, column)

public inline fun glSeparableFilter2D(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    row: Long,
    column: Long,
): Unit = GLWrapper.instance.ARBImaging.glSeparableFilter2D(target, internalformat, width, height,
        format, type, row, column)

public inline fun glGetSeparableFilter(
    target: Int,
    format: Int,
    type: Int,
    row: Ptr,
    column: Ptr,
    span: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetSeparableFilter(target, format, type, row, column,
        span)

public inline fun glGetSeparableFilter(
    target: Int,
    format: Int,
    type: Int,
    row: Long,
    column: Long,
    span: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetSeparableFilter(target, format, type, row, column,
        span)

public inline fun glConvolutionParameteri(
    target: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionParameteri(target, pname, `param`)

public inline fun glConvolutionParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionParameteriv(target, pname, params)

public inline fun glConvolutionParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionParameteriv(target, pname, params)

public inline fun glConvolutionParameterf(
    target: Int,
    pname: Int,
    `param`: Float,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionParameterf(target, pname, `param`)

public inline fun glConvolutionParameterfv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionParameterfv(target, pname, params)

public inline fun glConvolutionParameterfv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glConvolutionParameterfv(target, pname, params)

public inline fun glGetConvolutionParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetConvolutionParameteriv(target, pname, params)

public inline fun glGetConvolutionParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetConvolutionParameteriv(target, pname, params)

public inline fun glGetConvolutionParameterfv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetConvolutionParameterfv(target, pname, params)

public inline fun glGetConvolutionParameterfv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetConvolutionParameterfv(target, pname, params)

public inline fun glHistogram(
    target: Int,
    width: Int,
    internalformat: Int,
    sink: Boolean,
): Unit = GLWrapper.instance.ARBImaging.glHistogram(target, width, internalformat, sink)

public inline fun glResetHistogram(target: Int): Unit =
        GLWrapper.instance.ARBImaging.glResetHistogram(target)

public inline fun glGetHistogram(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    values: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetHistogram(target, reset, format, type, values)

public inline fun glGetHistogram(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    values: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetHistogram(target, reset, format, type, values)

public inline fun glGetHistogramParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetHistogramParameteriv(target, pname, params)

public inline fun glGetHistogramParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetHistogramParameteriv(target, pname, params)

public inline fun glGetHistogramParameterfv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetHistogramParameterfv(target, pname, params)

public inline fun glGetHistogramParameterfv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetHistogramParameterfv(target, pname, params)

public inline fun glMinmax(
    target: Int,
    internalformat: Int,
    sink: Boolean,
): Unit = GLWrapper.instance.ARBImaging.glMinmax(target, internalformat, sink)

public inline fun glResetMinmax(target: Int): Unit =
        GLWrapper.instance.ARBImaging.glResetMinmax(target)

public inline fun glGetMinmax(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    values: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetMinmax(target, reset, format, type, values)

public inline fun glGetMinmax(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    values: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetMinmax(target, reset, format, type, values)

public inline fun glGetMinmaxParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetMinmaxParameteriv(target, pname, params)

public inline fun glGetMinmaxParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetMinmaxParameteriv(target, pname, params)

public inline fun glGetMinmaxParameterfv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBImaging.glGetMinmaxParameterfv(target, pname, params)

public inline fun glGetMinmaxParameterfv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBImaging.glGetMinmaxParameterfv(target, pname, params)
