@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTEGLImageStorage : GLBase {
    @PtrParameter([2])
    public fun glEGLImageTargetTexStorageEXT(
        target: Int,
        image: Long,
        attrib_list: Ptr,
    )

    @Unsafe
    public fun glEGLImageTargetTexStorageEXT(
        target: Int,
        image: Long,
        attrib_list: Long,
    )

    @PtrParameter([2])
    public fun glEGLImageTargetTextureStorageEXT(
        texture: Int,
        image: Long,
        attrib_list: Ptr,
    )

    @Unsafe
    public fun glEGLImageTargetTextureStorageEXT(
        texture: Int,
        image: Long,
        attrib_list: Long,
    )
}

public inline fun glEGLImageTargetTexStorageEXT(
    target: Int,
    image: Long,
    attrib_list: Ptr,
): Unit = GLWrapper.instance.EXTEGLImageStorage.glEGLImageTargetTexStorageEXT(target, image,
        attrib_list)

public inline fun glEGLImageTargetTexStorageEXT(
    target: Int,
    image: Long,
    attrib_list: Long,
): Unit = GLWrapper.instance.EXTEGLImageStorage.glEGLImageTargetTexStorageEXT(target, image,
        attrib_list)

public inline fun glEGLImageTargetTextureStorageEXT(
    texture: Int,
    image: Long,
    attrib_list: Ptr,
): Unit = GLWrapper.instance.EXTEGLImageStorage.glEGLImageTargetTextureStorageEXT(texture, image,
        attrib_list)

public inline fun glEGLImageTargetTextureStorageEXT(
    texture: Int,
    image: Long,
    attrib_list: Long,
): Unit = GLWrapper.instance.EXTEGLImageStorage.glEGLImageTargetTextureStorageEXT(texture, image,
        attrib_list)
