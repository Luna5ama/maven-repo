@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface KHRTextureCompressionASTCLDR : GLBase

public const val GL_COMPRESSED_RGBA_ASTC_4x4_KHR: Int = 37_808

public const val GL_COMPRESSED_RGBA_ASTC_5x4_KHR: Int = 37_809

public const val GL_COMPRESSED_RGBA_ASTC_5x5_KHR: Int = 37_810

public const val GL_COMPRESSED_RGBA_ASTC_6x5_KHR: Int = 37_811

public const val GL_COMPRESSED_RGBA_ASTC_6x6_KHR: Int = 37_812

public const val GL_COMPRESSED_RGBA_ASTC_8x5_KHR: Int = 37_813

public const val GL_COMPRESSED_RGBA_ASTC_8x6_KHR: Int = 37_814

public const val GL_COMPRESSED_RGBA_ASTC_8x8_KHR: Int = 37_815

public const val GL_COMPRESSED_RGBA_ASTC_10x5_KHR: Int = 37_816

public const val GL_COMPRESSED_RGBA_ASTC_10x6_KHR: Int = 37_817

public const val GL_COMPRESSED_RGBA_ASTC_10x8_KHR: Int = 37_818

public const val GL_COMPRESSED_RGBA_ASTC_10x10_KHR: Int = 37_819

public const val GL_COMPRESSED_RGBA_ASTC_12x10_KHR: Int = 37_820

public const val GL_COMPRESSED_RGBA_ASTC_12x12_KHR: Int = 37_821

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR: Int = 37_840

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR: Int = 37_841

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR: Int = 37_842

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR: Int = 37_843

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR: Int = 37_844

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR: Int = 37_845

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR: Int = 37_846

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR: Int = 37_847

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR: Int = 37_848

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR: Int = 37_849

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR: Int = 37_850

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR: Int = 37_851

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR: Int = 37_852

public const val GL_COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR: Int = 37_853
