@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTSemaphoreFD : GLBase {
    public fun glImportSemaphoreFdEXT(
        semaphore: Int,
        handleType: Int,
        fd: Int,
    )
}

public inline fun glImportSemaphoreFdEXT(
    semaphore: Int,
    handleType: Int,
    fd: Int,
): Unit = GLWrapper.instance.EXTSemaphoreFD.glImportSemaphoreFdEXT(semaphore, handleType, fd)
