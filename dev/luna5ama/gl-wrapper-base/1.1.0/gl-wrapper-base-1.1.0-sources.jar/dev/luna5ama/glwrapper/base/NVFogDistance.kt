@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVFogDistance : GLBase

public const val GL_FOG_DISTANCE_MODE_NV: Int = 34_138

public const val GL_EYE_RADIAL_NV: Int = 34_139

public const val GL_EYE_PLANE_ABSOLUTE_NV: Int = 34_140
