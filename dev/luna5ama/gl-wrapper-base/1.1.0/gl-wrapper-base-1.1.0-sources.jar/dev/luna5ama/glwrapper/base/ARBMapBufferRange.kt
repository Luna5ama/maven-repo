@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress

public interface ARBMapBufferRange : GLBase {
    @PtrReturn
    public fun glMapBufferRange(
        target: Int,
        offset: Long,
        length: Long,
        access: Int,
    ): Ptr
}
