@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBVertexBlend : GLBase {
    @PtrParameter([1])
    public fun glWeightfvARB(size: Int, weights: Ptr)

    @Unsafe
    public fun glWeightfvARB(size: Int, weights: Long)

    @PtrParameter([1])
    public fun glWeightbvARB(size: Int, weights: Ptr)

    @Unsafe
    public fun glWeightbvARB(size: Int, weights: Long)

    @PtrParameter([1])
    public fun glWeightubvARB(size: Int, weights: Ptr)

    @Unsafe
    public fun glWeightubvARB(size: Int, weights: Long)

    @PtrParameter([1])
    public fun glWeightsvARB(size: Int, weights: Ptr)

    @Unsafe
    public fun glWeightsvARB(size: Int, weights: Long)

    @PtrParameter([1])
    public fun glWeightusvARB(size: Int, weights: Ptr)

    @Unsafe
    public fun glWeightusvARB(size: Int, weights: Long)

    @PtrParameter([1])
    public fun glWeightivARB(size: Int, weights: Ptr)

    @Unsafe
    public fun glWeightivARB(size: Int, weights: Long)

    @PtrParameter([1])
    public fun glWeightuivARB(size: Int, weights: Ptr)

    @Unsafe
    public fun glWeightuivARB(size: Int, weights: Long)

    @PtrParameter([1])
    public fun glWeightdvARB(size: Int, weights: Ptr)

    @Unsafe
    public fun glWeightdvARB(size: Int, weights: Long)

    @PtrParameter([3])
    public fun glWeightPointerARB(
        size: Int,
        type: Int,
        stride: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glWeightPointerARB(
        size: Int,
        type: Int,
        stride: Int,
        pointer: Long,
    )

    public fun glVertexBlendARB(count: Int)
}

public const val GL_MAX_VERTEX_UNITS_ARB: Int = 34_468

public const val GL_ACTIVE_VERTEX_UNITS_ARB: Int = 34_469

public const val GL_WEIGHT_SUM_UNITY_ARB: Int = 34_470

public const val GL_VERTEX_BLEND_ARB: Int = 34_471

public const val GL_MODELVIEW0_ARB: Int = 5_888

public const val GL_MODELVIEW1_ARB: Int = 34_058

public const val GL_MODELVIEW2_ARB: Int = 34_594

public const val GL_MODELVIEW3_ARB: Int = 34_595

public const val GL_MODELVIEW4_ARB: Int = 34_596

public const val GL_MODELVIEW5_ARB: Int = 34_597

public const val GL_MODELVIEW6_ARB: Int = 34_598

public const val GL_MODELVIEW7_ARB: Int = 34_599

public const val GL_MODELVIEW8_ARB: Int = 34_600

public const val GL_MODELVIEW9_ARB: Int = 34_601

public const val GL_MODELVIEW10_ARB: Int = 34_602

public const val GL_MODELVIEW11_ARB: Int = 34_603

public const val GL_MODELVIEW12_ARB: Int = 34_604

public const val GL_MODELVIEW13_ARB: Int = 34_605

public const val GL_MODELVIEW14_ARB: Int = 34_606

public const val GL_MODELVIEW15_ARB: Int = 34_607

public const val GL_MODELVIEW16_ARB: Int = 34_608

public const val GL_MODELVIEW17_ARB: Int = 34_609

public const val GL_MODELVIEW18_ARB: Int = 34_610

public const val GL_MODELVIEW19_ARB: Int = 34_611

public const val GL_MODELVIEW20_ARB: Int = 34_612

public const val GL_MODELVIEW21_ARB: Int = 34_613

public const val GL_MODELVIEW22_ARB: Int = 34_614

public const val GL_MODELVIEW23_ARB: Int = 34_615

public const val GL_MODELVIEW24_ARB: Int = 34_616

public const val GL_MODELVIEW25_ARB: Int = 34_617

public const val GL_MODELVIEW26_ARB: Int = 34_618

public const val GL_MODELVIEW27_ARB: Int = 34_619

public const val GL_MODELVIEW28_ARB: Int = 34_620

public const val GL_MODELVIEW29_ARB: Int = 34_621

public const val GL_MODELVIEW30_ARB: Int = 34_622

public const val GL_MODELVIEW31_ARB: Int = 34_623

public const val GL_CURRENT_WEIGHT_ARB: Int = 34_472

public const val GL_WEIGHT_ARRAY_TYPE_ARB: Int = 34_473

public const val GL_WEIGHT_ARRAY_STRIDE_ARB: Int = 34_474

public const val GL_WEIGHT_ARRAY_SIZE_ARB: Int = 34_475

public const val GL_WEIGHT_ARRAY_POINTER_ARB: Int = 34_476

public const val GL_WEIGHT_ARRAY_ARB: Int = 34_477

public inline fun glWeightfvARB(size: Int, weights: Ptr): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightfvARB(size, weights)

public inline fun glWeightfvARB(size: Int, weights: Long): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightfvARB(size, weights)

public inline fun glWeightbvARB(size: Int, weights: Ptr): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightbvARB(size, weights)

public inline fun glWeightbvARB(size: Int, weights: Long): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightbvARB(size, weights)

public inline fun glWeightubvARB(size: Int, weights: Ptr): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightubvARB(size, weights)

public inline fun glWeightubvARB(size: Int, weights: Long): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightubvARB(size, weights)

public inline fun glWeightsvARB(size: Int, weights: Ptr): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightsvARB(size, weights)

public inline fun glWeightsvARB(size: Int, weights: Long): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightsvARB(size, weights)

public inline fun glWeightusvARB(size: Int, weights: Ptr): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightusvARB(size, weights)

public inline fun glWeightusvARB(size: Int, weights: Long): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightusvARB(size, weights)

public inline fun glWeightivARB(size: Int, weights: Ptr): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightivARB(size, weights)

public inline fun glWeightivARB(size: Int, weights: Long): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightivARB(size, weights)

public inline fun glWeightuivARB(size: Int, weights: Ptr): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightuivARB(size, weights)

public inline fun glWeightuivARB(size: Int, weights: Long): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightuivARB(size, weights)

public inline fun glWeightdvARB(size: Int, weights: Ptr): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightdvARB(size, weights)

public inline fun glWeightdvARB(size: Int, weights: Long): Unit =
        GLWrapper.instance.ARBVertexBlend.glWeightdvARB(size, weights)

public inline fun glWeightPointerARB(
    size: Int,
    type: Int,
    stride: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.ARBVertexBlend.glWeightPointerARB(size, type, stride, pointer)

public inline fun glWeightPointerARB(
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
): Unit = GLWrapper.instance.ARBVertexBlend.glWeightPointerARB(size, type, stride, pointer)

public inline fun glVertexBlendARB(count: Int): Unit =
        GLWrapper.instance.ARBVertexBlend.glVertexBlendARB(count)
