@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBSparseBuffer : GLBase {
    public fun glBufferPageCommitmentARB(
        target: Int,
        offset: Long,
        size: Long,
        commit: Boolean,
    )

    public fun glNamedBufferPageCommitmentEXT(
        buffer: Int,
        offset: Long,
        size: Long,
        commit: Boolean,
    )

    public fun glNamedBufferPageCommitmentARB(
        buffer: Int,
        offset: Long,
        size: Long,
        commit: Boolean,
    )
}

public const val GL_SPARSE_STORAGE_BIT_ARB: Int = 1_024

public const val GL_SPARSE_BUFFER_PAGE_SIZE_ARB: Int = 33_528

public inline fun glBufferPageCommitmentARB(
    target: Int,
    offset: Long,
    size: Long,
    commit: Boolean,
): Unit = GLWrapper.instance.ARBSparseBuffer.glBufferPageCommitmentARB(target, offset, size, commit)

public inline fun glNamedBufferPageCommitmentEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    commit: Boolean,
): Unit = GLWrapper.instance.ARBSparseBuffer.glNamedBufferPageCommitmentEXT(buffer, offset, size,
        commit)

public inline fun glNamedBufferPageCommitmentARB(
    buffer: Int,
    offset: Long,
    size: Long,
    commit: Boolean,
): Unit = GLWrapper.instance.ARBSparseBuffer.glNamedBufferPageCommitmentARB(buffer, offset, size,
        commit)
