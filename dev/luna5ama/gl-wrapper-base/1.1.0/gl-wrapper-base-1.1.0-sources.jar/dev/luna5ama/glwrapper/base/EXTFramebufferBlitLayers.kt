@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTFramebufferBlitLayers : GLBase {
    public fun glBlitFramebufferLayersEXT(
        srcX0: Int,
        srcY0: Int,
        srcX1: Int,
        srcY1: Int,
        dstX0: Int,
        dstY0: Int,
        dstX1: Int,
        dstY1: Int,
        mask: Int,
        filter: Int,
    )

    public fun glBlitFramebufferLayerEXT(
        srcX0: Int,
        srcY0: Int,
        srcX1: Int,
        srcY1: Int,
        srcLayer: Int,
        dstX0: Int,
        dstY0: Int,
        dstX1: Int,
        dstY1: Int,
        dstLayer: Int,
        mask: Int,
        filter: Int,
    )
}

public inline fun glBlitFramebufferLayersEXT(
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    mask: Int,
    filter: Int,
): Unit = GLWrapper.instance.EXTFramebufferBlitLayers.glBlitFramebufferLayersEXT(srcX0, srcY0,
        srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter)

public inline fun glBlitFramebufferLayerEXT(
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    srcLayer: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    dstLayer: Int,
    mask: Int,
    filter: Int,
): Unit = GLWrapper.instance.EXTFramebufferBlitLayers.glBlitFramebufferLayerEXT(srcX0, srcY0, srcX1,
        srcY1, srcLayer, dstX0, dstY0, dstX1, dstY1, dstLayer, mask, filter)
