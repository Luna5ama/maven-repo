@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureFilterAnisotropic : GLBase

public const val GL_TEXTURE_MAX_ANISOTROPY_EXT: Int = 34_046

public const val GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT: Int = 34_047
