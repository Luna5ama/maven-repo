@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVDeepTexture3D : GLBase

public const val GL_MAX_DEEP_3D_TEXTURE_WIDTH_HEIGHT_NV: Int = 37_072

public const val GL_MAX_DEEP_3D_TEXTURE_DEPTH_NV: Int = 37_073
