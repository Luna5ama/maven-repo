@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBRobustness : GLBase {
    public fun glGetGraphicsResetStatusARB(): Int

    @PtrParameter([3])
    public fun glGetnMapdvARB(
        target: Int,
        query: Int,
        bufSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetnMapdvARB(
        target: Int,
        query: Int,
        bufSize: Int,
        `data`: Long,
    )

    @PtrParameter([3])
    public fun glGetnMapfvARB(
        target: Int,
        query: Int,
        bufSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetnMapfvARB(
        target: Int,
        query: Int,
        bufSize: Int,
        `data`: Long,
    )

    @PtrParameter([3])
    public fun glGetnMapivARB(
        target: Int,
        query: Int,
        bufSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetnMapivARB(
        target: Int,
        query: Int,
        bufSize: Int,
        `data`: Long,
    )

    @PtrParameter([2])
    public fun glGetnPixelMapfvARB(
        map: Int,
        bufSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetnPixelMapfvARB(
        map: Int,
        bufSize: Int,
        `data`: Long,
    )

    @PtrParameter([2])
    public fun glGetnPixelMapuivARB(
        map: Int,
        bufSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetnPixelMapuivARB(
        map: Int,
        bufSize: Int,
        `data`: Long,
    )

    @PtrParameter([2])
    public fun glGetnPixelMapusvARB(
        map: Int,
        bufSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetnPixelMapusvARB(
        map: Int,
        bufSize: Int,
        `data`: Long,
    )

    @PtrParameter([1])
    public fun glGetnPolygonStippleARB(bufSize: Int, pattern: Ptr)

    @Unsafe
    public fun glGetnPolygonStippleARB(bufSize: Int, pattern: Long)

    @PtrParameter([5])
    public fun glGetnTexImageARB(
        tex: Int,
        level: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        img: Ptr,
    )

    @Unsafe
    public fun glGetnTexImageARB(
        tex: Int,
        level: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        img: Long,
    )

    @PtrParameter([7])
    public fun glReadnPixelsARB(
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glReadnPixelsARB(
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        `data`: Long,
    )

    @PtrParameter([4])
    public fun glGetnColorTableARB(
        target: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        table: Ptr,
    )

    @Unsafe
    public fun glGetnColorTableARB(
        target: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        table: Long,
    )

    @PtrParameter([4])
    public fun glGetnConvolutionFilterARB(
        target: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        image: Ptr,
    )

    @Unsafe
    public fun glGetnConvolutionFilterARB(
        target: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        image: Long,
    )

    @PtrParameter([4, 6, 7])
    public fun glGetnSeparableFilterARB(
        target: Int,
        format: Int,
        type: Int,
        rowBufSize: Int,
        row: Ptr,
        columnBufSize: Int,
        column: Ptr,
        span: Ptr,
    )

    @Unsafe
    public fun glGetnSeparableFilterARB(
        target: Int,
        format: Int,
        type: Int,
        rowBufSize: Int,
        row: Long,
        columnBufSize: Int,
        column: Long,
        span: Long,
    )

    @PtrParameter([5])
    public fun glGetnHistogramARB(
        target: Int,
        reset: Boolean,
        format: Int,
        type: Int,
        bufSize: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glGetnHistogramARB(
        target: Int,
        reset: Boolean,
        format: Int,
        type: Int,
        bufSize: Int,
        values: Long,
    )

    @PtrParameter([5])
    public fun glGetnMinmaxARB(
        target: Int,
        reset: Boolean,
        format: Int,
        type: Int,
        bufSize: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glGetnMinmaxARB(
        target: Int,
        reset: Boolean,
        format: Int,
        type: Int,
        bufSize: Int,
        values: Long,
    )

    @PtrParameter([3])
    public fun glGetnCompressedTexImageARB(
        target: Int,
        level: Int,
        bufSize: Int,
        img: Ptr,
    )

    @Unsafe
    public fun glGetnCompressedTexImageARB(
        target: Int,
        level: Int,
        bufSize: Int,
        img: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformfvARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformfvARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformivARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformivARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformuivARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformuivARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformdvARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformdvARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )
}

public const val GL_GUILTY_CONTEXT_RESET_ARB: Int = 33_363

public const val GL_INNOCENT_CONTEXT_RESET_ARB: Int = 33_364

public const val GL_UNKNOWN_CONTEXT_RESET_ARB: Int = 33_365

public const val GL_RESET_NOTIFICATION_STRATEGY_ARB: Int = 33_366

public const val GL_LOSE_CONTEXT_ON_RESET_ARB: Int = 33_362

public const val GL_NO_RESET_NOTIFICATION_ARB: Int = 33_377

public const val GL_CONTEXT_FLAG_ROBUST_ACCESS_BIT_ARB: Int = 4

public inline fun glGetGraphicsResetStatusARB(): Int =
        GLWrapper.instance.ARBRobustness.glGetGraphicsResetStatusARB()

public inline fun glGetnMapdvARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnMapdvARB(target, query, bufSize, `data`)

public inline fun glGetnMapdvARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnMapdvARB(target, query, bufSize, `data`)

public inline fun glGetnMapfvARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnMapfvARB(target, query, bufSize, `data`)

public inline fun glGetnMapfvARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnMapfvARB(target, query, bufSize, `data`)

public inline fun glGetnMapivARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnMapivARB(target, query, bufSize, `data`)

public inline fun glGetnMapivARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnMapivARB(target, query, bufSize, `data`)

public inline fun glGetnPixelMapfvARB(
    map: Int,
    bufSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnPixelMapfvARB(map, bufSize, `data`)

public inline fun glGetnPixelMapfvARB(
    map: Int,
    bufSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnPixelMapfvARB(map, bufSize, `data`)

public inline fun glGetnPixelMapuivARB(
    map: Int,
    bufSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnPixelMapuivARB(map, bufSize, `data`)

public inline fun glGetnPixelMapuivARB(
    map: Int,
    bufSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnPixelMapuivARB(map, bufSize, `data`)

public inline fun glGetnPixelMapusvARB(
    map: Int,
    bufSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnPixelMapusvARB(map, bufSize, `data`)

public inline fun glGetnPixelMapusvARB(
    map: Int,
    bufSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnPixelMapusvARB(map, bufSize, `data`)

public inline fun glGetnPolygonStippleARB(bufSize: Int, pattern: Ptr): Unit =
        GLWrapper.instance.ARBRobustness.glGetnPolygonStippleARB(bufSize, pattern)

public inline fun glGetnPolygonStippleARB(bufSize: Int, pattern: Long): Unit =
        GLWrapper.instance.ARBRobustness.glGetnPolygonStippleARB(bufSize, pattern)

public inline fun glGetnTexImageARB(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    img: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnTexImageARB(tex, level, format, type, bufSize, img)

public inline fun glGetnTexImageARB(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    img: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnTexImageARB(tex, level, format, type, bufSize, img)

public inline fun glReadnPixelsARB(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glReadnPixelsARB(x, y, width, height, format, type,
        bufSize, `data`)

public inline fun glReadnPixelsARB(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.ARBRobustness.glReadnPixelsARB(x, y, width, height, format, type,
        bufSize, `data`)

public inline fun glGetnColorTableARB(
    target: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    table: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnColorTableARB(target, format, type, bufSize, table)

public inline fun glGetnColorTableARB(
    target: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    table: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnColorTableARB(target, format, type, bufSize, table)

public inline fun glGetnConvolutionFilterARB(
    target: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    image: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnConvolutionFilterARB(target, format, type, bufSize,
        image)

public inline fun glGetnConvolutionFilterARB(
    target: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    image: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnConvolutionFilterARB(target, format, type, bufSize,
        image)

public inline fun glGetnSeparableFilterARB(
    target: Int,
    format: Int,
    type: Int,
    rowBufSize: Int,
    row: Ptr,
    columnBufSize: Int,
    column: Ptr,
    span: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnSeparableFilterARB(target, format, type,
        rowBufSize, row, columnBufSize, column, span)

public inline fun glGetnSeparableFilterARB(
    target: Int,
    format: Int,
    type: Int,
    rowBufSize: Int,
    row: Long,
    columnBufSize: Int,
    column: Long,
    span: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnSeparableFilterARB(target, format, type,
        rowBufSize, row, columnBufSize, column, span)

public inline fun glGetnHistogramARB(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    bufSize: Int,
    values: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnHistogramARB(target, reset, format, type, bufSize,
        values)

public inline fun glGetnHistogramARB(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    bufSize: Int,
    values: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnHistogramARB(target, reset, format, type, bufSize,
        values)

public inline fun glGetnMinmaxARB(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    bufSize: Int,
    values: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnMinmaxARB(target, reset, format, type, bufSize,
        values)

public inline fun glGetnMinmaxARB(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    bufSize: Int,
    values: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnMinmaxARB(target, reset, format, type, bufSize,
        values)

public inline fun glGetnCompressedTexImageARB(
    target: Int,
    level: Int,
    bufSize: Int,
    img: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnCompressedTexImageARB(target, level, bufSize, img)

public inline fun glGetnCompressedTexImageARB(
    target: Int,
    level: Int,
    bufSize: Int,
    img: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnCompressedTexImageARB(target, level, bufSize, img)

public inline fun glGetnUniformfvARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnUniformfvARB(program, location, bufSize, params)

public inline fun glGetnUniformfvARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnUniformfvARB(program, location, bufSize, params)

public inline fun glGetnUniformivARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnUniformivARB(program, location, bufSize, params)

public inline fun glGetnUniformivARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnUniformivARB(program, location, bufSize, params)

public inline fun glGetnUniformuivARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnUniformuivARB(program, location, bufSize, params)

public inline fun glGetnUniformuivARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnUniformuivARB(program, location, bufSize, params)

public inline fun glGetnUniformdvARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBRobustness.glGetnUniformdvARB(program, location, bufSize, params)

public inline fun glGetnUniformdvARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBRobustness.glGetnUniformdvARB(program, location, bufSize, params)
