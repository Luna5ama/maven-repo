@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress

public interface NVQueryResource : GLBase {
    @PtrParameter([3])
    public fun glQueryResourceNV(
        queryType: Int,
        pname: Int,
        bufSize: Int,
        buffer: Ptr,
    ): Int

    @Unsafe
    public fun glQueryResourceNV(
        queryType: Int,
        pname: Int,
        bufSize: Int,
        buffer: Long,
    ): Int
}

public const val GL_QUERY_RESOURCE_TYPE_VIDMEM_ALLOC_NV: Int = 38_208

public const val GL_QUERY_RESOURCE_MEMTYPE_VIDMEM_NV: Int = 38_210

public const val GL_QUERY_RESOURCE_SYS_RESERVED_NV: Int = 38_212

public const val GL_QUERY_RESOURCE_TEXTURE_NV: Int = 38_213

public const val GL_QUERY_RESOURCE_RENDERBUFFER_NV: Int = 38_214

public const val GL_QUERY_RESOURCE_BUFFEROBJECT_NV: Int = 38_215

public inline fun glQueryResourceNV(
    queryType: Int,
    pname: Int,
    bufSize: Int,
    buffer: Ptr,
): Int = GLWrapper.instance.NVQueryResource.glQueryResourceNV(queryType, pname, bufSize, buffer)

public inline fun glQueryResourceNV(
    queryType: Int,
    pname: Int,
    bufSize: Int,
    buffer: Long,
): Int = GLWrapper.instance.NVQueryResource.glQueryResourceNV(queryType, pname, bufSize, buffer)
