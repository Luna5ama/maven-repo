@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Byte
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVPathRendering : GLBase {
    @PtrParameter([2, 5])
    public fun glPathCommandsNV(
        path: Int,
        numCommands: Int,
        commands: Ptr,
        numCoords: Int,
        coordType: Int,
        coords: Ptr,
    )

    @Unsafe
    public fun glPathCommandsNV(
        path: Int,
        numCommands: Int,
        commands: Long,
        numCoords: Int,
        coordType: Int,
        coords: Long,
    )

    @PtrParameter([3])
    public fun glPathCoordsNV(
        path: Int,
        numCoords: Int,
        coordType: Int,
        coords: Ptr,
    )

    @Unsafe
    public fun glPathCoordsNV(
        path: Int,
        numCoords: Int,
        coordType: Int,
        coords: Long,
    )

    @PtrParameter([4, 7])
    public fun glPathSubCommandsNV(
        path: Int,
        commandStart: Int,
        commandsToDelete: Int,
        numCommands: Int,
        commands: Ptr,
        numCoords: Int,
        coordType: Int,
        coords: Ptr,
    )

    @Unsafe
    public fun glPathSubCommandsNV(
        path: Int,
        commandStart: Int,
        commandsToDelete: Int,
        numCommands: Int,
        commands: Long,
        numCoords: Int,
        coordType: Int,
        coords: Long,
    )

    @PtrParameter([4])
    public fun glPathSubCoordsNV(
        path: Int,
        coordStart: Int,
        numCoords: Int,
        coordType: Int,
        coords: Ptr,
    )

    @Unsafe
    public fun glPathSubCoordsNV(
        path: Int,
        coordStart: Int,
        numCoords: Int,
        coordType: Int,
        coords: Long,
    )

    @PtrParameter([3])
    public fun glPathStringNV(
        path: Int,
        format: Int,
        length: Int,
        pathString: Ptr,
    )

    @Unsafe
    public fun glPathStringNV(
        path: Int,
        format: Int,
        length: Int,
        pathString: Long,
    )

    @PtrParameter([2, 6])
    public fun glPathGlyphsNV(
        firstPathName: Int,
        fontTarget: Int,
        fontName: Ptr,
        fontStyle: Int,
        numGlyphs: Int,
        type: Int,
        charcodes: Ptr,
        handleMissingGlyphs: Int,
        pathParameterTemplate: Int,
        emScale: Float,
    )

    @Unsafe
    public fun glPathGlyphsNV(
        firstPathName: Int,
        fontTarget: Int,
        fontName: Long,
        fontStyle: Int,
        numGlyphs: Int,
        type: Int,
        charcodes: Long,
        handleMissingGlyphs: Int,
        pathParameterTemplate: Int,
        emScale: Float,
    )

    @PtrParameter([2])
    public fun glPathGlyphRangeNV(
        firstPathName: Int,
        fontTarget: Int,
        fontName: Ptr,
        fontStyle: Int,
        firstGlyph: Int,
        numGlyphs: Int,
        handleMissingGlyphs: Int,
        pathParameterTemplate: Int,
        emScale: Float,
    )

    @Unsafe
    public fun glPathGlyphRangeNV(
        firstPathName: Int,
        fontTarget: Int,
        fontName: Long,
        fontStyle: Int,
        firstGlyph: Int,
        numGlyphs: Int,
        handleMissingGlyphs: Int,
        pathParameterTemplate: Int,
        emScale: Float,
    )

    @PtrParameter([2])
    public fun glPathGlyphIndexArrayNV(
        firstPathName: Int,
        fontTarget: Int,
        fontName: Ptr,
        fontStyle: Int,
        firstGlyphIndex: Int,
        numGlyphs: Int,
        pathParameterTemplate: Int,
        emScale: Float,
    ): Int

    @Unsafe
    public fun glPathGlyphIndexArrayNV(
        firstPathName: Int,
        fontTarget: Int,
        fontName: Long,
        fontStyle: Int,
        firstGlyphIndex: Int,
        numGlyphs: Int,
        pathParameterTemplate: Int,
        emScale: Float,
    ): Int

    @PtrParameter([3])
    public fun glPathMemoryGlyphIndexArrayNV(
        firstPathName: Int,
        fontTarget: Int,
        fontSize: Long,
        fontData: Ptr,
        faceIndex: Int,
        firstGlyphIndex: Int,
        numGlyphs: Int,
        pathParameterTemplate: Int,
        emScale: Float,
    ): Int

    @Unsafe
    public fun glPathMemoryGlyphIndexArrayNV(
        firstPathName: Int,
        fontTarget: Int,
        fontSize: Long,
        fontData: Long,
        faceIndex: Int,
        firstGlyphIndex: Int,
        numGlyphs: Int,
        pathParameterTemplate: Int,
        emScale: Float,
    ): Int

    public fun glCopyPathNV(resultPath: Int, srcPath: Int)

    @PtrParameter([2, 3])
    public fun glWeightPathsNV(
        resultPath: Int,
        numPaths: Int,
        paths: Ptr,
        weights: Ptr,
    )

    @Unsafe
    public fun glWeightPathsNV(
        resultPath: Int,
        numPaths: Int,
        paths: Long,
        weights: Long,
    )

    public fun glInterpolatePathsNV(
        resultPath: Int,
        pathA: Int,
        pathB: Int,
        weight: Float,
    )

    @PtrParameter([3])
    public fun glTransformPathNV(
        resultPath: Int,
        srcPath: Int,
        transformType: Int,
        transformValues: Ptr,
    )

    @Unsafe
    public fun glTransformPathNV(
        resultPath: Int,
        srcPath: Int,
        transformType: Int,
        transformValues: Long,
    )

    @PtrParameter([2])
    public fun glPathParameterivNV(
        path: Int,
        pname: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glPathParameterivNV(
        path: Int,
        pname: Int,
        `value`: Long,
    )

    public fun glPathParameteriNV(
        path: Int,
        pname: Int,
        `value`: Int,
    )

    @PtrParameter([2])
    public fun glPathParameterfvNV(
        path: Int,
        pname: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glPathParameterfvNV(
        path: Int,
        pname: Int,
        `value`: Long,
    )

    public fun glPathParameterfNV(
        path: Int,
        pname: Int,
        `value`: Float,
    )

    @PtrParameter([2])
    public fun glPathDashArrayNV(
        path: Int,
        dashCount: Int,
        dashArray: Ptr,
    )

    @Unsafe
    public fun glPathDashArrayNV(
        path: Int,
        dashCount: Int,
        dashArray: Long,
    )

    public fun glGenPathsNV(range: Int): Int

    public fun glDeletePathsNV(path: Int, range: Int)

    public fun glIsPathNV(path: Int): Boolean

    public fun glPathStencilFuncNV(
        func: Int,
        ref: Int,
        mask: Int,
    )

    public fun glPathStencilDepthOffsetNV(factor: Float, units: Float)

    public fun glStencilFillPathNV(
        path: Int,
        fillMode: Int,
        mask: Int,
    )

    public fun glStencilStrokePathNV(
        path: Int,
        reference: Int,
        mask: Int,
    )

    @PtrParameter([2, 7])
    public fun glStencilFillPathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Ptr,
        pathBase: Int,
        fillMode: Int,
        mask: Int,
        transformType: Int,
        transformValues: Ptr,
    )

    @Unsafe
    public fun glStencilFillPathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Long,
        pathBase: Int,
        fillMode: Int,
        mask: Int,
        transformType: Int,
        transformValues: Long,
    )

    @PtrParameter([2, 7])
    public fun glStencilStrokePathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Ptr,
        pathBase: Int,
        reference: Int,
        mask: Int,
        transformType: Int,
        transformValues: Ptr,
    )

    @Unsafe
    public fun glStencilStrokePathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Long,
        pathBase: Int,
        reference: Int,
        mask: Int,
        transformType: Int,
        transformValues: Long,
    )

    public fun glPathCoverDepthFuncNV(zfunc: Int)

    @PtrParameter([3])
    public fun glPathColorGenNV(
        color: Int,
        genMode: Int,
        colorFormat: Int,
        coeffs: Ptr,
    )

    @Unsafe
    public fun glPathColorGenNV(
        color: Int,
        genMode: Int,
        colorFormat: Int,
        coeffs: Long,
    )

    @PtrParameter([3])
    public fun glPathTexGenNV(
        texCoordSet: Int,
        genMode: Int,
        components: Int,
        coeffs: Ptr,
    )

    @Unsafe
    public fun glPathTexGenNV(
        texCoordSet: Int,
        genMode: Int,
        components: Int,
        coeffs: Long,
    )

    public fun glPathFogGenNV(genMode: Int)

    public fun glCoverFillPathNV(path: Int, coverMode: Int)

    public fun glCoverStrokePathNV(path: Int, coverMode: Int)

    @PtrParameter([2, 6])
    public fun glCoverFillPathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Ptr,
        pathBase: Int,
        coverMode: Int,
        transformType: Int,
        transformValues: Ptr,
    )

    @Unsafe
    public fun glCoverFillPathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Long,
        pathBase: Int,
        coverMode: Int,
        transformType: Int,
        transformValues: Long,
    )

    @PtrParameter([2, 6])
    public fun glCoverStrokePathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Ptr,
        pathBase: Int,
        coverMode: Int,
        transformType: Int,
        transformValues: Ptr,
    )

    @Unsafe
    public fun glCoverStrokePathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Long,
        pathBase: Int,
        coverMode: Int,
        transformType: Int,
        transformValues: Long,
    )

    public fun glStencilThenCoverFillPathNV(
        path: Int,
        fillMode: Int,
        mask: Int,
        coverMode: Int,
    )

    public fun glStencilThenCoverStrokePathNV(
        path: Int,
        reference: Int,
        mask: Int,
        coverMode: Int,
    )

    @PtrParameter([2, 8])
    public fun glStencilThenCoverFillPathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Ptr,
        pathBase: Int,
        fillMode: Int,
        mask: Int,
        coverMode: Int,
        transformType: Int,
        transformValues: Ptr,
    )

    @Unsafe
    public fun glStencilThenCoverFillPathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Long,
        pathBase: Int,
        fillMode: Int,
        mask: Int,
        coverMode: Int,
        transformType: Int,
        transformValues: Long,
    )

    @PtrParameter([2, 8])
    public fun glStencilThenCoverStrokePathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Ptr,
        pathBase: Int,
        reference: Int,
        mask: Int,
        coverMode: Int,
        transformType: Int,
        transformValues: Ptr,
    )

    @Unsafe
    public fun glStencilThenCoverStrokePathInstancedNV(
        numPaths: Int,
        pathNameType: Int,
        paths: Long,
        pathBase: Int,
        reference: Int,
        mask: Int,
        coverMode: Int,
        transformType: Int,
        transformValues: Long,
    )

    @PtrParameter([1, 5])
    public fun glPathGlyphIndexRangeNV(
        fontTarget: Int,
        fontName: Ptr,
        fontStyle: Int,
        pathParameterTemplate: Int,
        emScale: Float,
        baseAndCount: Ptr,
    ): Int

    @Unsafe
    public fun glPathGlyphIndexRangeNV(
        fontTarget: Int,
        fontName: Long,
        fontStyle: Int,
        pathParameterTemplate: Int,
        emScale: Float,
        baseAndCount: Long,
    ): Int

    @PtrParameter([4])
    public fun glProgramPathFragmentInputGenNV(
        program: Int,
        location: Int,
        genMode: Int,
        components: Int,
        coeffs: Ptr,
    )

    @Unsafe
    public fun glProgramPathFragmentInputGenNV(
        program: Int,
        location: Int,
        genMode: Int,
        components: Int,
        coeffs: Long,
    )

    @PtrParameter([2])
    public fun glGetPathParameterivNV(
        path: Int,
        pname: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glGetPathParameterivNV(
        path: Int,
        pname: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetPathParameterfvNV(
        path: Int,
        pname: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glGetPathParameterfvNV(
        path: Int,
        pname: Int,
        `value`: Long,
    )

    @PtrParameter([1])
    public fun glGetPathCommandsNV(path: Int, commands: Ptr)

    @Unsafe
    public fun glGetPathCommandsNV(path: Int, commands: Long)

    @PtrParameter([1])
    public fun glGetPathCoordsNV(path: Int, coords: Ptr)

    @Unsafe
    public fun glGetPathCoordsNV(path: Int, coords: Long)

    @PtrParameter([1])
    public fun glGetPathDashArrayNV(path: Int, dashArray: Ptr)

    @Unsafe
    public fun glGetPathDashArrayNV(path: Int, dashArray: Long)

    @PtrParameter([3, 6])
    public fun glGetPathMetricsNV(
        metricQueryMask: Int,
        numPaths: Int,
        pathNameType: Int,
        paths: Ptr,
        pathBase: Int,
        stride: Int,
        metrics: Ptr,
    )

    @Unsafe
    public fun glGetPathMetricsNV(
        metricQueryMask: Int,
        numPaths: Int,
        pathNameType: Int,
        paths: Long,
        pathBase: Int,
        stride: Int,
        metrics: Long,
    )

    @PtrParameter([4])
    public fun glGetPathMetricRangeNV(
        metricQueryMask: Int,
        firstPathName: Int,
        numPaths: Int,
        stride: Int,
        metrics: Ptr,
    )

    @Unsafe
    public fun glGetPathMetricRangeNV(
        metricQueryMask: Int,
        firstPathName: Int,
        numPaths: Int,
        stride: Int,
        metrics: Long,
    )

    @PtrParameter([3, 8])
    public fun glGetPathSpacingNV(
        pathListMode: Int,
        numPaths: Int,
        pathNameType: Int,
        paths: Ptr,
        pathBase: Int,
        advanceScale: Float,
        kerningScale: Float,
        transformType: Int,
        returnedSpacing: Ptr,
    )

    @Unsafe
    public fun glGetPathSpacingNV(
        pathListMode: Int,
        numPaths: Int,
        pathNameType: Int,
        paths: Long,
        pathBase: Int,
        advanceScale: Float,
        kerningScale: Float,
        transformType: Int,
        returnedSpacing: Long,
    )

    @PtrParameter([2])
    public fun glGetPathColorGenivNV(
        color: Int,
        pname: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glGetPathColorGenivNV(
        color: Int,
        pname: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetPathColorGenfvNV(
        color: Int,
        pname: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glGetPathColorGenfvNV(
        color: Int,
        pname: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetPathTexGenivNV(
        texCoordSet: Int,
        pname: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glGetPathTexGenivNV(
        texCoordSet: Int,
        pname: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetPathTexGenfvNV(
        texCoordSet: Int,
        pname: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glGetPathTexGenfvNV(
        texCoordSet: Int,
        pname: Int,
        `value`: Long,
    )

    public fun glIsPointInFillPathNV(
        path: Int,
        mask: Int,
        x: Float,
        y: Float,
    ): Boolean

    public fun glIsPointInStrokePathNV(
        path: Int,
        x: Float,
        y: Float,
    ): Boolean

    public fun glGetPathLengthNV(
        path: Int,
        startSegment: Int,
        numSegments: Int,
    ): Float

    @PtrParameter([4, 5, 6, 7])
    public fun glPointAlongPathNV(
        path: Int,
        startSegment: Int,
        numSegments: Int,
        distance: Float,
        x: Ptr,
        y: Ptr,
        tangentX: Ptr,
        tangentY: Ptr,
    ): Boolean

    @Unsafe
    public fun glPointAlongPathNV(
        path: Int,
        startSegment: Int,
        numSegments: Int,
        distance: Float,
        x: Long,
        y: Long,
        tangentX: Long,
        tangentY: Long,
    ): Boolean

    @PtrParameter([1])
    public fun glMatrixLoad3x2fNV(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixLoad3x2fNV(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixLoad3x3fNV(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixLoad3x3fNV(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixLoadTranspose3x3fNV(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixLoadTranspose3x3fNV(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixMult3x2fNV(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixMult3x2fNV(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixMult3x3fNV(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixMult3x3fNV(matrixMode: Int, m: Long)

    @PtrParameter([1])
    public fun glMatrixMultTranspose3x3fNV(matrixMode: Int, m: Ptr)

    @Unsafe
    public fun glMatrixMultTranspose3x3fNV(matrixMode: Int, m: Long)

    @PtrParameter([4, 6, 7])
    public fun glGetProgramResourcefvNV(
        program: Int,
        programInterface: Int,
        index: Int,
        propCount: Int,
        props: Ptr,
        bufSize: Int,
        length: Ptr,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramResourcefvNV(
        program: Int,
        programInterface: Int,
        index: Int,
        propCount: Int,
        props: Long,
        bufSize: Int,
        length: Long,
        params: Long,
    )
}

public const val GL_CLOSE_PATH_NV: Byte = 0x0.toByte()

public const val GL_MOVE_TO_NV: Byte = 0x2.toByte()

public const val GL_RELATIVE_MOVE_TO_NV: Byte = 0x3.toByte()

public const val GL_LINE_TO_NV: Byte = 0x4.toByte()

public const val GL_RELATIVE_LINE_TO_NV: Byte = 0x5.toByte()

public const val GL_HORIZONTAL_LINE_TO_NV: Byte = 0x6.toByte()

public const val GL_RELATIVE_HORIZONTAL_LINE_TO_NV: Byte = 0x7.toByte()

public const val GL_VERTICAL_LINE_TO_NV: Byte = 0x8.toByte()

public const val GL_RELATIVE_VERTICAL_LINE_TO_NV: Byte = 0x9.toByte()

public const val GL_QUADRATIC_CURVE_TO_NV: Byte = 0xA.toByte()

public const val GL_RELATIVE_QUADRATIC_CURVE_TO_NV: Byte = 0xB.toByte()

public const val GL_CUBIC_CURVE_TO_NV: Byte = 0xC.toByte()

public const val GL_RELATIVE_CUBIC_CURVE_TO_NV: Byte = 0xD.toByte()

public const val GL_SMOOTH_QUADRATIC_CURVE_TO_NV: Byte = 0xE.toByte()

public const val GL_RELATIVE_SMOOTH_QUADRATIC_CURVE_TO_NV: Byte = 0xF.toByte()

public const val GL_SMOOTH_CUBIC_CURVE_TO_NV: Byte = 0x10.toByte()

public const val GL_RELATIVE_SMOOTH_CUBIC_CURVE_TO_NV: Byte = 0x11.toByte()

public const val GL_SMALL_CCW_ARC_TO_NV: Byte = 0x12.toByte()

public const val GL_RELATIVE_SMALL_CCW_ARC_TO_NV: Byte = 0x13.toByte()

public const val GL_SMALL_CW_ARC_TO_NV: Byte = 0x14.toByte()

public const val GL_RELATIVE_SMALL_CW_ARC_TO_NV: Byte = 0x15.toByte()

public const val GL_LARGE_CCW_ARC_TO_NV: Byte = 0x16.toByte()

public const val GL_RELATIVE_LARGE_CCW_ARC_TO_NV: Byte = 0x17.toByte()

public const val GL_LARGE_CW_ARC_TO_NV: Byte = 0x18.toByte()

public const val GL_RELATIVE_LARGE_CW_ARC_TO_NV: Byte = 0x19.toByte()

public const val GL_CONIC_CURVE_TO_NV: Byte = 0x1A.toByte()

public const val GL_RELATIVE_CONIC_CURVE_TO_NV: Byte = 0x1B.toByte()

public const val GL_ROUNDED_RECT_NV: Byte = 0xE8.toByte()

public const val GL_RELATIVE_ROUNDED_RECT_NV: Byte = 0xE9.toByte()

public const val GL_ROUNDED_RECT2_NV: Byte = 0xEA.toByte()

public const val GL_RELATIVE_ROUNDED_RECT2_NV: Byte = 0xEB.toByte()

public const val GL_ROUNDED_RECT4_NV: Byte = 0xEC.toByte()

public const val GL_RELATIVE_ROUNDED_RECT4_NV: Byte = 0xED.toByte()

public const val GL_ROUNDED_RECT8_NV: Byte = 0xEE.toByte()

public const val GL_RELATIVE_ROUNDED_RECT8_NV: Byte = 0xEF.toByte()

public const val GL_RESTART_PATH_NV: Byte = 0xF0.toByte()

public const val GL_DUP_FIRST_CUBIC_CURVE_TO_NV: Byte = 0xF2.toByte()

public const val GL_DUP_LAST_CUBIC_CURVE_TO_NV: Byte = 0xF4.toByte()

public const val GL_RECT_NV: Byte = 0xF6.toByte()

public const val GL_RELATIVE_RECT_NV: Byte = 0xF7.toByte()

public const val GL_CIRCULAR_CCW_ARC_TO_NV: Byte = 0xF8.toByte()

public const val GL_CIRCULAR_CW_ARC_TO_NV: Byte = 0xFA.toByte()

public const val GL_CIRCULAR_TANGENT_ARC_TO_NV: Byte = 0xFC.toByte()

public const val GL_ARC_TO_NV: Byte = 0xFE.toByte()

public const val GL_RELATIVE_ARC_TO_NV: Byte = 0xFF.toByte()

public const val GL_PATH_FORMAT_SVG_NV: Int = 36_976

public const val GL_PATH_FORMAT_PS_NV: Int = 36_977

public const val GL_STANDARD_FONT_NAME_NV: Int = 36_978

public const val GL_SYSTEM_FONT_NAME_NV: Int = 36_979

public const val GL_FILE_NAME_NV: Int = 36_980

public const val GL_STANDARD_FONT_FORMAT_NV: Int = 37_740

public const val GL_SKIP_MISSING_GLYPH_NV: Int = 37_033

public const val GL_USE_MISSING_GLYPH_NV: Int = 37_034

public const val GL_FONT_GLYPHS_AVAILABLE_NV: Int = 37_736

public const val GL_FONT_TARGET_UNAVAILABLE_NV: Int = 37_737

public const val GL_FONT_UNAVAILABLE_NV: Int = 37_738

public const val GL_FONT_UNINTELLIGIBLE_NV: Int = 37_739

public const val GL_PATH_STROKE_WIDTH_NV: Int = 36_981

public const val GL_PATH_INITIAL_END_CAP_NV: Int = 36_983

public const val GL_PATH_TERMINAL_END_CAP_NV: Int = 36_984

public const val GL_PATH_JOIN_STYLE_NV: Int = 36_985

public const val GL_PATH_MITER_LIMIT_NV: Int = 36_986

public const val GL_PATH_INITIAL_DASH_CAP_NV: Int = 36_988

public const val GL_PATH_TERMINAL_DASH_CAP_NV: Int = 36_989

public const val GL_PATH_DASH_OFFSET_NV: Int = 36_990

public const val GL_PATH_CLIENT_LENGTH_NV: Int = 36_991

public const val GL_PATH_DASH_OFFSET_RESET_NV: Int = 37_044

public const val GL_PATH_FILL_MODE_NV: Int = 36_992

public const val GL_PATH_FILL_MASK_NV: Int = 36_993

public const val GL_PATH_FILL_COVER_MODE_NV: Int = 36_994

public const val GL_PATH_STROKE_COVER_MODE_NV: Int = 36_995

public const val GL_PATH_STROKE_MASK_NV: Int = 36_996

public const val GL_PATH_STROKE_BOUND_NV: Int = 36_998

public const val GL_PATH_END_CAPS_NV: Int = 36_982

public const val GL_PATH_DASH_CAPS_NV: Int = 36_987

public const val GL_COUNT_UP_NV: Int = 37_000

public const val GL_COUNT_DOWN_NV: Int = 37_001

public const val GL_PRIMARY_COLOR_NV: Int = 34_092

public const val GL_SECONDARY_COLOR_NV: Int = 34_093

public const val GL_PATH_OBJECT_BOUNDING_BOX_NV: Int = 37_002

public const val GL_CONVEX_HULL_NV: Int = 37_003

public const val GL_BOUNDING_BOX_NV: Int = 37_005

public const val GL_TRANSLATE_X_NV: Int = 37_006

public const val GL_TRANSLATE_Y_NV: Int = 37_007

public const val GL_TRANSLATE_2D_NV: Int = 37_008

public const val GL_TRANSLATE_3D_NV: Int = 37_009

public const val GL_AFFINE_2D_NV: Int = 37_010

public const val GL_AFFINE_3D_NV: Int = 37_012

public const val GL_TRANSPOSE_AFFINE_2D_NV: Int = 37_014

public const val GL_TRANSPOSE_AFFINE_3D_NV: Int = 37_016

public const val GL_UTF8_NV: Int = 37_018

public const val GL_UTF16_NV: Int = 37_019

public const val GL_BOUNDING_BOX_OF_BOUNDING_BOXES_NV: Int = 37_020

public const val GL_PATH_COMMAND_COUNT_NV: Int = 37_021

public const val GL_PATH_COORD_COUNT_NV: Int = 37_022

public const val GL_PATH_DASH_ARRAY_COUNT_NV: Int = 37_023

public const val GL_PATH_COMPUTED_LENGTH_NV: Int = 37_024

public const val GL_PATH_FILL_BOUNDING_BOX_NV: Int = 37_025

public const val GL_PATH_STROKE_BOUNDING_BOX_NV: Int = 37_026

public const val GL_SQUARE_NV: Int = 37_027

public const val GL_ROUND_NV: Int = 37_028

public const val GL_TRIANGULAR_NV: Int = 37_029

public const val GL_BEVEL_NV: Int = 37_030

public const val GL_MITER_REVERT_NV: Int = 37_031

public const val GL_MITER_TRUNCATE_NV: Int = 37_032

public const val GL_MOVE_TO_RESETS_NV: Int = 37_045

public const val GL_MOVE_TO_CONTINUES_NV: Int = 37_046

public const val GL_BOLD_BIT_NV: Int = 1

public const val GL_ITALIC_BIT_NV: Int = 2

public const val GL_PATH_ERROR_POSITION_NV: Int = 37_035

public const val GL_PATH_FOG_GEN_MODE_NV: Int = 37_036

public const val GL_PATH_STENCIL_FUNC_NV: Int = 37_047

public const val GL_PATH_STENCIL_REF_NV: Int = 37_048

public const val GL_PATH_STENCIL_VALUE_MASK_NV: Int = 37_049

public const val GL_PATH_STENCIL_DEPTH_OFFSET_FACTOR_NV: Int = 37_053

public const val GL_PATH_STENCIL_DEPTH_OFFSET_UNITS_NV: Int = 37_054

public const val GL_PATH_COVER_DEPTH_FUNC_NV: Int = 37_055

public const val GL_GLYPH_WIDTH_BIT_NV: Int = 1

public const val GL_GLYPH_HEIGHT_BIT_NV: Int = 2

public const val GL_GLYPH_HORIZONTAL_BEARING_X_BIT_NV: Int = 4

public const val GL_GLYPH_HORIZONTAL_BEARING_Y_BIT_NV: Int = 8

public const val GL_GLYPH_HORIZONTAL_BEARING_ADVANCE_BIT_NV: Int = 16

public const val GL_GLYPH_VERTICAL_BEARING_X_BIT_NV: Int = 32

public const val GL_GLYPH_VERTICAL_BEARING_Y_BIT_NV: Int = 64

public const val GL_GLYPH_VERTICAL_BEARING_ADVANCE_BIT_NV: Int = 128

public const val GL_GLYPH_HAS_KERNING_BIT_NV: Int = 256

public const val GL_FONT_X_MIN_BOUNDS_BIT_NV: Int = 65_536

public const val GL_FONT_Y_MIN_BOUNDS_BIT_NV: Int = 131_072

public const val GL_FONT_X_MAX_BOUNDS_BIT_NV: Int = 262_144

public const val GL_FONT_Y_MAX_BOUNDS_BIT_NV: Int = 524_288

public const val GL_FONT_UNITS_PER_EM_BIT_NV: Int = 1_048_576

public const val GL_FONT_ASCENDER_BIT_NV: Int = 2_097_152

public const val GL_FONT_DESCENDER_BIT_NV: Int = 4_194_304

public const val GL_FONT_HEIGHT_BIT_NV: Int = 8_388_608

public const val GL_FONT_MAX_ADVANCE_WIDTH_BIT_NV: Int = 16_777_216

public const val GL_FONT_MAX_ADVANCE_HEIGHT_BIT_NV: Int = 33_554_432

public const val GL_FONT_UNDERLINE_POSITION_BIT_NV: Int = 67_108_864

public const val GL_FONT_UNDERLINE_THICKNESS_BIT_NV: Int = 134_217_728

public const val GL_FONT_HAS_KERNING_BIT_NV: Int = 268_435_456

public const val GL_FONT_NUM_GLYPH_INDICES_BIT_NV: Int = 536_870_912

public const val GL_ACCUM_ADJACENT_PAIRS_NV: Int = 37_037

public const val GL_ADJACENT_PAIRS_NV: Int = 37_038

public const val GL_FIRST_TO_REST_NV: Int = 37_039

public const val GL_PATH_GEN_MODE_NV: Int = 37_040

public const val GL_PATH_GEN_COEFF_NV: Int = 37_041

public const val GL_PATH_GEN_COLOR_FORMAT_NV: Int = 37_042

public const val GL_PATH_GEN_COMPONENTS_NV: Int = 37_043

public const val GL_FRAGMENT_INPUT_NV: Int = 37_741

public const val GL_PATH_PROJECTION_NV: Int = 5_889

public const val GL_PATH_MODELVIEW_NV: Int = 5_888

public const val GL_PATH_MODELVIEW_STACK_DEPTH_NV: Int = 2_979

public const val GL_PATH_MODELVIEW_MATRIX_NV: Int = 2_982

public const val GL_PATH_MAX_MODELVIEW_STACK_DEPTH_NV: Int = 3_382

public const val GL_PATH_TRANSPOSE_MODELVIEW_MATRIX_NV: Int = 34_019

public const val GL_PATH_PROJECTION_STACK_DEPTH_NV: Int = 2_980

public const val GL_PATH_PROJECTION_MATRIX_NV: Int = 2_983

public const val GL_PATH_MAX_PROJECTION_STACK_DEPTH_NV: Int = 3_384

public const val GL_PATH_TRANSPOSE_PROJECTION_MATRIX_NV: Int = 34_020

public const val GL_2_BYTES_NV: Int = 5_127

public const val GL_3_BYTES_NV: Int = 5_128

public const val GL_4_BYTES_NV: Int = 5_129

public const val GL_EYE_LINEAR_NV: Int = 9_216

public const val GL_OBJECT_LINEAR_NV: Int = 9_217

public const val GL_CONSTANT_NV: Int = 34_166

public inline fun glPathCommandsNV(
    path: Int,
    numCommands: Int,
    commands: Ptr,
    numCoords: Int,
    coordType: Int,
    coords: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathCommandsNV(path, numCommands, commands,
        numCoords, coordType, coords)

public inline fun glPathCommandsNV(
    path: Int,
    numCommands: Int,
    commands: Long,
    numCoords: Int,
    coordType: Int,
    coords: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathCommandsNV(path, numCommands, commands,
        numCoords, coordType, coords)

public inline fun glPathCoordsNV(
    path: Int,
    numCoords: Int,
    coordType: Int,
    coords: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathCoordsNV(path, numCoords, coordType, coords)

public inline fun glPathCoordsNV(
    path: Int,
    numCoords: Int,
    coordType: Int,
    coords: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathCoordsNV(path, numCoords, coordType, coords)

public inline fun glPathSubCommandsNV(
    path: Int,
    commandStart: Int,
    commandsToDelete: Int,
    numCommands: Int,
    commands: Ptr,
    numCoords: Int,
    coordType: Int,
    coords: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathSubCommandsNV(path, commandStart,
        commandsToDelete, numCommands, commands, numCoords, coordType, coords)

public inline fun glPathSubCommandsNV(
    path: Int,
    commandStart: Int,
    commandsToDelete: Int,
    numCommands: Int,
    commands: Long,
    numCoords: Int,
    coordType: Int,
    coords: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathSubCommandsNV(path, commandStart,
        commandsToDelete, numCommands, commands, numCoords, coordType, coords)

public inline fun glPathSubCoordsNV(
    path: Int,
    coordStart: Int,
    numCoords: Int,
    coordType: Int,
    coords: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathSubCoordsNV(path, coordStart, numCoords,
        coordType, coords)

public inline fun glPathSubCoordsNV(
    path: Int,
    coordStart: Int,
    numCoords: Int,
    coordType: Int,
    coords: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathSubCoordsNV(path, coordStart, numCoords,
        coordType, coords)

public inline fun glPathStringNV(
    path: Int,
    format: Int,
    length: Int,
    pathString: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathStringNV(path, format, length, pathString)

public inline fun glPathStringNV(
    path: Int,
    format: Int,
    length: Int,
    pathString: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathStringNV(path, format, length, pathString)

public inline fun glPathGlyphsNV(
    firstPathName: Int,
    fontTarget: Int,
    fontName: Ptr,
    fontStyle: Int,
    numGlyphs: Int,
    type: Int,
    charcodes: Ptr,
    handleMissingGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
): Unit = GLWrapper.instance.NVPathRendering.glPathGlyphsNV(firstPathName, fontTarget, fontName,
        fontStyle, numGlyphs, type, charcodes, handleMissingGlyphs, pathParameterTemplate, emScale)

public inline fun glPathGlyphsNV(
    firstPathName: Int,
    fontTarget: Int,
    fontName: Long,
    fontStyle: Int,
    numGlyphs: Int,
    type: Int,
    charcodes: Long,
    handleMissingGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
): Unit = GLWrapper.instance.NVPathRendering.glPathGlyphsNV(firstPathName, fontTarget, fontName,
        fontStyle, numGlyphs, type, charcodes, handleMissingGlyphs, pathParameterTemplate, emScale)

public inline fun glPathGlyphRangeNV(
    firstPathName: Int,
    fontTarget: Int,
    fontName: Ptr,
    fontStyle: Int,
    firstGlyph: Int,
    numGlyphs: Int,
    handleMissingGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
): Unit = GLWrapper.instance.NVPathRendering.glPathGlyphRangeNV(firstPathName, fontTarget, fontName,
        fontStyle, firstGlyph, numGlyphs, handleMissingGlyphs, pathParameterTemplate, emScale)

public inline fun glPathGlyphRangeNV(
    firstPathName: Int,
    fontTarget: Int,
    fontName: Long,
    fontStyle: Int,
    firstGlyph: Int,
    numGlyphs: Int,
    handleMissingGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
): Unit = GLWrapper.instance.NVPathRendering.glPathGlyphRangeNV(firstPathName, fontTarget, fontName,
        fontStyle, firstGlyph, numGlyphs, handleMissingGlyphs, pathParameterTemplate, emScale)

public inline fun glPathGlyphIndexArrayNV(
    firstPathName: Int,
    fontTarget: Int,
    fontName: Ptr,
    fontStyle: Int,
    firstGlyphIndex: Int,
    numGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
): Int = GLWrapper.instance.NVPathRendering.glPathGlyphIndexArrayNV(firstPathName, fontTarget,
        fontName, fontStyle, firstGlyphIndex, numGlyphs, pathParameterTemplate, emScale)

public inline fun glPathGlyphIndexArrayNV(
    firstPathName: Int,
    fontTarget: Int,
    fontName: Long,
    fontStyle: Int,
    firstGlyphIndex: Int,
    numGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
): Int = GLWrapper.instance.NVPathRendering.glPathGlyphIndexArrayNV(firstPathName, fontTarget,
        fontName, fontStyle, firstGlyphIndex, numGlyphs, pathParameterTemplate, emScale)

public inline fun glPathMemoryGlyphIndexArrayNV(
    firstPathName: Int,
    fontTarget: Int,
    fontSize: Long,
    fontData: Ptr,
    faceIndex: Int,
    firstGlyphIndex: Int,
    numGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
): Int = GLWrapper.instance.NVPathRendering.glPathMemoryGlyphIndexArrayNV(firstPathName, fontTarget,
        fontSize, fontData, faceIndex, firstGlyphIndex, numGlyphs, pathParameterTemplate, emScale)

public inline fun glPathMemoryGlyphIndexArrayNV(
    firstPathName: Int,
    fontTarget: Int,
    fontSize: Long,
    fontData: Long,
    faceIndex: Int,
    firstGlyphIndex: Int,
    numGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
): Int = GLWrapper.instance.NVPathRendering.glPathMemoryGlyphIndexArrayNV(firstPathName, fontTarget,
        fontSize, fontData, faceIndex, firstGlyphIndex, numGlyphs, pathParameterTemplate, emScale)

public inline fun glCopyPathNV(resultPath: Int, srcPath: Int): Unit =
        GLWrapper.instance.NVPathRendering.glCopyPathNV(resultPath, srcPath)

public inline fun glWeightPathsNV(
    resultPath: Int,
    numPaths: Int,
    paths: Ptr,
    weights: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glWeightPathsNV(resultPath, numPaths, paths, weights)

public inline fun glWeightPathsNV(
    resultPath: Int,
    numPaths: Int,
    paths: Long,
    weights: Long,
): Unit = GLWrapper.instance.NVPathRendering.glWeightPathsNV(resultPath, numPaths, paths, weights)

public inline fun glInterpolatePathsNV(
    resultPath: Int,
    pathA: Int,
    pathB: Int,
    weight: Float,
): Unit = GLWrapper.instance.NVPathRendering.glInterpolatePathsNV(resultPath, pathA, pathB, weight)

public inline fun glTransformPathNV(
    resultPath: Int,
    srcPath: Int,
    transformType: Int,
    transformValues: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glTransformPathNV(resultPath, srcPath, transformType,
        transformValues)

public inline fun glTransformPathNV(
    resultPath: Int,
    srcPath: Int,
    transformType: Int,
    transformValues: Long,
): Unit = GLWrapper.instance.NVPathRendering.glTransformPathNV(resultPath, srcPath, transformType,
        transformValues)

public inline fun glPathParameterivNV(
    path: Int,
    pname: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathParameterivNV(path, pname, `value`)

public inline fun glPathParameterivNV(
    path: Int,
    pname: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathParameterivNV(path, pname, `value`)

public inline fun glPathParameteriNV(
    path: Int,
    pname: Int,
    `value`: Int,
): Unit = GLWrapper.instance.NVPathRendering.glPathParameteriNV(path, pname, `value`)

public inline fun glPathParameterfvNV(
    path: Int,
    pname: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathParameterfvNV(path, pname, `value`)

public inline fun glPathParameterfvNV(
    path: Int,
    pname: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathParameterfvNV(path, pname, `value`)

public inline fun glPathParameterfNV(
    path: Int,
    pname: Int,
    `value`: Float,
): Unit = GLWrapper.instance.NVPathRendering.glPathParameterfNV(path, pname, `value`)

public inline fun glPathDashArrayNV(
    path: Int,
    dashCount: Int,
    dashArray: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathDashArrayNV(path, dashCount, dashArray)

public inline fun glPathDashArrayNV(
    path: Int,
    dashCount: Int,
    dashArray: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathDashArrayNV(path, dashCount, dashArray)

public inline fun glGenPathsNV(range: Int): Int =
        GLWrapper.instance.NVPathRendering.glGenPathsNV(range)

public inline fun glDeletePathsNV(path: Int, range: Int): Unit =
        GLWrapper.instance.NVPathRendering.glDeletePathsNV(path, range)

public inline fun glIsPathNV(path: Int): Boolean =
        GLWrapper.instance.NVPathRendering.glIsPathNV(path)

public inline fun glPathStencilFuncNV(
    func: Int,
    ref: Int,
    mask: Int,
): Unit = GLWrapper.instance.NVPathRendering.glPathStencilFuncNV(func, ref, mask)

public inline fun glPathStencilDepthOffsetNV(factor: Float, units: Float): Unit =
        GLWrapper.instance.NVPathRendering.glPathStencilDepthOffsetNV(factor, units)

public inline fun glStencilFillPathNV(
    path: Int,
    fillMode: Int,
    mask: Int,
): Unit = GLWrapper.instance.NVPathRendering.glStencilFillPathNV(path, fillMode, mask)

public inline fun glStencilStrokePathNV(
    path: Int,
    reference: Int,
    mask: Int,
): Unit = GLWrapper.instance.NVPathRendering.glStencilStrokePathNV(path, reference, mask)

public inline fun glStencilFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Ptr,
    pathBase: Int,
    fillMode: Int,
    mask: Int,
    transformType: Int,
    transformValues: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glStencilFillPathInstancedNV(numPaths, pathNameType,
        paths, pathBase, fillMode, mask, transformType, transformValues)

public inline fun glStencilFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    fillMode: Int,
    mask: Int,
    transformType: Int,
    transformValues: Long,
): Unit = GLWrapper.instance.NVPathRendering.glStencilFillPathInstancedNV(numPaths, pathNameType,
        paths, pathBase, fillMode, mask, transformType, transformValues)

public inline fun glStencilStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Ptr,
    pathBase: Int,
    reference: Int,
    mask: Int,
    transformType: Int,
    transformValues: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glStencilStrokePathInstancedNV(numPaths, pathNameType,
        paths, pathBase, reference, mask, transformType, transformValues)

public inline fun glStencilStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    reference: Int,
    mask: Int,
    transformType: Int,
    transformValues: Long,
): Unit = GLWrapper.instance.NVPathRendering.glStencilStrokePathInstancedNV(numPaths, pathNameType,
        paths, pathBase, reference, mask, transformType, transformValues)

public inline fun glPathCoverDepthFuncNV(zfunc: Int): Unit =
        GLWrapper.instance.NVPathRendering.glPathCoverDepthFuncNV(zfunc)

public inline fun glPathColorGenNV(
    color: Int,
    genMode: Int,
    colorFormat: Int,
    coeffs: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathColorGenNV(color, genMode, colorFormat, coeffs)

public inline fun glPathColorGenNV(
    color: Int,
    genMode: Int,
    colorFormat: Int,
    coeffs: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathColorGenNV(color, genMode, colorFormat, coeffs)

public inline fun glPathTexGenNV(
    texCoordSet: Int,
    genMode: Int,
    components: Int,
    coeffs: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glPathTexGenNV(texCoordSet, genMode, components,
        coeffs)

public inline fun glPathTexGenNV(
    texCoordSet: Int,
    genMode: Int,
    components: Int,
    coeffs: Long,
): Unit = GLWrapper.instance.NVPathRendering.glPathTexGenNV(texCoordSet, genMode, components,
        coeffs)

public inline fun glPathFogGenNV(genMode: Int): Unit =
        GLWrapper.instance.NVPathRendering.glPathFogGenNV(genMode)

public inline fun glCoverFillPathNV(path: Int, coverMode: Int): Unit =
        GLWrapper.instance.NVPathRendering.glCoverFillPathNV(path, coverMode)

public inline fun glCoverStrokePathNV(path: Int, coverMode: Int): Unit =
        GLWrapper.instance.NVPathRendering.glCoverStrokePathNV(path, coverMode)

public inline fun glCoverFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Ptr,
    pathBase: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glCoverFillPathInstancedNV(numPaths, pathNameType,
        paths, pathBase, coverMode, transformType, transformValues)

public inline fun glCoverFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Long,
): Unit = GLWrapper.instance.NVPathRendering.glCoverFillPathInstancedNV(numPaths, pathNameType,
        paths, pathBase, coverMode, transformType, transformValues)

public inline fun glCoverStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Ptr,
    pathBase: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glCoverStrokePathInstancedNV(numPaths, pathNameType,
        paths, pathBase, coverMode, transformType, transformValues)

public inline fun glCoverStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Long,
): Unit = GLWrapper.instance.NVPathRendering.glCoverStrokePathInstancedNV(numPaths, pathNameType,
        paths, pathBase, coverMode, transformType, transformValues)

public inline fun glStencilThenCoverFillPathNV(
    path: Int,
    fillMode: Int,
    mask: Int,
    coverMode: Int,
): Unit = GLWrapper.instance.NVPathRendering.glStencilThenCoverFillPathNV(path, fillMode, mask,
        coverMode)

public inline fun glStencilThenCoverStrokePathNV(
    path: Int,
    reference: Int,
    mask: Int,
    coverMode: Int,
): Unit = GLWrapper.instance.NVPathRendering.glStencilThenCoverStrokePathNV(path, reference, mask,
        coverMode)

public inline fun glStencilThenCoverFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Ptr,
    pathBase: Int,
    fillMode: Int,
    mask: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glStencilThenCoverFillPathInstancedNV(numPaths,
        pathNameType, paths, pathBase, fillMode, mask, coverMode, transformType, transformValues)

public inline fun glStencilThenCoverFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    fillMode: Int,
    mask: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Long,
): Unit = GLWrapper.instance.NVPathRendering.glStencilThenCoverFillPathInstancedNV(numPaths,
        pathNameType, paths, pathBase, fillMode, mask, coverMode, transformType, transformValues)

public inline fun glStencilThenCoverStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Ptr,
    pathBase: Int,
    reference: Int,
    mask: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glStencilThenCoverStrokePathInstancedNV(numPaths,
        pathNameType, paths, pathBase, reference, mask, coverMode, transformType, transformValues)

public inline fun glStencilThenCoverStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    reference: Int,
    mask: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Long,
): Unit = GLWrapper.instance.NVPathRendering.glStencilThenCoverStrokePathInstancedNV(numPaths,
        pathNameType, paths, pathBase, reference, mask, coverMode, transformType, transformValues)

public inline fun glPathGlyphIndexRangeNV(
    fontTarget: Int,
    fontName: Ptr,
    fontStyle: Int,
    pathParameterTemplate: Int,
    emScale: Float,
    baseAndCount: Ptr,
): Int = GLWrapper.instance.NVPathRendering.glPathGlyphIndexRangeNV(fontTarget, fontName, fontStyle,
        pathParameterTemplate, emScale, baseAndCount)

public inline fun glPathGlyphIndexRangeNV(
    fontTarget: Int,
    fontName: Long,
    fontStyle: Int,
    pathParameterTemplate: Int,
    emScale: Float,
    baseAndCount: Long,
): Int = GLWrapper.instance.NVPathRendering.glPathGlyphIndexRangeNV(fontTarget, fontName, fontStyle,
        pathParameterTemplate, emScale, baseAndCount)

public inline fun glProgramPathFragmentInputGenNV(
    program: Int,
    location: Int,
    genMode: Int,
    components: Int,
    coeffs: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glProgramPathFragmentInputGenNV(program, location,
        genMode, components, coeffs)

public inline fun glProgramPathFragmentInputGenNV(
    program: Int,
    location: Int,
    genMode: Int,
    components: Int,
    coeffs: Long,
): Unit = GLWrapper.instance.NVPathRendering.glProgramPathFragmentInputGenNV(program, location,
        genMode, components, coeffs)

public inline fun glGetPathParameterivNV(
    path: Int,
    pname: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathParameterivNV(path, pname, `value`)

public inline fun glGetPathParameterivNV(
    path: Int,
    pname: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathParameterivNV(path, pname, `value`)

public inline fun glGetPathParameterfvNV(
    path: Int,
    pname: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathParameterfvNV(path, pname, `value`)

public inline fun glGetPathParameterfvNV(
    path: Int,
    pname: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathParameterfvNV(path, pname, `value`)

public inline fun glGetPathCommandsNV(path: Int, commands: Ptr): Unit =
        GLWrapper.instance.NVPathRendering.glGetPathCommandsNV(path, commands)

public inline fun glGetPathCommandsNV(path: Int, commands: Long): Unit =
        GLWrapper.instance.NVPathRendering.glGetPathCommandsNV(path, commands)

public inline fun glGetPathCoordsNV(path: Int, coords: Ptr): Unit =
        GLWrapper.instance.NVPathRendering.glGetPathCoordsNV(path, coords)

public inline fun glGetPathCoordsNV(path: Int, coords: Long): Unit =
        GLWrapper.instance.NVPathRendering.glGetPathCoordsNV(path, coords)

public inline fun glGetPathDashArrayNV(path: Int, dashArray: Ptr): Unit =
        GLWrapper.instance.NVPathRendering.glGetPathDashArrayNV(path, dashArray)

public inline fun glGetPathDashArrayNV(path: Int, dashArray: Long): Unit =
        GLWrapper.instance.NVPathRendering.glGetPathDashArrayNV(path, dashArray)

public inline fun glGetPathMetricsNV(
    metricQueryMask: Int,
    numPaths: Int,
    pathNameType: Int,
    paths: Ptr,
    pathBase: Int,
    stride: Int,
    metrics: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathMetricsNV(metricQueryMask, numPaths,
        pathNameType, paths, pathBase, stride, metrics)

public inline fun glGetPathMetricsNV(
    metricQueryMask: Int,
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    stride: Int,
    metrics: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathMetricsNV(metricQueryMask, numPaths,
        pathNameType, paths, pathBase, stride, metrics)

public inline fun glGetPathMetricRangeNV(
    metricQueryMask: Int,
    firstPathName: Int,
    numPaths: Int,
    stride: Int,
    metrics: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathMetricRangeNV(metricQueryMask, firstPathName,
        numPaths, stride, metrics)

public inline fun glGetPathMetricRangeNV(
    metricQueryMask: Int,
    firstPathName: Int,
    numPaths: Int,
    stride: Int,
    metrics: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathMetricRangeNV(metricQueryMask, firstPathName,
        numPaths, stride, metrics)

public inline fun glGetPathSpacingNV(
    pathListMode: Int,
    numPaths: Int,
    pathNameType: Int,
    paths: Ptr,
    pathBase: Int,
    advanceScale: Float,
    kerningScale: Float,
    transformType: Int,
    returnedSpacing: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathSpacingNV(pathListMode, numPaths,
        pathNameType, paths, pathBase, advanceScale, kerningScale, transformType, returnedSpacing)

public inline fun glGetPathSpacingNV(
    pathListMode: Int,
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    advanceScale: Float,
    kerningScale: Float,
    transformType: Int,
    returnedSpacing: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathSpacingNV(pathListMode, numPaths,
        pathNameType, paths, pathBase, advanceScale, kerningScale, transformType, returnedSpacing)

public inline fun glGetPathColorGenivNV(
    color: Int,
    pname: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathColorGenivNV(color, pname, `value`)

public inline fun glGetPathColorGenivNV(
    color: Int,
    pname: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathColorGenivNV(color, pname, `value`)

public inline fun glGetPathColorGenfvNV(
    color: Int,
    pname: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathColorGenfvNV(color, pname, `value`)

public inline fun glGetPathColorGenfvNV(
    color: Int,
    pname: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathColorGenfvNV(color, pname, `value`)

public inline fun glGetPathTexGenivNV(
    texCoordSet: Int,
    pname: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathTexGenivNV(texCoordSet, pname, `value`)

public inline fun glGetPathTexGenivNV(
    texCoordSet: Int,
    pname: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathTexGenivNV(texCoordSet, pname, `value`)

public inline fun glGetPathTexGenfvNV(
    texCoordSet: Int,
    pname: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathTexGenfvNV(texCoordSet, pname, `value`)

public inline fun glGetPathTexGenfvNV(
    texCoordSet: Int,
    pname: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetPathTexGenfvNV(texCoordSet, pname, `value`)

public inline fun glIsPointInFillPathNV(
    path: Int,
    mask: Int,
    x: Float,
    y: Float,
): Boolean = GLWrapper.instance.NVPathRendering.glIsPointInFillPathNV(path, mask, x, y)

public inline fun glIsPointInStrokePathNV(
    path: Int,
    x: Float,
    y: Float,
): Boolean = GLWrapper.instance.NVPathRendering.glIsPointInStrokePathNV(path, x, y)

public inline fun glGetPathLengthNV(
    path: Int,
    startSegment: Int,
    numSegments: Int,
): Float = GLWrapper.instance.NVPathRendering.glGetPathLengthNV(path, startSegment, numSegments)

public inline fun glPointAlongPathNV(
    path: Int,
    startSegment: Int,
    numSegments: Int,
    distance: Float,
    x: Ptr,
    y: Ptr,
    tangentX: Ptr,
    tangentY: Ptr,
): Boolean = GLWrapper.instance.NVPathRendering.glPointAlongPathNV(path, startSegment, numSegments,
        distance, x, y, tangentX, tangentY)

public inline fun glPointAlongPathNV(
    path: Int,
    startSegment: Int,
    numSegments: Int,
    distance: Float,
    x: Long,
    y: Long,
    tangentX: Long,
    tangentY: Long,
): Boolean = GLWrapper.instance.NVPathRendering.glPointAlongPathNV(path, startSegment, numSegments,
        distance, x, y, tangentX, tangentY)

public inline fun glMatrixLoad3x2fNV(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixLoad3x2fNV(matrixMode, m)

public inline fun glMatrixLoad3x2fNV(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixLoad3x2fNV(matrixMode, m)

public inline fun glMatrixLoad3x3fNV(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixLoad3x3fNV(matrixMode, m)

public inline fun glMatrixLoad3x3fNV(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixLoad3x3fNV(matrixMode, m)

public inline fun glMatrixLoadTranspose3x3fNV(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixLoadTranspose3x3fNV(matrixMode, m)

public inline fun glMatrixLoadTranspose3x3fNV(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixLoadTranspose3x3fNV(matrixMode, m)

public inline fun glMatrixMult3x2fNV(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixMult3x2fNV(matrixMode, m)

public inline fun glMatrixMult3x2fNV(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixMult3x2fNV(matrixMode, m)

public inline fun glMatrixMult3x3fNV(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixMult3x3fNV(matrixMode, m)

public inline fun glMatrixMult3x3fNV(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixMult3x3fNV(matrixMode, m)

public inline fun glMatrixMultTranspose3x3fNV(matrixMode: Int, m: Ptr): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixMultTranspose3x3fNV(matrixMode, m)

public inline fun glMatrixMultTranspose3x3fNV(matrixMode: Int, m: Long): Unit =
        GLWrapper.instance.NVPathRendering.glMatrixMultTranspose3x3fNV(matrixMode, m)

public inline fun glGetProgramResourcefvNV(
    program: Int,
    programInterface: Int,
    index: Int,
    propCount: Int,
    props: Ptr,
    bufSize: Int,
    length: Ptr,
    params: Ptr,
): Unit = GLWrapper.instance.NVPathRendering.glGetProgramResourcefvNV(program, programInterface,
        index, propCount, props, bufSize, length, params)

public inline fun glGetProgramResourcefvNV(
    program: Int,
    programInterface: Int,
    index: Int,
    propCount: Int,
    props: Long,
    bufSize: Int,
    length: Long,
    params: Long,
): Unit = GLWrapper.instance.NVPathRendering.glGetProgramResourcefvNV(program, programInterface,
        index, propCount, props, bufSize, length, params)
