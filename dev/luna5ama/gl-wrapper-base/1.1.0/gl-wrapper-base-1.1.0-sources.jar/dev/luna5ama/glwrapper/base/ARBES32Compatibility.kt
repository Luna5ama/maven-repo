@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface ARBES32Compatibility : GLBase {
    public fun glPrimitiveBoundingBoxARB(
        minX: Float,
        minY: Float,
        minZ: Float,
        minW: Float,
        maxX: Float,
        maxY: Float,
        maxZ: Float,
        maxW: Float,
    )
}

public const val GL_PRIMITIVE_BOUNDING_BOX_ARB: Int = 37_566

public const val GL_MULTISAMPLE_LINE_WIDTH_RANGE_ARB: Int = 37_761

public const val GL_MULTISAMPLE_LINE_WIDTH_GRANULARITY_ARB: Int = 37_762

public inline fun glPrimitiveBoundingBoxARB(
    minX: Float,
    minY: Float,
    minZ: Float,
    minW: Float,
    maxX: Float,
    maxY: Float,
    maxZ: Float,
    maxW: Float,
): Unit = GLWrapper.instance.ARBES32Compatibility.glPrimitiveBoundingBoxARB(minX, minY, minZ, minW,
        maxX, maxY, maxZ, maxW)
