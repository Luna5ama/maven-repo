@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTStencilClearTag : GLBase {
    public fun glStencilClearTagEXT(stencilTagBits: Int, stencilClearTag: Int)
}

public const val GL_STENCIL_TAG_BITS_EXT: Int = 35_058

public const val GL_STENCIL_CLEAR_TAG_VALUE_EXT: Int = 35_059

public inline fun glStencilClearTagEXT(stencilTagBits: Int, stencilClearTag: Int): Unit =
        GLWrapper.instance.EXTStencilClearTag.glStencilClearTagEXT(stencilTagBits, stencilClearTag)
