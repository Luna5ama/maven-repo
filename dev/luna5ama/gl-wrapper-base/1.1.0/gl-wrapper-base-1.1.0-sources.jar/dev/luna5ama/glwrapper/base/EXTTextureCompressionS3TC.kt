@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureCompressionS3TC : GLBase

public const val GL_COMPRESSED_RGB_S3TC_DXT1_EXT: Int = 33_776

public const val GL_COMPRESSED_RGBA_S3TC_DXT1_EXT: Int = 33_777

public const val GL_COMPRESSED_RGBA_S3TC_DXT3_EXT: Int = 33_778

public const val GL_COMPRESSED_RGBA_S3TC_DXT5_EXT: Int = 33_779
