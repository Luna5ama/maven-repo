@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface AMDQueryBufferObject : GLBase

public const val GL_QUERY_RESULT_NO_WAIT_AMD: Int = 37_268

public const val GL_QUERY_BUFFER_AMD: Int = 37_266

public const val GL_QUERY_BUFFER_BINDING_AMD: Int = 37_267
