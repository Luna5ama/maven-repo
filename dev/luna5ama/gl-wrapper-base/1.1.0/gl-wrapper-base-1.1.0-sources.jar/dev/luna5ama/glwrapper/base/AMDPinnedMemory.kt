@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface AMDPinnedMemory : GLBase

public const val GL_EXTERNAL_VIRTUAL_MEMORY_BUFFER_AMD: Int = 37_216
