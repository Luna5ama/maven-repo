@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVGPUMulticast : GLBase {
    public fun glRenderGpuMaskNV(mask: Int)

    @PtrParameter([4])
    public fun glMulticastBufferSubDataNV(
        gpuMask: Int,
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Ptr,
    )

    @Unsafe
    public fun glMulticastBufferSubDataNV(
        gpuMask: Int,
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Long,
    )

    public fun glMulticastCopyBufferSubDataNV(
        readGpu: Int,
        writeGpuMask: Int,
        readBuffer: Int,
        writeBuffer: Int,
        readOffset: Long,
        writeOffset: Long,
        size: Long,
    )

    public fun glMulticastCopyImageSubDataNV(
        srcGpu: Int,
        dstGpuMask: Int,
        srcName: Int,
        srcTarget: Int,
        srcLevel: Int,
        srcX: Int,
        srxY: Int,
        srcZ: Int,
        dstName: Int,
        dstTarget: Int,
        dstLevel: Int,
        dstX: Int,
        dstY: Int,
        dstZ: Int,
        srcWidth: Int,
        srcHeight: Int,
        srcDepth: Int,
    )

    public fun glMulticastBlitFramebufferNV(
        srcGpu: Int,
        dstGpu: Int,
        srcX0: Int,
        srcY0: Int,
        srcX1: Int,
        srcY1: Int,
        dstX0: Int,
        dstY0: Int,
        dstX1: Int,
        dstY1: Int,
        mask: Int,
        filter: Int,
    )

    @PtrParameter([4])
    public fun glMulticastFramebufferSampleLocationsfvNV(
        gpu: Int,
        framebuffer: Int,
        start: Int,
        count: Int,
        v: Ptr,
    )

    @Unsafe
    public fun glMulticastFramebufferSampleLocationsfvNV(
        gpu: Int,
        framebuffer: Int,
        start: Int,
        count: Int,
        v: Long,
    )

    public fun glMulticastBarrierNV()

    public fun glMulticastWaitSyncNV(signalGpu: Int, waitGpuMask: Int)

    @PtrParameter([3])
    public fun glMulticastGetQueryObjectivNV(
        gpu: Int,
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMulticastGetQueryObjectivNV(
        gpu: Int,
        id: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glMulticastGetQueryObjectuivNV(
        gpu: Int,
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMulticastGetQueryObjectuivNV(
        gpu: Int,
        id: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glMulticastGetQueryObjecti64vNV(
        gpu: Int,
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMulticastGetQueryObjecti64vNV(
        gpu: Int,
        id: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glMulticastGetQueryObjectui64vNV(
        gpu: Int,
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glMulticastGetQueryObjectui64vNV(
        gpu: Int,
        id: Int,
        pname: Int,
        params: Long,
    )
}

public const val GL_PER_GPU_STORAGE_BIT_NV: Int = 2_048

public const val GL_MULTICAST_GPUS_NV: Int = 37_562

public const val GL_RENDER_GPU_MASK_NV: Int = 38_232

public const val GL_PER_GPU_STORAGE_NV: Int = 38_216

public const val GL_MULTICAST_PROGRAMMABLE_SAMPLE_LOCATION_NV: Int = 38_217

public inline fun glRenderGpuMaskNV(mask: Int): Unit =
        GLWrapper.instance.NVGPUMulticast.glRenderGpuMaskNV(mask)

public inline fun glMulticastBufferSubDataNV(
    gpuMask: Int,
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Ptr,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastBufferSubDataNV(gpuMask, buffer, offset,
        size, `data`)

public inline fun glMulticastBufferSubDataNV(
    gpuMask: Int,
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastBufferSubDataNV(gpuMask, buffer, offset,
        size, `data`)

public inline fun glMulticastCopyBufferSubDataNV(
    readGpu: Int,
    writeGpuMask: Int,
    readBuffer: Int,
    writeBuffer: Int,
    readOffset: Long,
    writeOffset: Long,
    size: Long,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastCopyBufferSubDataNV(readGpu, writeGpuMask,
        readBuffer, writeBuffer, readOffset, writeOffset, size)

public inline fun glMulticastCopyImageSubDataNV(
    srcGpu: Int,
    dstGpuMask: Int,
    srcName: Int,
    srcTarget: Int,
    srcLevel: Int,
    srcX: Int,
    srxY: Int,
    srcZ: Int,
    dstName: Int,
    dstTarget: Int,
    dstLevel: Int,
    dstX: Int,
    dstY: Int,
    dstZ: Int,
    srcWidth: Int,
    srcHeight: Int,
    srcDepth: Int,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastCopyImageSubDataNV(srcGpu, dstGpuMask,
        srcName, srcTarget, srcLevel, srcX, srxY, srcZ, dstName, dstTarget, dstLevel, dstX, dstY,
        dstZ, srcWidth, srcHeight, srcDepth)

public inline fun glMulticastBlitFramebufferNV(
    srcGpu: Int,
    dstGpu: Int,
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    mask: Int,
    filter: Int,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastBlitFramebufferNV(srcGpu, dstGpu, srcX0,
        srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter)

public inline fun glMulticastFramebufferSampleLocationsfvNV(
    gpu: Int,
    framebuffer: Int,
    start: Int,
    count: Int,
    v: Ptr,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastFramebufferSampleLocationsfvNV(gpu,
        framebuffer, start, count, v)

public inline fun glMulticastFramebufferSampleLocationsfvNV(
    gpu: Int,
    framebuffer: Int,
    start: Int,
    count: Int,
    v: Long,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastFramebufferSampleLocationsfvNV(gpu,
        framebuffer, start, count, v)

public inline fun glMulticastBarrierNV(): Unit =
        GLWrapper.instance.NVGPUMulticast.glMulticastBarrierNV()

public inline fun glMulticastWaitSyncNV(signalGpu: Int, waitGpuMask: Int): Unit =
        GLWrapper.instance.NVGPUMulticast.glMulticastWaitSyncNV(signalGpu, waitGpuMask)

public inline fun glMulticastGetQueryObjectivNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastGetQueryObjectivNV(gpu, id, pname, params)

public inline fun glMulticastGetQueryObjectivNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastGetQueryObjectivNV(gpu, id, pname, params)

public inline fun glMulticastGetQueryObjectuivNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastGetQueryObjectuivNV(gpu, id, pname, params)

public inline fun glMulticastGetQueryObjectuivNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastGetQueryObjectuivNV(gpu, id, pname, params)

public inline fun glMulticastGetQueryObjecti64vNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastGetQueryObjecti64vNV(gpu, id, pname, params)

public inline fun glMulticastGetQueryObjecti64vNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastGetQueryObjecti64vNV(gpu, id, pname, params)

public inline fun glMulticastGetQueryObjectui64vNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastGetQueryObjectui64vNV(gpu, id, pname, params)

public inline fun glMulticastGetQueryObjectui64vNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVGPUMulticast.glMulticastGetQueryObjectui64vNV(gpu, id, pname, params)
