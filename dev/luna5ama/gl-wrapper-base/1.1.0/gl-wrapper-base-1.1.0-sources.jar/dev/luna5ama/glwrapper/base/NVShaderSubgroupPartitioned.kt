@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVShaderSubgroupPartitioned : GLBase

public const val GL_SUBGROUP_FEATURE_PARTITIONED_BIT_NV: Int = 256
