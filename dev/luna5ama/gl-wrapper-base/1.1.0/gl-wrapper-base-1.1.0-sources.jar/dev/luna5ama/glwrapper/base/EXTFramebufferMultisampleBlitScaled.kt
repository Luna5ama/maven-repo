@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTFramebufferMultisampleBlitScaled : GLBase

public const val GL_SCALED_RESOLVE_FASTEST_EXT: Int = 37_050

public const val GL_SCALED_RESOLVE_NICEST_EXT: Int = 37_051
