@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVPixelDataRange : GLBase {
    @PtrParameter([2])
    public fun glPixelDataRangeNV(
        target: Int,
        length: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glPixelDataRangeNV(
        target: Int,
        length: Int,
        pointer: Long,
    )

    public fun glFlushPixelDataRangeNV(target: Int)
}

public const val GL_WRITE_PIXEL_DATA_RANGE_NV: Int = 34_936

public const val GL_READ_PIXEL_DATA_RANGE_NV: Int = 34_937

public const val GL_WRITE_PIXEL_DATA_RANGE_LENGTH_NV: Int = 34_938

public const val GL_READ_PIXEL_DATA_RANGE_LENGTH_NV: Int = 34_939

public const val GL_WRITE_PIXEL_DATA_RANGE_POINTER_NV: Int = 34_940

public const val GL_READ_PIXEL_DATA_RANGE_POINTER_NV: Int = 34_941

public inline fun glPixelDataRangeNV(
    target: Int,
    length: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.NVPixelDataRange.glPixelDataRangeNV(target, length, pointer)

public inline fun glPixelDataRangeNV(
    target: Int,
    length: Int,
    pointer: Long,
): Unit = GLWrapper.instance.NVPixelDataRange.glPixelDataRangeNV(target, length, pointer)

public inline fun glFlushPixelDataRangeNV(target: Int): Unit =
        GLWrapper.instance.NVPixelDataRange.glFlushPixelDataRangeNV(target)
