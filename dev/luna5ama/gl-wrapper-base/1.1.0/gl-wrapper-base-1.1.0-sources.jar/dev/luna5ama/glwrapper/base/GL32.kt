@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import dev.luna5ama.kmogus.ensureCapacity
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL32 : GLBase {
    @PtrParameter([2])
    public fun glGetBufferParameteri64v(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetBufferParameteri64v(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glDrawElementsBaseVertex(
        mode: Int,
        count: Int,
        type: Int,
        indices: Ptr,
        basevertex: Int,
    )

    @Unsafe
    public fun glDrawElementsBaseVertex(
        mode: Int,
        count: Int,
        type: Int,
        indices: Long,
        basevertex: Int,
    )

    @PtrParameter([5])
    public fun glDrawRangeElementsBaseVertex(
        mode: Int,
        start: Int,
        end: Int,
        count: Int,
        type: Int,
        indices: Ptr,
        basevertex: Int,
    )

    @Unsafe
    public fun glDrawRangeElementsBaseVertex(
        mode: Int,
        start: Int,
        end: Int,
        count: Int,
        type: Int,
        indices: Long,
        basevertex: Int,
    )

    @PtrParameter([3])
    public fun glDrawElementsInstancedBaseVertex(
        mode: Int,
        count: Int,
        type: Int,
        indices: Ptr,
        primcount: Int,
        basevertex: Int,
    )

    @Unsafe
    public fun glDrawElementsInstancedBaseVertex(
        mode: Int,
        count: Int,
        type: Int,
        indices: Long,
        primcount: Int,
        basevertex: Int,
    )

    @PtrParameter([1, 3, 5])
    public fun glMultiDrawElementsBaseVertex(
        mode: Int,
        count: Ptr,
        type: Int,
        indices: Ptr,
        drawcount: Int,
        basevertex: Ptr,
    )

    @Unsafe
    public fun glMultiDrawElementsBaseVertex(
        mode: Int,
        count: Long,
        type: Int,
        indices: Long,
        drawcount: Int,
        basevertex: Long,
    )

    public fun glProvokingVertex(mode: Int)

    public fun glTexImage2DMultisample(
        target: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        fixedsamplelocations: Boolean,
    )

    public fun glTexImage3DMultisample(
        target: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        fixedsamplelocations: Boolean,
    )

    @PtrParameter([2])
    public fun glGetMultisamplefv(
        pname: Int,
        index: Int,
        `val`: Ptr,
    )

    @Unsafe
    public fun glGetMultisamplefv(
        pname: Int,
        index: Int,
        `val`: Long,
    )

    public fun glSampleMaski(index: Int, mask: Int)

    public fun glFramebufferTexture(
        target: Int,
        attachment: Int,
        texture: Int,
        level: Int,
    )

    public fun glFenceSync(condition: Int, flags: Int): Long

    public fun glIsSync(sync: Long): Boolean

    public fun glDeleteSync(sync: Long)

    public fun glClientWaitSync(
        sync: Long,
        flags: Int,
        timeout: Long,
    ): Int

    public fun glWaitSync(
        sync: Long,
        flags: Int,
        timeout: Long,
    )

    @PtrParameter([1])
    public fun glGetInteger64v(pname: Int, params: Ptr)

    @Unsafe
    public fun glGetInteger64v(pname: Int, params: Long)

    @PtrParameter([2])
    public fun glGetInteger64i_v(
        pname: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetInteger64i_v(
        pname: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([3, 4])
    public fun glGetSynciv(
        sync: Long,
        pname: Int,
        bufSize: Int,
        length: Ptr,
        values: Ptr,
    )

    @Unsafe
    public fun glGetSynciv(
        sync: Long,
        pname: Int,
        bufSize: Int,
        length: Long,
        values: Long,
    )

    @CoreOverload
    public fun glGetSynci(sync: Long, pname: Int): Int {
        tempArr.ensureCapacity(8, false)
        val ptr = tempArr.ptr
        ptr.setInt(1)
        glGetSynciv(sync, pname, 1, ptr, ptr + 4)
        return (ptr + 4).getInt()
    }
}

public const val GL_CONTEXT_PROFILE_MASK: Int = 37_158

public const val GL_CONTEXT_CORE_PROFILE_BIT: Int = 1

public const val GL_CONTEXT_COMPATIBILITY_PROFILE_BIT: Int = 2

public const val GL_MAX_VERTEX_OUTPUT_COMPONENTS: Int = 37_154

public const val GL_MAX_GEOMETRY_INPUT_COMPONENTS: Int = 37_155

public const val GL_MAX_GEOMETRY_OUTPUT_COMPONENTS: Int = 37_156

public const val GL_MAX_FRAGMENT_INPUT_COMPONENTS: Int = 37_157

public const val GL_FIRST_VERTEX_CONVENTION: Int = 36_429

public const val GL_LAST_VERTEX_CONVENTION: Int = 36_430

public const val GL_PROVOKING_VERTEX: Int = 36_431

public const val GL_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION: Int = 36_428

public const val GL_TEXTURE_CUBE_MAP_SEAMLESS: Int = 34_895

public const val GL_SAMPLE_POSITION: Int = 36_432

public const val GL_SAMPLE_MASK: Int = 36_433

public const val GL_SAMPLE_MASK_VALUE: Int = 36_434

public const val GL_TEXTURE_2D_MULTISAMPLE: Int = 37_120

public const val GL_PROXY_TEXTURE_2D_MULTISAMPLE: Int = 37_121

public const val GL_TEXTURE_2D_MULTISAMPLE_ARRAY: Int = 37_122

public const val GL_PROXY_TEXTURE_2D_MULTISAMPLE_ARRAY: Int = 37_123

public const val GL_MAX_SAMPLE_MASK_WORDS: Int = 36_441

public const val GL_MAX_COLOR_TEXTURE_SAMPLES: Int = 37_134

public const val GL_MAX_DEPTH_TEXTURE_SAMPLES: Int = 37_135

public const val GL_MAX_INTEGER_SAMPLES: Int = 37_136

public const val GL_TEXTURE_BINDING_2D_MULTISAMPLE: Int = 37_124

public const val GL_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY: Int = 37_125

public const val GL_TEXTURE_SAMPLES: Int = 37_126

public const val GL_TEXTURE_FIXED_SAMPLE_LOCATIONS: Int = 37_127

public const val GL_SAMPLER_2D_MULTISAMPLE: Int = 37_128

public const val GL_INT_SAMPLER_2D_MULTISAMPLE: Int = 37_129

public const val GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE: Int = 37_130

public const val GL_SAMPLER_2D_MULTISAMPLE_ARRAY: Int = 37_131

public const val GL_INT_SAMPLER_2D_MULTISAMPLE_ARRAY: Int = 37_132

public const val GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY: Int = 37_133

public const val GL_DEPTH_CLAMP: Int = 34_383

public const val GL_GEOMETRY_SHADER: Int = 36_313

public const val GL_GEOMETRY_VERTICES_OUT: Int = 36_314

public const val GL_GEOMETRY_INPUT_TYPE: Int = 36_315

public const val GL_GEOMETRY_OUTPUT_TYPE: Int = 36_316

public const val GL_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS: Int = 35_881

public const val GL_MAX_GEOMETRY_UNIFORM_COMPONENTS: Int = 36_319

public const val GL_MAX_GEOMETRY_OUTPUT_VERTICES: Int = 36_320

public const val GL_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS: Int = 36_321

public const val GL_LINES_ADJACENCY: Int = 10

public const val GL_LINE_STRIP_ADJACENCY: Int = 11

public const val GL_TRIANGLES_ADJACENCY: Int = 12

public const val GL_TRIANGLE_STRIP_ADJACENCY: Int = 13

public const val GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS: Int = 36_264

public const val GL_FRAMEBUFFER_ATTACHMENT_LAYERED: Int = 36_263

public const val GL_PROGRAM_POINT_SIZE: Int = 34_370

public const val GL_MAX_SERVER_WAIT_TIMEOUT: Int = 37_137

public const val GL_OBJECT_TYPE: Int = 37_138

public const val GL_SYNC_CONDITION: Int = 37_139

public const val GL_SYNC_STATUS: Int = 37_140

public const val GL_SYNC_FLAGS: Int = 37_141

public const val GL_SYNC_FENCE: Int = 37_142

public const val GL_SYNC_GPU_COMMANDS_COMPLETE: Int = 37_143

public const val GL_UNSIGNALED: Int = 37_144

public const val GL_SIGNALED: Int = 37_145

public const val GL_SYNC_FLUSH_COMMANDS_BIT: Int = 1

public const val GL_TIMEOUT_IGNORED: Long = 0x1L

public const val GL_ALREADY_SIGNALED: Int = 37_146

public const val GL_TIMEOUT_EXPIRED: Int = 37_147

public const val GL_CONDITION_SATISFIED: Int = 37_148

public const val GL_WAIT_FAILED: Int = 37_149

public inline fun glGetBufferParameteri64v(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL32.glGetBufferParameteri64v(target, pname, params)

public inline fun glGetBufferParameteri64v(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL32.glGetBufferParameteri64v(target, pname, params)

public inline fun glDrawElementsBaseVertex(
    mode: Int,
    count: Int,
    type: Int,
    indices: Ptr,
    basevertex: Int,
): Unit = GLWrapper.instance.GL32.glDrawElementsBaseVertex(mode, count, type, indices, basevertex)

public inline fun glDrawElementsBaseVertex(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    basevertex: Int,
): Unit = GLWrapper.instance.GL32.glDrawElementsBaseVertex(mode, count, type, indices, basevertex)

public inline fun glDrawRangeElementsBaseVertex(
    mode: Int,
    start: Int,
    end: Int,
    count: Int,
    type: Int,
    indices: Ptr,
    basevertex: Int,
): Unit = GLWrapper.instance.GL32.glDrawRangeElementsBaseVertex(mode, start, end, count, type,
        indices, basevertex)

public inline fun glDrawRangeElementsBaseVertex(
    mode: Int,
    start: Int,
    end: Int,
    count: Int,
    type: Int,
    indices: Long,
    basevertex: Int,
): Unit = GLWrapper.instance.GL32.glDrawRangeElementsBaseVertex(mode, start, end, count, type,
        indices, basevertex)

public inline fun glDrawElementsInstancedBaseVertex(
    mode: Int,
    count: Int,
    type: Int,
    indices: Ptr,
    primcount: Int,
    basevertex: Int,
): Unit = GLWrapper.instance.GL32.glDrawElementsInstancedBaseVertex(mode, count, type, indices,
        primcount, basevertex)

public inline fun glDrawElementsInstancedBaseVertex(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
    basevertex: Int,
): Unit = GLWrapper.instance.GL32.glDrawElementsInstancedBaseVertex(mode, count, type, indices,
        primcount, basevertex)

public inline fun glMultiDrawElementsBaseVertex(
    mode: Int,
    count: Ptr,
    type: Int,
    indices: Ptr,
    drawcount: Int,
    basevertex: Ptr,
): Unit = GLWrapper.instance.GL32.glMultiDrawElementsBaseVertex(mode, count, type, indices,
        drawcount, basevertex)

public inline fun glMultiDrawElementsBaseVertex(
    mode: Int,
    count: Long,
    type: Int,
    indices: Long,
    drawcount: Int,
    basevertex: Long,
): Unit = GLWrapper.instance.GL32.glMultiDrawElementsBaseVertex(mode, count, type, indices,
        drawcount, basevertex)

public inline fun glProvokingVertex(mode: Int): Unit =
        GLWrapper.instance.GL32.glProvokingVertex(mode)

public inline fun glTexImage2DMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    fixedsamplelocations: Boolean,
): Unit = GLWrapper.instance.GL32.glTexImage2DMultisample(target, samples, internalformat, width,
        height, fixedsamplelocations)

public inline fun glTexImage3DMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedsamplelocations: Boolean,
): Unit = GLWrapper.instance.GL32.glTexImage3DMultisample(target, samples, internalformat, width,
        height, depth, fixedsamplelocations)

public inline fun glGetMultisamplefv(
    pname: Int,
    index: Int,
    `val`: Ptr,
): Unit = GLWrapper.instance.GL32.glGetMultisamplefv(pname, index, `val`)

public inline fun glGetMultisamplefv(
    pname: Int,
    index: Int,
    `val`: Long,
): Unit = GLWrapper.instance.GL32.glGetMultisamplefv(pname, index, `val`)

public inline fun glSampleMaski(index: Int, mask: Int): Unit =
        GLWrapper.instance.GL32.glSampleMaski(index, mask)

public inline fun glFramebufferTexture(
    target: Int,
    attachment: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.GL32.glFramebufferTexture(target, attachment, texture, level)

public inline fun glFenceSync(condition: Int, flags: Int): Long =
        GLWrapper.instance.GL32.glFenceSync(condition, flags)

public inline fun glIsSync(sync: Long): Boolean = GLWrapper.instance.GL32.glIsSync(sync)

public inline fun glDeleteSync(sync: Long): Unit = GLWrapper.instance.GL32.glDeleteSync(sync)

public inline fun glClientWaitSync(
    sync: Long,
    flags: Int,
    timeout: Long,
): Int = GLWrapper.instance.GL32.glClientWaitSync(sync, flags, timeout)

public inline fun glWaitSync(
    sync: Long,
    flags: Int,
    timeout: Long,
): Unit = GLWrapper.instance.GL32.glWaitSync(sync, flags, timeout)

public inline fun glGetInteger64v(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.GL32.glGetInteger64v(pname, params)

public inline fun glGetInteger64v(pname: Int, params: Long): Unit =
        GLWrapper.instance.GL32.glGetInteger64v(pname, params)

public inline fun glGetInteger64i_v(
    pname: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL32.glGetInteger64i_v(pname, index, params)

public inline fun glGetInteger64i_v(
    pname: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.GL32.glGetInteger64i_v(pname, index, params)

public inline fun glGetSynciv(
    sync: Long,
    pname: Int,
    bufSize: Int,
    length: Ptr,
    values: Ptr,
): Unit = GLWrapper.instance.GL32.glGetSynciv(sync, pname, bufSize, length, values)

public inline fun glGetSynciv(
    sync: Long,
    pname: Int,
    bufSize: Int,
    length: Long,
    values: Long,
): Unit = GLWrapper.instance.GL32.glGetSynciv(sync, pname, bufSize, length, values)

public inline fun glGetSynci(sync: Long, pname: Int): Int = GLWrapper.instance.GL32.glGetSynci(sync,
        pname)
