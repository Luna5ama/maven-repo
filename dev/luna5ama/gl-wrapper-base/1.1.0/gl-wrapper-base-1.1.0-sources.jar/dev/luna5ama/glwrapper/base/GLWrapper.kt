package dev.luna5ama.glwrapper.base

public class GLWrapper {
    public val properties: WrapperProperties

    public val GL11: GL11

    public val GL12: GL12

    public val GL13: GL13

    public val GL14: GL14

    public val GL15: GL15

    public val GL20: GL20

    public val GL21: GL21

    public val GL30: GL30

    public val GL31: GL31

    public val GL32: GL32

    public val GL33: GL33

    public val GL40: GL40

    public val GL41: GL41

    public val GL42: GL42

    public val GL43: GL43

    public val GL44: GL44

    public val GL45: GL45

    public val GL46: GL46

    public val KHRBlendEquationAdvanced: KHRBlendEquationAdvanced

    public val KHRBlendEquationAdvancedCoherent: KHRBlendEquationAdvancedCoherent

    public val KHRContextFlushControl: KHRContextFlushControl

    public val KHRParallelShaderCompile: KHRParallelShaderCompile

    public val KHRShaderSubgroup: KHRShaderSubgroup

    public val KHRTextureCompressionASTCLDR: KHRTextureCompressionASTCLDR

    public val ARBBindlessTexture: ARBBindlessTexture

    public val ARBCLEvent: ARBCLEvent

    public val ARBComputeVariableGroupSize: ARBComputeVariableGroupSize

    public val ARBDebugOutput: ARBDebugOutput

    public val ARBDepthBufferFloat: ARBDepthBufferFloat

    public val ARBES32Compatibility: ARBES32Compatibility

    public val ARBFragmentProgram: ARBFragmentProgram

    public val ARBFramebufferSRGB: ARBFramebufferSRGB

    public val ARBGPUShaderInt64: ARBGPUShaderInt64

    public val ARBHalfFloatPixel: ARBHalfFloatPixel

    public val ARBHalfFloatVertex: ARBHalfFloatVertex

    public val ARBImaging: ARBImaging

    public val ARBMapBufferRange: ARBMapBufferRange

    public val ARBMatrixPalette: ARBMatrixPalette

    public val ARBParallelShaderCompile: ARBParallelShaderCompile

    public val ARBRobustness: ARBRobustness

    public val ARBSampleLocations: ARBSampleLocations

    public val ARBSeamlessCubemapPerTexture: ARBSeamlessCubemapPerTexture

    public val ARBShadingLanguageInclude: ARBShadingLanguageInclude

    public val ARBShadowAmbient: ARBShadowAmbient

    public val ARBSparseBuffer: ARBSparseBuffer

    public val ARBSparseTexture: ARBSparseTexture

    public val ARBTextureCompressionRGTC: ARBTextureCompressionRGTC

    public val ARBTextureFilterMinmax: ARBTextureFilterMinmax

    public val ARBTextureRG: ARBTextureRG

    public val ARBVertexBlend: ARBVertexBlend

    public val ARBVertexProgram: ARBVertexProgram

    public val EXT422Pixels: EXT422Pixels

    public val EXTABGR: EXTABGR

    public val EXTBindableUniform: EXTBindableUniform

    public val EXTBlendEquationSeparate: EXTBlendEquationSeparate

    public val EXTClipVolumeHint: EXTClipVolumeHint

    public val EXTCompiledVertexArray: EXTCompiledVertexArray

    public val EXTDebugLabel: EXTDebugLabel

    public val EXTDebugMarker: EXTDebugMarker

    public val EXTDepthBoundsTest: EXTDepthBoundsTest

    public val EXTDirectStateAccess: EXTDirectStateAccess

    public val EXTDrawInstanced: EXTDrawInstanced

    public val EXTEGLImageStorage: EXTEGLImageStorage

    public val EXTExternalBuffer: EXTExternalBuffer

    public val EXTFramebufferBlit: EXTFramebufferBlit

    public val EXTFramebufferBlitLayers: EXTFramebufferBlitLayers

    public val EXTFramebufferMultisample: EXTFramebufferMultisample

    public val EXTFramebufferMultisampleBlitScaled: EXTFramebufferMultisampleBlitScaled

    public val EXTFramebufferObject: EXTFramebufferObject

    public val EXTGPUProgramParameters: EXTGPUProgramParameters

    public val EXTGPUShader4: EXTGPUShader4

    public val EXTGeometryShader4: EXTGeometryShader4

    public val EXTMemoryObject: EXTMemoryObject

    public val EXTMemoryObjectFD: EXTMemoryObjectFD

    public val EXTMemoryObjectWin32: EXTMemoryObjectWin32

    public val EXTPackedDepthStencil: EXTPackedDepthStencil

    public val EXTPixelBufferObject: EXTPixelBufferObject

    public val EXTPointParameters: EXTPointParameters

    public val EXTPolygonOffsetClamp: EXTPolygonOffsetClamp

    public val EXTProvokingVertex: EXTProvokingVertex

    public val EXTRasterMultisample: EXTRasterMultisample

    public val EXTSemaphore: EXTSemaphore

    public val EXTSemaphoreFD: EXTSemaphoreFD

    public val EXTSemaphoreWin32: EXTSemaphoreWin32

    public val EXTSeparateShaderObjects: EXTSeparateShaderObjects

    public val EXTShaderFramebufferFetch: EXTShaderFramebufferFetch

    public val EXTShaderFramebufferFetchNonCoherent: EXTShaderFramebufferFetchNonCoherent

    public val EXTShaderImageLoadStore: EXTShaderImageLoadStore

    public val EXTSharedTexturePalette: EXTSharedTexturePalette

    public val EXTStencilClearTag: EXTStencilClearTag

    public val EXTTextureBufferObject: EXTTextureBufferObject

    public val EXTTextureCompressionLATC: EXTTextureCompressionLATC

    public val EXTTextureCompressionS3TC: EXTTextureCompressionS3TC

    public val EXTTextureFilterAnisotropic: EXTTextureFilterAnisotropic

    public val EXTTextureFilterMinmax: EXTTextureFilterMinmax

    public val EXTTextureMirrorClamp: EXTTextureMirrorClamp

    public val EXTTextureSRGBDecode: EXTTextureSRGBDecode

    public val EXTTextureSRGBR8: EXTTextureSRGBR8

    public val EXTTextureSRGBRG8: EXTTextureSRGBRG8

    public val EXTTextureSnorm: EXTTextureSnorm

    public val EXTTextureStorage: EXTTextureStorage

    public val EXTTextureSwizzle: EXTTextureSwizzle

    public val EXTTimerQuery: EXTTimerQuery

    public val EXTTransformFeedback: EXTTransformFeedback

    public val EXTVertexAttrib64bit: EXTVertexAttrib64bit

    public val EXTWin32KeyedMutex: EXTWin32KeyedMutex

    public val EXTWindowRectangles: EXTWindowRectangles

    public val EXTX11SyncObject: EXTX11SyncObject

    public val NVAlphaToCoverageDitherControl: NVAlphaToCoverageDitherControl

    public val NVBindlessMultiDrawIndirect: NVBindlessMultiDrawIndirect

    public val NVBindlessMultiDrawIndirectCount: NVBindlessMultiDrawIndirectCount

    public val NVBindlessTexture: NVBindlessTexture

    public val NVBlendEquationAdvanced: NVBlendEquationAdvanced

    public val NVBlendEquationAdvancedCoherent: NVBlendEquationAdvancedCoherent

    public val NVBlendMinmaxFactor: NVBlendMinmaxFactor

    public val NVClipSpaceWScaling: NVClipSpaceWScaling

    public val NVCommandList: NVCommandList

    public val NVConservativeRaster: NVConservativeRaster

    public val NVConservativeRasterDilate: NVConservativeRasterDilate

    public val NVConservativeRasterPreSnap: NVConservativeRasterPreSnap

    public val NVConservativeRasterPreSnapTriangles: NVConservativeRasterPreSnapTriangles

    public val NVCopyDepthToColor: NVCopyDepthToColor

    public val NVCopyImage: NVCopyImage

    public val NVDeepTexture3D: NVDeepTexture3D

    public val NVDepthBufferFloat: NVDepthBufferFloat

    public val NVDepthClamp: NVDepthClamp

    public val NVDrawTexture: NVDrawTexture

    public val NVDrawVulkanImage: NVDrawVulkanImage

    public val NVExplicitMultisample: NVExplicitMultisample

    public val NVFence: NVFence

    public val NVFillRectangle: NVFillRectangle

    public val NVFloatBuffer: NVFloatBuffer

    public val NVFogDistance: NVFogDistance

    public val NVFragmentCoverageToColor: NVFragmentCoverageToColor

    public val NVFramebufferMixedSamples: NVFramebufferMixedSamples

    public val NVFramebufferMultisampleCoverage: NVFramebufferMultisampleCoverage

    public val NVGPUMulticast: NVGPUMulticast

    public val NVGPUShader5: NVGPUShader5

    public val NVInternalformatSampleQuery: NVInternalformatSampleQuery

    public val NVLightMaxExponent: NVLightMaxExponent

    public val NVMemoryAttachment: NVMemoryAttachment

    public val NVMemoryObjectSparse: NVMemoryObjectSparse

    public val NVMeshShader: NVMeshShader

    public val NVMultisampleCoverage: NVMultisampleCoverage

    public val NVMultisampleFilterHint: NVMultisampleFilterHint

    public val NVPackedDepthStencil: NVPackedDepthStencil

    public val NVPathRendering: NVPathRendering

    public val NVPathRenderingSharedEdge: NVPathRenderingSharedEdge

    public val NVPixelDataRange: NVPixelDataRange

    public val NVPointSprite: NVPointSprite

    public val NVPrimitiveShadingRate: NVPrimitiveShadingRate

    public val NVQueryResource: NVQueryResource

    public val NVQueryResourceTag: NVQueryResourceTag

    public val NVRepresentativeFragmentTest: NVRepresentativeFragmentTest

    public val NVRobustnessVideoMemoryPurge: NVRobustnessVideoMemoryPurge

    public val NVSampleLocations: NVSampleLocations

    public val NVScissorExclusive: NVScissorExclusive

    public val NVShaderBufferLoad: NVShaderBufferLoad

    public val NVShaderBufferStore: NVShaderBufferStore

    public val NVShaderSubgroupPartitioned: NVShaderSubgroupPartitioned

    public val NVShaderThreadGroup: NVShaderThreadGroup

    public val NVShadingRateImage: NVShadingRateImage

    public val NVTexgenReflection: NVTexgenReflection

    public val NVTextureBarrier: NVTextureBarrier

    public val NVTextureMultisample: NVTextureMultisample

    public val NVTextureShader: NVTextureShader

    public val NVTextureShader2: NVTextureShader2

    public val NVTextureShader3: NVTextureShader3

    public val NVTimelineSemaphore: NVTimelineSemaphore

    public val NVTransformFeedback: NVTransformFeedback

    public val NVTransformFeedback2: NVTransformFeedback2

    public val NVUniformBufferUnifiedMemory: NVUniformBufferUnifiedMemory

    public val NVVertexArrayRange: NVVertexArrayRange

    public val NVVertexArrayRange2: NVVertexArrayRange2

    public val NVVertexAttribInteger64bit: NVVertexAttribInteger64bit

    public val NVVertexBufferUnifiedMemory: NVVertexBufferUnifiedMemory

    public val NVViewportSwizzle: NVViewportSwizzle

    public val AMDBlendMinmaxFactor: AMDBlendMinmaxFactor

    public val AMDDebugOutput: AMDDebugOutput

    public val AMDDepthClampSeparate: AMDDepthClampSeparate

    public val AMDDrawBuffersBlend: AMDDrawBuffersBlend

    public val AMDFramebufferMultisampleAdvanced: AMDFramebufferMultisampleAdvanced

    public val AMDGPUShaderHalfFloat: AMDGPUShaderHalfFloat

    public val AMDGPUShaderHalfFloatFetch: AMDGPUShaderHalfFloatFetch

    public val AMDGPUShaderInt64: AMDGPUShaderInt64

    public val AMDInterleavedElements: AMDInterleavedElements

    public val AMDOcclusionQueryEvent: AMDOcclusionQueryEvent

    public val AMDPerformanceMonitor: AMDPerformanceMonitor

    public val AMDPinnedMemory: AMDPinnedMemory

    public val AMDQueryBufferObject: AMDQueryBufferObject

    public val AMDSamplePositions: AMDSamplePositions

    public val AMDSeamlessCubemapPerTexture: AMDSeamlessCubemapPerTexture

    public val AMDSparseTexture: AMDSparseTexture

    public val AMDStencilOperationExtended: AMDStencilOperationExtended

    public val AMDTransformFeedback4: AMDTransformFeedback4

    public val AMDVertexShaderTessellator: AMDVertexShaderTessellator

    public constructor(
        GL11: GLBase.Constructor<GL11>,
        GL12: GLBase.Constructor<GL12>,
        GL13: GLBase.Constructor<GL13>,
        GL14: GLBase.Constructor<GL14>,
        GL15: GLBase.Constructor<GL15>,
        GL20: GLBase.Constructor<GL20>,
        GL21: GLBase.Constructor<GL21>,
        GL30: GLBase.Constructor<GL30>,
        GL31: GLBase.Constructor<GL31>,
        GL32: GLBase.Constructor<GL32>,
        GL33: GLBase.Constructor<GL33>,
        GL40: GLBase.Constructor<GL40>,
        GL41: GLBase.Constructor<GL41>,
        GL42: GLBase.Constructor<GL42>,
        GL43: GLBase.Constructor<GL43>,
        GL44: GLBase.Constructor<GL44>,
        GL45: GLBase.Constructor<GL45>,
        GL46: GLBase.Constructor<GL46>,
        KHRBlendEquationAdvanced: GLBase.Constructor<KHRBlendEquationAdvanced>,
        KHRBlendEquationAdvancedCoherent: GLBase.Constructor<KHRBlendEquationAdvancedCoherent>,
        KHRContextFlushControl: GLBase.Constructor<KHRContextFlushControl>,
        KHRParallelShaderCompile: GLBase.Constructor<KHRParallelShaderCompile>,
        KHRShaderSubgroup: GLBase.Constructor<KHRShaderSubgroup>,
        KHRTextureCompressionASTCLDR: GLBase.Constructor<KHRTextureCompressionASTCLDR>,
        ARBBindlessTexture: GLBase.Constructor<ARBBindlessTexture>,
        ARBCLEvent: GLBase.Constructor<ARBCLEvent>,
        ARBComputeVariableGroupSize: GLBase.Constructor<ARBComputeVariableGroupSize>,
        ARBDebugOutput: GLBase.Constructor<ARBDebugOutput>,
        ARBDepthBufferFloat: GLBase.Constructor<ARBDepthBufferFloat>,
        ARBES32Compatibility: GLBase.Constructor<ARBES32Compatibility>,
        ARBFragmentProgram: GLBase.Constructor<ARBFragmentProgram>,
        ARBFramebufferSRGB: GLBase.Constructor<ARBFramebufferSRGB>,
        ARBGPUShaderInt64: GLBase.Constructor<ARBGPUShaderInt64>,
        ARBHalfFloatPixel: GLBase.Constructor<ARBHalfFloatPixel>,
        ARBHalfFloatVertex: GLBase.Constructor<ARBHalfFloatVertex>,
        ARBImaging: GLBase.Constructor<ARBImaging>,
        ARBMapBufferRange: GLBase.Constructor<ARBMapBufferRange>,
        ARBMatrixPalette: GLBase.Constructor<ARBMatrixPalette>,
        ARBParallelShaderCompile: GLBase.Constructor<ARBParallelShaderCompile>,
        ARBRobustness: GLBase.Constructor<ARBRobustness>,
        ARBSampleLocations: GLBase.Constructor<ARBSampleLocations>,
        ARBSeamlessCubemapPerTexture: GLBase.Constructor<ARBSeamlessCubemapPerTexture>,
        ARBShadingLanguageInclude: GLBase.Constructor<ARBShadingLanguageInclude>,
        ARBShadowAmbient: GLBase.Constructor<ARBShadowAmbient>,
        ARBSparseBuffer: GLBase.Constructor<ARBSparseBuffer>,
        ARBSparseTexture: GLBase.Constructor<ARBSparseTexture>,
        ARBTextureCompressionRGTC: GLBase.Constructor<ARBTextureCompressionRGTC>,
        ARBTextureFilterMinmax: GLBase.Constructor<ARBTextureFilterMinmax>,
        ARBTextureRG: GLBase.Constructor<ARBTextureRG>,
        ARBVertexBlend: GLBase.Constructor<ARBVertexBlend>,
        ARBVertexProgram: GLBase.Constructor<ARBVertexProgram>,
        EXT422Pixels: GLBase.Constructor<EXT422Pixels>,
        EXTABGR: GLBase.Constructor<EXTABGR>,
        EXTBindableUniform: GLBase.Constructor<EXTBindableUniform>,
        EXTBlendEquationSeparate: GLBase.Constructor<EXTBlendEquationSeparate>,
        EXTClipVolumeHint: GLBase.Constructor<EXTClipVolumeHint>,
        EXTCompiledVertexArray: GLBase.Constructor<EXTCompiledVertexArray>,
        EXTDebugLabel: GLBase.Constructor<EXTDebugLabel>,
        EXTDebugMarker: GLBase.Constructor<EXTDebugMarker>,
        EXTDepthBoundsTest: GLBase.Constructor<EXTDepthBoundsTest>,
        EXTDirectStateAccess: GLBase.Constructor<EXTDirectStateAccess>,
        EXTDrawInstanced: GLBase.Constructor<EXTDrawInstanced>,
        EXTEGLImageStorage: GLBase.Constructor<EXTEGLImageStorage>,
        EXTExternalBuffer: GLBase.Constructor<EXTExternalBuffer>,
        EXTFramebufferBlit: GLBase.Constructor<EXTFramebufferBlit>,
        EXTFramebufferBlitLayers: GLBase.Constructor<EXTFramebufferBlitLayers>,
        EXTFramebufferMultisample: GLBase.Constructor<EXTFramebufferMultisample>,
        EXTFramebufferMultisampleBlitScaled: GLBase.Constructor<EXTFramebufferMultisampleBlitScaled>,
        EXTFramebufferObject: GLBase.Constructor<EXTFramebufferObject>,
        EXTGPUProgramParameters: GLBase.Constructor<EXTGPUProgramParameters>,
        EXTGPUShader4: GLBase.Constructor<EXTGPUShader4>,
        EXTGeometryShader4: GLBase.Constructor<EXTGeometryShader4>,
        EXTMemoryObject: GLBase.Constructor<EXTMemoryObject>,
        EXTMemoryObjectFD: GLBase.Constructor<EXTMemoryObjectFD>,
        EXTMemoryObjectWin32: GLBase.Constructor<EXTMemoryObjectWin32>,
        EXTPackedDepthStencil: GLBase.Constructor<EXTPackedDepthStencil>,
        EXTPixelBufferObject: GLBase.Constructor<EXTPixelBufferObject>,
        EXTPointParameters: GLBase.Constructor<EXTPointParameters>,
        EXTPolygonOffsetClamp: GLBase.Constructor<EXTPolygonOffsetClamp>,
        EXTProvokingVertex: GLBase.Constructor<EXTProvokingVertex>,
        EXTRasterMultisample: GLBase.Constructor<EXTRasterMultisample>,
        EXTSemaphore: GLBase.Constructor<EXTSemaphore>,
        EXTSemaphoreFD: GLBase.Constructor<EXTSemaphoreFD>,
        EXTSemaphoreWin32: GLBase.Constructor<EXTSemaphoreWin32>,
        EXTSeparateShaderObjects: GLBase.Constructor<EXTSeparateShaderObjects>,
        EXTShaderFramebufferFetch: GLBase.Constructor<EXTShaderFramebufferFetch>,
        EXTShaderFramebufferFetchNonCoherent: GLBase.Constructor<EXTShaderFramebufferFetchNonCoherent>,
        EXTShaderImageLoadStore: GLBase.Constructor<EXTShaderImageLoadStore>,
        EXTSharedTexturePalette: GLBase.Constructor<EXTSharedTexturePalette>,
        EXTStencilClearTag: GLBase.Constructor<EXTStencilClearTag>,
        EXTTextureBufferObject: GLBase.Constructor<EXTTextureBufferObject>,
        EXTTextureCompressionLATC: GLBase.Constructor<EXTTextureCompressionLATC>,
        EXTTextureCompressionS3TC: GLBase.Constructor<EXTTextureCompressionS3TC>,
        EXTTextureFilterAnisotropic: GLBase.Constructor<EXTTextureFilterAnisotropic>,
        EXTTextureFilterMinmax: GLBase.Constructor<EXTTextureFilterMinmax>,
        EXTTextureMirrorClamp: GLBase.Constructor<EXTTextureMirrorClamp>,
        EXTTextureSRGBDecode: GLBase.Constructor<EXTTextureSRGBDecode>,
        EXTTextureSRGBR8: GLBase.Constructor<EXTTextureSRGBR8>,
        EXTTextureSRGBRG8: GLBase.Constructor<EXTTextureSRGBRG8>,
        EXTTextureSnorm: GLBase.Constructor<EXTTextureSnorm>,
        EXTTextureStorage: GLBase.Constructor<EXTTextureStorage>,
        EXTTextureSwizzle: GLBase.Constructor<EXTTextureSwizzle>,
        EXTTimerQuery: GLBase.Constructor<EXTTimerQuery>,
        EXTTransformFeedback: GLBase.Constructor<EXTTransformFeedback>,
        EXTVertexAttrib64bit: GLBase.Constructor<EXTVertexAttrib64bit>,
        EXTWin32KeyedMutex: GLBase.Constructor<EXTWin32KeyedMutex>,
        EXTWindowRectangles: GLBase.Constructor<EXTWindowRectangles>,
        EXTX11SyncObject: GLBase.Constructor<EXTX11SyncObject>,
        NVAlphaToCoverageDitherControl: GLBase.Constructor<NVAlphaToCoverageDitherControl>,
        NVBindlessMultiDrawIndirect: GLBase.Constructor<NVBindlessMultiDrawIndirect>,
        NVBindlessMultiDrawIndirectCount: GLBase.Constructor<NVBindlessMultiDrawIndirectCount>,
        NVBindlessTexture: GLBase.Constructor<NVBindlessTexture>,
        NVBlendEquationAdvanced: GLBase.Constructor<NVBlendEquationAdvanced>,
        NVBlendEquationAdvancedCoherent: GLBase.Constructor<NVBlendEquationAdvancedCoherent>,
        NVBlendMinmaxFactor: GLBase.Constructor<NVBlendMinmaxFactor>,
        NVClipSpaceWScaling: GLBase.Constructor<NVClipSpaceWScaling>,
        NVCommandList: GLBase.Constructor<NVCommandList>,
        NVConservativeRaster: GLBase.Constructor<NVConservativeRaster>,
        NVConservativeRasterDilate: GLBase.Constructor<NVConservativeRasterDilate>,
        NVConservativeRasterPreSnap: GLBase.Constructor<NVConservativeRasterPreSnap>,
        NVConservativeRasterPreSnapTriangles: GLBase.Constructor<NVConservativeRasterPreSnapTriangles>,
        NVCopyDepthToColor: GLBase.Constructor<NVCopyDepthToColor>,
        NVCopyImage: GLBase.Constructor<NVCopyImage>,
        NVDeepTexture3D: GLBase.Constructor<NVDeepTexture3D>,
        NVDepthBufferFloat: GLBase.Constructor<NVDepthBufferFloat>,
        NVDepthClamp: GLBase.Constructor<NVDepthClamp>,
        NVDrawTexture: GLBase.Constructor<NVDrawTexture>,
        NVDrawVulkanImage: GLBase.Constructor<NVDrawVulkanImage>,
        NVExplicitMultisample: GLBase.Constructor<NVExplicitMultisample>,
        NVFence: GLBase.Constructor<NVFence>,
        NVFillRectangle: GLBase.Constructor<NVFillRectangle>,
        NVFloatBuffer: GLBase.Constructor<NVFloatBuffer>,
        NVFogDistance: GLBase.Constructor<NVFogDistance>,
        NVFragmentCoverageToColor: GLBase.Constructor<NVFragmentCoverageToColor>,
        NVFramebufferMixedSamples: GLBase.Constructor<NVFramebufferMixedSamples>,
        NVFramebufferMultisampleCoverage: GLBase.Constructor<NVFramebufferMultisampleCoverage>,
        NVGPUMulticast: GLBase.Constructor<NVGPUMulticast>,
        NVGPUShader5: GLBase.Constructor<NVGPUShader5>,
        NVInternalformatSampleQuery: GLBase.Constructor<NVInternalformatSampleQuery>,
        NVLightMaxExponent: GLBase.Constructor<NVLightMaxExponent>,
        NVMemoryAttachment: GLBase.Constructor<NVMemoryAttachment>,
        NVMemoryObjectSparse: GLBase.Constructor<NVMemoryObjectSparse>,
        NVMeshShader: GLBase.Constructor<NVMeshShader>,
        NVMultisampleCoverage: GLBase.Constructor<NVMultisampleCoverage>,
        NVMultisampleFilterHint: GLBase.Constructor<NVMultisampleFilterHint>,
        NVPackedDepthStencil: GLBase.Constructor<NVPackedDepthStencil>,
        NVPathRendering: GLBase.Constructor<NVPathRendering>,
        NVPathRenderingSharedEdge: GLBase.Constructor<NVPathRenderingSharedEdge>,
        NVPixelDataRange: GLBase.Constructor<NVPixelDataRange>,
        NVPointSprite: GLBase.Constructor<NVPointSprite>,
        NVPrimitiveShadingRate: GLBase.Constructor<NVPrimitiveShadingRate>,
        NVQueryResource: GLBase.Constructor<NVQueryResource>,
        NVQueryResourceTag: GLBase.Constructor<NVQueryResourceTag>,
        NVRepresentativeFragmentTest: GLBase.Constructor<NVRepresentativeFragmentTest>,
        NVRobustnessVideoMemoryPurge: GLBase.Constructor<NVRobustnessVideoMemoryPurge>,
        NVSampleLocations: GLBase.Constructor<NVSampleLocations>,
        NVScissorExclusive: GLBase.Constructor<NVScissorExclusive>,
        NVShaderBufferLoad: GLBase.Constructor<NVShaderBufferLoad>,
        NVShaderBufferStore: GLBase.Constructor<NVShaderBufferStore>,
        NVShaderSubgroupPartitioned: GLBase.Constructor<NVShaderSubgroupPartitioned>,
        NVShaderThreadGroup: GLBase.Constructor<NVShaderThreadGroup>,
        NVShadingRateImage: GLBase.Constructor<NVShadingRateImage>,
        NVTexgenReflection: GLBase.Constructor<NVTexgenReflection>,
        NVTextureBarrier: GLBase.Constructor<NVTextureBarrier>,
        NVTextureMultisample: GLBase.Constructor<NVTextureMultisample>,
        NVTextureShader: GLBase.Constructor<NVTextureShader>,
        NVTextureShader2: GLBase.Constructor<NVTextureShader2>,
        NVTextureShader3: GLBase.Constructor<NVTextureShader3>,
        NVTimelineSemaphore: GLBase.Constructor<NVTimelineSemaphore>,
        NVTransformFeedback: GLBase.Constructor<NVTransformFeedback>,
        NVTransformFeedback2: GLBase.Constructor<NVTransformFeedback2>,
        NVUniformBufferUnifiedMemory: GLBase.Constructor<NVUniformBufferUnifiedMemory>,
        NVVertexArrayRange: GLBase.Constructor<NVVertexArrayRange>,
        NVVertexArrayRange2: GLBase.Constructor<NVVertexArrayRange2>,
        NVVertexAttribInteger64bit: GLBase.Constructor<NVVertexAttribInteger64bit>,
        NVVertexBufferUnifiedMemory: GLBase.Constructor<NVVertexBufferUnifiedMemory>,
        NVViewportSwizzle: GLBase.Constructor<NVViewportSwizzle>,
        AMDBlendMinmaxFactor: GLBase.Constructor<AMDBlendMinmaxFactor>,
        AMDDebugOutput: GLBase.Constructor<AMDDebugOutput>,
        AMDDepthClampSeparate: GLBase.Constructor<AMDDepthClampSeparate>,
        AMDDrawBuffersBlend: GLBase.Constructor<AMDDrawBuffersBlend>,
        AMDFramebufferMultisampleAdvanced: GLBase.Constructor<AMDFramebufferMultisampleAdvanced>,
        AMDGPUShaderHalfFloat: GLBase.Constructor<AMDGPUShaderHalfFloat>,
        AMDGPUShaderHalfFloatFetch: GLBase.Constructor<AMDGPUShaderHalfFloatFetch>,
        AMDGPUShaderInt64: GLBase.Constructor<AMDGPUShaderInt64>,
        AMDInterleavedElements: GLBase.Constructor<AMDInterleavedElements>,
        AMDOcclusionQueryEvent: GLBase.Constructor<AMDOcclusionQueryEvent>,
        AMDPerformanceMonitor: GLBase.Constructor<AMDPerformanceMonitor>,
        AMDPinnedMemory: GLBase.Constructor<AMDPinnedMemory>,
        AMDQueryBufferObject: GLBase.Constructor<AMDQueryBufferObject>,
        AMDSamplePositions: GLBase.Constructor<AMDSamplePositions>,
        AMDSeamlessCubemapPerTexture: GLBase.Constructor<AMDSeamlessCubemapPerTexture>,
        AMDSparseTexture: GLBase.Constructor<AMDSparseTexture>,
        AMDStencilOperationExtended: GLBase.Constructor<AMDStencilOperationExtended>,
        AMDTransformFeedback4: GLBase.Constructor<AMDTransformFeedback4>,
        AMDVertexShaderTessellator: GLBase.Constructor<AMDVertexShaderTessellator>,
    ) {
        this.properties = WrapperProperties(this)
        this.GL11 = GL11(this)
        this.GL12 = GL12(this)
        this.GL13 = GL13(this)
        this.GL14 = GL14(this)
        this.GL15 = GL15(this)
        this.GL20 = GL20(this)
        this.GL21 = GL21(this)
        this.GL30 = GL30(this)
        this.GL31 = GL31(this)
        this.GL32 = GL32(this)
        this.GL33 = GL33(this)
        this.GL40 = GL40(this)
        this.GL41 = GL41(this)
        this.GL42 = GL42(this)
        this.GL43 = GL43(this)
        this.GL44 = GL44(this)
        this.GL45 = GL45(this)
        this.GL46 = GL46(this)
        this.KHRBlendEquationAdvanced = KHRBlendEquationAdvanced(this)
        this.KHRBlendEquationAdvancedCoherent = KHRBlendEquationAdvancedCoherent(this)
        this.KHRContextFlushControl = KHRContextFlushControl(this)
        this.KHRParallelShaderCompile = KHRParallelShaderCompile(this)
        this.KHRShaderSubgroup = KHRShaderSubgroup(this)
        this.KHRTextureCompressionASTCLDR = KHRTextureCompressionASTCLDR(this)
        this.ARBBindlessTexture = ARBBindlessTexture(this)
        this.ARBCLEvent = ARBCLEvent(this)
        this.ARBComputeVariableGroupSize = ARBComputeVariableGroupSize(this)
        this.ARBDebugOutput = ARBDebugOutput(this)
        this.ARBDepthBufferFloat = ARBDepthBufferFloat(this)
        this.ARBES32Compatibility = ARBES32Compatibility(this)
        this.ARBFragmentProgram = ARBFragmentProgram(this)
        this.ARBFramebufferSRGB = ARBFramebufferSRGB(this)
        this.ARBGPUShaderInt64 = ARBGPUShaderInt64(this)
        this.ARBHalfFloatPixel = ARBHalfFloatPixel(this)
        this.ARBHalfFloatVertex = ARBHalfFloatVertex(this)
        this.ARBImaging = ARBImaging(this)
        this.ARBMapBufferRange = ARBMapBufferRange(this)
        this.ARBMatrixPalette = ARBMatrixPalette(this)
        this.ARBParallelShaderCompile = ARBParallelShaderCompile(this)
        this.ARBRobustness = ARBRobustness(this)
        this.ARBSampleLocations = ARBSampleLocations(this)
        this.ARBSeamlessCubemapPerTexture = ARBSeamlessCubemapPerTexture(this)
        this.ARBShadingLanguageInclude = ARBShadingLanguageInclude(this)
        this.ARBShadowAmbient = ARBShadowAmbient(this)
        this.ARBSparseBuffer = ARBSparseBuffer(this)
        this.ARBSparseTexture = ARBSparseTexture(this)
        this.ARBTextureCompressionRGTC = ARBTextureCompressionRGTC(this)
        this.ARBTextureFilterMinmax = ARBTextureFilterMinmax(this)
        this.ARBTextureRG = ARBTextureRG(this)
        this.ARBVertexBlend = ARBVertexBlend(this)
        this.ARBVertexProgram = ARBVertexProgram(this)
        this.EXT422Pixels = EXT422Pixels(this)
        this.EXTABGR = EXTABGR(this)
        this.EXTBindableUniform = EXTBindableUniform(this)
        this.EXTBlendEquationSeparate = EXTBlendEquationSeparate(this)
        this.EXTClipVolumeHint = EXTClipVolumeHint(this)
        this.EXTCompiledVertexArray = EXTCompiledVertexArray(this)
        this.EXTDebugLabel = EXTDebugLabel(this)
        this.EXTDebugMarker = EXTDebugMarker(this)
        this.EXTDepthBoundsTest = EXTDepthBoundsTest(this)
        this.EXTDirectStateAccess = EXTDirectStateAccess(this)
        this.EXTDrawInstanced = EXTDrawInstanced(this)
        this.EXTEGLImageStorage = EXTEGLImageStorage(this)
        this.EXTExternalBuffer = EXTExternalBuffer(this)
        this.EXTFramebufferBlit = EXTFramebufferBlit(this)
        this.EXTFramebufferBlitLayers = EXTFramebufferBlitLayers(this)
        this.EXTFramebufferMultisample = EXTFramebufferMultisample(this)
        this.EXTFramebufferMultisampleBlitScaled = EXTFramebufferMultisampleBlitScaled(this)
        this.EXTFramebufferObject = EXTFramebufferObject(this)
        this.EXTGPUProgramParameters = EXTGPUProgramParameters(this)
        this.EXTGPUShader4 = EXTGPUShader4(this)
        this.EXTGeometryShader4 = EXTGeometryShader4(this)
        this.EXTMemoryObject = EXTMemoryObject(this)
        this.EXTMemoryObjectFD = EXTMemoryObjectFD(this)
        this.EXTMemoryObjectWin32 = EXTMemoryObjectWin32(this)
        this.EXTPackedDepthStencil = EXTPackedDepthStencil(this)
        this.EXTPixelBufferObject = EXTPixelBufferObject(this)
        this.EXTPointParameters = EXTPointParameters(this)
        this.EXTPolygonOffsetClamp = EXTPolygonOffsetClamp(this)
        this.EXTProvokingVertex = EXTProvokingVertex(this)
        this.EXTRasterMultisample = EXTRasterMultisample(this)
        this.EXTSemaphore = EXTSemaphore(this)
        this.EXTSemaphoreFD = EXTSemaphoreFD(this)
        this.EXTSemaphoreWin32 = EXTSemaphoreWin32(this)
        this.EXTSeparateShaderObjects = EXTSeparateShaderObjects(this)
        this.EXTShaderFramebufferFetch = EXTShaderFramebufferFetch(this)
        this.EXTShaderFramebufferFetchNonCoherent = EXTShaderFramebufferFetchNonCoherent(this)
        this.EXTShaderImageLoadStore = EXTShaderImageLoadStore(this)
        this.EXTSharedTexturePalette = EXTSharedTexturePalette(this)
        this.EXTStencilClearTag = EXTStencilClearTag(this)
        this.EXTTextureBufferObject = EXTTextureBufferObject(this)
        this.EXTTextureCompressionLATC = EXTTextureCompressionLATC(this)
        this.EXTTextureCompressionS3TC = EXTTextureCompressionS3TC(this)
        this.EXTTextureFilterAnisotropic = EXTTextureFilterAnisotropic(this)
        this.EXTTextureFilterMinmax = EXTTextureFilterMinmax(this)
        this.EXTTextureMirrorClamp = EXTTextureMirrorClamp(this)
        this.EXTTextureSRGBDecode = EXTTextureSRGBDecode(this)
        this.EXTTextureSRGBR8 = EXTTextureSRGBR8(this)
        this.EXTTextureSRGBRG8 = EXTTextureSRGBRG8(this)
        this.EXTTextureSnorm = EXTTextureSnorm(this)
        this.EXTTextureStorage = EXTTextureStorage(this)
        this.EXTTextureSwizzle = EXTTextureSwizzle(this)
        this.EXTTimerQuery = EXTTimerQuery(this)
        this.EXTTransformFeedback = EXTTransformFeedback(this)
        this.EXTVertexAttrib64bit = EXTVertexAttrib64bit(this)
        this.EXTWin32KeyedMutex = EXTWin32KeyedMutex(this)
        this.EXTWindowRectangles = EXTWindowRectangles(this)
        this.EXTX11SyncObject = EXTX11SyncObject(this)
        this.NVAlphaToCoverageDitherControl = NVAlphaToCoverageDitherControl(this)
        this.NVBindlessMultiDrawIndirect = NVBindlessMultiDrawIndirect(this)
        this.NVBindlessMultiDrawIndirectCount = NVBindlessMultiDrawIndirectCount(this)
        this.NVBindlessTexture = NVBindlessTexture(this)
        this.NVBlendEquationAdvanced = NVBlendEquationAdvanced(this)
        this.NVBlendEquationAdvancedCoherent = NVBlendEquationAdvancedCoherent(this)
        this.NVBlendMinmaxFactor = NVBlendMinmaxFactor(this)
        this.NVClipSpaceWScaling = NVClipSpaceWScaling(this)
        this.NVCommandList = NVCommandList(this)
        this.NVConservativeRaster = NVConservativeRaster(this)
        this.NVConservativeRasterDilate = NVConservativeRasterDilate(this)
        this.NVConservativeRasterPreSnap = NVConservativeRasterPreSnap(this)
        this.NVConservativeRasterPreSnapTriangles = NVConservativeRasterPreSnapTriangles(this)
        this.NVCopyDepthToColor = NVCopyDepthToColor(this)
        this.NVCopyImage = NVCopyImage(this)
        this.NVDeepTexture3D = NVDeepTexture3D(this)
        this.NVDepthBufferFloat = NVDepthBufferFloat(this)
        this.NVDepthClamp = NVDepthClamp(this)
        this.NVDrawTexture = NVDrawTexture(this)
        this.NVDrawVulkanImage = NVDrawVulkanImage(this)
        this.NVExplicitMultisample = NVExplicitMultisample(this)
        this.NVFence = NVFence(this)
        this.NVFillRectangle = NVFillRectangle(this)
        this.NVFloatBuffer = NVFloatBuffer(this)
        this.NVFogDistance = NVFogDistance(this)
        this.NVFragmentCoverageToColor = NVFragmentCoverageToColor(this)
        this.NVFramebufferMixedSamples = NVFramebufferMixedSamples(this)
        this.NVFramebufferMultisampleCoverage = NVFramebufferMultisampleCoverage(this)
        this.NVGPUMulticast = NVGPUMulticast(this)
        this.NVGPUShader5 = NVGPUShader5(this)
        this.NVInternalformatSampleQuery = NVInternalformatSampleQuery(this)
        this.NVLightMaxExponent = NVLightMaxExponent(this)
        this.NVMemoryAttachment = NVMemoryAttachment(this)
        this.NVMemoryObjectSparse = NVMemoryObjectSparse(this)
        this.NVMeshShader = NVMeshShader(this)
        this.NVMultisampleCoverage = NVMultisampleCoverage(this)
        this.NVMultisampleFilterHint = NVMultisampleFilterHint(this)
        this.NVPackedDepthStencil = NVPackedDepthStencil(this)
        this.NVPathRendering = NVPathRendering(this)
        this.NVPathRenderingSharedEdge = NVPathRenderingSharedEdge(this)
        this.NVPixelDataRange = NVPixelDataRange(this)
        this.NVPointSprite = NVPointSprite(this)
        this.NVPrimitiveShadingRate = NVPrimitiveShadingRate(this)
        this.NVQueryResource = NVQueryResource(this)
        this.NVQueryResourceTag = NVQueryResourceTag(this)
        this.NVRepresentativeFragmentTest = NVRepresentativeFragmentTest(this)
        this.NVRobustnessVideoMemoryPurge = NVRobustnessVideoMemoryPurge(this)
        this.NVSampleLocations = NVSampleLocations(this)
        this.NVScissorExclusive = NVScissorExclusive(this)
        this.NVShaderBufferLoad = NVShaderBufferLoad(this)
        this.NVShaderBufferStore = NVShaderBufferStore(this)
        this.NVShaderSubgroupPartitioned = NVShaderSubgroupPartitioned(this)
        this.NVShaderThreadGroup = NVShaderThreadGroup(this)
        this.NVShadingRateImage = NVShadingRateImage(this)
        this.NVTexgenReflection = NVTexgenReflection(this)
        this.NVTextureBarrier = NVTextureBarrier(this)
        this.NVTextureMultisample = NVTextureMultisample(this)
        this.NVTextureShader = NVTextureShader(this)
        this.NVTextureShader2 = NVTextureShader2(this)
        this.NVTextureShader3 = NVTextureShader3(this)
        this.NVTimelineSemaphore = NVTimelineSemaphore(this)
        this.NVTransformFeedback = NVTransformFeedback(this)
        this.NVTransformFeedback2 = NVTransformFeedback2(this)
        this.NVUniformBufferUnifiedMemory = NVUniformBufferUnifiedMemory(this)
        this.NVVertexArrayRange = NVVertexArrayRange(this)
        this.NVVertexArrayRange2 = NVVertexArrayRange2(this)
        this.NVVertexAttribInteger64bit = NVVertexAttribInteger64bit(this)
        this.NVVertexBufferUnifiedMemory = NVVertexBufferUnifiedMemory(this)
        this.NVViewportSwizzle = NVViewportSwizzle(this)
        this.AMDBlendMinmaxFactor = AMDBlendMinmaxFactor(this)
        this.AMDDebugOutput = AMDDebugOutput(this)
        this.AMDDepthClampSeparate = AMDDepthClampSeparate(this)
        this.AMDDrawBuffersBlend = AMDDrawBuffersBlend(this)
        this.AMDFramebufferMultisampleAdvanced = AMDFramebufferMultisampleAdvanced(this)
        this.AMDGPUShaderHalfFloat = AMDGPUShaderHalfFloat(this)
        this.AMDGPUShaderHalfFloatFetch = AMDGPUShaderHalfFloatFetch(this)
        this.AMDGPUShaderInt64 = AMDGPUShaderInt64(this)
        this.AMDInterleavedElements = AMDInterleavedElements(this)
        this.AMDOcclusionQueryEvent = AMDOcclusionQueryEvent(this)
        this.AMDPerformanceMonitor = AMDPerformanceMonitor(this)
        this.AMDPinnedMemory = AMDPinnedMemory(this)
        this.AMDQueryBufferObject = AMDQueryBufferObject(this)
        this.AMDSamplePositions = AMDSamplePositions(this)
        this.AMDSeamlessCubemapPerTexture = AMDSeamlessCubemapPerTexture(this)
        this.AMDSparseTexture = AMDSparseTexture(this)
        this.AMDStencilOperationExtended = AMDStencilOperationExtended(this)
        this.AMDTransformFeedback4 = AMDTransformFeedback4(this)
        this.AMDVertexShaderTessellator = AMDVertexShaderTessellator(this)
    }

    public constructor(
        `delegate`: GLWrapper,
        GL11: GL11 = `delegate`.GL11,
        GL12: GL12 = `delegate`.GL12,
        GL13: GL13 = `delegate`.GL13,
        GL14: GL14 = `delegate`.GL14,
        GL15: GL15 = `delegate`.GL15,
        GL20: GL20 = `delegate`.GL20,
        GL21: GL21 = `delegate`.GL21,
        GL30: GL30 = `delegate`.GL30,
        GL31: GL31 = `delegate`.GL31,
        GL32: GL32 = `delegate`.GL32,
        GL33: GL33 = `delegate`.GL33,
        GL40: GL40 = `delegate`.GL40,
        GL41: GL41 = `delegate`.GL41,
        GL42: GL42 = `delegate`.GL42,
        GL43: GL43 = `delegate`.GL43,
        GL44: GL44 = `delegate`.GL44,
        GL45: GL45 = `delegate`.GL45,
        GL46: GL46 = `delegate`.GL46,
        KHRBlendEquationAdvanced: KHRBlendEquationAdvanced = `delegate`.KHRBlendEquationAdvanced,
        KHRBlendEquationAdvancedCoherent: KHRBlendEquationAdvancedCoherent =
                `delegate`.KHRBlendEquationAdvancedCoherent,
        KHRContextFlushControl: KHRContextFlushControl = `delegate`.KHRContextFlushControl,
        KHRParallelShaderCompile: KHRParallelShaderCompile = `delegate`.KHRParallelShaderCompile,
        KHRShaderSubgroup: KHRShaderSubgroup = `delegate`.KHRShaderSubgroup,
        KHRTextureCompressionASTCLDR: KHRTextureCompressionASTCLDR =
                `delegate`.KHRTextureCompressionASTCLDR,
        ARBBindlessTexture: ARBBindlessTexture = `delegate`.ARBBindlessTexture,
        ARBCLEvent: ARBCLEvent = `delegate`.ARBCLEvent,
        ARBComputeVariableGroupSize: ARBComputeVariableGroupSize =
                `delegate`.ARBComputeVariableGroupSize,
        ARBDebugOutput: ARBDebugOutput = `delegate`.ARBDebugOutput,
        ARBDepthBufferFloat: ARBDepthBufferFloat = `delegate`.ARBDepthBufferFloat,
        ARBES32Compatibility: ARBES32Compatibility = `delegate`.ARBES32Compatibility,
        ARBFragmentProgram: ARBFragmentProgram = `delegate`.ARBFragmentProgram,
        ARBFramebufferSRGB: ARBFramebufferSRGB = `delegate`.ARBFramebufferSRGB,
        ARBGPUShaderInt64: ARBGPUShaderInt64 = `delegate`.ARBGPUShaderInt64,
        ARBHalfFloatPixel: ARBHalfFloatPixel = `delegate`.ARBHalfFloatPixel,
        ARBHalfFloatVertex: ARBHalfFloatVertex = `delegate`.ARBHalfFloatVertex,
        ARBImaging: ARBImaging = `delegate`.ARBImaging,
        ARBMapBufferRange: ARBMapBufferRange = `delegate`.ARBMapBufferRange,
        ARBMatrixPalette: ARBMatrixPalette = `delegate`.ARBMatrixPalette,
        ARBParallelShaderCompile: ARBParallelShaderCompile = `delegate`.ARBParallelShaderCompile,
        ARBRobustness: ARBRobustness = `delegate`.ARBRobustness,
        ARBSampleLocations: ARBSampleLocations = `delegate`.ARBSampleLocations,
        ARBSeamlessCubemapPerTexture: ARBSeamlessCubemapPerTexture =
                `delegate`.ARBSeamlessCubemapPerTexture,
        ARBShadingLanguageInclude: ARBShadingLanguageInclude = `delegate`.ARBShadingLanguageInclude,
        ARBShadowAmbient: ARBShadowAmbient = `delegate`.ARBShadowAmbient,
        ARBSparseBuffer: ARBSparseBuffer = `delegate`.ARBSparseBuffer,
        ARBSparseTexture: ARBSparseTexture = `delegate`.ARBSparseTexture,
        ARBTextureCompressionRGTC: ARBTextureCompressionRGTC = `delegate`.ARBTextureCompressionRGTC,
        ARBTextureFilterMinmax: ARBTextureFilterMinmax = `delegate`.ARBTextureFilterMinmax,
        ARBTextureRG: ARBTextureRG = `delegate`.ARBTextureRG,
        ARBVertexBlend: ARBVertexBlend = `delegate`.ARBVertexBlend,
        ARBVertexProgram: ARBVertexProgram = `delegate`.ARBVertexProgram,
        EXT422Pixels: EXT422Pixels = `delegate`.EXT422Pixels,
        EXTABGR: EXTABGR = `delegate`.EXTABGR,
        EXTBindableUniform: EXTBindableUniform = `delegate`.EXTBindableUniform,
        EXTBlendEquationSeparate: EXTBlendEquationSeparate = `delegate`.EXTBlendEquationSeparate,
        EXTClipVolumeHint: EXTClipVolumeHint = `delegate`.EXTClipVolumeHint,
        EXTCompiledVertexArray: EXTCompiledVertexArray = `delegate`.EXTCompiledVertexArray,
        EXTDebugLabel: EXTDebugLabel = `delegate`.EXTDebugLabel,
        EXTDebugMarker: EXTDebugMarker = `delegate`.EXTDebugMarker,
        EXTDepthBoundsTest: EXTDepthBoundsTest = `delegate`.EXTDepthBoundsTest,
        EXTDirectStateAccess: EXTDirectStateAccess = `delegate`.EXTDirectStateAccess,
        EXTDrawInstanced: EXTDrawInstanced = `delegate`.EXTDrawInstanced,
        EXTEGLImageStorage: EXTEGLImageStorage = `delegate`.EXTEGLImageStorage,
        EXTExternalBuffer: EXTExternalBuffer = `delegate`.EXTExternalBuffer,
        EXTFramebufferBlit: EXTFramebufferBlit = `delegate`.EXTFramebufferBlit,
        EXTFramebufferBlitLayers: EXTFramebufferBlitLayers = `delegate`.EXTFramebufferBlitLayers,
        EXTFramebufferMultisample: EXTFramebufferMultisample = `delegate`.EXTFramebufferMultisample,
        EXTFramebufferMultisampleBlitScaled: EXTFramebufferMultisampleBlitScaled =
                `delegate`.EXTFramebufferMultisampleBlitScaled,
        EXTFramebufferObject: EXTFramebufferObject = `delegate`.EXTFramebufferObject,
        EXTGPUProgramParameters: EXTGPUProgramParameters = `delegate`.EXTGPUProgramParameters,
        EXTGPUShader4: EXTGPUShader4 = `delegate`.EXTGPUShader4,
        EXTGeometryShader4: EXTGeometryShader4 = `delegate`.EXTGeometryShader4,
        EXTMemoryObject: EXTMemoryObject = `delegate`.EXTMemoryObject,
        EXTMemoryObjectFD: EXTMemoryObjectFD = `delegate`.EXTMemoryObjectFD,
        EXTMemoryObjectWin32: EXTMemoryObjectWin32 = `delegate`.EXTMemoryObjectWin32,
        EXTPackedDepthStencil: EXTPackedDepthStencil = `delegate`.EXTPackedDepthStencil,
        EXTPixelBufferObject: EXTPixelBufferObject = `delegate`.EXTPixelBufferObject,
        EXTPointParameters: EXTPointParameters = `delegate`.EXTPointParameters,
        EXTPolygonOffsetClamp: EXTPolygonOffsetClamp = `delegate`.EXTPolygonOffsetClamp,
        EXTProvokingVertex: EXTProvokingVertex = `delegate`.EXTProvokingVertex,
        EXTRasterMultisample: EXTRasterMultisample = `delegate`.EXTRasterMultisample,
        EXTSemaphore: EXTSemaphore = `delegate`.EXTSemaphore,
        EXTSemaphoreFD: EXTSemaphoreFD = `delegate`.EXTSemaphoreFD,
        EXTSemaphoreWin32: EXTSemaphoreWin32 = `delegate`.EXTSemaphoreWin32,
        EXTSeparateShaderObjects: EXTSeparateShaderObjects = `delegate`.EXTSeparateShaderObjects,
        EXTShaderFramebufferFetch: EXTShaderFramebufferFetch = `delegate`.EXTShaderFramebufferFetch,
        EXTShaderFramebufferFetchNonCoherent: EXTShaderFramebufferFetchNonCoherent =
                `delegate`.EXTShaderFramebufferFetchNonCoherent,
        EXTShaderImageLoadStore: EXTShaderImageLoadStore = `delegate`.EXTShaderImageLoadStore,
        EXTSharedTexturePalette: EXTSharedTexturePalette = `delegate`.EXTSharedTexturePalette,
        EXTStencilClearTag: EXTStencilClearTag = `delegate`.EXTStencilClearTag,
        EXTTextureBufferObject: EXTTextureBufferObject = `delegate`.EXTTextureBufferObject,
        EXTTextureCompressionLATC: EXTTextureCompressionLATC = `delegate`.EXTTextureCompressionLATC,
        EXTTextureCompressionS3TC: EXTTextureCompressionS3TC = `delegate`.EXTTextureCompressionS3TC,
        EXTTextureFilterAnisotropic: EXTTextureFilterAnisotropic =
                `delegate`.EXTTextureFilterAnisotropic,
        EXTTextureFilterMinmax: EXTTextureFilterMinmax = `delegate`.EXTTextureFilterMinmax,
        EXTTextureMirrorClamp: EXTTextureMirrorClamp = `delegate`.EXTTextureMirrorClamp,
        EXTTextureSRGBDecode: EXTTextureSRGBDecode = `delegate`.EXTTextureSRGBDecode,
        EXTTextureSRGBR8: EXTTextureSRGBR8 = `delegate`.EXTTextureSRGBR8,
        EXTTextureSRGBRG8: EXTTextureSRGBRG8 = `delegate`.EXTTextureSRGBRG8,
        EXTTextureSnorm: EXTTextureSnorm = `delegate`.EXTTextureSnorm,
        EXTTextureStorage: EXTTextureStorage = `delegate`.EXTTextureStorage,
        EXTTextureSwizzle: EXTTextureSwizzle = `delegate`.EXTTextureSwizzle,
        EXTTimerQuery: EXTTimerQuery = `delegate`.EXTTimerQuery,
        EXTTransformFeedback: EXTTransformFeedback = `delegate`.EXTTransformFeedback,
        EXTVertexAttrib64bit: EXTVertexAttrib64bit = `delegate`.EXTVertexAttrib64bit,
        EXTWin32KeyedMutex: EXTWin32KeyedMutex = `delegate`.EXTWin32KeyedMutex,
        EXTWindowRectangles: EXTWindowRectangles = `delegate`.EXTWindowRectangles,
        EXTX11SyncObject: EXTX11SyncObject = `delegate`.EXTX11SyncObject,
        NVAlphaToCoverageDitherControl: NVAlphaToCoverageDitherControl =
                `delegate`.NVAlphaToCoverageDitherControl,
        NVBindlessMultiDrawIndirect: NVBindlessMultiDrawIndirect =
                `delegate`.NVBindlessMultiDrawIndirect,
        NVBindlessMultiDrawIndirectCount: NVBindlessMultiDrawIndirectCount =
                `delegate`.NVBindlessMultiDrawIndirectCount,
        NVBindlessTexture: NVBindlessTexture = `delegate`.NVBindlessTexture,
        NVBlendEquationAdvanced: NVBlendEquationAdvanced = `delegate`.NVBlendEquationAdvanced,
        NVBlendEquationAdvancedCoherent: NVBlendEquationAdvancedCoherent =
                `delegate`.NVBlendEquationAdvancedCoherent,
        NVBlendMinmaxFactor: NVBlendMinmaxFactor = `delegate`.NVBlendMinmaxFactor,
        NVClipSpaceWScaling: NVClipSpaceWScaling = `delegate`.NVClipSpaceWScaling,
        NVCommandList: NVCommandList = `delegate`.NVCommandList,
        NVConservativeRaster: NVConservativeRaster = `delegate`.NVConservativeRaster,
        NVConservativeRasterDilate: NVConservativeRasterDilate =
                `delegate`.NVConservativeRasterDilate,
        NVConservativeRasterPreSnap: NVConservativeRasterPreSnap =
                `delegate`.NVConservativeRasterPreSnap,
        NVConservativeRasterPreSnapTriangles: NVConservativeRasterPreSnapTriangles =
                `delegate`.NVConservativeRasterPreSnapTriangles,
        NVCopyDepthToColor: NVCopyDepthToColor = `delegate`.NVCopyDepthToColor,
        NVCopyImage: NVCopyImage = `delegate`.NVCopyImage,
        NVDeepTexture3D: NVDeepTexture3D = `delegate`.NVDeepTexture3D,
        NVDepthBufferFloat: NVDepthBufferFloat = `delegate`.NVDepthBufferFloat,
        NVDepthClamp: NVDepthClamp = `delegate`.NVDepthClamp,
        NVDrawTexture: NVDrawTexture = `delegate`.NVDrawTexture,
        NVDrawVulkanImage: NVDrawVulkanImage = `delegate`.NVDrawVulkanImage,
        NVExplicitMultisample: NVExplicitMultisample = `delegate`.NVExplicitMultisample,
        NVFence: NVFence = `delegate`.NVFence,
        NVFillRectangle: NVFillRectangle = `delegate`.NVFillRectangle,
        NVFloatBuffer: NVFloatBuffer = `delegate`.NVFloatBuffer,
        NVFogDistance: NVFogDistance = `delegate`.NVFogDistance,
        NVFragmentCoverageToColor: NVFragmentCoverageToColor = `delegate`.NVFragmentCoverageToColor,
        NVFramebufferMixedSamples: NVFramebufferMixedSamples = `delegate`.NVFramebufferMixedSamples,
        NVFramebufferMultisampleCoverage: NVFramebufferMultisampleCoverage =
                `delegate`.NVFramebufferMultisampleCoverage,
        NVGPUMulticast: NVGPUMulticast = `delegate`.NVGPUMulticast,
        NVGPUShader5: NVGPUShader5 = `delegate`.NVGPUShader5,
        NVInternalformatSampleQuery: NVInternalformatSampleQuery =
                `delegate`.NVInternalformatSampleQuery,
        NVLightMaxExponent: NVLightMaxExponent = `delegate`.NVLightMaxExponent,
        NVMemoryAttachment: NVMemoryAttachment = `delegate`.NVMemoryAttachment,
        NVMemoryObjectSparse: NVMemoryObjectSparse = `delegate`.NVMemoryObjectSparse,
        NVMeshShader: NVMeshShader = `delegate`.NVMeshShader,
        NVMultisampleCoverage: NVMultisampleCoverage = `delegate`.NVMultisampleCoverage,
        NVMultisampleFilterHint: NVMultisampleFilterHint = `delegate`.NVMultisampleFilterHint,
        NVPackedDepthStencil: NVPackedDepthStencil = `delegate`.NVPackedDepthStencil,
        NVPathRendering: NVPathRendering = `delegate`.NVPathRendering,
        NVPathRenderingSharedEdge: NVPathRenderingSharedEdge = `delegate`.NVPathRenderingSharedEdge,
        NVPixelDataRange: NVPixelDataRange = `delegate`.NVPixelDataRange,
        NVPointSprite: NVPointSprite = `delegate`.NVPointSprite,
        NVPrimitiveShadingRate: NVPrimitiveShadingRate = `delegate`.NVPrimitiveShadingRate,
        NVQueryResource: NVQueryResource = `delegate`.NVQueryResource,
        NVQueryResourceTag: NVQueryResourceTag = `delegate`.NVQueryResourceTag,
        NVRepresentativeFragmentTest: NVRepresentativeFragmentTest =
                `delegate`.NVRepresentativeFragmentTest,
        NVRobustnessVideoMemoryPurge: NVRobustnessVideoMemoryPurge =
                `delegate`.NVRobustnessVideoMemoryPurge,
        NVSampleLocations: NVSampleLocations = `delegate`.NVSampleLocations,
        NVScissorExclusive: NVScissorExclusive = `delegate`.NVScissorExclusive,
        NVShaderBufferLoad: NVShaderBufferLoad = `delegate`.NVShaderBufferLoad,
        NVShaderBufferStore: NVShaderBufferStore = `delegate`.NVShaderBufferStore,
        NVShaderSubgroupPartitioned: NVShaderSubgroupPartitioned =
                `delegate`.NVShaderSubgroupPartitioned,
        NVShaderThreadGroup: NVShaderThreadGroup = `delegate`.NVShaderThreadGroup,
        NVShadingRateImage: NVShadingRateImage = `delegate`.NVShadingRateImage,
        NVTexgenReflection: NVTexgenReflection = `delegate`.NVTexgenReflection,
        NVTextureBarrier: NVTextureBarrier = `delegate`.NVTextureBarrier,
        NVTextureMultisample: NVTextureMultisample = `delegate`.NVTextureMultisample,
        NVTextureShader: NVTextureShader = `delegate`.NVTextureShader,
        NVTextureShader2: NVTextureShader2 = `delegate`.NVTextureShader2,
        NVTextureShader3: NVTextureShader3 = `delegate`.NVTextureShader3,
        NVTimelineSemaphore: NVTimelineSemaphore = `delegate`.NVTimelineSemaphore,
        NVTransformFeedback: NVTransformFeedback = `delegate`.NVTransformFeedback,
        NVTransformFeedback2: NVTransformFeedback2 = `delegate`.NVTransformFeedback2,
        NVUniformBufferUnifiedMemory: NVUniformBufferUnifiedMemory =
                `delegate`.NVUniformBufferUnifiedMemory,
        NVVertexArrayRange: NVVertexArrayRange = `delegate`.NVVertexArrayRange,
        NVVertexArrayRange2: NVVertexArrayRange2 = `delegate`.NVVertexArrayRange2,
        NVVertexAttribInteger64bit: NVVertexAttribInteger64bit =
                `delegate`.NVVertexAttribInteger64bit,
        NVVertexBufferUnifiedMemory: NVVertexBufferUnifiedMemory =
                `delegate`.NVVertexBufferUnifiedMemory,
        NVViewportSwizzle: NVViewportSwizzle = `delegate`.NVViewportSwizzle,
        AMDBlendMinmaxFactor: AMDBlendMinmaxFactor = `delegate`.AMDBlendMinmaxFactor,
        AMDDebugOutput: AMDDebugOutput = `delegate`.AMDDebugOutput,
        AMDDepthClampSeparate: AMDDepthClampSeparate = `delegate`.AMDDepthClampSeparate,
        AMDDrawBuffersBlend: AMDDrawBuffersBlend = `delegate`.AMDDrawBuffersBlend,
        AMDFramebufferMultisampleAdvanced: AMDFramebufferMultisampleAdvanced =
                `delegate`.AMDFramebufferMultisampleAdvanced,
        AMDGPUShaderHalfFloat: AMDGPUShaderHalfFloat = `delegate`.AMDGPUShaderHalfFloat,
        AMDGPUShaderHalfFloatFetch: AMDGPUShaderHalfFloatFetch =
                `delegate`.AMDGPUShaderHalfFloatFetch,
        AMDGPUShaderInt64: AMDGPUShaderInt64 = `delegate`.AMDGPUShaderInt64,
        AMDInterleavedElements: AMDInterleavedElements = `delegate`.AMDInterleavedElements,
        AMDOcclusionQueryEvent: AMDOcclusionQueryEvent = `delegate`.AMDOcclusionQueryEvent,
        AMDPerformanceMonitor: AMDPerformanceMonitor = `delegate`.AMDPerformanceMonitor,
        AMDPinnedMemory: AMDPinnedMemory = `delegate`.AMDPinnedMemory,
        AMDQueryBufferObject: AMDQueryBufferObject = `delegate`.AMDQueryBufferObject,
        AMDSamplePositions: AMDSamplePositions = `delegate`.AMDSamplePositions,
        AMDSeamlessCubemapPerTexture: AMDSeamlessCubemapPerTexture =
                `delegate`.AMDSeamlessCubemapPerTexture,
        AMDSparseTexture: AMDSparseTexture = `delegate`.AMDSparseTexture,
        AMDStencilOperationExtended: AMDStencilOperationExtended =
                `delegate`.AMDStencilOperationExtended,
        AMDTransformFeedback4: AMDTransformFeedback4 = `delegate`.AMDTransformFeedback4,
        AMDVertexShaderTessellator: AMDVertexShaderTessellator =
                `delegate`.AMDVertexShaderTessellator,
    ) {
        this.properties = `delegate`.properties
        this.GL11 = GL11
        this.GL12 = GL12
        this.GL13 = GL13
        this.GL14 = GL14
        this.GL15 = GL15
        this.GL20 = GL20
        this.GL21 = GL21
        this.GL30 = GL30
        this.GL31 = GL31
        this.GL32 = GL32
        this.GL33 = GL33
        this.GL40 = GL40
        this.GL41 = GL41
        this.GL42 = GL42
        this.GL43 = GL43
        this.GL44 = GL44
        this.GL45 = GL45
        this.GL46 = GL46
        this.KHRBlendEquationAdvanced = KHRBlendEquationAdvanced
        this.KHRBlendEquationAdvancedCoherent = KHRBlendEquationAdvancedCoherent
        this.KHRContextFlushControl = KHRContextFlushControl
        this.KHRParallelShaderCompile = KHRParallelShaderCompile
        this.KHRShaderSubgroup = KHRShaderSubgroup
        this.KHRTextureCompressionASTCLDR = KHRTextureCompressionASTCLDR
        this.ARBBindlessTexture = ARBBindlessTexture
        this.ARBCLEvent = ARBCLEvent
        this.ARBComputeVariableGroupSize = ARBComputeVariableGroupSize
        this.ARBDebugOutput = ARBDebugOutput
        this.ARBDepthBufferFloat = ARBDepthBufferFloat
        this.ARBES32Compatibility = ARBES32Compatibility
        this.ARBFragmentProgram = ARBFragmentProgram
        this.ARBFramebufferSRGB = ARBFramebufferSRGB
        this.ARBGPUShaderInt64 = ARBGPUShaderInt64
        this.ARBHalfFloatPixel = ARBHalfFloatPixel
        this.ARBHalfFloatVertex = ARBHalfFloatVertex
        this.ARBImaging = ARBImaging
        this.ARBMapBufferRange = ARBMapBufferRange
        this.ARBMatrixPalette = ARBMatrixPalette
        this.ARBParallelShaderCompile = ARBParallelShaderCompile
        this.ARBRobustness = ARBRobustness
        this.ARBSampleLocations = ARBSampleLocations
        this.ARBSeamlessCubemapPerTexture = ARBSeamlessCubemapPerTexture
        this.ARBShadingLanguageInclude = ARBShadingLanguageInclude
        this.ARBShadowAmbient = ARBShadowAmbient
        this.ARBSparseBuffer = ARBSparseBuffer
        this.ARBSparseTexture = ARBSparseTexture
        this.ARBTextureCompressionRGTC = ARBTextureCompressionRGTC
        this.ARBTextureFilterMinmax = ARBTextureFilterMinmax
        this.ARBTextureRG = ARBTextureRG
        this.ARBVertexBlend = ARBVertexBlend
        this.ARBVertexProgram = ARBVertexProgram
        this.EXT422Pixels = EXT422Pixels
        this.EXTABGR = EXTABGR
        this.EXTBindableUniform = EXTBindableUniform
        this.EXTBlendEquationSeparate = EXTBlendEquationSeparate
        this.EXTClipVolumeHint = EXTClipVolumeHint
        this.EXTCompiledVertexArray = EXTCompiledVertexArray
        this.EXTDebugLabel = EXTDebugLabel
        this.EXTDebugMarker = EXTDebugMarker
        this.EXTDepthBoundsTest = EXTDepthBoundsTest
        this.EXTDirectStateAccess = EXTDirectStateAccess
        this.EXTDrawInstanced = EXTDrawInstanced
        this.EXTEGLImageStorage = EXTEGLImageStorage
        this.EXTExternalBuffer = EXTExternalBuffer
        this.EXTFramebufferBlit = EXTFramebufferBlit
        this.EXTFramebufferBlitLayers = EXTFramebufferBlitLayers
        this.EXTFramebufferMultisample = EXTFramebufferMultisample
        this.EXTFramebufferMultisampleBlitScaled = EXTFramebufferMultisampleBlitScaled
        this.EXTFramebufferObject = EXTFramebufferObject
        this.EXTGPUProgramParameters = EXTGPUProgramParameters
        this.EXTGPUShader4 = EXTGPUShader4
        this.EXTGeometryShader4 = EXTGeometryShader4
        this.EXTMemoryObject = EXTMemoryObject
        this.EXTMemoryObjectFD = EXTMemoryObjectFD
        this.EXTMemoryObjectWin32 = EXTMemoryObjectWin32
        this.EXTPackedDepthStencil = EXTPackedDepthStencil
        this.EXTPixelBufferObject = EXTPixelBufferObject
        this.EXTPointParameters = EXTPointParameters
        this.EXTPolygonOffsetClamp = EXTPolygonOffsetClamp
        this.EXTProvokingVertex = EXTProvokingVertex
        this.EXTRasterMultisample = EXTRasterMultisample
        this.EXTSemaphore = EXTSemaphore
        this.EXTSemaphoreFD = EXTSemaphoreFD
        this.EXTSemaphoreWin32 = EXTSemaphoreWin32
        this.EXTSeparateShaderObjects = EXTSeparateShaderObjects
        this.EXTShaderFramebufferFetch = EXTShaderFramebufferFetch
        this.EXTShaderFramebufferFetchNonCoherent = EXTShaderFramebufferFetchNonCoherent
        this.EXTShaderImageLoadStore = EXTShaderImageLoadStore
        this.EXTSharedTexturePalette = EXTSharedTexturePalette
        this.EXTStencilClearTag = EXTStencilClearTag
        this.EXTTextureBufferObject = EXTTextureBufferObject
        this.EXTTextureCompressionLATC = EXTTextureCompressionLATC
        this.EXTTextureCompressionS3TC = EXTTextureCompressionS3TC
        this.EXTTextureFilterAnisotropic = EXTTextureFilterAnisotropic
        this.EXTTextureFilterMinmax = EXTTextureFilterMinmax
        this.EXTTextureMirrorClamp = EXTTextureMirrorClamp
        this.EXTTextureSRGBDecode = EXTTextureSRGBDecode
        this.EXTTextureSRGBR8 = EXTTextureSRGBR8
        this.EXTTextureSRGBRG8 = EXTTextureSRGBRG8
        this.EXTTextureSnorm = EXTTextureSnorm
        this.EXTTextureStorage = EXTTextureStorage
        this.EXTTextureSwizzle = EXTTextureSwizzle
        this.EXTTimerQuery = EXTTimerQuery
        this.EXTTransformFeedback = EXTTransformFeedback
        this.EXTVertexAttrib64bit = EXTVertexAttrib64bit
        this.EXTWin32KeyedMutex = EXTWin32KeyedMutex
        this.EXTWindowRectangles = EXTWindowRectangles
        this.EXTX11SyncObject = EXTX11SyncObject
        this.NVAlphaToCoverageDitherControl = NVAlphaToCoverageDitherControl
        this.NVBindlessMultiDrawIndirect = NVBindlessMultiDrawIndirect
        this.NVBindlessMultiDrawIndirectCount = NVBindlessMultiDrawIndirectCount
        this.NVBindlessTexture = NVBindlessTexture
        this.NVBlendEquationAdvanced = NVBlendEquationAdvanced
        this.NVBlendEquationAdvancedCoherent = NVBlendEquationAdvancedCoherent
        this.NVBlendMinmaxFactor = NVBlendMinmaxFactor
        this.NVClipSpaceWScaling = NVClipSpaceWScaling
        this.NVCommandList = NVCommandList
        this.NVConservativeRaster = NVConservativeRaster
        this.NVConservativeRasterDilate = NVConservativeRasterDilate
        this.NVConservativeRasterPreSnap = NVConservativeRasterPreSnap
        this.NVConservativeRasterPreSnapTriangles = NVConservativeRasterPreSnapTriangles
        this.NVCopyDepthToColor = NVCopyDepthToColor
        this.NVCopyImage = NVCopyImage
        this.NVDeepTexture3D = NVDeepTexture3D
        this.NVDepthBufferFloat = NVDepthBufferFloat
        this.NVDepthClamp = NVDepthClamp
        this.NVDrawTexture = NVDrawTexture
        this.NVDrawVulkanImage = NVDrawVulkanImage
        this.NVExplicitMultisample = NVExplicitMultisample
        this.NVFence = NVFence
        this.NVFillRectangle = NVFillRectangle
        this.NVFloatBuffer = NVFloatBuffer
        this.NVFogDistance = NVFogDistance
        this.NVFragmentCoverageToColor = NVFragmentCoverageToColor
        this.NVFramebufferMixedSamples = NVFramebufferMixedSamples
        this.NVFramebufferMultisampleCoverage = NVFramebufferMultisampleCoverage
        this.NVGPUMulticast = NVGPUMulticast
        this.NVGPUShader5 = NVGPUShader5
        this.NVInternalformatSampleQuery = NVInternalformatSampleQuery
        this.NVLightMaxExponent = NVLightMaxExponent
        this.NVMemoryAttachment = NVMemoryAttachment
        this.NVMemoryObjectSparse = NVMemoryObjectSparse
        this.NVMeshShader = NVMeshShader
        this.NVMultisampleCoverage = NVMultisampleCoverage
        this.NVMultisampleFilterHint = NVMultisampleFilterHint
        this.NVPackedDepthStencil = NVPackedDepthStencil
        this.NVPathRendering = NVPathRendering
        this.NVPathRenderingSharedEdge = NVPathRenderingSharedEdge
        this.NVPixelDataRange = NVPixelDataRange
        this.NVPointSprite = NVPointSprite
        this.NVPrimitiveShadingRate = NVPrimitiveShadingRate
        this.NVQueryResource = NVQueryResource
        this.NVQueryResourceTag = NVQueryResourceTag
        this.NVRepresentativeFragmentTest = NVRepresentativeFragmentTest
        this.NVRobustnessVideoMemoryPurge = NVRobustnessVideoMemoryPurge
        this.NVSampleLocations = NVSampleLocations
        this.NVScissorExclusive = NVScissorExclusive
        this.NVShaderBufferLoad = NVShaderBufferLoad
        this.NVShaderBufferStore = NVShaderBufferStore
        this.NVShaderSubgroupPartitioned = NVShaderSubgroupPartitioned
        this.NVShaderThreadGroup = NVShaderThreadGroup
        this.NVShadingRateImage = NVShadingRateImage
        this.NVTexgenReflection = NVTexgenReflection
        this.NVTextureBarrier = NVTextureBarrier
        this.NVTextureMultisample = NVTextureMultisample
        this.NVTextureShader = NVTextureShader
        this.NVTextureShader2 = NVTextureShader2
        this.NVTextureShader3 = NVTextureShader3
        this.NVTimelineSemaphore = NVTimelineSemaphore
        this.NVTransformFeedback = NVTransformFeedback
        this.NVTransformFeedback2 = NVTransformFeedback2
        this.NVUniformBufferUnifiedMemory = NVUniformBufferUnifiedMemory
        this.NVVertexArrayRange = NVVertexArrayRange
        this.NVVertexArrayRange2 = NVVertexArrayRange2
        this.NVVertexAttribInteger64bit = NVVertexAttribInteger64bit
        this.NVVertexBufferUnifiedMemory = NVVertexBufferUnifiedMemory
        this.NVViewportSwizzle = NVViewportSwizzle
        this.AMDBlendMinmaxFactor = AMDBlendMinmaxFactor
        this.AMDDebugOutput = AMDDebugOutput
        this.AMDDepthClampSeparate = AMDDepthClampSeparate
        this.AMDDrawBuffersBlend = AMDDrawBuffersBlend
        this.AMDFramebufferMultisampleAdvanced = AMDFramebufferMultisampleAdvanced
        this.AMDGPUShaderHalfFloat = AMDGPUShaderHalfFloat
        this.AMDGPUShaderHalfFloatFetch = AMDGPUShaderHalfFloatFetch
        this.AMDGPUShaderInt64 = AMDGPUShaderInt64
        this.AMDInterleavedElements = AMDInterleavedElements
        this.AMDOcclusionQueryEvent = AMDOcclusionQueryEvent
        this.AMDPerformanceMonitor = AMDPerformanceMonitor
        this.AMDPinnedMemory = AMDPinnedMemory
        this.AMDQueryBufferObject = AMDQueryBufferObject
        this.AMDSamplePositions = AMDSamplePositions
        this.AMDSeamlessCubemapPerTexture = AMDSeamlessCubemapPerTexture
        this.AMDSparseTexture = AMDSparseTexture
        this.AMDStencilOperationExtended = AMDStencilOperationExtended
        this.AMDTransformFeedback4 = AMDTransformFeedback4
        this.AMDVertexShaderTessellator = AMDVertexShaderTessellator
    }

    public companion object : WrapperManager()
}
