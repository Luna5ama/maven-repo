@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL21 : GLBase {
    @PtrParameter([3])
    public fun glUniformMatrix2x3fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix2x3fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix3x2fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix3x2fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix2x4fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix2x4fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix4x2fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix4x2fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix3x4fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix3x4fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix4x3fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix4x3fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )
}

public const val GL_FLOAT_MAT2x3: Int = 35_685

public const val GL_FLOAT_MAT2x4: Int = 35_686

public const val GL_FLOAT_MAT3x2: Int = 35_687

public const val GL_FLOAT_MAT3x4: Int = 35_688

public const val GL_FLOAT_MAT4x2: Int = 35_689

public const val GL_FLOAT_MAT4x3: Int = 35_690

public const val GL_PIXEL_PACK_BUFFER: Int = 35_051

public const val GL_PIXEL_UNPACK_BUFFER: Int = 35_052

public const val GL_PIXEL_PACK_BUFFER_BINDING: Int = 35_053

public const val GL_PIXEL_UNPACK_BUFFER_BINDING: Int = 35_055

public const val GL_SRGB: Int = 35_904

public const val GL_SRGB8: Int = 35_905

public const val GL_SRGB_ALPHA: Int = 35_906

public const val GL_SRGB8_ALPHA8: Int = 35_907

public const val GL_COMPRESSED_SRGB: Int = 35_912

public const val GL_COMPRESSED_SRGB_ALPHA: Int = 35_913

public inline fun glUniformMatrix2x3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL21.glUniformMatrix2x3fv(location, count, transpose, `value`)

public inline fun glUniformMatrix2x3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL21.glUniformMatrix2x3fv(location, count, transpose, `value`)

public inline fun glUniformMatrix3x2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL21.glUniformMatrix3x2fv(location, count, transpose, `value`)

public inline fun glUniformMatrix3x2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL21.glUniformMatrix3x2fv(location, count, transpose, `value`)

public inline fun glUniformMatrix2x4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL21.glUniformMatrix2x4fv(location, count, transpose, `value`)

public inline fun glUniformMatrix2x4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL21.glUniformMatrix2x4fv(location, count, transpose, `value`)

public inline fun glUniformMatrix4x2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL21.glUniformMatrix4x2fv(location, count, transpose, `value`)

public inline fun glUniformMatrix4x2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL21.glUniformMatrix4x2fv(location, count, transpose, `value`)

public inline fun glUniformMatrix3x4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL21.glUniformMatrix3x4fv(location, count, transpose, `value`)

public inline fun glUniformMatrix3x4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL21.glUniformMatrix3x4fv(location, count, transpose, `value`)

public inline fun glUniformMatrix4x3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL21.glUniformMatrix4x3fv(location, count, transpose, `value`)

public inline fun glUniformMatrix4x3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL21.glUniformMatrix4x3fv(location, count, transpose, `value`)
