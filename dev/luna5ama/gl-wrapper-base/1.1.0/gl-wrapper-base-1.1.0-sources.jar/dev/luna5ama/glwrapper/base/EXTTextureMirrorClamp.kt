@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureMirrorClamp : GLBase

public const val GL_MIRROR_CLAMP_EXT: Int = 34_626

public const val GL_MIRROR_CLAMP_TO_EDGE_EXT: Int = 34_627

public const val GL_MIRROR_CLAMP_TO_BORDER_EXT: Int = 35_090
