@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureSRGBR8 : GLBase

public const val GL_SR8_EXT: Int = 36_797
