@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import dev.luna5ama.kmogus.ensureCapacity
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL33 : GLBase {
    @PtrParameter([3])
    public fun glBindFragDataLocationIndexed(
        program: Int,
        colorNumber: Int,
        index: Int,
        name: Ptr,
    )

    @Unsafe
    public fun glBindFragDataLocationIndexed(
        program: Int,
        colorNumber: Int,
        index: Int,
        name: Long,
    )

    @PtrParameter([1])
    public fun glGetFragDataIndex(program: Int, name: Ptr): Int

    @Unsafe
    public fun glGetFragDataIndex(program: Int, name: Long): Int

    @PtrParameter([1])
    public fun glGenSamplers(count: Int, samplers: Ptr)

    @Unsafe
    public fun glGenSamplers(count: Int, samplers: Long)

    @PtrParameter([1])
    public fun glDeleteSamplers(count: Int, samplers: Ptr)

    @Unsafe
    public fun glDeleteSamplers(count: Int, samplers: Long)

    public fun glIsSampler(sampler: Int): Boolean

    public fun glBindSampler(unit: Int, sampler: Int)

    public fun glSamplerParameteri(
        sampler: Int,
        pname: Int,
        `param`: Int,
    )

    public fun glSamplerParameterf(
        sampler: Int,
        pname: Int,
        `param`: Float,
    )

    @PtrParameter([2])
    public fun glSamplerParameteriv(
        sampler: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glSamplerParameteriv(
        sampler: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glSamplerParameterfv(
        sampler: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glSamplerParameterfv(
        sampler: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glSamplerParameterIiv(
        sampler: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glSamplerParameterIiv(
        sampler: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glSamplerParameterIuiv(
        sampler: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glSamplerParameterIuiv(
        sampler: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetSamplerParameteriv(
        sampler: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetSamplerParameteriv(
        sampler: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetSamplerParameterfv(
        sampler: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetSamplerParameterfv(
        sampler: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetSamplerParameterIiv(
        sampler: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetSamplerParameterIiv(
        sampler: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetSamplerParameterIuiv(
        sampler: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetSamplerParameterIuiv(
        sampler: Int,
        pname: Int,
        params: Long,
    )

    public fun glQueryCounter(id: Int, target: Int)

    @PtrParameter([2])
    public fun glGetQueryObjecti64v(
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetQueryObjecti64v(
        id: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetQueryObjectui64v(
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetQueryObjectui64v(
        id: Int,
        pname: Int,
        params: Long,
    )

    public fun glVertexAttribDivisor(index: Int, divisor: Int)

    public fun glVertexAttribP1ui(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Int,
    )

    public fun glVertexAttribP2ui(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Int,
    )

    public fun glVertexAttribP3ui(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Int,
    )

    public fun glVertexAttribP4ui(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Int,
    )

    @PtrParameter([3])
    public fun glVertexAttribP1uiv(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glVertexAttribP1uiv(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glVertexAttribP2uiv(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glVertexAttribP2uiv(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glVertexAttribP3uiv(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glVertexAttribP3uiv(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glVertexAttribP4uiv(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glVertexAttribP4uiv(
        index: Int,
        type: Int,
        normalized: Boolean,
        `value`: Long,
    )

    @CoreOverload
    public fun glSamplerParameterfv(
        sampler: Int,
        pname: Int,
        v1: Float,
        v2: Float,
        v3: Float,
        v4: Float,
    ) {
        tempArr.ensureCapacity(16, false)
        tempArr.ptr.setFloatInc(v1).setFloatInc(v2).setFloatInc(v3).setFloatInc(v4)
        glSamplerParameterfv(sampler, pname, tempArr.ptr)
    }

    @CoreOverload
    public fun glSamplerParameteriv(
        sampler: Int,
        pname: Int,
        v1: Int,
        v2: Int,
        v3: Int,
        v4: Int,
    ) {
        tempArr.ensureCapacity(16, false)
        tempArr.ptr.setIntInc(v1).setIntInc(v2).setIntInc(v3).setIntInc(v4)
        glSamplerParameteriv(sampler, pname, tempArr.ptr)
    }

    @CoreOverload
    public fun glGetQueryObjecti64(id: Int, pname: Int): Long {
        tempArr.ensureCapacity(8, false)
        glGetQueryObjecti64v(id, pname, tempArr.ptr)
        return tempArr.ptr.getLong()
    }

    @CoreOverload
    public fun glGetQueryObjectui64(id: Int, pname: Int): Long {
        tempArr.ensureCapacity(8, false)
        glGetQueryObjectui64v(id, pname, tempArr.ptr)
        return tempArr.ptr.getLong()
    }

    public fun glDeleteSamplers(sampler: Int)
}

public const val GL_SRC1_COLOR: Int = 35_065

public const val GL_ONE_MINUS_SRC1_COLOR: Int = 35_066

public const val GL_ONE_MINUS_SRC1_ALPHA: Int = 35_067

public const val GL_MAX_DUAL_SOURCE_DRAW_BUFFERS: Int = 35_068

public const val GL_ANY_SAMPLES_PASSED: Int = 35_887

public const val GL_SAMPLER_BINDING: Int = 35_097

public const val GL_RGB10_A2UI: Int = 36_975

public const val GL_TEXTURE_SWIZZLE_R: Int = 36_418

public const val GL_TEXTURE_SWIZZLE_G: Int = 36_419

public const val GL_TEXTURE_SWIZZLE_B: Int = 36_420

public const val GL_TEXTURE_SWIZZLE_A: Int = 36_421

public const val GL_TEXTURE_SWIZZLE_RGBA: Int = 36_422

public const val GL_TIME_ELAPSED: Int = 35_007

public const val GL_TIMESTAMP: Int = 36_392

public const val GL_VERTEX_ATTRIB_ARRAY_DIVISOR: Int = 35_070

public const val GL_INT_2_10_10_10_REV: Int = 36_255

public inline fun glBindFragDataLocationIndexed(
    program: Int,
    colorNumber: Int,
    index: Int,
    name: Ptr,
): Unit = GLWrapper.instance.GL33.glBindFragDataLocationIndexed(program, colorNumber, index, name)

public inline fun glBindFragDataLocationIndexed(
    program: Int,
    colorNumber: Int,
    index: Int,
    name: Long,
): Unit = GLWrapper.instance.GL33.glBindFragDataLocationIndexed(program, colorNumber, index, name)

public inline fun glGetFragDataIndex(program: Int, name: Ptr): Int =
        GLWrapper.instance.GL33.glGetFragDataIndex(program, name)

public inline fun glGetFragDataIndex(program: Int, name: Long): Int =
        GLWrapper.instance.GL33.glGetFragDataIndex(program, name)

public inline fun glGenSamplers(count: Int, samplers: Ptr): Unit =
        GLWrapper.instance.GL33.glGenSamplers(count, samplers)

public inline fun glGenSamplers(count: Int, samplers: Long): Unit =
        GLWrapper.instance.GL33.glGenSamplers(count, samplers)

public inline fun glDeleteSamplers(count: Int, samplers: Ptr): Unit =
        GLWrapper.instance.GL33.glDeleteSamplers(count, samplers)

public inline fun glDeleteSamplers(count: Int, samplers: Long): Unit =
        GLWrapper.instance.GL33.glDeleteSamplers(count, samplers)

public inline fun glIsSampler(sampler: Int): Boolean = GLWrapper.instance.GL33.glIsSampler(sampler)

public inline fun glBindSampler(unit: Int, sampler: Int): Unit =
        GLWrapper.instance.GL33.glBindSampler(unit, sampler)

public inline fun glSamplerParameteri(
    sampler: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.GL33.glSamplerParameteri(sampler, pname, `param`)

public inline fun glSamplerParameterf(
    sampler: Int,
    pname: Int,
    `param`: Float,
): Unit = GLWrapper.instance.GL33.glSamplerParameterf(sampler, pname, `param`)

public inline fun glSamplerParameteriv(
    sampler: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glSamplerParameteriv(sampler, pname, params)

public inline fun glSamplerParameteriv(
    sampler: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glSamplerParameteriv(sampler, pname, params)

public inline fun glSamplerParameterfv(
    sampler: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glSamplerParameterfv(sampler, pname, params)

public inline fun glSamplerParameterfv(
    sampler: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glSamplerParameterfv(sampler, pname, params)

public inline fun glSamplerParameterIiv(
    sampler: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glSamplerParameterIiv(sampler, pname, params)

public inline fun glSamplerParameterIiv(
    sampler: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glSamplerParameterIiv(sampler, pname, params)

public inline fun glSamplerParameterIuiv(
    sampler: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glSamplerParameterIuiv(sampler, pname, params)

public inline fun glSamplerParameterIuiv(
    sampler: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glSamplerParameterIuiv(sampler, pname, params)

public inline fun glGetSamplerParameteriv(
    sampler: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glGetSamplerParameteriv(sampler, pname, params)

public inline fun glGetSamplerParameteriv(
    sampler: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glGetSamplerParameteriv(sampler, pname, params)

public inline fun glGetSamplerParameterfv(
    sampler: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glGetSamplerParameterfv(sampler, pname, params)

public inline fun glGetSamplerParameterfv(
    sampler: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glGetSamplerParameterfv(sampler, pname, params)

public inline fun glGetSamplerParameterIiv(
    sampler: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glGetSamplerParameterIiv(sampler, pname, params)

public inline fun glGetSamplerParameterIiv(
    sampler: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glGetSamplerParameterIiv(sampler, pname, params)

public inline fun glGetSamplerParameterIuiv(
    sampler: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glGetSamplerParameterIuiv(sampler, pname, params)

public inline fun glGetSamplerParameterIuiv(
    sampler: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glGetSamplerParameterIuiv(sampler, pname, params)

public inline fun glQueryCounter(id: Int, target: Int): Unit =
        GLWrapper.instance.GL33.glQueryCounter(id, target)

public inline fun glGetQueryObjecti64v(
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glGetQueryObjecti64v(id, pname, params)

public inline fun glGetQueryObjecti64v(
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glGetQueryObjecti64v(id, pname, params)

public inline fun glGetQueryObjectui64v(
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL33.glGetQueryObjectui64v(id, pname, params)

public inline fun glGetQueryObjectui64v(
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL33.glGetQueryObjectui64v(id, pname, params)

public inline fun glVertexAttribDivisor(index: Int, divisor: Int): Unit =
        GLWrapper.instance.GL33.glVertexAttribDivisor(index, divisor)

public inline fun glVertexAttribP1ui(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Int,
): Unit = GLWrapper.instance.GL33.glVertexAttribP1ui(index, type, normalized, `value`)

public inline fun glVertexAttribP2ui(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Int,
): Unit = GLWrapper.instance.GL33.glVertexAttribP2ui(index, type, normalized, `value`)

public inline fun glVertexAttribP3ui(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Int,
): Unit = GLWrapper.instance.GL33.glVertexAttribP3ui(index, type, normalized, `value`)

public inline fun glVertexAttribP4ui(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Int,
): Unit = GLWrapper.instance.GL33.glVertexAttribP4ui(index, type, normalized, `value`)

public inline fun glVertexAttribP1uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL33.glVertexAttribP1uiv(index, type, normalized, `value`)

public inline fun glVertexAttribP1uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL33.glVertexAttribP1uiv(index, type, normalized, `value`)

public inline fun glVertexAttribP2uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL33.glVertexAttribP2uiv(index, type, normalized, `value`)

public inline fun glVertexAttribP2uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL33.glVertexAttribP2uiv(index, type, normalized, `value`)

public inline fun glVertexAttribP3uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL33.glVertexAttribP3uiv(index, type, normalized, `value`)

public inline fun glVertexAttribP3uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL33.glVertexAttribP3uiv(index, type, normalized, `value`)

public inline fun glVertexAttribP4uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL33.glVertexAttribP4uiv(index, type, normalized, `value`)

public inline fun glVertexAttribP4uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL33.glVertexAttribP4uiv(index, type, normalized, `value`)

public inline fun glSamplerParameterfv(
    sampler: Int,
    pname: Int,
    v1: Float,
    v2: Float,
    v3: Float,
    v4: Float,
): Unit = GLWrapper.instance.GL33.glSamplerParameterfv(sampler, pname, v1, v2, v3, v4)

public inline fun glSamplerParameteriv(
    sampler: Int,
    pname: Int,
    v1: Int,
    v2: Int,
    v3: Int,
    v4: Int,
): Unit = GLWrapper.instance.GL33.glSamplerParameteriv(sampler, pname, v1, v2, v3, v4)

public inline fun glGetQueryObjecti64(id: Int, pname: Int): Long =
        GLWrapper.instance.GL33.glGetQueryObjecti64(id, pname)

public inline fun glGetQueryObjectui64(id: Int, pname: Int): Long =
        GLWrapper.instance.GL33.glGetQueryObjectui64(id, pname)

public inline fun glDeleteSamplers(sampler: Int): Unit =
        GLWrapper.instance.GL33.glDeleteSamplers(sampler)
