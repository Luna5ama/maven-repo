@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVLightMaxExponent : GLBase

public const val GL_MAX_SHININESS_NV: Int = 34_052

public const val GL_MAX_SPOT_EXPONENT_NV: Int = 34_053
