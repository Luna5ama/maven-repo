@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTSemaphoreWin32 : GLBase {
    @PtrParameter([2])
    public fun glImportSemaphoreWin32HandleEXT(
        semaphore: Int,
        handleType: Int,
        handle: Ptr,
    )

    @Unsafe
    public fun glImportSemaphoreWin32HandleEXT(
        semaphore: Int,
        handleType: Int,
        handle: Long,
    )

    @PtrParameter([2])
    public fun glImportSemaphoreWin32NameEXT(
        semaphore: Int,
        handleType: Int,
        name: Ptr,
    )

    @Unsafe
    public fun glImportSemaphoreWin32NameEXT(
        semaphore: Int,
        handleType: Int,
        name: Long,
    )
}

public const val GL_HANDLE_TYPE_D3D12_FENCE_EXT: Int = 38_292

public const val GL_D3D12_FENCE_VALUE_EXT: Int = 38_293

public inline fun glImportSemaphoreWin32HandleEXT(
    semaphore: Int,
    handleType: Int,
    handle: Ptr,
): Unit = GLWrapper.instance.EXTSemaphoreWin32.glImportSemaphoreWin32HandleEXT(semaphore,
        handleType, handle)

public inline fun glImportSemaphoreWin32HandleEXT(
    semaphore: Int,
    handleType: Int,
    handle: Long,
): Unit = GLWrapper.instance.EXTSemaphoreWin32.glImportSemaphoreWin32HandleEXT(semaphore,
        handleType, handle)

public inline fun glImportSemaphoreWin32NameEXT(
    semaphore: Int,
    handleType: Int,
    name: Ptr,
): Unit = GLWrapper.instance.EXTSemaphoreWin32.glImportSemaphoreWin32NameEXT(semaphore, handleType,
        name)

public inline fun glImportSemaphoreWin32NameEXT(
    semaphore: Int,
    handleType: Int,
    name: Long,
): Unit = GLWrapper.instance.EXTSemaphoreWin32.glImportSemaphoreWin32NameEXT(semaphore, handleType,
        name)
