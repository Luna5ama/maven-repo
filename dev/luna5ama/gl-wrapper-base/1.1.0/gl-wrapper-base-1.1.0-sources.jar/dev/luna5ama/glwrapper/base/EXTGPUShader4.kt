@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTGPUShader4 : GLBase {
    public fun glVertexAttribI1iEXT(index: Int, x: Int)

    public fun glVertexAttribI2iEXT(
        index: Int,
        x: Int,
        y: Int,
    )

    public fun glVertexAttribI3iEXT(
        index: Int,
        x: Int,
        y: Int,
        z: Int,
    )

    public fun glVertexAttribI4iEXT(
        index: Int,
        x: Int,
        y: Int,
        z: Int,
        w: Int,
    )

    public fun glVertexAttribI1uiEXT(index: Int, x: Int)

    public fun glVertexAttribI2uiEXT(
        index: Int,
        x: Int,
        y: Int,
    )

    public fun glVertexAttribI3uiEXT(
        index: Int,
        x: Int,
        y: Int,
        z: Int,
    )

    public fun glVertexAttribI4uiEXT(
        index: Int,
        x: Int,
        y: Int,
        z: Int,
        w: Int,
    )

    @PtrParameter([1])
    public fun glVertexAttribI1ivEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI1ivEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI2ivEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI2ivEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI3ivEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI3ivEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4ivEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4ivEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI1uivEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI1uivEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI2uivEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI2uivEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI3uivEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI3uivEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4uivEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4uivEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4bvEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4bvEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4svEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4svEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4ubvEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4ubvEXT(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4usvEXT(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4usvEXT(index: Int, v: Long)

    @PtrParameter([4])
    public fun glVertexAttribIPointerEXT(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glVertexAttribIPointerEXT(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribIivEXT(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribIivEXT(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribIuivEXT(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribIuivEXT(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformuivEXT(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformuivEXT(
        program: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glBindFragDataLocationEXT(
        program: Int,
        color: Int,
        name: Ptr,
    )

    @Unsafe
    public fun glBindFragDataLocationEXT(
        program: Int,
        color: Int,
        name: Long,
    )

    @PtrParameter([1])
    public fun glGetFragDataLocationEXT(program: Int, name: Ptr): Int

    @Unsafe
    public fun glGetFragDataLocationEXT(program: Int, name: Long): Int

    public fun glUniform1uiEXT(location: Int, v0: Int)

    public fun glUniform2uiEXT(
        location: Int,
        v0: Int,
        v1: Int,
    )

    public fun glUniform3uiEXT(
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
    )

    public fun glUniform4uiEXT(
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
        v3: Int,
    )

    @PtrParameter([2])
    public fun glUniform1uivEXT(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1uivEXT(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform2uivEXT(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2uivEXT(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform3uivEXT(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3uivEXT(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform4uivEXT(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4uivEXT(
        location: Int,
        count: Int,
        `value`: Long,
    )
}

public const val GL_VERTEX_ATTRIB_ARRAY_INTEGER_EXT: Int = 35_069

public const val GL_SAMPLER_1D_ARRAY_EXT: Int = 36_288

public const val GL_SAMPLER_2D_ARRAY_EXT: Int = 36_289

public const val GL_SAMPLER_BUFFER_EXT: Int = 36_290

public const val GL_SAMPLER_1D_ARRAY_SHADOW_EXT: Int = 36_291

public const val GL_SAMPLER_2D_ARRAY_SHADOW_EXT: Int = 36_292

public const val GL_SAMPLER_CUBE_SHADOW_EXT: Int = 36_293

public const val GL_UNSIGNED_INT_VEC2_EXT: Int = 36_294

public const val GL_UNSIGNED_INT_VEC3_EXT: Int = 36_295

public const val GL_UNSIGNED_INT_VEC4_EXT: Int = 36_296

public const val GL_INT_SAMPLER_1D_EXT: Int = 36_297

public const val GL_INT_SAMPLER_2D_EXT: Int = 36_298

public const val GL_INT_SAMPLER_3D_EXT: Int = 36_299

public const val GL_INT_SAMPLER_CUBE_EXT: Int = 36_300

public const val GL_INT_SAMPLER_2D_RECT_EXT: Int = 36_301

public const val GL_INT_SAMPLER_1D_ARRAY_EXT: Int = 36_302

public const val GL_INT_SAMPLER_2D_ARRAY_EXT: Int = 36_303

public const val GL_INT_SAMPLER_BUFFER_EXT: Int = 36_304

public const val GL_UNSIGNED_INT_SAMPLER_1D_EXT: Int = 36_305

public const val GL_UNSIGNED_INT_SAMPLER_2D_EXT: Int = 36_306

public const val GL_UNSIGNED_INT_SAMPLER_3D_EXT: Int = 36_307

public const val GL_UNSIGNED_INT_SAMPLER_CUBE_EXT: Int = 36_308

public const val GL_UNSIGNED_INT_SAMPLER_2D_RECT_EXT: Int = 36_309

public const val GL_UNSIGNED_INT_SAMPLER_1D_ARRAY_EXT: Int = 36_310

public const val GL_UNSIGNED_INT_SAMPLER_2D_ARRAY_EXT: Int = 36_311

public const val GL_UNSIGNED_INT_SAMPLER_BUFFER_EXT: Int = 36_312

public const val GL_MIN_PROGRAM_TEXEL_OFFSET_EXT: Int = 35_076

public const val GL_MAX_PROGRAM_TEXEL_OFFSET_EXT: Int = 35_077

public inline fun glVertexAttribI1iEXT(index: Int, x: Int): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI1iEXT(index, x)

public inline fun glVertexAttribI2iEXT(
    index: Int,
    x: Int,
    y: Int,
): Unit = GLWrapper.instance.EXTGPUShader4.glVertexAttribI2iEXT(index, x, y)

public inline fun glVertexAttribI3iEXT(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
): Unit = GLWrapper.instance.EXTGPUShader4.glVertexAttribI3iEXT(index, x, y, z)

public inline fun glVertexAttribI4iEXT(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
): Unit = GLWrapper.instance.EXTGPUShader4.glVertexAttribI4iEXT(index, x, y, z, w)

public inline fun glVertexAttribI1uiEXT(index: Int, x: Int): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI1uiEXT(index, x)

public inline fun glVertexAttribI2uiEXT(
    index: Int,
    x: Int,
    y: Int,
): Unit = GLWrapper.instance.EXTGPUShader4.glVertexAttribI2uiEXT(index, x, y)

public inline fun glVertexAttribI3uiEXT(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
): Unit = GLWrapper.instance.EXTGPUShader4.glVertexAttribI3uiEXT(index, x, y, z)

public inline fun glVertexAttribI4uiEXT(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
): Unit = GLWrapper.instance.EXTGPUShader4.glVertexAttribI4uiEXT(index, x, y, z, w)

public inline fun glVertexAttribI1ivEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI1ivEXT(index, v)

public inline fun glVertexAttribI1ivEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI1ivEXT(index, v)

public inline fun glVertexAttribI2ivEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI2ivEXT(index, v)

public inline fun glVertexAttribI2ivEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI2ivEXT(index, v)

public inline fun glVertexAttribI3ivEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI3ivEXT(index, v)

public inline fun glVertexAttribI3ivEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI3ivEXT(index, v)

public inline fun glVertexAttribI4ivEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4ivEXT(index, v)

public inline fun glVertexAttribI4ivEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4ivEXT(index, v)

public inline fun glVertexAttribI1uivEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI1uivEXT(index, v)

public inline fun glVertexAttribI1uivEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI1uivEXT(index, v)

public inline fun glVertexAttribI2uivEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI2uivEXT(index, v)

public inline fun glVertexAttribI2uivEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI2uivEXT(index, v)

public inline fun glVertexAttribI3uivEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI3uivEXT(index, v)

public inline fun glVertexAttribI3uivEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI3uivEXT(index, v)

public inline fun glVertexAttribI4uivEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4uivEXT(index, v)

public inline fun glVertexAttribI4uivEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4uivEXT(index, v)

public inline fun glVertexAttribI4bvEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4bvEXT(index, v)

public inline fun glVertexAttribI4bvEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4bvEXT(index, v)

public inline fun glVertexAttribI4svEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4svEXT(index, v)

public inline fun glVertexAttribI4svEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4svEXT(index, v)

public inline fun glVertexAttribI4ubvEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4ubvEXT(index, v)

public inline fun glVertexAttribI4ubvEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4ubvEXT(index, v)

public inline fun glVertexAttribI4usvEXT(index: Int, v: Ptr): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4usvEXT(index, v)

public inline fun glVertexAttribI4usvEXT(index: Int, v: Long): Unit =
        GLWrapper.instance.EXTGPUShader4.glVertexAttribI4usvEXT(index, v)

public inline fun glVertexAttribIPointerEXT(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.EXTGPUShader4.glVertexAttribIPointerEXT(index, size, type, stride,
        pointer)

public inline fun glVertexAttribIPointerEXT(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
): Unit = GLWrapper.instance.EXTGPUShader4.glVertexAttribIPointerEXT(index, size, type, stride,
        pointer)

public inline fun glGetVertexAttribIivEXT(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTGPUShader4.glGetVertexAttribIivEXT(index, pname, params)

public inline fun glGetVertexAttribIivEXT(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTGPUShader4.glGetVertexAttribIivEXT(index, pname, params)

public inline fun glGetVertexAttribIuivEXT(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTGPUShader4.glGetVertexAttribIuivEXT(index, pname, params)

public inline fun glGetVertexAttribIuivEXT(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTGPUShader4.glGetVertexAttribIuivEXT(index, pname, params)

public inline fun glGetUniformuivEXT(
    program: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTGPUShader4.glGetUniformuivEXT(program, location, params)

public inline fun glGetUniformuivEXT(
    program: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTGPUShader4.glGetUniformuivEXT(program, location, params)

public inline fun glBindFragDataLocationEXT(
    program: Int,
    color: Int,
    name: Ptr,
): Unit = GLWrapper.instance.EXTGPUShader4.glBindFragDataLocationEXT(program, color, name)

public inline fun glBindFragDataLocationEXT(
    program: Int,
    color: Int,
    name: Long,
): Unit = GLWrapper.instance.EXTGPUShader4.glBindFragDataLocationEXT(program, color, name)

public inline fun glGetFragDataLocationEXT(program: Int, name: Ptr): Int =
        GLWrapper.instance.EXTGPUShader4.glGetFragDataLocationEXT(program, name)

public inline fun glGetFragDataLocationEXT(program: Int, name: Long): Int =
        GLWrapper.instance.EXTGPUShader4.glGetFragDataLocationEXT(program, name)

public inline fun glUniform1uiEXT(location: Int, v0: Int): Unit =
        GLWrapper.instance.EXTGPUShader4.glUniform1uiEXT(location, v0)

public inline fun glUniform2uiEXT(
    location: Int,
    v0: Int,
    v1: Int,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform2uiEXT(location, v0, v1)

public inline fun glUniform3uiEXT(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform3uiEXT(location, v0, v1, v2)

public inline fun glUniform4uiEXT(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform4uiEXT(location, v0, v1, v2, v3)

public inline fun glUniform1uivEXT(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform1uivEXT(location, count, `value`)

public inline fun glUniform1uivEXT(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform1uivEXT(location, count, `value`)

public inline fun glUniform2uivEXT(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform2uivEXT(location, count, `value`)

public inline fun glUniform2uivEXT(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform2uivEXT(location, count, `value`)

public inline fun glUniform3uivEXT(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform3uivEXT(location, count, `value`)

public inline fun glUniform3uivEXT(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform3uivEXT(location, count, `value`)

public inline fun glUniform4uivEXT(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform4uivEXT(location, count, `value`)

public inline fun glUniform4uivEXT(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.EXTGPUShader4.glUniform4uivEXT(location, count, `value`)
