@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface ARBFragmentProgram : GLBase

public const val GL_FRAGMENT_PROGRAM_ARB: Int = 34_820

public const val GL_PROGRAM_ALU_INSTRUCTIONS_ARB: Int = 34_821

public const val GL_PROGRAM_TEX_INSTRUCTIONS_ARB: Int = 34_822

public const val GL_PROGRAM_TEX_INDIRECTIONS_ARB: Int = 34_823

public const val GL_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB: Int = 34_824

public const val GL_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB: Int = 34_825

public const val GL_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB: Int = 34_826

public const val GL_MAX_PROGRAM_ALU_INSTRUCTIONS_ARB: Int = 34_827

public const val GL_MAX_PROGRAM_TEX_INSTRUCTIONS_ARB: Int = 34_828

public const val GL_MAX_PROGRAM_TEX_INDIRECTIONS_ARB: Int = 34_829

public const val GL_MAX_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB: Int = 34_830

public const val GL_MAX_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB: Int = 34_831

public const val GL_MAX_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB: Int = 34_832

public const val GL_MAX_TEXTURE_COORDS_ARB: Int = 34_929

public const val GL_MAX_TEXTURE_IMAGE_UNITS_ARB: Int = 34_930
