@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface ARBParallelShaderCompile : GLBase {
    public fun glMaxShaderCompilerThreadsARB(count: Int)
}

public const val GL_MAX_SHADER_COMPILER_THREADS_ARB: Int = 37_296

public const val GL_COMPLETION_STATUS_ARB: Int = 37_297

public inline fun glMaxShaderCompilerThreadsARB(count: Int): Unit =
        GLWrapper.instance.ARBParallelShaderCompile.glMaxShaderCompilerThreadsARB(count)
