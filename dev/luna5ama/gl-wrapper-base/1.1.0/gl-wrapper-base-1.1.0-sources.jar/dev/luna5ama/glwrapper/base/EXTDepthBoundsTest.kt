@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Double
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTDepthBoundsTest : GLBase {
    public fun glDepthBoundsEXT(zmin: Double, zmax: Double)
}

public const val GL_DEPTH_BOUNDS_TEST_EXT: Int = 34_960

public const val GL_DEPTH_BOUNDS_EXT: Int = 34_961

public inline fun glDepthBoundsEXT(zmin: Double, zmax: Double): Unit =
        GLWrapper.instance.EXTDepthBoundsTest.glDepthBoundsEXT(zmin, zmax)
