@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Arr
import dev.luna5ama.kmogus.Ptr
import dev.luna5ama.kmogus.ensureCapacity
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL45 : GLBase {
    public fun glClipControl(origin: Int, depth: Int)

    @PtrParameter([1])
    public fun glCreateTransformFeedbacks(n: Int, ids: Ptr)

    @Unsafe
    public fun glCreateTransformFeedbacks(n: Int, ids: Long)

    public fun glTransformFeedbackBufferBase(
        xfb: Int,
        index: Int,
        buffer: Int,
    )

    public fun glTransformFeedbackBufferRange(
        xfb: Int,
        index: Int,
        buffer: Int,
        offset: Long,
        size: Long,
    )

    @PtrParameter([2])
    public fun glGetTransformFeedbackiv(
        xfb: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetTransformFeedbackiv(
        xfb: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrParameter([3])
    public fun glGetTransformFeedbacki_v(
        xfb: Int,
        pname: Int,
        index: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetTransformFeedbacki_v(
        xfb: Int,
        pname: Int,
        index: Int,
        `param`: Long,
    )

    @PtrParameter([3])
    public fun glGetTransformFeedbacki64_v(
        xfb: Int,
        pname: Int,
        index: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetTransformFeedbacki64_v(
        xfb: Int,
        pname: Int,
        index: Int,
        `param`: Long,
    )

    @PtrParameter([1])
    public fun glCreateBuffers(n: Int, buffers: Ptr)

    @Unsafe
    public fun glCreateBuffers(n: Int, buffers: Long)

    @PtrParameter([2])
    public fun glNamedBufferStorage(
        buffer: Int,
        size: Long,
        `data`: Ptr,
        flags: Int,
    )

    @Unsafe
    public fun glNamedBufferStorage(
        buffer: Int,
        size: Long,
        `data`: Long,
        flags: Int,
    )

    @PtrParameter([2])
    public fun glNamedBufferData(
        buffer: Int,
        size: Long,
        `data`: Ptr,
        usage: Int,
    )

    @Unsafe
    public fun glNamedBufferData(
        buffer: Int,
        size: Long,
        `data`: Long,
        usage: Int,
    )

    @PtrParameter([3])
    public fun glNamedBufferSubData(
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Ptr,
    )

    @Unsafe
    public fun glNamedBufferSubData(
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Long,
    )

    public fun glCopyNamedBufferSubData(
        readBuffer: Int,
        writeBuffer: Int,
        readOffset: Long,
        writeOffset: Long,
        size: Long,
    )

    @PtrParameter([4])
    public fun glClearNamedBufferData(
        buffer: Int,
        internalformat: Int,
        format: Int,
        type: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glClearNamedBufferData(
        buffer: Int,
        internalformat: Int,
        format: Int,
        type: Int,
        `data`: Long,
    )

    @PtrParameter([6])
    public fun glClearNamedBufferSubData(
        buffer: Int,
        internalformat: Int,
        offset: Long,
        size: Long,
        format: Int,
        type: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glClearNamedBufferSubData(
        buffer: Int,
        internalformat: Int,
        offset: Long,
        size: Long,
        format: Int,
        type: Int,
        `data`: Long,
    )

    @PtrReturn
    public fun glMapNamedBuffer(buffer: Int, access: Int): Ptr

    public fun glUnmapNamedBuffer(buffer: Int): Boolean

    public fun glFlushMappedNamedBufferRange(
        buffer: Int,
        offset: Long,
        length: Long,
    )

    @PtrParameter([2])
    public fun glGetNamedBufferParameteriv(
        buffer: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedBufferParameteriv(
        buffer: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetNamedBufferParameteri64v(
        buffer: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedBufferParameteri64v(
        buffer: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetNamedBufferPointerv(
        buffer: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedBufferPointerv(
        buffer: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetNamedBufferSubData(
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetNamedBufferSubData(
        buffer: Int,
        offset: Long,
        size: Long,
        `data`: Long,
    )

    @PtrParameter([1])
    public fun glCreateFramebuffers(n: Int, framebuffers: Ptr)

    @Unsafe
    public fun glCreateFramebuffers(n: Int, framebuffers: Long)

    public fun glNamedFramebufferRenderbuffer(
        framebuffer: Int,
        attachment: Int,
        renderbuffertarget: Int,
        renderbuffer: Int,
    )

    public fun glNamedFramebufferParameteri(
        framebuffer: Int,
        pname: Int,
        `param`: Int,
    )

    public fun glNamedFramebufferTexture(
        framebuffer: Int,
        attachment: Int,
        texture: Int,
        level: Int,
    )

    public fun glNamedFramebufferTextureLayer(
        framebuffer: Int,
        attachment: Int,
        texture: Int,
        level: Int,
        layer: Int,
    )

    public fun glNamedFramebufferDrawBuffer(framebuffer: Int, buf: Int)

    @PtrParameter([2])
    public fun glNamedFramebufferDrawBuffers(
        framebuffer: Int,
        n: Int,
        bufs: Ptr,
    )

    @Unsafe
    public fun glNamedFramebufferDrawBuffers(
        framebuffer: Int,
        n: Int,
        bufs: Long,
    )

    public fun glNamedFramebufferReadBuffer(framebuffer: Int, src: Int)

    @PtrParameter([2])
    public fun glInvalidateNamedFramebufferData(
        framebuffer: Int,
        numAttachments: Int,
        attachments: Ptr,
    )

    @Unsafe
    public fun glInvalidateNamedFramebufferData(
        framebuffer: Int,
        numAttachments: Int,
        attachments: Long,
    )

    @PtrParameter([2])
    public fun glInvalidateNamedFramebufferSubData(
        framebuffer: Int,
        numAttachments: Int,
        attachments: Ptr,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    @Unsafe
    public fun glInvalidateNamedFramebufferSubData(
        framebuffer: Int,
        numAttachments: Int,
        attachments: Long,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([3])
    public fun glClearNamedFramebufferiv(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glClearNamedFramebufferiv(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glClearNamedFramebufferuiv(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glClearNamedFramebufferuiv(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glClearNamedFramebufferfv(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glClearNamedFramebufferfv(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        `value`: Long,
    )

    public fun glClearNamedFramebufferfi(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        depth: Float,
        stencil: Int,
    )

    public fun glBlitNamedFramebuffer(
        readFramebuffer: Int,
        drawFramebuffer: Int,
        srcX0: Int,
        srcY0: Int,
        srcX1: Int,
        srcY1: Int,
        dstX0: Int,
        dstY0: Int,
        dstX1: Int,
        dstY1: Int,
        mask: Int,
        filter: Int,
    )

    public fun glCheckNamedFramebufferStatus(framebuffer: Int, target: Int): Int

    @PtrParameter([2])
    public fun glGetNamedFramebufferParameteriv(
        framebuffer: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedFramebufferParameteriv(
        framebuffer: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetNamedFramebufferAttachmentParameteriv(
        framebuffer: Int,
        attachment: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedFramebufferAttachmentParameteriv(
        framebuffer: Int,
        attachment: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([1])
    public fun glCreateRenderbuffers(n: Int, renderbuffers: Ptr)

    @Unsafe
    public fun glCreateRenderbuffers(n: Int, renderbuffers: Long)

    public fun glNamedRenderbufferStorage(
        renderbuffer: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    public fun glNamedRenderbufferStorageMultisample(
        renderbuffer: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([2])
    public fun glGetNamedRenderbufferParameteriv(
        renderbuffer: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetNamedRenderbufferParameteriv(
        renderbuffer: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glCreateTextures(
        target: Int,
        n: Int,
        textures: Ptr,
    )

    @Unsafe
    public fun glCreateTextures(
        target: Int,
        n: Int,
        textures: Long,
    )

    public fun glTextureBuffer(
        texture: Int,
        internalformat: Int,
        buffer: Int,
    )

    public fun glTextureBufferRange(
        texture: Int,
        internalformat: Int,
        buffer: Int,
        offset: Long,
        size: Long,
    )

    public fun glTextureStorage1D(
        texture: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
    )

    public fun glTextureStorage2D(
        texture: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    public fun glTextureStorage3D(
        texture: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
    )

    public fun glTextureStorage2DMultisample(
        texture: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        fixedsamplelocations: Boolean,
    )

    public fun glTextureStorage3DMultisample(
        texture: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
        fixedsamplelocations: Boolean,
    )

    @PtrParameter([6])
    public fun glTextureSubImage1D(
        texture: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTextureSubImage1D(
        texture: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([8])
    public fun glTextureSubImage2D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTextureSubImage2D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([10])
    public fun glTextureSubImage3D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glTextureSubImage3D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        pixels: Long,
    )

    @PtrParameter([6])
    public fun glCompressedTextureSubImage1D(
        texture: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTextureSubImage1D(
        texture: Int,
        level: Int,
        xoffset: Int,
        width: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([8])
    public fun glCompressedTextureSubImage2D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTextureSubImage2D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        width: Int,
        height: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    @PtrParameter([10])
    public fun glCompressedTextureSubImage3D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        imageSize: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glCompressedTextureSubImage3D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        imageSize: Int,
        `data`: Long,
    )

    public fun glCopyTextureSubImage1D(
        texture: Int,
        level: Int,
        xoffset: Int,
        x: Int,
        y: Int,
        width: Int,
    )

    public fun glCopyTextureSubImage2D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    public fun glCopyTextureSubImage3D(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )

    public fun glTextureParameterf(
        texture: Int,
        pname: Int,
        `param`: Float,
    )

    @PtrParameter([2])
    public fun glTextureParameterfv(
        texture: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTextureParameterfv(
        texture: Int,
        pname: Int,
        params: Long,
    )

    public fun glTextureParameteri(
        texture: Int,
        pname: Int,
        `param`: Int,
    )

    @PtrParameter([2])
    public fun glTextureParameterIiv(
        texture: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTextureParameterIiv(
        texture: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glTextureParameterIuiv(
        texture: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTextureParameterIuiv(
        texture: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glTextureParameteriv(
        texture: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTextureParameteriv(
        texture: Int,
        pname: Int,
        params: Long,
    )

    public fun glGenerateTextureMipmap(texture: Int)

    public fun glBindTextureUnit(unit: Int, texture: Int)

    @PtrParameter([5])
    public fun glGetTextureImage(
        texture: Int,
        level: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glGetTextureImage(
        texture: Int,
        level: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        pixels: Long,
    )

    @PtrParameter([3])
    public fun glGetCompressedTextureImage(
        texture: Int,
        level: Int,
        bufSize: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glGetCompressedTextureImage(
        texture: Int,
        level: Int,
        bufSize: Int,
        pixels: Long,
    )

    @PtrParameter([3])
    public fun glGetTextureLevelParameterfv(
        texture: Int,
        level: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureLevelParameterfv(
        texture: Int,
        level: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetTextureLevelParameteriv(
        texture: Int,
        level: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureLevelParameteriv(
        texture: Int,
        level: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetTextureParameterfv(
        texture: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureParameterfv(
        texture: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetTextureParameterIiv(
        texture: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureParameterIiv(
        texture: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetTextureParameterIuiv(
        texture: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureParameterIuiv(
        texture: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetTextureParameteriv(
        texture: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTextureParameteriv(
        texture: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([1])
    public fun glCreateVertexArrays(n: Int, arrays: Ptr)

    @Unsafe
    public fun glCreateVertexArrays(n: Int, arrays: Long)

    public fun glDisableVertexArrayAttrib(vaobj: Int, index: Int)

    public fun glEnableVertexArrayAttrib(vaobj: Int, index: Int)

    public fun glVertexArrayElementBuffer(vaobj: Int, buffer: Int)

    public fun glVertexArrayVertexBuffer(
        vaobj: Int,
        bindingindex: Int,
        buffer: Int,
        offset: Long,
        stride: Int,
    )

    @PtrParameter([3, 4, 5])
    public fun glVertexArrayVertexBuffers(
        vaobj: Int,
        first: Int,
        count: Int,
        buffers: Ptr,
        offsets: Ptr,
        strides: Ptr,
    )

    @Unsafe
    public fun glVertexArrayVertexBuffers(
        vaobj: Int,
        first: Int,
        count: Int,
        buffers: Long,
        offsets: Long,
        strides: Long,
    )

    public fun glVertexArrayAttribFormat(
        vaobj: Int,
        attribindex: Int,
        size: Int,
        type: Int,
        normalized: Boolean,
        relativeoffset: Int,
    )

    public fun glVertexArrayAttribIFormat(
        vaobj: Int,
        attribindex: Int,
        size: Int,
        type: Int,
        relativeoffset: Int,
    )

    public fun glVertexArrayAttribLFormat(
        vaobj: Int,
        attribindex: Int,
        size: Int,
        type: Int,
        relativeoffset: Int,
    )

    public fun glVertexArrayAttribBinding(
        vaobj: Int,
        attribindex: Int,
        bindingindex: Int,
    )

    public fun glVertexArrayBindingDivisor(
        vaobj: Int,
        bindingindex: Int,
        divisor: Int,
    )

    @PtrParameter([2])
    public fun glGetVertexArrayiv(
        vaobj: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetVertexArrayiv(
        vaobj: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrParameter([3])
    public fun glGetVertexArrayIndexediv(
        vaobj: Int,
        index: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetVertexArrayIndexediv(
        vaobj: Int,
        index: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrParameter([3])
    public fun glGetVertexArrayIndexed64iv(
        vaobj: Int,
        index: Int,
        pname: Int,
        `param`: Ptr,
    )

    @Unsafe
    public fun glGetVertexArrayIndexed64iv(
        vaobj: Int,
        index: Int,
        pname: Int,
        `param`: Long,
    )

    @PtrParameter([1])
    public fun glCreateSamplers(n: Int, samplers: Ptr)

    @Unsafe
    public fun glCreateSamplers(n: Int, samplers: Long)

    @PtrParameter([1])
    public fun glCreateProgramPipelines(n: Int, pipelines: Ptr)

    @Unsafe
    public fun glCreateProgramPipelines(n: Int, pipelines: Long)

    @PtrParameter([2])
    public fun glCreateQueries(
        target: Int,
        n: Int,
        ids: Ptr,
    )

    @Unsafe
    public fun glCreateQueries(
        target: Int,
        n: Int,
        ids: Long,
    )

    public fun glGetQueryBufferObjectiv(
        id: Int,
        buffer: Int,
        pname: Int,
        offset: Long,
    )

    public fun glGetQueryBufferObjectuiv(
        id: Int,
        buffer: Int,
        pname: Int,
        offset: Long,
    )

    public fun glGetQueryBufferObjecti64v(
        id: Int,
        buffer: Int,
        pname: Int,
        offset: Long,
    )

    public fun glGetQueryBufferObjectui64v(
        id: Int,
        buffer: Int,
        pname: Int,
        offset: Long,
    )

    public fun glMemoryBarrierByRegion(barriers: Int)

    @PtrParameter([11])
    public fun glGetTextureSubImage(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glGetTextureSubImage(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        pixels: Long,
    )

    @PtrParameter([9])
    public fun glGetCompressedTextureSubImage(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        bufSize: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glGetCompressedTextureSubImage(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        bufSize: Int,
        pixels: Long,
    )

    public fun glTextureBarrier()

    public fun glGetGraphicsResetStatus(): Int

    @PtrParameter([5])
    public fun glGetnTexImage(
        tex: Int,
        level: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        img: Ptr,
    )

    @Unsafe
    public fun glGetnTexImage(
        tex: Int,
        level: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        img: Long,
    )

    @PtrParameter([7])
    public fun glReadnPixels(
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        pixels: Ptr,
    )

    @Unsafe
    public fun glReadnPixels(
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        format: Int,
        type: Int,
        bufSize: Int,
        pixels: Long,
    )

    @PtrParameter([3])
    public fun glGetnCompressedTexImage(
        target: Int,
        level: Int,
        bufSize: Int,
        img: Ptr,
    )

    @Unsafe
    public fun glGetnCompressedTexImage(
        target: Int,
        level: Int,
        bufSize: Int,
        img: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformfv(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformfv(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformdv(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformdv(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformiv(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformiv(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformuiv(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformuiv(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )

    public fun glCreateBuffers(): Int

    public fun glCreateRenderbuffers(): Int

    public fun glCreateSamplers(): Int

    public fun glCreateFramebuffers(): Int

    public fun glCreateVertexArrays(): Int

    public fun glCreateTextures(target: Int): Int

    public fun glCreateProgramPipelines(): Int

    public fun glCreateQueries(target: Int): Int

    public fun glCreateTransformFeedbacks(): Int

    @CoreOverload
    public fun glTextureParameterfv(
        texture: Int,
        pname: Int,
        v1: Float,
        v2: Float,
        v3: Float,
        v4: Float,
    ) {
        tempArr.ensureCapacity(16, false)
        tempArr.ptr.setFloatInc(v1).setFloatInc(v2).setFloatInc(v3).setFloatInc(v4)
        glTextureParameterfv(texture, pname, tempArr.ptr)
    }

    @CoreOverload
    public fun glTextureParameteriv(
        texture: Int,
        pname: Int,
        v1: Int,
        v2: Int,
        v3: Int,
        v4: Int,
    ) {
        tempArr.ensureCapacity(16, false)
        tempArr.ptr.setIntInc(v1).setIntInc(v2).setIntInc(v3).setIntInc(v4)
        glTextureParameteriv(texture, pname, tempArr.ptr)
    }

    @CoreOverload
    public fun glClearNamedFramebufferi(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        stencil: Int,
    ) {
        tempArr.ensureCapacity(4, false)
        tempArr.ptr.setIntInc(stencil)
        glClearNamedFramebufferiv(framebuffer, buffer, drawbuffer, tempArr.ptr)
    }

    @CoreOverload
    public fun glClearNamedFramebufferf(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        red: Float,
        green: Float,
        blue: Float,
        alpha: Float,
    ) {
        tempArr.ensureCapacity(16, false)
        tempArr.ptr.setFloatInc(red).setFloatInc(green).setFloatInc(blue).setFloatInc(alpha)
        glClearNamedFramebufferfv(framebuffer, buffer, drawbuffer, tempArr.ptr)
    }

    @CoreOverload
    public fun glClearNamedFramebufferf(
        framebuffer: Int,
        buffer: Int,
        drawbuffer: Int,
        depth: Float,
    ) {
        tempArr.ensureCapacity(4, false)
        tempArr.ptr.setFloatInc(depth)
        glClearNamedFramebufferfv(framebuffer, buffer, drawbuffer, tempArr.ptr)
    }

    @PtrReturn
    public fun nglMapNamedBufferRange(
        buffer: Int,
        offset: Long,
        length: Long,
        access: Int,
    ): Ptr

    @CoreOverload
    public fun glMapNamedBufferRange(
        buffer: Int,
        offset: Long,
        length: Long,
        access: Int,
    ): Arr = Arr.wrap(nglMapNamedBufferRange(buffer, offset, length, access).address, length)
}

public const val GL_NEGATIVE_ONE_TO_ONE: Int = 37_726

public const val GL_ZERO_TO_ONE: Int = 37_727

public const val GL_CLIP_ORIGIN: Int = 37_724

public const val GL_CLIP_DEPTH_MODE: Int = 37_725

public const val GL_QUERY_WAIT_INVERTED: Int = 36_375

public const val GL_QUERY_NO_WAIT_INVERTED: Int = 36_376

public const val GL_QUERY_BY_REGION_WAIT_INVERTED: Int = 36_377

public const val GL_QUERY_BY_REGION_NO_WAIT_INVERTED: Int = 36_378

public const val GL_MAX_CULL_DISTANCES: Int = 33_529

public const val GL_MAX_COMBINED_CLIP_AND_CULL_DISTANCES: Int = 33_530

public const val GL_TEXTURE_TARGET: Int = 4_102

public const val GL_QUERY_TARGET: Int = 33_514

public const val GL_CONTEXT_RELEASE_BEHAVIOR: Int = 33_531

public const val GL_CONTEXT_RELEASE_BEHAVIOR_FLUSH: Int = 33_532

public const val GL_GUILTY_CONTEXT_RESET: Int = 33_363

public const val GL_INNOCENT_CONTEXT_RESET: Int = 33_364

public const val GL_UNKNOWN_CONTEXT_RESET: Int = 33_365

public const val GL_RESET_NOTIFICATION_STRATEGY: Int = 33_366

public const val GL_LOSE_CONTEXT_ON_RESET: Int = 33_362

public const val GL_NO_RESET_NOTIFICATION: Int = 33_377

public const val GL_CONTEXT_FLAG_ROBUST_ACCESS_BIT: Int = 4

public const val GL_CONTEXT_LOST: Int = 1_287

public inline fun glClipControl(origin: Int, depth: Int): Unit =
        GLWrapper.instance.GL45.glClipControl(origin, depth)

public inline fun glCreateTransformFeedbacks(n: Int, ids: Ptr): Unit =
        GLWrapper.instance.GL45.glCreateTransformFeedbacks(n, ids)

public inline fun glCreateTransformFeedbacks(n: Int, ids: Long): Unit =
        GLWrapper.instance.GL45.glCreateTransformFeedbacks(n, ids)

public inline fun glTransformFeedbackBufferBase(
    xfb: Int,
    index: Int,
    buffer: Int,
): Unit = GLWrapper.instance.GL45.glTransformFeedbackBufferBase(xfb, index, buffer)

public inline fun glTransformFeedbackBufferRange(
    xfb: Int,
    index: Int,
    buffer: Int,
    offset: Long,
    size: Long,
): Unit = GLWrapper.instance.GL45.glTransformFeedbackBufferRange(xfb, index, buffer, offset, size)

public inline fun glGetTransformFeedbackiv(
    xfb: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTransformFeedbackiv(xfb, pname, `param`)

public inline fun glGetTransformFeedbackiv(
    xfb: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.GL45.glGetTransformFeedbackiv(xfb, pname, `param`)

public inline fun glGetTransformFeedbacki_v(
    xfb: Int,
    pname: Int,
    index: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTransformFeedbacki_v(xfb, pname, index, `param`)

public inline fun glGetTransformFeedbacki_v(
    xfb: Int,
    pname: Int,
    index: Int,
    `param`: Long,
): Unit = GLWrapper.instance.GL45.glGetTransformFeedbacki_v(xfb, pname, index, `param`)

public inline fun glGetTransformFeedbacki64_v(
    xfb: Int,
    pname: Int,
    index: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTransformFeedbacki64_v(xfb, pname, index, `param`)

public inline fun glGetTransformFeedbacki64_v(
    xfb: Int,
    pname: Int,
    index: Int,
    `param`: Long,
): Unit = GLWrapper.instance.GL45.glGetTransformFeedbacki64_v(xfb, pname, index, `param`)

public inline fun glCreateBuffers(n: Int, buffers: Ptr): Unit =
        GLWrapper.instance.GL45.glCreateBuffers(n, buffers)

public inline fun glCreateBuffers(n: Int, buffers: Long): Unit =
        GLWrapper.instance.GL45.glCreateBuffers(n, buffers)

public inline fun glNamedBufferStorage(
    buffer: Int,
    size: Long,
    `data`: Ptr,
    flags: Int,
): Unit = GLWrapper.instance.GL45.glNamedBufferStorage(buffer, size, `data`, flags)

public inline fun glNamedBufferStorage(
    buffer: Int,
    size: Long,
    `data`: Long,
    flags: Int,
): Unit = GLWrapper.instance.GL45.glNamedBufferStorage(buffer, size, `data`, flags)

public inline fun glNamedBufferData(
    buffer: Int,
    size: Long,
    `data`: Ptr,
    usage: Int,
): Unit = GLWrapper.instance.GL45.glNamedBufferData(buffer, size, `data`, usage)

public inline fun glNamedBufferData(
    buffer: Int,
    size: Long,
    `data`: Long,
    usage: Int,
): Unit = GLWrapper.instance.GL45.glNamedBufferData(buffer, size, `data`, usage)

public inline fun glNamedBufferSubData(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL45.glNamedBufferSubData(buffer, offset, size, `data`)

public inline fun glNamedBufferSubData(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
): Unit = GLWrapper.instance.GL45.glNamedBufferSubData(buffer, offset, size, `data`)

public inline fun glCopyNamedBufferSubData(
    readBuffer: Int,
    writeBuffer: Int,
    readOffset: Long,
    writeOffset: Long,
    size: Long,
): Unit = GLWrapper.instance.GL45.glCopyNamedBufferSubData(readBuffer, writeBuffer, readOffset,
        writeOffset, size)

public inline fun glClearNamedBufferData(
    buffer: Int,
    internalformat: Int,
    format: Int,
    type: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL45.glClearNamedBufferData(buffer, internalformat, format, type,
        `data`)

public inline fun glClearNamedBufferData(
    buffer: Int,
    internalformat: Int,
    format: Int,
    type: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL45.glClearNamedBufferData(buffer, internalformat, format, type,
        `data`)

public inline fun glClearNamedBufferSubData(
    buffer: Int,
    internalformat: Int,
    offset: Long,
    size: Long,
    format: Int,
    type: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL45.glClearNamedBufferSubData(buffer, internalformat, offset, size,
        format, type, `data`)

public inline fun glClearNamedBufferSubData(
    buffer: Int,
    internalformat: Int,
    offset: Long,
    size: Long,
    format: Int,
    type: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL45.glClearNamedBufferSubData(buffer, internalformat, offset, size,
        format, type, `data`)

public inline fun glMapNamedBuffer(buffer: Int, access: Int): Ptr =
        GLWrapper.instance.GL45.glMapNamedBuffer(buffer, access)

public inline fun glUnmapNamedBuffer(buffer: Int): Boolean =
        GLWrapper.instance.GL45.glUnmapNamedBuffer(buffer)

public inline fun glFlushMappedNamedBufferRange(
    buffer: Int,
    offset: Long,
    length: Long,
): Unit = GLWrapper.instance.GL45.glFlushMappedNamedBufferRange(buffer, offset, length)

public inline fun glGetNamedBufferParameteriv(
    buffer: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetNamedBufferParameteriv(buffer, pname, params)

public inline fun glGetNamedBufferParameteriv(
    buffer: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetNamedBufferParameteriv(buffer, pname, params)

public inline fun glGetNamedBufferParameteri64v(
    buffer: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetNamedBufferParameteri64v(buffer, pname, params)

public inline fun glGetNamedBufferParameteri64v(
    buffer: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetNamedBufferParameteri64v(buffer, pname, params)

public inline fun glGetNamedBufferPointerv(
    buffer: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetNamedBufferPointerv(buffer, pname, params)

public inline fun glGetNamedBufferPointerv(
    buffer: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetNamedBufferPointerv(buffer, pname, params)

public inline fun glGetNamedBufferSubData(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL45.glGetNamedBufferSubData(buffer, offset, size, `data`)

public inline fun glGetNamedBufferSubData(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
): Unit = GLWrapper.instance.GL45.glGetNamedBufferSubData(buffer, offset, size, `data`)

public inline fun glCreateFramebuffers(n: Int, framebuffers: Ptr): Unit =
        GLWrapper.instance.GL45.glCreateFramebuffers(n, framebuffers)

public inline fun glCreateFramebuffers(n: Int, framebuffers: Long): Unit =
        GLWrapper.instance.GL45.glCreateFramebuffers(n, framebuffers)

public inline fun glNamedFramebufferRenderbuffer(
    framebuffer: Int,
    attachment: Int,
    renderbuffertarget: Int,
    renderbuffer: Int,
): Unit = GLWrapper.instance.GL45.glNamedFramebufferRenderbuffer(framebuffer, attachment,
        renderbuffertarget, renderbuffer)

public inline fun glNamedFramebufferParameteri(
    framebuffer: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.GL45.glNamedFramebufferParameteri(framebuffer, pname, `param`)

public inline fun glNamedFramebufferTexture(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.GL45.glNamedFramebufferTexture(framebuffer, attachment, texture, level)

public inline fun glNamedFramebufferTextureLayer(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    layer: Int,
): Unit = GLWrapper.instance.GL45.glNamedFramebufferTextureLayer(framebuffer, attachment, texture,
        level, layer)

public inline fun glNamedFramebufferDrawBuffer(framebuffer: Int, buf: Int): Unit =
        GLWrapper.instance.GL45.glNamedFramebufferDrawBuffer(framebuffer, buf)

public inline fun glNamedFramebufferDrawBuffers(
    framebuffer: Int,
    n: Int,
    bufs: Ptr,
): Unit = GLWrapper.instance.GL45.glNamedFramebufferDrawBuffers(framebuffer, n, bufs)

public inline fun glNamedFramebufferDrawBuffers(
    framebuffer: Int,
    n: Int,
    bufs: Long,
): Unit = GLWrapper.instance.GL45.glNamedFramebufferDrawBuffers(framebuffer, n, bufs)

public inline fun glNamedFramebufferReadBuffer(framebuffer: Int, src: Int): Unit =
        GLWrapper.instance.GL45.glNamedFramebufferReadBuffer(framebuffer, src)

public inline fun glInvalidateNamedFramebufferData(
    framebuffer: Int,
    numAttachments: Int,
    attachments: Ptr,
): Unit = GLWrapper.instance.GL45.glInvalidateNamedFramebufferData(framebuffer, numAttachments,
        attachments)

public inline fun glInvalidateNamedFramebufferData(
    framebuffer: Int,
    numAttachments: Int,
    attachments: Long,
): Unit = GLWrapper.instance.GL45.glInvalidateNamedFramebufferData(framebuffer, numAttachments,
        attachments)

public inline fun glInvalidateNamedFramebufferSubData(
    framebuffer: Int,
    numAttachments: Int,
    attachments: Ptr,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL45.glInvalidateNamedFramebufferSubData(framebuffer, numAttachments,
        attachments, x, y, width, height)

public inline fun glInvalidateNamedFramebufferSubData(
    framebuffer: Int,
    numAttachments: Int,
    attachments: Long,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL45.glInvalidateNamedFramebufferSubData(framebuffer, numAttachments,
        attachments, x, y, width, height)

public inline fun glClearNamedFramebufferiv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferiv(framebuffer, buffer, drawbuffer,
        `value`)

public inline fun glClearNamedFramebufferiv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferiv(framebuffer, buffer, drawbuffer,
        `value`)

public inline fun glClearNamedFramebufferuiv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferuiv(framebuffer, buffer, drawbuffer,
        `value`)

public inline fun glClearNamedFramebufferuiv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferuiv(framebuffer, buffer, drawbuffer,
        `value`)

public inline fun glClearNamedFramebufferfv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferfv(framebuffer, buffer, drawbuffer,
        `value`)

public inline fun glClearNamedFramebufferfv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferfv(framebuffer, buffer, drawbuffer,
        `value`)

public inline fun glClearNamedFramebufferfi(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    depth: Float,
    stencil: Int,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferfi(framebuffer, buffer, drawbuffer, depth,
        stencil)

public inline fun glBlitNamedFramebuffer(
    readFramebuffer: Int,
    drawFramebuffer: Int,
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    mask: Int,
    filter: Int,
): Unit = GLWrapper.instance.GL45.glBlitNamedFramebuffer(readFramebuffer, drawFramebuffer, srcX0,
        srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter)

public inline fun glCheckNamedFramebufferStatus(framebuffer: Int, target: Int): Int =
        GLWrapper.instance.GL45.glCheckNamedFramebufferStatus(framebuffer, target)

public inline fun glGetNamedFramebufferParameteriv(
    framebuffer: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetNamedFramebufferParameteriv(framebuffer, pname, params)

public inline fun glGetNamedFramebufferParameteriv(
    framebuffer: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetNamedFramebufferParameteriv(framebuffer, pname, params)

public inline fun glGetNamedFramebufferAttachmentParameteriv(
    framebuffer: Int,
    attachment: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetNamedFramebufferAttachmentParameteriv(framebuffer,
        attachment, pname, params)

public inline fun glGetNamedFramebufferAttachmentParameteriv(
    framebuffer: Int,
    attachment: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetNamedFramebufferAttachmentParameteriv(framebuffer,
        attachment, pname, params)

public inline fun glCreateRenderbuffers(n: Int, renderbuffers: Ptr): Unit =
        GLWrapper.instance.GL45.glCreateRenderbuffers(n, renderbuffers)

public inline fun glCreateRenderbuffers(n: Int, renderbuffers: Long): Unit =
        GLWrapper.instance.GL45.glCreateRenderbuffers(n, renderbuffers)

public inline fun glNamedRenderbufferStorage(
    renderbuffer: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL45.glNamedRenderbufferStorage(renderbuffer, internalformat, width,
        height)

public inline fun glNamedRenderbufferStorageMultisample(
    renderbuffer: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL45.glNamedRenderbufferStorageMultisample(renderbuffer, samples,
        internalformat, width, height)

public inline fun glGetNamedRenderbufferParameteriv(
    renderbuffer: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetNamedRenderbufferParameteriv(renderbuffer, pname, params)

public inline fun glGetNamedRenderbufferParameteriv(
    renderbuffer: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetNamedRenderbufferParameteriv(renderbuffer, pname, params)

public inline fun glCreateTextures(
    target: Int,
    n: Int,
    textures: Ptr,
): Unit = GLWrapper.instance.GL45.glCreateTextures(target, n, textures)

public inline fun glCreateTextures(
    target: Int,
    n: Int,
    textures: Long,
): Unit = GLWrapper.instance.GL45.glCreateTextures(target, n, textures)

public inline fun glTextureBuffer(
    texture: Int,
    internalformat: Int,
    buffer: Int,
): Unit = GLWrapper.instance.GL45.glTextureBuffer(texture, internalformat, buffer)

public inline fun glTextureBufferRange(
    texture: Int,
    internalformat: Int,
    buffer: Int,
    offset: Long,
    size: Long,
): Unit = GLWrapper.instance.GL45.glTextureBufferRange(texture, internalformat, buffer, offset,
        size)

public inline fun glTextureStorage1D(
    texture: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
): Unit = GLWrapper.instance.GL45.glTextureStorage1D(texture, levels, internalformat, width)

public inline fun glTextureStorage2D(
    texture: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL45.glTextureStorage2D(texture, levels, internalformat, width, height)

public inline fun glTextureStorage3D(
    texture: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
): Unit = GLWrapper.instance.GL45.glTextureStorage3D(texture, levels, internalformat, width, height,
        depth)

public inline fun glTextureStorage2DMultisample(
    texture: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    fixedsamplelocations: Boolean,
): Unit = GLWrapper.instance.GL45.glTextureStorage2DMultisample(texture, samples, internalformat,
        width, height, fixedsamplelocations)

public inline fun glTextureStorage3DMultisample(
    texture: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedsamplelocations: Boolean,
): Unit = GLWrapper.instance.GL45.glTextureStorage3DMultisample(texture, samples, internalformat,
        width, height, depth, fixedsamplelocations)

public inline fun glTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL45.glTextureSubImage1D(texture, level, xoffset, width, format, type,
        pixels)

public inline fun glTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL45.glTextureSubImage1D(texture, level, xoffset, width, format, type,
        pixels)

public inline fun glTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL45.glTextureSubImage2D(texture, level, xoffset, yoffset, width,
        height, format, type, pixels)

public inline fun glTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL45.glTextureSubImage2D(texture, level, xoffset, yoffset, width,
        height, format, type, pixels)

public inline fun glTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL45.glTextureSubImage3D(texture, level, xoffset, yoffset, zoffset,
        width, height, depth, format, type, pixels)

public inline fun glTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL45.glTextureSubImage3D(texture, level, xoffset, yoffset, zoffset,
        width, height, depth, format, type, pixels)

public inline fun glCompressedTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL45.glCompressedTextureSubImage1D(texture, level, xoffset, width,
        format, imageSize, `data`)

public inline fun glCompressedTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL45.glCompressedTextureSubImage1D(texture, level, xoffset, width,
        format, imageSize, `data`)

public inline fun glCompressedTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL45.glCompressedTextureSubImage2D(texture, level, xoffset, yoffset,
        width, height, format, imageSize, `data`)

public inline fun glCompressedTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL45.glCompressedTextureSubImage2D(texture, level, xoffset, yoffset,
        width, height, format, imageSize, `data`)

public inline fun glCompressedTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL45.glCompressedTextureSubImage3D(texture, level, xoffset, yoffset,
        zoffset, width, height, depth, format, imageSize, `data`)

public inline fun glCompressedTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL45.glCompressedTextureSubImage3D(texture, level, xoffset, yoffset,
        zoffset, width, height, depth, format, imageSize, `data`)

public inline fun glCopyTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    x: Int,
    y: Int,
    width: Int,
): Unit = GLWrapper.instance.GL45.glCopyTextureSubImage1D(texture, level, xoffset, x, y, width)

public inline fun glCopyTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL45.glCopyTextureSubImage2D(texture, level, xoffset, yoffset, x, y,
        width, height)

public inline fun glCopyTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL45.glCopyTextureSubImage3D(texture, level, xoffset, yoffset, zoffset,
        x, y, width, height)

public inline fun glTextureParameterf(
    texture: Int,
    pname: Int,
    `param`: Float,
): Unit = GLWrapper.instance.GL45.glTextureParameterf(texture, pname, `param`)

public inline fun glTextureParameterfv(
    texture: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glTextureParameterfv(texture, pname, params)

public inline fun glTextureParameterfv(
    texture: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glTextureParameterfv(texture, pname, params)

public inline fun glTextureParameteri(
    texture: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.GL45.glTextureParameteri(texture, pname, `param`)

public inline fun glTextureParameterIiv(
    texture: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glTextureParameterIiv(texture, pname, params)

public inline fun glTextureParameterIiv(
    texture: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glTextureParameterIiv(texture, pname, params)

public inline fun glTextureParameterIuiv(
    texture: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glTextureParameterIuiv(texture, pname, params)

public inline fun glTextureParameterIuiv(
    texture: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glTextureParameterIuiv(texture, pname, params)

public inline fun glTextureParameteriv(
    texture: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glTextureParameteriv(texture, pname, params)

public inline fun glTextureParameteriv(
    texture: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glTextureParameteriv(texture, pname, params)

public inline fun glGenerateTextureMipmap(texture: Int): Unit =
        GLWrapper.instance.GL45.glGenerateTextureMipmap(texture)

public inline fun glBindTextureUnit(unit: Int, texture: Int): Unit =
        GLWrapper.instance.GL45.glBindTextureUnit(unit, texture)

public inline fun glGetTextureImage(
    texture: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTextureImage(texture, level, format, type, bufSize, pixels)

public inline fun glGetTextureImage(
    texture: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL45.glGetTextureImage(texture, level, format, type, bufSize, pixels)

public inline fun glGetCompressedTextureImage(
    texture: Int,
    level: Int,
    bufSize: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL45.glGetCompressedTextureImage(texture, level, bufSize, pixels)

public inline fun glGetCompressedTextureImage(
    texture: Int,
    level: Int,
    bufSize: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL45.glGetCompressedTextureImage(texture, level, bufSize, pixels)

public inline fun glGetTextureLevelParameterfv(
    texture: Int,
    level: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTextureLevelParameterfv(texture, level, pname, params)

public inline fun glGetTextureLevelParameterfv(
    texture: Int,
    level: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetTextureLevelParameterfv(texture, level, pname, params)

public inline fun glGetTextureLevelParameteriv(
    texture: Int,
    level: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTextureLevelParameteriv(texture, level, pname, params)

public inline fun glGetTextureLevelParameteriv(
    texture: Int,
    level: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetTextureLevelParameteriv(texture, level, pname, params)

public inline fun glGetTextureParameterfv(
    texture: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTextureParameterfv(texture, pname, params)

public inline fun glGetTextureParameterfv(
    texture: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetTextureParameterfv(texture, pname, params)

public inline fun glGetTextureParameterIiv(
    texture: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTextureParameterIiv(texture, pname, params)

public inline fun glGetTextureParameterIiv(
    texture: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetTextureParameterIiv(texture, pname, params)

public inline fun glGetTextureParameterIuiv(
    texture: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTextureParameterIuiv(texture, pname, params)

public inline fun glGetTextureParameterIuiv(
    texture: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetTextureParameterIuiv(texture, pname, params)

public inline fun glGetTextureParameteriv(
    texture: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTextureParameteriv(texture, pname, params)

public inline fun glGetTextureParameteriv(
    texture: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetTextureParameteriv(texture, pname, params)

public inline fun glCreateVertexArrays(n: Int, arrays: Ptr): Unit =
        GLWrapper.instance.GL45.glCreateVertexArrays(n, arrays)

public inline fun glCreateVertexArrays(n: Int, arrays: Long): Unit =
        GLWrapper.instance.GL45.glCreateVertexArrays(n, arrays)

public inline fun glDisableVertexArrayAttrib(vaobj: Int, index: Int): Unit =
        GLWrapper.instance.GL45.glDisableVertexArrayAttrib(vaobj, index)

public inline fun glEnableVertexArrayAttrib(vaobj: Int, index: Int): Unit =
        GLWrapper.instance.GL45.glEnableVertexArrayAttrib(vaobj, index)

public inline fun glVertexArrayElementBuffer(vaobj: Int, buffer: Int): Unit =
        GLWrapper.instance.GL45.glVertexArrayElementBuffer(vaobj, buffer)

public inline fun glVertexArrayVertexBuffer(
    vaobj: Int,
    bindingindex: Int,
    buffer: Int,
    offset: Long,
    stride: Int,
): Unit = GLWrapper.instance.GL45.glVertexArrayVertexBuffer(vaobj, bindingindex, buffer, offset,
        stride)

public inline fun glVertexArrayVertexBuffers(
    vaobj: Int,
    first: Int,
    count: Int,
    buffers: Ptr,
    offsets: Ptr,
    strides: Ptr,
): Unit = GLWrapper.instance.GL45.glVertexArrayVertexBuffers(vaobj, first, count, buffers, offsets,
        strides)

public inline fun glVertexArrayVertexBuffers(
    vaobj: Int,
    first: Int,
    count: Int,
    buffers: Long,
    offsets: Long,
    strides: Long,
): Unit = GLWrapper.instance.GL45.glVertexArrayVertexBuffers(vaobj, first, count, buffers, offsets,
        strides)

public inline fun glVertexArrayAttribFormat(
    vaobj: Int,
    attribindex: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    relativeoffset: Int,
): Unit = GLWrapper.instance.GL45.glVertexArrayAttribFormat(vaobj, attribindex, size, type,
        normalized, relativeoffset)

public inline fun glVertexArrayAttribIFormat(
    vaobj: Int,
    attribindex: Int,
    size: Int,
    type: Int,
    relativeoffset: Int,
): Unit = GLWrapper.instance.GL45.glVertexArrayAttribIFormat(vaobj, attribindex, size, type,
        relativeoffset)

public inline fun glVertexArrayAttribLFormat(
    vaobj: Int,
    attribindex: Int,
    size: Int,
    type: Int,
    relativeoffset: Int,
): Unit = GLWrapper.instance.GL45.glVertexArrayAttribLFormat(vaobj, attribindex, size, type,
        relativeoffset)

public inline fun glVertexArrayAttribBinding(
    vaobj: Int,
    attribindex: Int,
    bindingindex: Int,
): Unit = GLWrapper.instance.GL45.glVertexArrayAttribBinding(vaobj, attribindex, bindingindex)

public inline fun glVertexArrayBindingDivisor(
    vaobj: Int,
    bindingindex: Int,
    divisor: Int,
): Unit = GLWrapper.instance.GL45.glVertexArrayBindingDivisor(vaobj, bindingindex, divisor)

public inline fun glGetVertexArrayiv(
    vaobj: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.GL45.glGetVertexArrayiv(vaobj, pname, `param`)

public inline fun glGetVertexArrayiv(
    vaobj: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.GL45.glGetVertexArrayiv(vaobj, pname, `param`)

public inline fun glGetVertexArrayIndexediv(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.GL45.glGetVertexArrayIndexediv(vaobj, index, pname, `param`)

public inline fun glGetVertexArrayIndexediv(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.GL45.glGetVertexArrayIndexediv(vaobj, index, pname, `param`)

public inline fun glGetVertexArrayIndexed64iv(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Ptr,
): Unit = GLWrapper.instance.GL45.glGetVertexArrayIndexed64iv(vaobj, index, pname, `param`)

public inline fun glGetVertexArrayIndexed64iv(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Long,
): Unit = GLWrapper.instance.GL45.glGetVertexArrayIndexed64iv(vaobj, index, pname, `param`)

public inline fun glCreateSamplers(n: Int, samplers: Ptr): Unit =
        GLWrapper.instance.GL45.glCreateSamplers(n, samplers)

public inline fun glCreateSamplers(n: Int, samplers: Long): Unit =
        GLWrapper.instance.GL45.glCreateSamplers(n, samplers)

public inline fun glCreateProgramPipelines(n: Int, pipelines: Ptr): Unit =
        GLWrapper.instance.GL45.glCreateProgramPipelines(n, pipelines)

public inline fun glCreateProgramPipelines(n: Int, pipelines: Long): Unit =
        GLWrapper.instance.GL45.glCreateProgramPipelines(n, pipelines)

public inline fun glCreateQueries(
    target: Int,
    n: Int,
    ids: Ptr,
): Unit = GLWrapper.instance.GL45.glCreateQueries(target, n, ids)

public inline fun glCreateQueries(
    target: Int,
    n: Int,
    ids: Long,
): Unit = GLWrapper.instance.GL45.glCreateQueries(target, n, ids)

public inline fun glGetQueryBufferObjectiv(
    id: Int,
    buffer: Int,
    pname: Int,
    offset: Long,
): Unit = GLWrapper.instance.GL45.glGetQueryBufferObjectiv(id, buffer, pname, offset)

public inline fun glGetQueryBufferObjectuiv(
    id: Int,
    buffer: Int,
    pname: Int,
    offset: Long,
): Unit = GLWrapper.instance.GL45.glGetQueryBufferObjectuiv(id, buffer, pname, offset)

public inline fun glGetQueryBufferObjecti64v(
    id: Int,
    buffer: Int,
    pname: Int,
    offset: Long,
): Unit = GLWrapper.instance.GL45.glGetQueryBufferObjecti64v(id, buffer, pname, offset)

public inline fun glGetQueryBufferObjectui64v(
    id: Int,
    buffer: Int,
    pname: Int,
    offset: Long,
): Unit = GLWrapper.instance.GL45.glGetQueryBufferObjectui64v(id, buffer, pname, offset)

public inline fun glMemoryBarrierByRegion(barriers: Int): Unit =
        GLWrapper.instance.GL45.glMemoryBarrierByRegion(barriers)

public inline fun glGetTextureSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL45.glGetTextureSubImage(texture, level, xoffset, yoffset, zoffset,
        width, height, depth, format, type, bufSize, pixels)

public inline fun glGetTextureSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL45.glGetTextureSubImage(texture, level, xoffset, yoffset, zoffset,
        width, height, depth, format, type, bufSize, pixels)

public inline fun glGetCompressedTextureSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    bufSize: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL45.glGetCompressedTextureSubImage(texture, level, xoffset, yoffset,
        zoffset, width, height, depth, bufSize, pixels)

public inline fun glGetCompressedTextureSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    bufSize: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL45.glGetCompressedTextureSubImage(texture, level, xoffset, yoffset,
        zoffset, width, height, depth, bufSize, pixels)

public inline fun glTextureBarrier(): Unit = GLWrapper.instance.GL45.glTextureBarrier()

public inline fun glGetGraphicsResetStatus(): Int =
        GLWrapper.instance.GL45.glGetGraphicsResetStatus()

public inline fun glGetnTexImage(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    img: Ptr,
): Unit = GLWrapper.instance.GL45.glGetnTexImage(tex, level, format, type, bufSize, img)

public inline fun glGetnTexImage(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    img: Long,
): Unit = GLWrapper.instance.GL45.glGetnTexImage(tex, level, format, type, bufSize, img)

public inline fun glReadnPixels(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    pixels: Ptr,
): Unit = GLWrapper.instance.GL45.glReadnPixels(x, y, width, height, format, type, bufSize, pixels)

public inline fun glReadnPixels(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    pixels: Long,
): Unit = GLWrapper.instance.GL45.glReadnPixels(x, y, width, height, format, type, bufSize, pixels)

public inline fun glGetnCompressedTexImage(
    target: Int,
    level: Int,
    bufSize: Int,
    img: Ptr,
): Unit = GLWrapper.instance.GL45.glGetnCompressedTexImage(target, level, bufSize, img)

public inline fun glGetnCompressedTexImage(
    target: Int,
    level: Int,
    bufSize: Int,
    img: Long,
): Unit = GLWrapper.instance.GL45.glGetnCompressedTexImage(target, level, bufSize, img)

public inline fun glGetnUniformfv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetnUniformfv(program, location, bufSize, params)

public inline fun glGetnUniformfv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetnUniformfv(program, location, bufSize, params)

public inline fun glGetnUniformdv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetnUniformdv(program, location, bufSize, params)

public inline fun glGetnUniformdv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetnUniformdv(program, location, bufSize, params)

public inline fun glGetnUniformiv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetnUniformiv(program, location, bufSize, params)

public inline fun glGetnUniformiv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetnUniformiv(program, location, bufSize, params)

public inline fun glGetnUniformuiv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL45.glGetnUniformuiv(program, location, bufSize, params)

public inline fun glGetnUniformuiv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.GL45.glGetnUniformuiv(program, location, bufSize, params)

public inline fun glCreateBuffers(): Int = GLWrapper.instance.GL45.glCreateBuffers()

public inline fun glCreateRenderbuffers(): Int = GLWrapper.instance.GL45.glCreateRenderbuffers()

public inline fun glCreateSamplers(): Int = GLWrapper.instance.GL45.glCreateSamplers()

public inline fun glCreateFramebuffers(): Int = GLWrapper.instance.GL45.glCreateFramebuffers()

public inline fun glCreateVertexArrays(): Int = GLWrapper.instance.GL45.glCreateVertexArrays()

public inline fun glCreateTextures(target: Int): Int =
        GLWrapper.instance.GL45.glCreateTextures(target)

public inline fun glCreateProgramPipelines(): Int =
        GLWrapper.instance.GL45.glCreateProgramPipelines()

public inline fun glCreateQueries(target: Int): Int =
        GLWrapper.instance.GL45.glCreateQueries(target)

public inline fun glCreateTransformFeedbacks(): Int =
        GLWrapper.instance.GL45.glCreateTransformFeedbacks()

public inline fun glTextureParameterfv(
    texture: Int,
    pname: Int,
    v1: Float,
    v2: Float,
    v3: Float,
    v4: Float,
): Unit = GLWrapper.instance.GL45.glTextureParameterfv(texture, pname, v1, v2, v3, v4)

public inline fun glTextureParameteriv(
    texture: Int,
    pname: Int,
    v1: Int,
    v2: Int,
    v3: Int,
    v4: Int,
): Unit = GLWrapper.instance.GL45.glTextureParameteriv(texture, pname, v1, v2, v3, v4)

public inline fun glClearNamedFramebufferi(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    stencil: Int,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferi(framebuffer, buffer, drawbuffer, stencil)

public inline fun glClearNamedFramebufferf(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    red: Float,
    green: Float,
    blue: Float,
    alpha: Float,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferf(framebuffer, buffer, drawbuffer, red,
        green, blue, alpha)

public inline fun glClearNamedFramebufferf(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    depth: Float,
): Unit = GLWrapper.instance.GL45.glClearNamedFramebufferf(framebuffer, buffer, drawbuffer, depth)

public inline fun nglMapNamedBufferRange(
    buffer: Int,
    offset: Long,
    length: Long,
    access: Int,
): Ptr = GLWrapper.instance.GL45.nglMapNamedBufferRange(buffer, offset, length, access)

public inline fun glMapNamedBufferRange(
    buffer: Int,
    offset: Long,
    length: Long,
    access: Int,
): Arr = GLWrapper.instance.GL45.glMapNamedBufferRange(buffer, offset, length, access)
