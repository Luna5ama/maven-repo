@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVVertexArrayRange2 : GLBase

public const val GL_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH_NV: Int = 34_099
