@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL31 : GLBase {
    public fun glDrawArraysInstanced(
        mode: Int,
        first: Int,
        count: Int,
        primcount: Int,
    )

    @PtrParameter([3])
    public fun glDrawElementsInstanced(
        mode: Int,
        count: Int,
        type: Int,
        indices: Ptr,
        primcount: Int,
    )

    @Unsafe
    public fun glDrawElementsInstanced(
        mode: Int,
        count: Int,
        type: Int,
        indices: Long,
        primcount: Int,
    )

    public fun glCopyBufferSubData(
        readTarget: Int,
        writeTarget: Int,
        readOffset: Long,
        writeOffset: Long,
        size: Long,
    )

    public fun glPrimitiveRestartIndex(index: Int)

    public fun glTexBuffer(
        target: Int,
        internalformat: Int,
        buffer: Int,
    )

    @PtrParameter([2, 3])
    public fun glGetUniformIndices(
        program: Int,
        uniformCount: Int,
        uniformNames: Ptr,
        uniformIndices: Ptr,
    )

    @Unsafe
    public fun glGetUniformIndices(
        program: Int,
        uniformCount: Int,
        uniformNames: Long,
        uniformIndices: Long,
    )

    @PtrParameter([2, 4])
    public fun glGetActiveUniformsiv(
        program: Int,
        uniformCount: Int,
        uniformIndices: Ptr,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetActiveUniformsiv(
        program: Int,
        uniformCount: Int,
        uniformIndices: Long,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3, 4])
    public fun glGetActiveUniformName(
        program: Int,
        uniformIndex: Int,
        bufSize: Int,
        length: Ptr,
        uniformName: Ptr,
    )

    @Unsafe
    public fun glGetActiveUniformName(
        program: Int,
        uniformIndex: Int,
        bufSize: Int,
        length: Long,
        uniformName: Long,
    )

    @PtrParameter([1])
    public fun glGetUniformBlockIndex(program: Int, uniformBlockName: Ptr): Int

    @Unsafe
    public fun glGetUniformBlockIndex(program: Int, uniformBlockName: Long): Int

    @PtrParameter([3])
    public fun glGetActiveUniformBlockiv(
        program: Int,
        uniformBlockIndex: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetActiveUniformBlockiv(
        program: Int,
        uniformBlockIndex: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([3, 4])
    public fun glGetActiveUniformBlockName(
        program: Int,
        uniformBlockIndex: Int,
        bufSize: Int,
        length: Ptr,
        uniformBlockName: Ptr,
    )

    @Unsafe
    public fun glGetActiveUniformBlockName(
        program: Int,
        uniformBlockIndex: Int,
        bufSize: Int,
        length: Long,
        uniformBlockName: Long,
    )

    public fun glUniformBlockBinding(
        program: Int,
        uniformBlockIndex: Int,
        uniformBlockBinding: Int,
    )
}

public const val GL_R8_SNORM: Int = 36_756

public const val GL_RG8_SNORM: Int = 36_757

public const val GL_RGB8_SNORM: Int = 36_758

public const val GL_RGBA8_SNORM: Int = 36_759

public const val GL_R16_SNORM: Int = 36_760

public const val GL_RG16_SNORM: Int = 36_761

public const val GL_RGB16_SNORM: Int = 36_762

public const val GL_RGBA16_SNORM: Int = 36_763

public const val GL_SIGNED_NORMALIZED: Int = 36_764

public const val GL_SAMPLER_BUFFER: Int = 36_290

public const val GL_INT_SAMPLER_2D_RECT: Int = 36_301

public const val GL_INT_SAMPLER_BUFFER: Int = 36_304

public const val GL_UNSIGNED_INT_SAMPLER_2D_RECT: Int = 36_309

public const val GL_UNSIGNED_INT_SAMPLER_BUFFER: Int = 36_312

public const val GL_COPY_READ_BUFFER: Int = 36_662

public const val GL_COPY_WRITE_BUFFER: Int = 36_663

public const val GL_PRIMITIVE_RESTART: Int = 36_765

public const val GL_PRIMITIVE_RESTART_INDEX: Int = 36_766

public const val GL_TEXTURE_BUFFER: Int = 35_882

public const val GL_MAX_TEXTURE_BUFFER_SIZE: Int = 35_883

public const val GL_TEXTURE_BINDING_BUFFER: Int = 35_884

public const val GL_TEXTURE_BUFFER_DATA_STORE_BINDING: Int = 35_885

public const val GL_TEXTURE_RECTANGLE: Int = 34_037

public const val GL_TEXTURE_BINDING_RECTANGLE: Int = 34_038

public const val GL_PROXY_TEXTURE_RECTANGLE: Int = 34_039

public const val GL_MAX_RECTANGLE_TEXTURE_SIZE: Int = 34_040

public const val GL_SAMPLER_2D_RECT: Int = 35_683

public const val GL_SAMPLER_2D_RECT_SHADOW: Int = 35_684

public const val GL_UNIFORM_BUFFER: Int = 35_345

public const val GL_UNIFORM_BUFFER_BINDING: Int = 35_368

public const val GL_UNIFORM_BUFFER_START: Int = 35_369

public const val GL_UNIFORM_BUFFER_SIZE: Int = 35_370

public const val GL_MAX_VERTEX_UNIFORM_BLOCKS: Int = 35_371

public const val GL_MAX_GEOMETRY_UNIFORM_BLOCKS: Int = 35_372

public const val GL_MAX_FRAGMENT_UNIFORM_BLOCKS: Int = 35_373

public const val GL_MAX_COMBINED_UNIFORM_BLOCKS: Int = 35_374

public const val GL_MAX_UNIFORM_BUFFER_BINDINGS: Int = 35_375

public const val GL_MAX_UNIFORM_BLOCK_SIZE: Int = 35_376

public const val GL_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS: Int = 35_377

public const val GL_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS: Int = 35_378

public const val GL_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS: Int = 35_379

public const val GL_UNIFORM_BUFFER_OFFSET_ALIGNMENT: Int = 35_380

public const val GL_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH: Int = 35_381

public const val GL_ACTIVE_UNIFORM_BLOCKS: Int = 35_382

public const val GL_UNIFORM_TYPE: Int = 35_383

public const val GL_UNIFORM_SIZE: Int = 35_384

public const val GL_UNIFORM_NAME_LENGTH: Int = 35_385

public const val GL_UNIFORM_BLOCK_INDEX: Int = 35_386

public const val GL_UNIFORM_OFFSET: Int = 35_387

public const val GL_UNIFORM_ARRAY_STRIDE: Int = 35_388

public const val GL_UNIFORM_MATRIX_STRIDE: Int = 35_389

public const val GL_UNIFORM_IS_ROW_MAJOR: Int = 35_390

public const val GL_UNIFORM_BLOCK_BINDING: Int = 35_391

public const val GL_UNIFORM_BLOCK_DATA_SIZE: Int = 35_392

public const val GL_UNIFORM_BLOCK_NAME_LENGTH: Int = 35_393

public const val GL_UNIFORM_BLOCK_ACTIVE_UNIFORMS: Int = 35_394

public const val GL_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES: Int = 35_395

public const val GL_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER: Int = 35_396

public const val GL_UNIFORM_BLOCK_REFERENCED_BY_GEOMETRY_SHADER: Int = 35_397

public const val GL_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER: Int = 35_398

public const val GL_INVALID_INDEX: Int = 1

public inline fun glDrawArraysInstanced(
    mode: Int,
    first: Int,
    count: Int,
    primcount: Int,
): Unit = GLWrapper.instance.GL31.glDrawArraysInstanced(mode, first, count, primcount)

public inline fun glDrawElementsInstanced(
    mode: Int,
    count: Int,
    type: Int,
    indices: Ptr,
    primcount: Int,
): Unit = GLWrapper.instance.GL31.glDrawElementsInstanced(mode, count, type, indices, primcount)

public inline fun glDrawElementsInstanced(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
): Unit = GLWrapper.instance.GL31.glDrawElementsInstanced(mode, count, type, indices, primcount)

public inline fun glCopyBufferSubData(
    readTarget: Int,
    writeTarget: Int,
    readOffset: Long,
    writeOffset: Long,
    size: Long,
): Unit = GLWrapper.instance.GL31.glCopyBufferSubData(readTarget, writeTarget, readOffset,
        writeOffset, size)

public inline fun glPrimitiveRestartIndex(index: Int): Unit =
        GLWrapper.instance.GL31.glPrimitiveRestartIndex(index)

public inline fun glTexBuffer(
    target: Int,
    internalformat: Int,
    buffer: Int,
): Unit = GLWrapper.instance.GL31.glTexBuffer(target, internalformat, buffer)

public inline fun glGetUniformIndices(
    program: Int,
    uniformCount: Int,
    uniformNames: Ptr,
    uniformIndices: Ptr,
): Unit = GLWrapper.instance.GL31.glGetUniformIndices(program, uniformCount, uniformNames,
        uniformIndices)

public inline fun glGetUniformIndices(
    program: Int,
    uniformCount: Int,
    uniformNames: Long,
    uniformIndices: Long,
): Unit = GLWrapper.instance.GL31.glGetUniformIndices(program, uniformCount, uniformNames,
        uniformIndices)

public inline fun glGetActiveUniformsiv(
    program: Int,
    uniformCount: Int,
    uniformIndices: Ptr,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL31.glGetActiveUniformsiv(program, uniformCount, uniformIndices,
        pname, params)

public inline fun glGetActiveUniformsiv(
    program: Int,
    uniformCount: Int,
    uniformIndices: Long,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL31.glGetActiveUniformsiv(program, uniformCount, uniformIndices,
        pname, params)

public inline fun glGetActiveUniformName(
    program: Int,
    uniformIndex: Int,
    bufSize: Int,
    length: Ptr,
    uniformName: Ptr,
): Unit = GLWrapper.instance.GL31.glGetActiveUniformName(program, uniformIndex, bufSize, length,
        uniformName)

public inline fun glGetActiveUniformName(
    program: Int,
    uniformIndex: Int,
    bufSize: Int,
    length: Long,
    uniformName: Long,
): Unit = GLWrapper.instance.GL31.glGetActiveUniformName(program, uniformIndex, bufSize, length,
        uniformName)

public inline fun glGetUniformBlockIndex(program: Int, uniformBlockName: Ptr): Int =
        GLWrapper.instance.GL31.glGetUniformBlockIndex(program, uniformBlockName)

public inline fun glGetUniformBlockIndex(program: Int, uniformBlockName: Long): Int =
        GLWrapper.instance.GL31.glGetUniformBlockIndex(program, uniformBlockName)

public inline fun glGetActiveUniformBlockiv(
    program: Int,
    uniformBlockIndex: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL31.glGetActiveUniformBlockiv(program, uniformBlockIndex, pname,
        params)

public inline fun glGetActiveUniformBlockiv(
    program: Int,
    uniformBlockIndex: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL31.glGetActiveUniformBlockiv(program, uniformBlockIndex, pname,
        params)

public inline fun glGetActiveUniformBlockName(
    program: Int,
    uniformBlockIndex: Int,
    bufSize: Int,
    length: Ptr,
    uniformBlockName: Ptr,
): Unit = GLWrapper.instance.GL31.glGetActiveUniformBlockName(program, uniformBlockIndex, bufSize,
        length, uniformBlockName)

public inline fun glGetActiveUniformBlockName(
    program: Int,
    uniformBlockIndex: Int,
    bufSize: Int,
    length: Long,
    uniformBlockName: Long,
): Unit = GLWrapper.instance.GL31.glGetActiveUniformBlockName(program, uniformBlockIndex, bufSize,
        length, uniformBlockName)

public inline fun glUniformBlockBinding(
    program: Int,
    uniformBlockIndex: Int,
    uniformBlockBinding: Int,
): Unit = GLWrapper.instance.GL31.glUniformBlockBinding(program, uniformBlockIndex,
        uniformBlockBinding)
