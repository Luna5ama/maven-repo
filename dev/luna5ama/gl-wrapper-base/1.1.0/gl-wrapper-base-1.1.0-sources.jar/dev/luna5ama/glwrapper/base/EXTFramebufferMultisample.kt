@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTFramebufferMultisample : GLBase {
    public fun glRenderbufferStorageMultisampleEXT(
        target: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )
}

public const val GL_RENDERBUFFER_SAMPLES_EXT: Int = 36_011

public const val GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE_EXT: Int = 36_182

public const val GL_MAX_SAMPLES_EXT: Int = 36_183

public inline fun glRenderbufferStorageMultisampleEXT(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.EXTFramebufferMultisample.glRenderbufferStorageMultisampleEXT(target,
        samples, internalformat, width, height)
