@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL30 : GLBase {
    @PtrReturn
    public fun glGetStringi(name: Int, index: Int): Ptr

    @PtrParameter([2])
    public fun glClearBufferiv(
        buffer: Int,
        drawbuffer: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glClearBufferiv(
        buffer: Int,
        drawbuffer: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glClearBufferuiv(
        buffer: Int,
        drawbuffer: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glClearBufferuiv(
        buffer: Int,
        drawbuffer: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glClearBufferfv(
        buffer: Int,
        drawbuffer: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glClearBufferfv(
        buffer: Int,
        drawbuffer: Int,
        `value`: Long,
    )

    public fun glClearBufferfi(
        buffer: Int,
        drawbuffer: Int,
        depth: Float,
        stencil: Int,
    )

    public fun glVertexAttribI1i(index: Int, x: Int)

    public fun glVertexAttribI2i(
        index: Int,
        x: Int,
        y: Int,
    )

    public fun glVertexAttribI3i(
        index: Int,
        x: Int,
        y: Int,
        z: Int,
    )

    public fun glVertexAttribI4i(
        index: Int,
        x: Int,
        y: Int,
        z: Int,
        w: Int,
    )

    public fun glVertexAttribI1ui(index: Int, x: Int)

    public fun glVertexAttribI2ui(
        index: Int,
        x: Int,
        y: Int,
    )

    public fun glVertexAttribI3ui(
        index: Int,
        x: Int,
        y: Int,
        z: Int,
    )

    public fun glVertexAttribI4ui(
        index: Int,
        x: Int,
        y: Int,
        z: Int,
        w: Int,
    )

    @PtrParameter([1])
    public fun glVertexAttribI1iv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI1iv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI2iv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI2iv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI3iv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI3iv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4iv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4iv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI1uiv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI1uiv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI2uiv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI2uiv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI3uiv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI3uiv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4uiv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4uiv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4bv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4bv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4sv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4sv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4ubv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4ubv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttribI4usv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttribI4usv(index: Int, v: Long)

    @PtrParameter([4])
    public fun glVertexAttribIPointer(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glVertexAttribIPointer(
        index: Int,
        size: Int,
        type: Int,
        stride: Int,
        pointer: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribIiv(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribIiv(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribIuiv(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribIuiv(
        index: Int,
        pname: Int,
        params: Long,
    )

    public fun glUniform1ui(location: Int, v0: Int)

    public fun glUniform2ui(
        location: Int,
        v0: Int,
        v1: Int,
    )

    public fun glUniform3ui(
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
    )

    public fun glUniform4ui(
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
        v3: Int,
    )

    @PtrParameter([2])
    public fun glUniform1uiv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1uiv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform2uiv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2uiv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform3uiv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3uiv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform4uiv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4uiv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformuiv(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformuiv(
        program: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glBindFragDataLocation(
        program: Int,
        colorNumber: Int,
        name: Ptr,
    )

    @Unsafe
    public fun glBindFragDataLocation(
        program: Int,
        colorNumber: Int,
        name: Long,
    )

    @PtrParameter([1])
    public fun glGetFragDataLocation(program: Int, name: Ptr): Int

    @Unsafe
    public fun glGetFragDataLocation(program: Int, name: Long): Int

    public fun glBeginConditionalRender(id: Int, mode: Int)

    public fun glEndConditionalRender()

    @PtrReturn
    public fun glMapBufferRange(
        target: Int,
        offset: Long,
        length: Long,
        access: Int,
    ): Ptr

    public fun glFlushMappedBufferRange(
        target: Int,
        offset: Long,
        length: Long,
    )

    public fun glClampColor(target: Int, clamp: Int)

    public fun glIsRenderbuffer(renderbuffer: Int): Boolean

    public fun glBindRenderbuffer(target: Int, renderbuffer: Int)

    @PtrParameter([1])
    public fun glDeleteRenderbuffers(n: Int, renderbuffers: Ptr)

    @Unsafe
    public fun glDeleteRenderbuffers(n: Int, renderbuffers: Long)

    @PtrParameter([1])
    public fun glGenRenderbuffers(n: Int, renderbuffers: Ptr)

    @Unsafe
    public fun glGenRenderbuffers(n: Int, renderbuffers: Long)

    public fun glRenderbufferStorage(
        target: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    public fun glRenderbufferStorageMultisample(
        target: Int,
        samples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([2])
    public fun glGetRenderbufferParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetRenderbufferParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glIsFramebuffer(framebuffer: Int): Boolean

    public fun glBindFramebuffer(target: Int, framebuffer: Int)

    @PtrParameter([1])
    public fun glDeleteFramebuffers(n: Int, framebuffers: Ptr)

    @Unsafe
    public fun glDeleteFramebuffers(n: Int, framebuffers: Long)

    @PtrParameter([1])
    public fun glGenFramebuffers(n: Int, framebuffers: Ptr)

    @Unsafe
    public fun glGenFramebuffers(n: Int, framebuffers: Long)

    public fun glCheckFramebufferStatus(target: Int): Int

    public fun glFramebufferTexture1D(
        target: Int,
        attachment: Int,
        textarget: Int,
        texture: Int,
        level: Int,
    )

    public fun glFramebufferTexture2D(
        target: Int,
        attachment: Int,
        textarget: Int,
        texture: Int,
        level: Int,
    )

    public fun glFramebufferTexture3D(
        target: Int,
        attachment: Int,
        textarget: Int,
        texture: Int,
        level: Int,
        layer: Int,
    )

    public fun glFramebufferTextureLayer(
        target: Int,
        attachment: Int,
        texture: Int,
        level: Int,
        layer: Int,
    )

    public fun glFramebufferRenderbuffer(
        target: Int,
        attachment: Int,
        renderbuffertarget: Int,
        renderbuffer: Int,
    )

    @PtrParameter([3])
    public fun glGetFramebufferAttachmentParameteriv(
        target: Int,
        attachment: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetFramebufferAttachmentParameteriv(
        target: Int,
        attachment: Int,
        pname: Int,
        params: Long,
    )

    public fun glBlitFramebuffer(
        srcX0: Int,
        srcY0: Int,
        srcX1: Int,
        srcY1: Int,
        dstX0: Int,
        dstY0: Int,
        dstX1: Int,
        dstY1: Int,
        mask: Int,
        filter: Int,
    )

    public fun glGenerateMipmap(target: Int)

    @PtrParameter([2])
    public fun glTexParameterIiv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTexParameterIiv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glTexParameterIuiv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glTexParameterIuiv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetTexParameterIiv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTexParameterIiv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetTexParameterIuiv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetTexParameterIuiv(
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glColorMaski(
        buf: Int,
        r: Boolean,
        g: Boolean,
        b: Boolean,
        a: Boolean,
    )

    @PtrParameter([2])
    public fun glGetBooleani_v(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetBooleani_v(
        target: Int,
        index: Int,
        `data`: Long,
    )

    @PtrParameter([2])
    public fun glGetIntegeri_v(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetIntegeri_v(
        target: Int,
        index: Int,
        `data`: Long,
    )

    public fun glEnablei(cap: Int, index: Int)

    public fun glDisablei(target: Int, index: Int)

    public fun glIsEnabledi(target: Int, index: Int): Boolean

    public fun glBindBufferRange(
        target: Int,
        index: Int,
        buffer: Int,
        offset: Long,
        size: Long,
    )

    public fun glBindBufferBase(
        target: Int,
        index: Int,
        buffer: Int,
    )

    public fun glBeginTransformFeedback(primitiveMode: Int)

    public fun glEndTransformFeedback()

    @PtrParameter([2])
    public fun glTransformFeedbackVaryings(
        program: Int,
        count: Int,
        varyings: Ptr,
        bufferMode: Int,
    )

    @Unsafe
    public fun glTransformFeedbackVaryings(
        program: Int,
        count: Int,
        varyings: Long,
        bufferMode: Int,
    )

    @PtrParameter([3, 4, 5, 6])
    public fun glGetTransformFeedbackVarying(
        program: Int,
        index: Int,
        bufSize: Int,
        length: Ptr,
        size: Ptr,
        type: Ptr,
        name: Ptr,
    )

    @Unsafe
    public fun glGetTransformFeedbackVarying(
        program: Int,
        index: Int,
        bufSize: Int,
        length: Long,
        size: Long,
        type: Long,
        name: Long,
    )

    public fun glBindVertexArray(array: Int)

    @PtrParameter([1])
    public fun glDeleteVertexArrays(n: Int, arrays: Ptr)

    @Unsafe
    public fun glDeleteVertexArrays(n: Int, arrays: Long)

    @PtrParameter([1])
    public fun glGenVertexArrays(n: Int, arrays: Ptr)

    @Unsafe
    public fun glGenVertexArrays(n: Int, arrays: Long)

    public fun glIsVertexArray(array: Int): Boolean

    public fun glDeleteRenderbuffers(renderbuffer: Int)

    public fun glDeleteVertexArrays(array: Int)

    public fun glDeleteFramebuffers(framebuffer: Int)
}

public const val GL_MAJOR_VERSION: Int = 33_307

public const val GL_MINOR_VERSION: Int = 33_308

public const val GL_NUM_EXTENSIONS: Int = 33_309

public const val GL_CONTEXT_FLAGS: Int = 33_310

public const val GL_CONTEXT_FLAG_FORWARD_COMPATIBLE_BIT: Int = 1

public const val GL_COMPARE_REF_TO_TEXTURE: Int = 34_894

public const val GL_CLIP_DISTANCE0: Int = 12_288

public const val GL_CLIP_DISTANCE1: Int = 12_289

public const val GL_CLIP_DISTANCE2: Int = 12_290

public const val GL_CLIP_DISTANCE3: Int = 12_291

public const val GL_CLIP_DISTANCE4: Int = 12_292

public const val GL_CLIP_DISTANCE5: Int = 12_293

public const val GL_CLIP_DISTANCE6: Int = 12_294

public const val GL_CLIP_DISTANCE7: Int = 12_295

public const val GL_MAX_CLIP_DISTANCES: Int = 3_378

public const val GL_MAX_VARYING_COMPONENTS: Int = 35_659

public const val GL_VERTEX_ATTRIB_ARRAY_INTEGER: Int = 35_069

public const val GL_SAMPLER_1D_ARRAY: Int = 36_288

public const val GL_SAMPLER_2D_ARRAY: Int = 36_289

public const val GL_SAMPLER_1D_ARRAY_SHADOW: Int = 36_291

public const val GL_SAMPLER_2D_ARRAY_SHADOW: Int = 36_292

public const val GL_SAMPLER_CUBE_SHADOW: Int = 36_293

public const val GL_UNSIGNED_INT_VEC2: Int = 36_294

public const val GL_UNSIGNED_INT_VEC3: Int = 36_295

public const val GL_UNSIGNED_INT_VEC4: Int = 36_296

public const val GL_INT_SAMPLER_1D: Int = 36_297

public const val GL_INT_SAMPLER_2D: Int = 36_298

public const val GL_INT_SAMPLER_3D: Int = 36_299

public const val GL_INT_SAMPLER_CUBE: Int = 36_300

public const val GL_INT_SAMPLER_1D_ARRAY: Int = 36_302

public const val GL_INT_SAMPLER_2D_ARRAY: Int = 36_303

public const val GL_UNSIGNED_INT_SAMPLER_1D: Int = 36_305

public const val GL_UNSIGNED_INT_SAMPLER_2D: Int = 36_306

public const val GL_UNSIGNED_INT_SAMPLER_3D: Int = 36_307

public const val GL_UNSIGNED_INT_SAMPLER_CUBE: Int = 36_308

public const val GL_UNSIGNED_INT_SAMPLER_1D_ARRAY: Int = 36_310

public const val GL_UNSIGNED_INT_SAMPLER_2D_ARRAY: Int = 36_311

public const val GL_MIN_PROGRAM_TEXEL_OFFSET: Int = 35_076

public const val GL_MAX_PROGRAM_TEXEL_OFFSET: Int = 35_077

public const val GL_QUERY_WAIT: Int = 36_371

public const val GL_QUERY_NO_WAIT: Int = 36_372

public const val GL_QUERY_BY_REGION_WAIT: Int = 36_373

public const val GL_QUERY_BY_REGION_NO_WAIT: Int = 36_374

public const val GL_MAP_READ_BIT: Int = 1

public const val GL_MAP_WRITE_BIT: Int = 2

public const val GL_MAP_INVALIDATE_RANGE_BIT: Int = 4

public const val GL_MAP_INVALIDATE_BUFFER_BIT: Int = 8

public const val GL_MAP_FLUSH_EXPLICIT_BIT: Int = 16

public const val GL_MAP_UNSYNCHRONIZED_BIT: Int = 32

public const val GL_BUFFER_ACCESS_FLAGS: Int = 37_151

public const val GL_BUFFER_MAP_LENGTH: Int = 37_152

public const val GL_BUFFER_MAP_OFFSET: Int = 37_153

public const val GL_CLAMP_READ_COLOR: Int = 35_100

public const val GL_FIXED_ONLY: Int = 35_101

public const val GL_DEPTH_COMPONENT32F: Int = 36_012

public const val GL_DEPTH32F_STENCIL8: Int = 36_013

public const val GL_FLOAT_32_UNSIGNED_INT_24_8_REV: Int = 36_269

public const val GL_TEXTURE_RED_TYPE: Int = 35_856

public const val GL_TEXTURE_GREEN_TYPE: Int = 35_857

public const val GL_TEXTURE_BLUE_TYPE: Int = 35_858

public const val GL_TEXTURE_ALPHA_TYPE: Int = 35_859

public const val GL_TEXTURE_DEPTH_TYPE: Int = 35_862

public const val GL_UNSIGNED_NORMALIZED: Int = 35_863

public const val GL_RGBA32F: Int = 34_836

public const val GL_RGB32F: Int = 34_837

public const val GL_RGBA16F: Int = 34_842

public const val GL_RGB16F: Int = 34_843

public const val GL_R11F_G11F_B10F: Int = 35_898

public const val GL_UNSIGNED_INT_10F_11F_11F_REV: Int = 35_899

public const val GL_RGB9_E5: Int = 35_901

public const val GL_UNSIGNED_INT_5_9_9_9_REV: Int = 35_902

public const val GL_TEXTURE_SHARED_SIZE: Int = 35_903

public const val GL_FRAMEBUFFER: Int = 36_160

public const val GL_READ_FRAMEBUFFER: Int = 36_008

public const val GL_DRAW_FRAMEBUFFER: Int = 36_009

public const val GL_RENDERBUFFER: Int = 36_161

public const val GL_STENCIL_INDEX1: Int = 36_166

public const val GL_STENCIL_INDEX4: Int = 36_167

public const val GL_STENCIL_INDEX8: Int = 36_168

public const val GL_STENCIL_INDEX16: Int = 36_169

public const val GL_RENDERBUFFER_WIDTH: Int = 36_162

public const val GL_RENDERBUFFER_HEIGHT: Int = 36_163

public const val GL_RENDERBUFFER_INTERNAL_FORMAT: Int = 36_164

public const val GL_RENDERBUFFER_RED_SIZE: Int = 36_176

public const val GL_RENDERBUFFER_GREEN_SIZE: Int = 36_177

public const val GL_RENDERBUFFER_BLUE_SIZE: Int = 36_178

public const val GL_RENDERBUFFER_ALPHA_SIZE: Int = 36_179

public const val GL_RENDERBUFFER_DEPTH_SIZE: Int = 36_180

public const val GL_RENDERBUFFER_STENCIL_SIZE: Int = 36_181

public const val GL_RENDERBUFFER_SAMPLES: Int = 36_011

public const val GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE: Int = 36_048

public const val GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME: Int = 36_049

public const val GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL: Int = 36_050

public const val GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE: Int = 36_051

public const val GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER: Int = 36_052

public const val GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING: Int = 33_296

public const val GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE: Int = 33_297

public const val GL_FRAMEBUFFER_ATTACHMENT_RED_SIZE: Int = 33_298

public const val GL_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE: Int = 33_299

public const val GL_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE: Int = 33_300

public const val GL_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE: Int = 33_301

public const val GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE: Int = 33_302

public const val GL_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE: Int = 33_303

public const val GL_FRAMEBUFFER_DEFAULT: Int = 33_304

public const val GL_COLOR_ATTACHMENT0: Int = 36_064

public const val GL_COLOR_ATTACHMENT1: Int = 36_065

public const val GL_COLOR_ATTACHMENT2: Int = 36_066

public const val GL_COLOR_ATTACHMENT3: Int = 36_067

public const val GL_COLOR_ATTACHMENT4: Int = 36_068

public const val GL_COLOR_ATTACHMENT5: Int = 36_069

public const val GL_COLOR_ATTACHMENT6: Int = 36_070

public const val GL_COLOR_ATTACHMENT7: Int = 36_071

public const val GL_COLOR_ATTACHMENT8: Int = 36_072

public const val GL_COLOR_ATTACHMENT9: Int = 36_073

public const val GL_COLOR_ATTACHMENT10: Int = 36_074

public const val GL_COLOR_ATTACHMENT11: Int = 36_075

public const val GL_COLOR_ATTACHMENT12: Int = 36_076

public const val GL_COLOR_ATTACHMENT13: Int = 36_077

public const val GL_COLOR_ATTACHMENT14: Int = 36_078

public const val GL_COLOR_ATTACHMENT15: Int = 36_079

public const val GL_COLOR_ATTACHMENT16: Int = 36_080

public const val GL_COLOR_ATTACHMENT17: Int = 36_081

public const val GL_COLOR_ATTACHMENT18: Int = 36_082

public const val GL_COLOR_ATTACHMENT19: Int = 36_083

public const val GL_COLOR_ATTACHMENT20: Int = 36_084

public const val GL_COLOR_ATTACHMENT21: Int = 36_085

public const val GL_COLOR_ATTACHMENT22: Int = 36_086

public const val GL_COLOR_ATTACHMENT23: Int = 36_087

public const val GL_COLOR_ATTACHMENT24: Int = 36_088

public const val GL_COLOR_ATTACHMENT25: Int = 36_089

public const val GL_COLOR_ATTACHMENT26: Int = 36_090

public const val GL_COLOR_ATTACHMENT27: Int = 36_091

public const val GL_COLOR_ATTACHMENT28: Int = 36_092

public const val GL_COLOR_ATTACHMENT29: Int = 36_093

public const val GL_COLOR_ATTACHMENT30: Int = 36_094

public const val GL_COLOR_ATTACHMENT31: Int = 36_095

public const val GL_DEPTH_ATTACHMENT: Int = 36_096

public const val GL_STENCIL_ATTACHMENT: Int = 36_128

public const val GL_DEPTH_STENCIL_ATTACHMENT: Int = 33_306

public const val GL_MAX_SAMPLES: Int = 36_183

public const val GL_FRAMEBUFFER_COMPLETE: Int = 36_053

public const val GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT: Int = 36_054

public const val GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT: Int = 36_055

public const val GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER: Int = 36_059

public const val GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER: Int = 36_060

public const val GL_FRAMEBUFFER_UNSUPPORTED: Int = 36_061

public const val GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE: Int = 36_182

public const val GL_FRAMEBUFFER_UNDEFINED: Int = 33_305

public const val GL_FRAMEBUFFER_BINDING: Int = 36_006

public const val GL_DRAW_FRAMEBUFFER_BINDING: Int = 36_006

public const val GL_READ_FRAMEBUFFER_BINDING: Int = 36_010

public const val GL_RENDERBUFFER_BINDING: Int = 36_007

public const val GL_MAX_COLOR_ATTACHMENTS: Int = 36_063

public const val GL_MAX_RENDERBUFFER_SIZE: Int = 34_024

public const val GL_INVALID_FRAMEBUFFER_OPERATION: Int = 1_286

public const val GL_DEPTH_STENCIL: Int = 34_041

public const val GL_UNSIGNED_INT_24_8: Int = 34_042

public const val GL_DEPTH24_STENCIL8: Int = 35_056

public const val GL_TEXTURE_STENCIL_SIZE: Int = 35_057

public const val GL_HALF_FLOAT: Int = 5_131

public const val GL_RGBA32UI: Int = 36_208

public const val GL_RGB32UI: Int = 36_209

public const val GL_RGBA16UI: Int = 36_214

public const val GL_RGB16UI: Int = 36_215

public const val GL_RGBA8UI: Int = 36_220

public const val GL_RGB8UI: Int = 36_221

public const val GL_RGBA32I: Int = 36_226

public const val GL_RGB32I: Int = 36_227

public const val GL_RGBA16I: Int = 36_232

public const val GL_RGB16I: Int = 36_233

public const val GL_RGBA8I: Int = 36_238

public const val GL_RGB8I: Int = 36_239

public const val GL_RED_INTEGER: Int = 36_244

public const val GL_GREEN_INTEGER: Int = 36_245

public const val GL_BLUE_INTEGER: Int = 36_246

public const val GL_RGB_INTEGER: Int = 36_248

public const val GL_RGBA_INTEGER: Int = 36_249

public const val GL_BGR_INTEGER: Int = 36_250

public const val GL_BGRA_INTEGER: Int = 36_251

public const val GL_TEXTURE_1D_ARRAY: Int = 35_864

public const val GL_TEXTURE_2D_ARRAY: Int = 35_866

public const val GL_PROXY_TEXTURE_2D_ARRAY: Int = 35_867

public const val GL_PROXY_TEXTURE_1D_ARRAY: Int = 35_865

public const val GL_TEXTURE_BINDING_1D_ARRAY: Int = 35_868

public const val GL_TEXTURE_BINDING_2D_ARRAY: Int = 35_869

public const val GL_MAX_ARRAY_TEXTURE_LAYERS: Int = 35_071

public const val GL_COMPRESSED_RED_RGTC1: Int = 36_283

public const val GL_COMPRESSED_SIGNED_RED_RGTC1: Int = 36_284

public const val GL_COMPRESSED_RG_RGTC2: Int = 36_285

public const val GL_COMPRESSED_SIGNED_RG_RGTC2: Int = 36_286

public const val GL_R8: Int = 33_321

public const val GL_R16: Int = 33_322

public const val GL_RG8: Int = 33_323

public const val GL_RG16: Int = 33_324

public const val GL_R16F: Int = 33_325

public const val GL_R32F: Int = 33_326

public const val GL_RG16F: Int = 33_327

public const val GL_RG32F: Int = 33_328

public const val GL_R8I: Int = 33_329

public const val GL_R8UI: Int = 33_330

public const val GL_R16I: Int = 33_331

public const val GL_R16UI: Int = 33_332

public const val GL_R32I: Int = 33_333

public const val GL_R32UI: Int = 33_334

public const val GL_RG8I: Int = 33_335

public const val GL_RG8UI: Int = 33_336

public const val GL_RG16I: Int = 33_337

public const val GL_RG16UI: Int = 33_338

public const val GL_RG32I: Int = 33_339

public const val GL_RG32UI: Int = 33_340

public const val GL_RG: Int = 33_319

public const val GL_COMPRESSED_RED: Int = 33_317

public const val GL_COMPRESSED_RG: Int = 33_318

public const val GL_RG_INTEGER: Int = 33_320

public const val GL_TRANSFORM_FEEDBACK_BUFFER: Int = 35_982

public const val GL_TRANSFORM_FEEDBACK_BUFFER_START: Int = 35_972

public const val GL_TRANSFORM_FEEDBACK_BUFFER_SIZE: Int = 35_973

public const val GL_TRANSFORM_FEEDBACK_BUFFER_BINDING: Int = 35_983

public const val GL_INTERLEAVED_ATTRIBS: Int = 35_980

public const val GL_SEPARATE_ATTRIBS: Int = 35_981

public const val GL_PRIMITIVES_GENERATED: Int = 35_975

public const val GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN: Int = 35_976

public const val GL_RASTERIZER_DISCARD: Int = 35_977

public const val GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS: Int = 35_978

public const val GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS: Int = 35_979

public const val GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS: Int = 35_968

public const val GL_TRANSFORM_FEEDBACK_VARYINGS: Int = 35_971

public const val GL_TRANSFORM_FEEDBACK_BUFFER_MODE: Int = 35_967

public const val GL_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH: Int = 35_958

public const val GL_VERTEX_ARRAY_BINDING: Int = 34_229

public const val GL_FRAMEBUFFER_SRGB: Int = 36_281

public inline fun glGetStringi(name: Int, index: Int): Ptr =
        GLWrapper.instance.GL30.glGetStringi(name, index)

public inline fun glClearBufferiv(
    buffer: Int,
    drawbuffer: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL30.glClearBufferiv(buffer, drawbuffer, `value`)

public inline fun glClearBufferiv(
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL30.glClearBufferiv(buffer, drawbuffer, `value`)

public inline fun glClearBufferuiv(
    buffer: Int,
    drawbuffer: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL30.glClearBufferuiv(buffer, drawbuffer, `value`)

public inline fun glClearBufferuiv(
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL30.glClearBufferuiv(buffer, drawbuffer, `value`)

public inline fun glClearBufferfv(
    buffer: Int,
    drawbuffer: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL30.glClearBufferfv(buffer, drawbuffer, `value`)

public inline fun glClearBufferfv(
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL30.glClearBufferfv(buffer, drawbuffer, `value`)

public inline fun glClearBufferfi(
    buffer: Int,
    drawbuffer: Int,
    depth: Float,
    stencil: Int,
): Unit = GLWrapper.instance.GL30.glClearBufferfi(buffer, drawbuffer, depth, stencil)

public inline fun glVertexAttribI1i(index: Int, x: Int): Unit =
        GLWrapper.instance.GL30.glVertexAttribI1i(index, x)

public inline fun glVertexAttribI2i(
    index: Int,
    x: Int,
    y: Int,
): Unit = GLWrapper.instance.GL30.glVertexAttribI2i(index, x, y)

public inline fun glVertexAttribI3i(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
): Unit = GLWrapper.instance.GL30.glVertexAttribI3i(index, x, y, z)

public inline fun glVertexAttribI4i(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
): Unit = GLWrapper.instance.GL30.glVertexAttribI4i(index, x, y, z, w)

public inline fun glVertexAttribI1ui(index: Int, x: Int): Unit =
        GLWrapper.instance.GL30.glVertexAttribI1ui(index, x)

public inline fun glVertexAttribI2ui(
    index: Int,
    x: Int,
    y: Int,
): Unit = GLWrapper.instance.GL30.glVertexAttribI2ui(index, x, y)

public inline fun glVertexAttribI3ui(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
): Unit = GLWrapper.instance.GL30.glVertexAttribI3ui(index, x, y, z)

public inline fun glVertexAttribI4ui(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
): Unit = GLWrapper.instance.GL30.glVertexAttribI4ui(index, x, y, z, w)

public inline fun glVertexAttribI1iv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI1iv(index, v)

public inline fun glVertexAttribI1iv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI1iv(index, v)

public inline fun glVertexAttribI2iv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI2iv(index, v)

public inline fun glVertexAttribI2iv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI2iv(index, v)

public inline fun glVertexAttribI3iv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI3iv(index, v)

public inline fun glVertexAttribI3iv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI3iv(index, v)

public inline fun glVertexAttribI4iv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4iv(index, v)

public inline fun glVertexAttribI4iv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4iv(index, v)

public inline fun glVertexAttribI1uiv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI1uiv(index, v)

public inline fun glVertexAttribI1uiv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI1uiv(index, v)

public inline fun glVertexAttribI2uiv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI2uiv(index, v)

public inline fun glVertexAttribI2uiv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI2uiv(index, v)

public inline fun glVertexAttribI3uiv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI3uiv(index, v)

public inline fun glVertexAttribI3uiv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI3uiv(index, v)

public inline fun glVertexAttribI4uiv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4uiv(index, v)

public inline fun glVertexAttribI4uiv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4uiv(index, v)

public inline fun glVertexAttribI4bv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4bv(index, v)

public inline fun glVertexAttribI4bv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4bv(index, v)

public inline fun glVertexAttribI4sv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4sv(index, v)

public inline fun glVertexAttribI4sv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4sv(index, v)

public inline fun glVertexAttribI4ubv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4ubv(index, v)

public inline fun glVertexAttribI4ubv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4ubv(index, v)

public inline fun glVertexAttribI4usv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4usv(index, v)

public inline fun glVertexAttribI4usv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL30.glVertexAttribI4usv(index, v)

public inline fun glVertexAttribIPointer(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.GL30.glVertexAttribIPointer(index, size, type, stride, pointer)

public inline fun glVertexAttribIPointer(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
): Unit = GLWrapper.instance.GL30.glVertexAttribIPointer(index, size, type, stride, pointer)

public inline fun glGetVertexAttribIiv(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL30.glGetVertexAttribIiv(index, pname, params)

public inline fun glGetVertexAttribIiv(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL30.glGetVertexAttribIiv(index, pname, params)

public inline fun glGetVertexAttribIuiv(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL30.glGetVertexAttribIuiv(index, pname, params)

public inline fun glGetVertexAttribIuiv(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL30.glGetVertexAttribIuiv(index, pname, params)

public inline fun glUniform1ui(location: Int, v0: Int): Unit =
        GLWrapper.instance.GL30.glUniform1ui(location, v0)

public inline fun glUniform2ui(
    location: Int,
    v0: Int,
    v1: Int,
): Unit = GLWrapper.instance.GL30.glUniform2ui(location, v0, v1)

public inline fun glUniform3ui(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
): Unit = GLWrapper.instance.GL30.glUniform3ui(location, v0, v1, v2)

public inline fun glUniform4ui(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
): Unit = GLWrapper.instance.GL30.glUniform4ui(location, v0, v1, v2, v3)

public inline fun glUniform1uiv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL30.glUniform1uiv(location, count, `value`)

public inline fun glUniform1uiv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL30.glUniform1uiv(location, count, `value`)

public inline fun glUniform2uiv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL30.glUniform2uiv(location, count, `value`)

public inline fun glUniform2uiv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL30.glUniform2uiv(location, count, `value`)

public inline fun glUniform3uiv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL30.glUniform3uiv(location, count, `value`)

public inline fun glUniform3uiv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL30.glUniform3uiv(location, count, `value`)

public inline fun glUniform4uiv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL30.glUniform4uiv(location, count, `value`)

public inline fun glUniform4uiv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL30.glUniform4uiv(location, count, `value`)

public inline fun glGetUniformuiv(
    program: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL30.glGetUniformuiv(program, location, params)

public inline fun glGetUniformuiv(
    program: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.GL30.glGetUniformuiv(program, location, params)

public inline fun glBindFragDataLocation(
    program: Int,
    colorNumber: Int,
    name: Ptr,
): Unit = GLWrapper.instance.GL30.glBindFragDataLocation(program, colorNumber, name)

public inline fun glBindFragDataLocation(
    program: Int,
    colorNumber: Int,
    name: Long,
): Unit = GLWrapper.instance.GL30.glBindFragDataLocation(program, colorNumber, name)

public inline fun glGetFragDataLocation(program: Int, name: Ptr): Int =
        GLWrapper.instance.GL30.glGetFragDataLocation(program, name)

public inline fun glGetFragDataLocation(program: Int, name: Long): Int =
        GLWrapper.instance.GL30.glGetFragDataLocation(program, name)

public inline fun glBeginConditionalRender(id: Int, mode: Int): Unit =
        GLWrapper.instance.GL30.glBeginConditionalRender(id, mode)

public inline fun glEndConditionalRender(): Unit = GLWrapper.instance.GL30.glEndConditionalRender()

public inline fun glMapBufferRange(
    target: Int,
    offset: Long,
    length: Long,
    access: Int,
): Ptr = GLWrapper.instance.GL30.glMapBufferRange(target, offset, length, access)

public inline fun glFlushMappedBufferRange(
    target: Int,
    offset: Long,
    length: Long,
): Unit = GLWrapper.instance.GL30.glFlushMappedBufferRange(target, offset, length)

public inline fun glClampColor(target: Int, clamp: Int): Unit =
        GLWrapper.instance.GL30.glClampColor(target, clamp)

public inline fun glIsRenderbuffer(renderbuffer: Int): Boolean =
        GLWrapper.instance.GL30.glIsRenderbuffer(renderbuffer)

public inline fun glBindRenderbuffer(target: Int, renderbuffer: Int): Unit =
        GLWrapper.instance.GL30.glBindRenderbuffer(target, renderbuffer)

public inline fun glDeleteRenderbuffers(n: Int, renderbuffers: Ptr): Unit =
        GLWrapper.instance.GL30.glDeleteRenderbuffers(n, renderbuffers)

public inline fun glDeleteRenderbuffers(n: Int, renderbuffers: Long): Unit =
        GLWrapper.instance.GL30.glDeleteRenderbuffers(n, renderbuffers)

public inline fun glGenRenderbuffers(n: Int, renderbuffers: Ptr): Unit =
        GLWrapper.instance.GL30.glGenRenderbuffers(n, renderbuffers)

public inline fun glGenRenderbuffers(n: Int, renderbuffers: Long): Unit =
        GLWrapper.instance.GL30.glGenRenderbuffers(n, renderbuffers)

public inline fun glRenderbufferStorage(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL30.glRenderbufferStorage(target, internalformat, width, height)

public inline fun glRenderbufferStorageMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL30.glRenderbufferStorageMultisample(target, samples, internalformat,
        width, height)

public inline fun glGetRenderbufferParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL30.glGetRenderbufferParameteriv(target, pname, params)

public inline fun glGetRenderbufferParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL30.glGetRenderbufferParameteriv(target, pname, params)

public inline fun glIsFramebuffer(framebuffer: Int): Boolean =
        GLWrapper.instance.GL30.glIsFramebuffer(framebuffer)

public inline fun glBindFramebuffer(target: Int, framebuffer: Int): Unit =
        GLWrapper.instance.GL30.glBindFramebuffer(target, framebuffer)

public inline fun glDeleteFramebuffers(n: Int, framebuffers: Ptr): Unit =
        GLWrapper.instance.GL30.glDeleteFramebuffers(n, framebuffers)

public inline fun glDeleteFramebuffers(n: Int, framebuffers: Long): Unit =
        GLWrapper.instance.GL30.glDeleteFramebuffers(n, framebuffers)

public inline fun glGenFramebuffers(n: Int, framebuffers: Ptr): Unit =
        GLWrapper.instance.GL30.glGenFramebuffers(n, framebuffers)

public inline fun glGenFramebuffers(n: Int, framebuffers: Long): Unit =
        GLWrapper.instance.GL30.glGenFramebuffers(n, framebuffers)

public inline fun glCheckFramebufferStatus(target: Int): Int =
        GLWrapper.instance.GL30.glCheckFramebufferStatus(target)

public inline fun glFramebufferTexture1D(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.GL30.glFramebufferTexture1D(target, attachment, textarget, texture,
        level)

public inline fun glFramebufferTexture2D(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.GL30.glFramebufferTexture2D(target, attachment, textarget, texture,
        level)

public inline fun glFramebufferTexture3D(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
    layer: Int,
): Unit = GLWrapper.instance.GL30.glFramebufferTexture3D(target, attachment, textarget, texture,
        level, layer)

public inline fun glFramebufferTextureLayer(
    target: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    layer: Int,
): Unit = GLWrapper.instance.GL30.glFramebufferTextureLayer(target, attachment, texture, level,
        layer)

public inline fun glFramebufferRenderbuffer(
    target: Int,
    attachment: Int,
    renderbuffertarget: Int,
    renderbuffer: Int,
): Unit = GLWrapper.instance.GL30.glFramebufferRenderbuffer(target, attachment, renderbuffertarget,
        renderbuffer)

public inline fun glGetFramebufferAttachmentParameteriv(
    target: Int,
    attachment: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL30.glGetFramebufferAttachmentParameteriv(target, attachment, pname,
        params)

public inline fun glGetFramebufferAttachmentParameteriv(
    target: Int,
    attachment: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL30.glGetFramebufferAttachmentParameteriv(target, attachment, pname,
        params)

public inline fun glBlitFramebuffer(
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    mask: Int,
    filter: Int,
): Unit = GLWrapper.instance.GL30.glBlitFramebuffer(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1,
        dstY1, mask, filter)

public inline fun glGenerateMipmap(target: Int): Unit =
        GLWrapper.instance.GL30.glGenerateMipmap(target)

public inline fun glTexParameterIiv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL30.glTexParameterIiv(target, pname, params)

public inline fun glTexParameterIiv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL30.glTexParameterIiv(target, pname, params)

public inline fun glTexParameterIuiv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL30.glTexParameterIuiv(target, pname, params)

public inline fun glTexParameterIuiv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL30.glTexParameterIuiv(target, pname, params)

public inline fun glGetTexParameterIiv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL30.glGetTexParameterIiv(target, pname, params)

public inline fun glGetTexParameterIiv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL30.glGetTexParameterIiv(target, pname, params)

public inline fun glGetTexParameterIuiv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL30.glGetTexParameterIuiv(target, pname, params)

public inline fun glGetTexParameterIuiv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL30.glGetTexParameterIuiv(target, pname, params)

public inline fun glColorMaski(
    buf: Int,
    r: Boolean,
    g: Boolean,
    b: Boolean,
    a: Boolean,
): Unit = GLWrapper.instance.GL30.glColorMaski(buf, r, g, b, a)

public inline fun glGetBooleani_v(
    target: Int,
    index: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL30.glGetBooleani_v(target, index, `data`)

public inline fun glGetBooleani_v(
    target: Int,
    index: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL30.glGetBooleani_v(target, index, `data`)

public inline fun glGetIntegeri_v(
    target: Int,
    index: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL30.glGetIntegeri_v(target, index, `data`)

public inline fun glGetIntegeri_v(
    target: Int,
    index: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL30.glGetIntegeri_v(target, index, `data`)

public inline fun glEnablei(cap: Int, index: Int): Unit = GLWrapper.instance.GL30.glEnablei(cap,
        index)

public inline fun glDisablei(target: Int, index: Int): Unit =
        GLWrapper.instance.GL30.glDisablei(target, index)

public inline fun glIsEnabledi(target: Int, index: Int): Boolean =
        GLWrapper.instance.GL30.glIsEnabledi(target, index)

public inline fun glBindBufferRange(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
    size: Long,
): Unit = GLWrapper.instance.GL30.glBindBufferRange(target, index, buffer, offset, size)

public inline fun glBindBufferBase(
    target: Int,
    index: Int,
    buffer: Int,
): Unit = GLWrapper.instance.GL30.glBindBufferBase(target, index, buffer)

public inline fun glBeginTransformFeedback(primitiveMode: Int): Unit =
        GLWrapper.instance.GL30.glBeginTransformFeedback(primitiveMode)

public inline fun glEndTransformFeedback(): Unit = GLWrapper.instance.GL30.glEndTransformFeedback()

public inline fun glTransformFeedbackVaryings(
    program: Int,
    count: Int,
    varyings: Ptr,
    bufferMode: Int,
): Unit = GLWrapper.instance.GL30.glTransformFeedbackVaryings(program, count, varyings, bufferMode)

public inline fun glTransformFeedbackVaryings(
    program: Int,
    count: Int,
    varyings: Long,
    bufferMode: Int,
): Unit = GLWrapper.instance.GL30.glTransformFeedbackVaryings(program, count, varyings, bufferMode)

public inline fun glGetTransformFeedbackVarying(
    program: Int,
    index: Int,
    bufSize: Int,
    length: Ptr,
    size: Ptr,
    type: Ptr,
    name: Ptr,
): Unit = GLWrapper.instance.GL30.glGetTransformFeedbackVarying(program, index, bufSize, length,
        size, type, name)

public inline fun glGetTransformFeedbackVarying(
    program: Int,
    index: Int,
    bufSize: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
): Unit = GLWrapper.instance.GL30.glGetTransformFeedbackVarying(program, index, bufSize, length,
        size, type, name)

public inline fun glBindVertexArray(array: Int): Unit =
        GLWrapper.instance.GL30.glBindVertexArray(array)

public inline fun glDeleteVertexArrays(n: Int, arrays: Ptr): Unit =
        GLWrapper.instance.GL30.glDeleteVertexArrays(n, arrays)

public inline fun glDeleteVertexArrays(n: Int, arrays: Long): Unit =
        GLWrapper.instance.GL30.glDeleteVertexArrays(n, arrays)

public inline fun glGenVertexArrays(n: Int, arrays: Ptr): Unit =
        GLWrapper.instance.GL30.glGenVertexArrays(n, arrays)

public inline fun glGenVertexArrays(n: Int, arrays: Long): Unit =
        GLWrapper.instance.GL30.glGenVertexArrays(n, arrays)

public inline fun glIsVertexArray(array: Int): Boolean =
        GLWrapper.instance.GL30.glIsVertexArray(array)

public inline fun glDeleteRenderbuffers(renderbuffer: Int): Unit =
        GLWrapper.instance.GL30.glDeleteRenderbuffers(renderbuffer)

public inline fun glDeleteVertexArrays(array: Int): Unit =
        GLWrapper.instance.GL30.glDeleteVertexArrays(array)

public inline fun glDeleteFramebuffers(framebuffer: Int): Unit =
        GLWrapper.instance.GL30.glDeleteFramebuffers(framebuffer)
