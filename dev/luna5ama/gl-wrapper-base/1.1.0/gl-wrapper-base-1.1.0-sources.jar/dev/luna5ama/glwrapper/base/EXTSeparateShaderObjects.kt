@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTSeparateShaderObjects : GLBase {
    public fun glUseShaderProgramEXT(type: Int, program: Int)

    public fun glActiveProgramEXT(program: Int)

    @PtrParameter([1])
    public fun glCreateShaderProgramEXT(type: Int, string: Ptr): Int

    @Unsafe
    public fun glCreateShaderProgramEXT(type: Int, string: Long): Int
}

public const val GL_ACTIVE_PROGRAM_EXT: Int = 35_725

public inline fun glUseShaderProgramEXT(type: Int, program: Int): Unit =
        GLWrapper.instance.EXTSeparateShaderObjects.glUseShaderProgramEXT(type, program)

public inline fun glActiveProgramEXT(program: Int): Unit =
        GLWrapper.instance.EXTSeparateShaderObjects.glActiveProgramEXT(program)

public inline fun glCreateShaderProgramEXT(type: Int, string: Ptr): Int =
        GLWrapper.instance.EXTSeparateShaderObjects.glCreateShaderProgramEXT(type, string)

public inline fun glCreateShaderProgramEXT(type: Int, string: Long): Int =
        GLWrapper.instance.EXTSeparateShaderObjects.glCreateShaderProgramEXT(type, string)
