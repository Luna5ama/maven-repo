@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVShaderThreadGroup : GLBase

public const val GL_WARP_SIZE_NV: Int = 37_689

public const val GL_WARPS_PER_SM_NV: Int = 37_690

public const val GL_SM_COUNT_NV: Int = 37_691
