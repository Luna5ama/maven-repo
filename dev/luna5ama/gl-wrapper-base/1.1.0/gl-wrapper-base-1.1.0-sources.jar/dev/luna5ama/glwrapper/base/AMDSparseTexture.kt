@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface AMDSparseTexture : GLBase {
    public fun glTexStorageSparseAMD(
        target: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        depth: Int,
        layers: Int,
        flags: Int,
    )

    public fun glTextureStorageSparseAMD(
        texture: Int,
        target: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        depth: Int,
        layers: Int,
        flags: Int,
    )
}

public const val GL_TEXTURE_STORAGE_SPARSE_BIT_AMD: Int = 1

public const val GL_VIRTUAL_PAGE_SIZE_X_AMD: Int = 37_269

public const val GL_VIRTUAL_PAGE_SIZE_Y_AMD: Int = 37_270

public const val GL_VIRTUAL_PAGE_SIZE_Z_AMD: Int = 37_271

public const val GL_MAX_SPARSE_TEXTURE_SIZE_AMD: Int = 37_272

public const val GL_MAX_SPARSE_3D_TEXTURE_SIZE_AMD: Int = 37_273

public const val GL_MAX_SPARSE_ARRAY_TEXTURE_LAYERS: Int = 37_274

public const val GL_MIN_SPARSE_LEVEL_AMD: Int = 37_275

public const val GL_MIN_LOD_WARNING_AMD: Int = 37_276

public inline fun glTexStorageSparseAMD(
    target: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    layers: Int,
    flags: Int,
): Unit = GLWrapper.instance.AMDSparseTexture.glTexStorageSparseAMD(target, internalFormat, width,
        height, depth, layers, flags)

public inline fun glTextureStorageSparseAMD(
    texture: Int,
    target: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    layers: Int,
    flags: Int,
): Unit = GLWrapper.instance.AMDSparseTexture.glTextureStorageSparseAMD(texture, target,
        internalFormat, width, height, depth, layers, flags)
