@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface ARBShadowAmbient : GLBase

public const val GL_TEXTURE_COMPARE_FAIL_VALUE_ARB: Int = 32_959
