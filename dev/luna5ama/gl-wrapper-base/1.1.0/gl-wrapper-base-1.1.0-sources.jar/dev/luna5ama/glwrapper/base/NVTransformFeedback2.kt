@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVTransformFeedback2 : GLBase {
    public fun glBindTransformFeedbackNV(target: Int, id: Int)

    @PtrParameter([1])
    public fun glDeleteTransformFeedbacksNV(n: Int, ids: Ptr)

    @Unsafe
    public fun glDeleteTransformFeedbacksNV(n: Int, ids: Long)

    @PtrParameter([1])
    public fun glGenTransformFeedbacksNV(n: Int, ids: Ptr)

    @Unsafe
    public fun glGenTransformFeedbacksNV(n: Int, ids: Long)

    public fun glIsTransformFeedbackNV(id: Int): Boolean

    public fun glPauseTransformFeedbackNV()

    public fun glResumeTransformFeedbackNV()

    public fun glDrawTransformFeedbackNV(mode: Int, id: Int)
}

public const val GL_TRANSFORM_FEEDBACK_NV: Int = 36_386

public const val GL_TRANSFORM_FEEDBACK_BUFFER_PAUSED_NV: Int = 36_387

public const val GL_TRANSFORM_FEEDBACK_BUFFER_ACTIVE_NV: Int = 36_388

public const val GL_TRANSFORM_FEEDBACK_BINDING_NV: Int = 36_389

public inline fun glBindTransformFeedbackNV(target: Int, id: Int): Unit =
        GLWrapper.instance.NVTransformFeedback2.glBindTransformFeedbackNV(target, id)

public inline fun glDeleteTransformFeedbacksNV(n: Int, ids: Ptr): Unit =
        GLWrapper.instance.NVTransformFeedback2.glDeleteTransformFeedbacksNV(n, ids)

public inline fun glDeleteTransformFeedbacksNV(n: Int, ids: Long): Unit =
        GLWrapper.instance.NVTransformFeedback2.glDeleteTransformFeedbacksNV(n, ids)

public inline fun glGenTransformFeedbacksNV(n: Int, ids: Ptr): Unit =
        GLWrapper.instance.NVTransformFeedback2.glGenTransformFeedbacksNV(n, ids)

public inline fun glGenTransformFeedbacksNV(n: Int, ids: Long): Unit =
        GLWrapper.instance.NVTransformFeedback2.glGenTransformFeedbacksNV(n, ids)

public inline fun glIsTransformFeedbackNV(id: Int): Boolean =
        GLWrapper.instance.NVTransformFeedback2.glIsTransformFeedbackNV(id)

public inline fun glPauseTransformFeedbackNV(): Unit =
        GLWrapper.instance.NVTransformFeedback2.glPauseTransformFeedbackNV()

public inline fun glResumeTransformFeedbackNV(): Unit =
        GLWrapper.instance.NVTransformFeedback2.glResumeTransformFeedbackNV()

public inline fun glDrawTransformFeedbackNV(mode: Int, id: Int): Unit =
        GLWrapper.instance.NVTransformFeedback2.glDrawTransformFeedbackNV(mode, id)
