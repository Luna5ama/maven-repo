@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Suppress

public interface EXTX11SyncObject : GLBase {
    public fun glImportSyncEXT(
        external_sync_type: Int,
        external_sync: Long,
        flags: Int,
    ): Long
}

public const val GL_SYNC_X11_FENCE_EXT: Int = 37_089

public inline fun glImportSyncEXT(
    external_sync_type: Int,
    external_sync: Long,
    flags: Int,
): Long = GLWrapper.instance.EXTX11SyncObject.glImportSyncEXT(external_sync_type, external_sync,
        flags)
