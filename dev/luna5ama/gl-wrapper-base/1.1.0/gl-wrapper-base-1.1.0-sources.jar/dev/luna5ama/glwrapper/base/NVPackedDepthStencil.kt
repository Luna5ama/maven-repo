@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVPackedDepthStencil : GLBase

public const val GL_DEPTH_STENCIL_NV: Int = 34_041

public const val GL_UNSIGNED_INT_24_8_NV: Int = 34_042
