@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVTimelineSemaphore : GLBase {
    @PtrParameter([1])
    public fun glCreateSemaphoresNV(n: Int, semaphores: Ptr)

    @Unsafe
    public fun glCreateSemaphoresNV(n: Int, semaphores: Long)

    @PtrParameter([2])
    public fun glSemaphoreParameterivNV(
        semaphore: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glSemaphoreParameterivNV(
        semaphore: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetSemaphoreParameterivNV(
        semaphore: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetSemaphoreParameterivNV(
        semaphore: Int,
        pname: Int,
        params: Long,
    )
}

public const val GL_SEMAPHORE_TYPE_NV: Int = 38_323

public const val GL_SEMAPHORE_TYPE_BINARY_NV: Int = 38_324

public const val GL_SEMAPHORE_TYPE_TIMELINE_NV: Int = 38_325

public const val GL_TIMELINE_SEMAPHORE_VALUE_NV: Int = 38_293

public const val GL_MAX_TIMELINE_SEMAPHORE_VALUE_DIFFERENCE_NV: Int = 38_326

public inline fun glCreateSemaphoresNV(n: Int, semaphores: Ptr): Unit =
        GLWrapper.instance.NVTimelineSemaphore.glCreateSemaphoresNV(n, semaphores)

public inline fun glCreateSemaphoresNV(n: Int, semaphores: Long): Unit =
        GLWrapper.instance.NVTimelineSemaphore.glCreateSemaphoresNV(n, semaphores)

public inline fun glSemaphoreParameterivNV(
    semaphore: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVTimelineSemaphore.glSemaphoreParameterivNV(semaphore, pname, params)

public inline fun glSemaphoreParameterivNV(
    semaphore: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVTimelineSemaphore.glSemaphoreParameterivNV(semaphore, pname, params)

public inline fun glGetSemaphoreParameterivNV(
    semaphore: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVTimelineSemaphore.glGetSemaphoreParameterivNV(semaphore, pname,
        params)

public inline fun glGetSemaphoreParameterivNV(
    semaphore: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVTimelineSemaphore.glGetSemaphoreParameterivNV(semaphore, pname,
        params)
