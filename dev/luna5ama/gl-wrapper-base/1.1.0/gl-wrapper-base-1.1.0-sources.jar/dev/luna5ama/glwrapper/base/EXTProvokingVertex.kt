@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTProvokingVertex : GLBase {
    public fun glProvokingVertexEXT(mode: Int)
}

public const val GL_FIRST_VERTEX_CONVENTION_EXT: Int = 36_429

public const val GL_LAST_VERTEX_CONVENTION_EXT: Int = 36_430

public const val GL_PROVOKING_VERTEX_EXT: Int = 36_431

public const val GL_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION_EXT: Int = 36_428

public inline fun glProvokingVertexEXT(mode: Int): Unit =
        GLWrapper.instance.EXTProvokingVertex.glProvokingVertexEXT(mode)
