@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import dev.luna5ama.kmogus.ensureCapacity
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL42 : GLBase {
    @PtrParameter([3])
    public fun glGetActiveAtomicCounterBufferiv(
        program: Int,
        bufferIndex: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetActiveAtomicCounterBufferiv(
        program: Int,
        bufferIndex: Int,
        pname: Int,
        params: Long,
    )

    public fun glTexStorage1D(
        target: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
    )

    public fun glTexStorage2D(
        target: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    public fun glTexStorage3D(
        target: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
    )

    public fun glDrawTransformFeedbackInstanced(
        mode: Int,
        id: Int,
        primcount: Int,
    )

    public fun glDrawTransformFeedbackStreamInstanced(
        mode: Int,
        id: Int,
        stream: Int,
        primcount: Int,
    )

    public fun glDrawArraysInstancedBaseInstance(
        mode: Int,
        first: Int,
        count: Int,
        primcount: Int,
        baseinstance: Int,
    )

    @PtrParameter([3])
    public fun glDrawElementsInstancedBaseInstance(
        mode: Int,
        count: Int,
        type: Int,
        indices: Ptr,
        primcount: Int,
        baseinstance: Int,
    )

    @Unsafe
    public fun glDrawElementsInstancedBaseInstance(
        mode: Int,
        count: Int,
        type: Int,
        indices: Long,
        primcount: Int,
        baseinstance: Int,
    )

    @PtrParameter([3])
    public fun glDrawElementsInstancedBaseVertexBaseInstance(
        mode: Int,
        count: Int,
        type: Int,
        indices: Ptr,
        primcount: Int,
        basevertex: Int,
        baseinstance: Int,
    )

    @Unsafe
    public fun glDrawElementsInstancedBaseVertexBaseInstance(
        mode: Int,
        count: Int,
        type: Int,
        indices: Long,
        primcount: Int,
        basevertex: Int,
        baseinstance: Int,
    )

    public fun glBindImageTexture(
        unit: Int,
        texture: Int,
        level: Int,
        layered: Boolean,
        layer: Int,
        access: Int,
        format: Int,
    )

    public fun glMemoryBarrier(barriers: Int)

    @PtrParameter([4])
    public fun glGetInternalformativ(
        target: Int,
        internalformat: Int,
        pname: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetInternalformativ(
        target: Int,
        internalformat: Int,
        pname: Int,
        bufSize: Int,
        params: Long,
    )

    @CoreOverload
    public fun glGetInternalformati(
        target: Int,
        internalformat: Int,
        pname: Int,
    ): Int {
        tempArr.ensureCapacity(4, false)
        glGetInternalformativ(target, internalformat, pname, 1, tempArr.ptr)
        return tempArr.ptr.getInt()
    }

    @CoreOverload
    public fun glGetInternalformati64(
        target: Int,
        internalformat: Int,
        pname: Int,
    ): Long {
        tempArr.ensureCapacity(8, false)
        glGetInternalformati64v(target, internalformat, pname, 1, tempArr.ptr)
        return tempArr.ptr.getLong()
    }
}

public const val GL_COPY_READ_BUFFER_BINDING: Int = GL_COPY_READ_BUFFER

public const val GL_COPY_WRITE_BUFFER_BINDING: Int = GL_COPY_WRITE_BUFFER

public const val GL_TRANSFORM_FEEDBACK_ACTIVE: Int = GL_TRANSFORM_FEEDBACK_BUFFER_ACTIVE

public const val GL_TRANSFORM_FEEDBACK_PAUSED: Int = GL_TRANSFORM_FEEDBACK_BUFFER_PAUSED

public const val GL_COMPRESSED_RGBA_BPTC_UNORM: Int = 36_492

public const val GL_COMPRESSED_SRGB_ALPHA_BPTC_UNORM: Int = 36_493

public const val GL_COMPRESSED_RGB_BPTC_SIGNED_FLOAT: Int = 36_494

public const val GL_COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT: Int = 36_495

public const val GL_UNPACK_COMPRESSED_BLOCK_WIDTH: Int = 37_159

public const val GL_UNPACK_COMPRESSED_BLOCK_HEIGHT: Int = 37_160

public const val GL_UNPACK_COMPRESSED_BLOCK_DEPTH: Int = 37_161

public const val GL_UNPACK_COMPRESSED_BLOCK_SIZE: Int = 37_162

public const val GL_PACK_COMPRESSED_BLOCK_WIDTH: Int = 37_163

public const val GL_PACK_COMPRESSED_BLOCK_HEIGHT: Int = 37_164

public const val GL_PACK_COMPRESSED_BLOCK_DEPTH: Int = 37_165

public const val GL_PACK_COMPRESSED_BLOCK_SIZE: Int = 37_166

public const val GL_ATOMIC_COUNTER_BUFFER: Int = 37_568

public const val GL_ATOMIC_COUNTER_BUFFER_BINDING: Int = 37_569

public const val GL_ATOMIC_COUNTER_BUFFER_START: Int = 37_570

public const val GL_ATOMIC_COUNTER_BUFFER_SIZE: Int = 37_571

public const val GL_ATOMIC_COUNTER_BUFFER_DATA_SIZE: Int = 37_572

public const val GL_ATOMIC_COUNTER_BUFFER_ACTIVE_ATOMIC_COUNTERS: Int = 37_573

public const val GL_ATOMIC_COUNTER_BUFFER_ACTIVE_ATOMIC_COUNTER_INDICES: Int = 37_574

public const val GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_VERTEX_SHADER: Int = 37_575

public const val GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_TESS_CONTROL_SHADER: Int = 37_576

public const val GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_TESS_EVALUATION_SHADER: Int = 37_577

public const val GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_GEOMETRY_SHADER: Int = 37_578

public const val GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_FRAGMENT_SHADER: Int = 37_579

public const val GL_MAX_VERTEX_ATOMIC_COUNTER_BUFFERS: Int = 37_580

public const val GL_MAX_TESS_CONTROL_ATOMIC_COUNTER_BUFFERS: Int = 37_581

public const val GL_MAX_TESS_EVALUATION_ATOMIC_COUNTER_BUFFERS: Int = 37_582

public const val GL_MAX_GEOMETRY_ATOMIC_COUNTER_BUFFERS: Int = 37_583

public const val GL_MAX_FRAGMENT_ATOMIC_COUNTER_BUFFERS: Int = 37_584

public const val GL_MAX_COMBINED_ATOMIC_COUNTER_BUFFERS: Int = 37_585

public const val GL_MAX_VERTEX_ATOMIC_COUNTERS: Int = 37_586

public const val GL_MAX_TESS_CONTROL_ATOMIC_COUNTERS: Int = 37_587

public const val GL_MAX_TESS_EVALUATION_ATOMIC_COUNTERS: Int = 37_588

public const val GL_MAX_GEOMETRY_ATOMIC_COUNTERS: Int = 37_589

public const val GL_MAX_FRAGMENT_ATOMIC_COUNTERS: Int = 37_590

public const val GL_MAX_COMBINED_ATOMIC_COUNTERS: Int = 37_591

public const val GL_MAX_ATOMIC_COUNTER_BUFFER_SIZE: Int = 37_592

public const val GL_MAX_ATOMIC_COUNTER_BUFFER_BINDINGS: Int = 37_596

public const val GL_ACTIVE_ATOMIC_COUNTER_BUFFERS: Int = 37_593

public const val GL_UNIFORM_ATOMIC_COUNTER_BUFFER_INDEX: Int = 37_594

public const val GL_UNSIGNED_INT_ATOMIC_COUNTER: Int = 37_595

public const val GL_TEXTURE_IMMUTABLE_FORMAT: Int = 37_167

public const val GL_MAX_IMAGE_UNITS: Int = 36_664

public const val GL_MAX_COMBINED_IMAGE_UNITS_AND_FRAGMENT_OUTPUTS: Int = 36_665

public const val GL_MAX_IMAGE_SAMPLES: Int = 36_973

public const val GL_MAX_VERTEX_IMAGE_UNIFORMS: Int = 37_066

public const val GL_MAX_TESS_CONTROL_IMAGE_UNIFORMS: Int = 37_067

public const val GL_MAX_TESS_EVALUATION_IMAGE_UNIFORMS: Int = 37_068

public const val GL_MAX_GEOMETRY_IMAGE_UNIFORMS: Int = 37_069

public const val GL_MAX_FRAGMENT_IMAGE_UNIFORMS: Int = 37_070

public const val GL_MAX_COMBINED_IMAGE_UNIFORMS: Int = 37_071

public const val GL_IMAGE_BINDING_NAME: Int = 36_666

public const val GL_IMAGE_BINDING_LEVEL: Int = 36_667

public const val GL_IMAGE_BINDING_LAYERED: Int = 36_668

public const val GL_IMAGE_BINDING_LAYER: Int = 36_669

public const val GL_IMAGE_BINDING_ACCESS: Int = 36_670

public const val GL_IMAGE_BINDING_FORMAT: Int = 36_974

public const val GL_VERTEX_ATTRIB_ARRAY_BARRIER_BIT: Int = 1

public const val GL_ELEMENT_ARRAY_BARRIER_BIT: Int = 2

public const val GL_UNIFORM_BARRIER_BIT: Int = 4

public const val GL_TEXTURE_FETCH_BARRIER_BIT: Int = 8

public const val GL_SHADER_IMAGE_ACCESS_BARRIER_BIT: Int = 32

public const val GL_COMMAND_BARRIER_BIT: Int = 64

public const val GL_PIXEL_BUFFER_BARRIER_BIT: Int = 128

public const val GL_TEXTURE_UPDATE_BARRIER_BIT: Int = 256

public const val GL_BUFFER_UPDATE_BARRIER_BIT: Int = 512

public const val GL_FRAMEBUFFER_BARRIER_BIT: Int = 1_024

public const val GL_TRANSFORM_FEEDBACK_BARRIER_BIT: Int = 2_048

public const val GL_ATOMIC_COUNTER_BARRIER_BIT: Int = 4_096

public const val GL_ALL_BARRIER_BITS: Int = 1

public const val GL_IMAGE_1D: Int = 36_940

public const val GL_IMAGE_2D: Int = 36_941

public const val GL_IMAGE_3D: Int = 36_942

public const val GL_IMAGE_2D_RECT: Int = 36_943

public const val GL_IMAGE_CUBE: Int = 36_944

public const val GL_IMAGE_BUFFER: Int = 36_945

public const val GL_IMAGE_1D_ARRAY: Int = 36_946

public const val GL_IMAGE_2D_ARRAY: Int = 36_947

public const val GL_IMAGE_CUBE_MAP_ARRAY: Int = 36_948

public const val GL_IMAGE_2D_MULTISAMPLE: Int = 36_949

public const val GL_IMAGE_2D_MULTISAMPLE_ARRAY: Int = 36_950

public const val GL_INT_IMAGE_1D: Int = 36_951

public const val GL_INT_IMAGE_2D: Int = 36_952

public const val GL_INT_IMAGE_3D: Int = 36_953

public const val GL_INT_IMAGE_2D_RECT: Int = 36_954

public const val GL_INT_IMAGE_CUBE: Int = 36_955

public const val GL_INT_IMAGE_BUFFER: Int = 36_956

public const val GL_INT_IMAGE_1D_ARRAY: Int = 36_957

public const val GL_INT_IMAGE_2D_ARRAY: Int = 36_958

public const val GL_INT_IMAGE_CUBE_MAP_ARRAY: Int = 36_959

public const val GL_INT_IMAGE_2D_MULTISAMPLE: Int = 36_960

public const val GL_INT_IMAGE_2D_MULTISAMPLE_ARRAY: Int = 36_961

public const val GL_UNSIGNED_INT_IMAGE_1D: Int = 36_962

public const val GL_UNSIGNED_INT_IMAGE_2D: Int = 36_963

public const val GL_UNSIGNED_INT_IMAGE_3D: Int = 36_964

public const val GL_UNSIGNED_INT_IMAGE_2D_RECT: Int = 36_965

public const val GL_UNSIGNED_INT_IMAGE_CUBE: Int = 36_966

public const val GL_UNSIGNED_INT_IMAGE_BUFFER: Int = 36_967

public const val GL_UNSIGNED_INT_IMAGE_1D_ARRAY: Int = 36_968

public const val GL_UNSIGNED_INT_IMAGE_2D_ARRAY: Int = 36_969

public const val GL_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY: Int = 36_970

public const val GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE: Int = 36_971

public const val GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_ARRAY: Int = 36_972

public const val GL_IMAGE_FORMAT_COMPATIBILITY_TYPE: Int = 37_063

public const val GL_IMAGE_FORMAT_COMPATIBILITY_BY_SIZE: Int = 37_064

public const val GL_IMAGE_FORMAT_COMPATIBILITY_BY_CLASS: Int = 37_065

public const val GL_NUM_SAMPLE_COUNTS: Int = 37_760

public const val GL_MIN_MAP_BUFFER_ALIGNMENT: Int = 37_052

public inline fun glGetActiveAtomicCounterBufferiv(
    program: Int,
    bufferIndex: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL42.glGetActiveAtomicCounterBufferiv(program, bufferIndex, pname,
        params)

public inline fun glGetActiveAtomicCounterBufferiv(
    program: Int,
    bufferIndex: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL42.glGetActiveAtomicCounterBufferiv(program, bufferIndex, pname,
        params)

public inline fun glTexStorage1D(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
): Unit = GLWrapper.instance.GL42.glTexStorage1D(target, levels, internalformat, width)

public inline fun glTexStorage2D(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.GL42.glTexStorage2D(target, levels, internalformat, width, height)

public inline fun glTexStorage3D(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
): Unit = GLWrapper.instance.GL42.glTexStorage3D(target, levels, internalformat, width, height,
        depth)

public inline fun glDrawTransformFeedbackInstanced(
    mode: Int,
    id: Int,
    primcount: Int,
): Unit = GLWrapper.instance.GL42.glDrawTransformFeedbackInstanced(mode, id, primcount)

public inline fun glDrawTransformFeedbackStreamInstanced(
    mode: Int,
    id: Int,
    stream: Int,
    primcount: Int,
): Unit = GLWrapper.instance.GL42.glDrawTransformFeedbackStreamInstanced(mode, id, stream,
        primcount)

public inline fun glDrawArraysInstancedBaseInstance(
    mode: Int,
    first: Int,
    count: Int,
    primcount: Int,
    baseinstance: Int,
): Unit = GLWrapper.instance.GL42.glDrawArraysInstancedBaseInstance(mode, first, count, primcount,
        baseinstance)

public inline fun glDrawElementsInstancedBaseInstance(
    mode: Int,
    count: Int,
    type: Int,
    indices: Ptr,
    primcount: Int,
    baseinstance: Int,
): Unit = GLWrapper.instance.GL42.glDrawElementsInstancedBaseInstance(mode, count, type, indices,
        primcount, baseinstance)

public inline fun glDrawElementsInstancedBaseInstance(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
    baseinstance: Int,
): Unit = GLWrapper.instance.GL42.glDrawElementsInstancedBaseInstance(mode, count, type, indices,
        primcount, baseinstance)

public inline fun glDrawElementsInstancedBaseVertexBaseInstance(
    mode: Int,
    count: Int,
    type: Int,
    indices: Ptr,
    primcount: Int,
    basevertex: Int,
    baseinstance: Int,
): Unit = GLWrapper.instance.GL42.glDrawElementsInstancedBaseVertexBaseInstance(mode, count, type,
        indices, primcount, basevertex, baseinstance)

public inline fun glDrawElementsInstancedBaseVertexBaseInstance(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
    basevertex: Int,
    baseinstance: Int,
): Unit = GLWrapper.instance.GL42.glDrawElementsInstancedBaseVertexBaseInstance(mode, count, type,
        indices, primcount, basevertex, baseinstance)

public inline fun glBindImageTexture(
    unit: Int,
    texture: Int,
    level: Int,
    layered: Boolean,
    layer: Int,
    access: Int,
    format: Int,
): Unit = GLWrapper.instance.GL42.glBindImageTexture(unit, texture, level, layered, layer, access,
        format)

public inline fun glMemoryBarrier(barriers: Int): Unit =
        GLWrapper.instance.GL42.glMemoryBarrier(barriers)

public inline fun glGetInternalformativ(
    target: Int,
    internalformat: Int,
    pname: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL42.glGetInternalformativ(target, internalformat, pname, bufSize,
        params)

public inline fun glGetInternalformativ(
    target: Int,
    internalformat: Int,
    pname: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.GL42.glGetInternalformativ(target, internalformat, pname, bufSize,
        params)

public inline fun glGetInternalformati(
    target: Int,
    internalformat: Int,
    pname: Int,
): Int = GLWrapper.instance.GL42.glGetInternalformati(target, internalformat, pname)

public inline fun glGetInternalformati64(
    target: Int,
    internalformat: Int,
    pname: Int,
): Long = GLWrapper.instance.GL42.glGetInternalformati64(target, internalformat, pname)
