@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import dev.luna5ama.kmogus.ensureCapacity
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL15 : GLBase {
    public fun glBindBuffer(target: Int, buffer: Int)

    @PtrParameter([1])
    public fun glDeleteBuffers(n: Int, buffers: Ptr)

    @Unsafe
    public fun glDeleteBuffers(n: Int, buffers: Long)

    @PtrParameter([1])
    public fun glGenBuffers(n: Int, buffers: Ptr)

    @Unsafe
    public fun glGenBuffers(n: Int, buffers: Long)

    public fun glIsBuffer(buffer: Int): Boolean

    @PtrParameter([2])
    public fun glBufferData(
        target: Int,
        size: Long,
        `data`: Ptr,
        usage: Int,
    )

    @Unsafe
    public fun glBufferData(
        target: Int,
        size: Long,
        `data`: Long,
        usage: Int,
    )

    @PtrParameter([3])
    public fun glBufferSubData(
        target: Int,
        offset: Long,
        size: Long,
        `data`: Ptr,
    )

    @Unsafe
    public fun glBufferSubData(
        target: Int,
        offset: Long,
        size: Long,
        `data`: Long,
    )

    @PtrParameter([3])
    public fun glGetBufferSubData(
        target: Int,
        offset: Long,
        size: Long,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetBufferSubData(
        target: Int,
        offset: Long,
        size: Long,
        `data`: Long,
    )

    @PtrReturn
    public fun glMapBuffer(target: Int, access: Int): Ptr

    public fun glUnmapBuffer(target: Int): Boolean

    @PtrParameter([2])
    public fun glGetBufferParameteriv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetBufferParameteriv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetBufferPointerv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetBufferPointerv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([1])
    public fun glGenQueries(n: Int, ids: Ptr)

    @Unsafe
    public fun glGenQueries(n: Int, ids: Long)

    @PtrParameter([1])
    public fun glDeleteQueries(n: Int, ids: Ptr)

    @Unsafe
    public fun glDeleteQueries(n: Int, ids: Long)

    public fun glIsQuery(id: Int): Boolean

    public fun glBeginQuery(target: Int, id: Int)

    public fun glEndQuery(target: Int)

    @PtrParameter([2])
    public fun glGetQueryiv(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetQueryiv(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetQueryObjectiv(
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetQueryObjectiv(
        id: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetQueryObjectuiv(
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetQueryObjectuiv(
        id: Int,
        pname: Int,
        params: Long,
    )

    public fun glDeleteQueries(query: Int)

    public fun glDeleteBuffers(buffer: Int)

    @CoreOverload
    public fun glGetQueryObjecti(id: Int, pname: Int): Int {
        tempArr.ensureCapacity(4, false)
        glGetQueryObjectiv(id, pname, tempArr.ptr)
        return tempArr.ptr.getInt()
    }

    @CoreOverload
    public fun glGetQueryObjectui(id: Int, pname: Int): Int {
        tempArr.ensureCapacity(4, false)
        glGetQueryObjectuiv(id, pname, tempArr.ptr)
        return tempArr.ptr.getInt()
    }
}

public const val GL_SRC1_ALPHA: Int = 34_185

public const val GL_ARRAY_BUFFER: Int = 34_962

public const val GL_ELEMENT_ARRAY_BUFFER: Int = 34_963

public const val GL_ARRAY_BUFFER_BINDING: Int = 34_964

public const val GL_ELEMENT_ARRAY_BUFFER_BINDING: Int = 34_965

public const val GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING: Int = 34_975

public const val GL_STREAM_DRAW: Int = 35_040

public const val GL_STREAM_READ: Int = 35_041

public const val GL_STREAM_COPY: Int = 35_042

public const val GL_STATIC_DRAW: Int = 35_044

public const val GL_STATIC_READ: Int = 35_045

public const val GL_STATIC_COPY: Int = 35_046

public const val GL_DYNAMIC_DRAW: Int = 35_048

public const val GL_DYNAMIC_READ: Int = 35_049

public const val GL_DYNAMIC_COPY: Int = 35_050

public const val GL_READ_ONLY: Int = 35_000

public const val GL_WRITE_ONLY: Int = 35_001

public const val GL_READ_WRITE: Int = 35_002

public const val GL_BUFFER_SIZE: Int = 34_660

public const val GL_BUFFER_USAGE: Int = 34_661

public const val GL_BUFFER_ACCESS: Int = 35_003

public const val GL_BUFFER_MAPPED: Int = 35_004

public const val GL_BUFFER_MAP_POINTER: Int = 35_005

public const val GL_SAMPLES_PASSED: Int = 35_092

public const val GL_QUERY_COUNTER_BITS: Int = 34_916

public const val GL_CURRENT_QUERY: Int = 34_917

public const val GL_QUERY_RESULT: Int = 34_918

public const val GL_QUERY_RESULT_AVAILABLE: Int = 34_919

public inline fun glBindBuffer(target: Int, buffer: Int): Unit =
        GLWrapper.instance.GL15.glBindBuffer(target, buffer)

public inline fun glDeleteBuffers(n: Int, buffers: Ptr): Unit =
        GLWrapper.instance.GL15.glDeleteBuffers(n, buffers)

public inline fun glDeleteBuffers(n: Int, buffers: Long): Unit =
        GLWrapper.instance.GL15.glDeleteBuffers(n, buffers)

public inline fun glGenBuffers(n: Int, buffers: Ptr): Unit = GLWrapper.instance.GL15.glGenBuffers(n,
        buffers)

public inline fun glGenBuffers(n: Int, buffers: Long): Unit =
        GLWrapper.instance.GL15.glGenBuffers(n, buffers)

public inline fun glIsBuffer(buffer: Int): Boolean = GLWrapper.instance.GL15.glIsBuffer(buffer)

public inline fun glBufferData(
    target: Int,
    size: Long,
    `data`: Ptr,
    usage: Int,
): Unit = GLWrapper.instance.GL15.glBufferData(target, size, `data`, usage)

public inline fun glBufferData(
    target: Int,
    size: Long,
    `data`: Long,
    usage: Int,
): Unit = GLWrapper.instance.GL15.glBufferData(target, size, `data`, usage)

public inline fun glBufferSubData(
    target: Int,
    offset: Long,
    size: Long,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL15.glBufferSubData(target, offset, size, `data`)

public inline fun glBufferSubData(
    target: Int,
    offset: Long,
    size: Long,
    `data`: Long,
): Unit = GLWrapper.instance.GL15.glBufferSubData(target, offset, size, `data`)

public inline fun glGetBufferSubData(
    target: Int,
    offset: Long,
    size: Long,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL15.glGetBufferSubData(target, offset, size, `data`)

public inline fun glGetBufferSubData(
    target: Int,
    offset: Long,
    size: Long,
    `data`: Long,
): Unit = GLWrapper.instance.GL15.glGetBufferSubData(target, offset, size, `data`)

public inline fun glMapBuffer(target: Int, access: Int): Ptr =
        GLWrapper.instance.GL15.glMapBuffer(target, access)

public inline fun glUnmapBuffer(target: Int): Boolean =
        GLWrapper.instance.GL15.glUnmapBuffer(target)

public inline fun glGetBufferParameteriv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL15.glGetBufferParameteriv(target, pname, params)

public inline fun glGetBufferParameteriv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL15.glGetBufferParameteriv(target, pname, params)

public inline fun glGetBufferPointerv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL15.glGetBufferPointerv(target, pname, params)

public inline fun glGetBufferPointerv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL15.glGetBufferPointerv(target, pname, params)

public inline fun glGenQueries(n: Int, ids: Ptr): Unit = GLWrapper.instance.GL15.glGenQueries(n,
        ids)

public inline fun glGenQueries(n: Int, ids: Long): Unit = GLWrapper.instance.GL15.glGenQueries(n,
        ids)

public inline fun glDeleteQueries(n: Int, ids: Ptr): Unit =
        GLWrapper.instance.GL15.glDeleteQueries(n, ids)

public inline fun glDeleteQueries(n: Int, ids: Long): Unit =
        GLWrapper.instance.GL15.glDeleteQueries(n, ids)

public inline fun glIsQuery(id: Int): Boolean = GLWrapper.instance.GL15.glIsQuery(id)

public inline fun glBeginQuery(target: Int, id: Int): Unit =
        GLWrapper.instance.GL15.glBeginQuery(target, id)

public inline fun glEndQuery(target: Int): Unit = GLWrapper.instance.GL15.glEndQuery(target)

public inline fun glGetQueryiv(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL15.glGetQueryiv(target, pname, params)

public inline fun glGetQueryiv(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL15.glGetQueryiv(target, pname, params)

public inline fun glGetQueryObjectiv(
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL15.glGetQueryObjectiv(id, pname, params)

public inline fun glGetQueryObjectiv(
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL15.glGetQueryObjectiv(id, pname, params)

public inline fun glGetQueryObjectuiv(
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL15.glGetQueryObjectuiv(id, pname, params)

public inline fun glGetQueryObjectuiv(
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL15.glGetQueryObjectuiv(id, pname, params)

public inline fun glDeleteQueries(query: Int): Unit = GLWrapper.instance.GL15.glDeleteQueries(query)

public inline fun glDeleteBuffers(buffer: Int): Unit =
        GLWrapper.instance.GL15.glDeleteBuffers(buffer)

public inline fun glGetQueryObjecti(id: Int, pname: Int): Int =
        GLWrapper.instance.GL15.glGetQueryObjecti(id, pname)

public inline fun glGetQueryObjectui(id: Int, pname: Int): Int =
        GLWrapper.instance.GL15.glGetQueryObjectui(id, pname)
