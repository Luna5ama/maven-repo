@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBGPUShaderInt64 : GLBase {
    public fun glUniform1i64ARB(location: Int, x: Long)

    @PtrParameter([2])
    public fun glUniform1i64vARB(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1i64vARB(
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glProgramUniform1i64ARB(
        program: Int,
        location: Int,
        x: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1i64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1i64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glUniform2i64ARB(
        location: Int,
        x: Long,
        y: Long,
    )

    @PtrParameter([2])
    public fun glUniform2i64vARB(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2i64vARB(
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glProgramUniform2i64ARB(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2i64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2i64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glUniform3i64ARB(
        location: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    @PtrParameter([2])
    public fun glUniform3i64vARB(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3i64vARB(
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glProgramUniform3i64ARB(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3i64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3i64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glUniform4i64ARB(
        location: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([2])
    public fun glUniform4i64vARB(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4i64vARB(
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glProgramUniform4i64ARB(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4i64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4i64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glUniform1ui64ARB(location: Int, x: Long)

    @PtrParameter([2])
    public fun glUniform1ui64vARB(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1ui64vARB(
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glProgramUniform1ui64ARB(
        program: Int,
        location: Int,
        x: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1ui64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1ui64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glUniform2ui64ARB(
        location: Int,
        x: Long,
        y: Long,
    )

    @PtrParameter([2])
    public fun glUniform2ui64vARB(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2ui64vARB(
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glProgramUniform2ui64ARB(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2ui64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2ui64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glUniform3ui64ARB(
        location: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    @PtrParameter([2])
    public fun glUniform3ui64vARB(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3ui64vARB(
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glProgramUniform3ui64ARB(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3ui64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3ui64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glUniform4ui64ARB(
        location: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([2])
    public fun glUniform4ui64vARB(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4ui64vARB(
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glProgramUniform4ui64ARB(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4ui64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4ui64vARB(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformi64vARB(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformi64vARB(
        program: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformui64vARB(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformui64vARB(
        program: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformi64vARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformi64vARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetnUniformui64vARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetnUniformui64vARB(
        program: Int,
        location: Int,
        bufSize: Int,
        params: Long,
    )
}

public const val GL_INT64_ARB: Int = 5_134

public const val GL_INT64_VEC2_ARB: Int = 36_841

public const val GL_INT64_VEC3_ARB: Int = 36_842

public const val GL_INT64_VEC4_ARB: Int = 36_843

public const val GL_UNSIGNED_INT64_VEC2_ARB: Int = 36_853

public const val GL_UNSIGNED_INT64_VEC3_ARB: Int = 36_854

public const val GL_UNSIGNED_INT64_VEC4_ARB: Int = 36_855

public inline fun glUniform1i64ARB(location: Int, x: Long): Unit =
        GLWrapper.instance.ARBGPUShaderInt64.glUniform1i64ARB(location, x)

public inline fun glUniform1i64vARB(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform1i64vARB(location, count, `value`)

public inline fun glUniform1i64vARB(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform1i64vARB(location, count, `value`)

public inline fun glProgramUniform1i64ARB(
    program: Int,
    location: Int,
    x: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform1i64ARB(program, location, x)

public inline fun glProgramUniform1i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform1i64vARB(program, location, count,
        `value`)

public inline fun glProgramUniform1i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform1i64vARB(program, location, count,
        `value`)

public inline fun glUniform2i64ARB(
    location: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform2i64ARB(location, x, y)

public inline fun glUniform2i64vARB(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform2i64vARB(location, count, `value`)

public inline fun glUniform2i64vARB(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform2i64vARB(location, count, `value`)

public inline fun glProgramUniform2i64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform2i64ARB(program, location, x, y)

public inline fun glProgramUniform2i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform2i64vARB(program, location, count,
        `value`)

public inline fun glProgramUniform2i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform2i64vARB(program, location, count,
        `value`)

public inline fun glUniform3i64ARB(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform3i64ARB(location, x, y, z)

public inline fun glUniform3i64vARB(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform3i64vARB(location, count, `value`)

public inline fun glUniform3i64vARB(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform3i64vARB(location, count, `value`)

public inline fun glProgramUniform3i64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform3i64ARB(program, location, x, y, z)

public inline fun glProgramUniform3i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform3i64vARB(program, location, count,
        `value`)

public inline fun glProgramUniform3i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform3i64vARB(program, location, count,
        `value`)

public inline fun glUniform4i64ARB(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform4i64ARB(location, x, y, z, w)

public inline fun glUniform4i64vARB(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform4i64vARB(location, count, `value`)

public inline fun glUniform4i64vARB(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform4i64vARB(location, count, `value`)

public inline fun glProgramUniform4i64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform4i64ARB(program, location, x, y, z,
        w)

public inline fun glProgramUniform4i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform4i64vARB(program, location, count,
        `value`)

public inline fun glProgramUniform4i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform4i64vARB(program, location, count,
        `value`)

public inline fun glUniform1ui64ARB(location: Int, x: Long): Unit =
        GLWrapper.instance.ARBGPUShaderInt64.glUniform1ui64ARB(location, x)

public inline fun glUniform1ui64vARB(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform1ui64vARB(location, count, `value`)

public inline fun glUniform1ui64vARB(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform1ui64vARB(location, count, `value`)

public inline fun glProgramUniform1ui64ARB(
    program: Int,
    location: Int,
    x: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform1ui64ARB(program, location, x)

public inline fun glProgramUniform1ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform1ui64vARB(program, location, count,
        `value`)

public inline fun glProgramUniform1ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform1ui64vARB(program, location, count,
        `value`)

public inline fun glUniform2ui64ARB(
    location: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform2ui64ARB(location, x, y)

public inline fun glUniform2ui64vARB(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform2ui64vARB(location, count, `value`)

public inline fun glUniform2ui64vARB(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform2ui64vARB(location, count, `value`)

public inline fun glProgramUniform2ui64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform2ui64ARB(program, location, x, y)

public inline fun glProgramUniform2ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform2ui64vARB(program, location, count,
        `value`)

public inline fun glProgramUniform2ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform2ui64vARB(program, location, count,
        `value`)

public inline fun glUniform3ui64ARB(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform3ui64ARB(location, x, y, z)

public inline fun glUniform3ui64vARB(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform3ui64vARB(location, count, `value`)

public inline fun glUniform3ui64vARB(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform3ui64vARB(location, count, `value`)

public inline fun glProgramUniform3ui64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform3ui64ARB(program, location, x, y, z)

public inline fun glProgramUniform3ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform3ui64vARB(program, location, count,
        `value`)

public inline fun glProgramUniform3ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform3ui64vARB(program, location, count,
        `value`)

public inline fun glUniform4ui64ARB(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform4ui64ARB(location, x, y, z, w)

public inline fun glUniform4ui64vARB(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform4ui64vARB(location, count, `value`)

public inline fun glUniform4ui64vARB(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glUniform4ui64vARB(location, count, `value`)

public inline fun glProgramUniform4ui64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform4ui64ARB(program, location, x, y, z,
        w)

public inline fun glProgramUniform4ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform4ui64vARB(program, location, count,
        `value`)

public inline fun glProgramUniform4ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glProgramUniform4ui64vARB(program, location, count,
        `value`)

public inline fun glGetUniformi64vARB(
    program: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glGetUniformi64vARB(program, location, params)

public inline fun glGetUniformi64vARB(
    program: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glGetUniformi64vARB(program, location, params)

public inline fun glGetUniformui64vARB(
    program: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glGetUniformui64vARB(program, location, params)

public inline fun glGetUniformui64vARB(
    program: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glGetUniformui64vARB(program, location, params)

public inline fun glGetnUniformi64vARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glGetnUniformi64vARB(program, location, bufSize,
        params)

public inline fun glGetnUniformi64vARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glGetnUniformi64vARB(program, location, bufSize,
        params)

public inline fun glGetnUniformui64vARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glGetnUniformui64vARB(program, location, bufSize,
        params)

public inline fun glGetnUniformui64vARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBGPUShaderInt64.glGetnUniformui64vARB(program, location, bufSize,
        params)
