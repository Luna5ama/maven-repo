@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTGeometryShader4 : GLBase {
    public fun glProgramParameteriEXT(
        program: Int,
        pname: Int,
        `value`: Int,
    )

    public fun glFramebufferTextureEXT(
        target: Int,
        attachment: Int,
        texture: Int,
        level: Int,
    )

    public fun glFramebufferTextureFaceEXT(
        target: Int,
        attachment: Int,
        texture: Int,
        level: Int,
        face: Int,
    )
}

public const val GL_GEOMETRY_SHADER_EXT: Int = 36_313

public const val GL_GEOMETRY_VERTICES_OUT_EXT: Int = 36_314

public const val GL_GEOMETRY_INPUT_TYPE_EXT: Int = 36_315

public const val GL_GEOMETRY_OUTPUT_TYPE_EXT: Int = 36_316

public const val GL_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS_EXT: Int = 35_881

public const val GL_MAX_GEOMETRY_VARYING_COMPONENTS_EXT: Int = 36_317

public const val GL_MAX_VERTEX_VARYING_COMPONENTS_EXT: Int = 36_318

public const val GL_MAX_VARYING_COMPONENTS_EXT: Int = 35_659

public const val GL_MAX_GEOMETRY_UNIFORM_COMPONENTS_EXT: Int = 36_319

public const val GL_MAX_GEOMETRY_OUTPUT_VERTICES_EXT: Int = 36_320

public const val GL_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS_EXT: Int = 36_321

public const val GL_LINES_ADJACENCY_EXT: Int = 10

public const val GL_LINE_STRIP_ADJACENCY_EXT: Int = 11

public const val GL_TRIANGLES_ADJACENCY_EXT: Int = 12

public const val GL_TRIANGLE_STRIP_ADJACENCY_EXT: Int = 13

public const val GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS_EXT: Int = 36_264

public const val GL_FRAMEBUFFER_INCOMPLETE_LAYER_COUNT_EXT: Int = 36_265

public const val GL_FRAMEBUFFER_ATTACHMENT_LAYERED_EXT: Int = 36_263

public const val GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER_EXT: Int = 36_052

public const val GL_PROGRAM_POINT_SIZE_EXT: Int = 34_370

public inline fun glProgramParameteriEXT(
    program: Int,
    pname: Int,
    `value`: Int,
): Unit = GLWrapper.instance.EXTGeometryShader4.glProgramParameteriEXT(program, pname, `value`)

public inline fun glFramebufferTextureEXT(
    target: Int,
    attachment: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.EXTGeometryShader4.glFramebufferTextureEXT(target, attachment, texture,
        level)

public inline fun glFramebufferTextureFaceEXT(
    target: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    face: Int,
): Unit = GLWrapper.instance.EXTGeometryShader4.glFramebufferTextureFaceEXT(target, attachment,
        texture, level, face)
