@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVMemoryObjectSparse : GLBase {
    public fun glBufferPageCommitmentMemNV(
        target: Int,
        offset: Long,
        size: Long,
        memory: Int,
        memOffset: Long,
        commit: Boolean,
    )

    public fun glNamedBufferPageCommitmentMemNV(
        buffer: Int,
        offset: Long,
        size: Long,
        memory: Int,
        memOffset: Long,
        commit: Boolean,
    )

    public fun glTexPageCommitmentMemNV(
        target: Int,
        layer: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        memory: Int,
        offset: Long,
        commit: Boolean,
    )

    public fun glTexturePageCommitmentMemNV(
        texture: Int,
        layer: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        memory: Int,
        offset: Long,
        commit: Boolean,
    )
}

public inline fun glBufferPageCommitmentMemNV(
    target: Int,
    offset: Long,
    size: Long,
    memory: Int,
    memOffset: Long,
    commit: Boolean,
): Unit = GLWrapper.instance.NVMemoryObjectSparse.glBufferPageCommitmentMemNV(target, offset, size,
        memory, memOffset, commit)

public inline fun glNamedBufferPageCommitmentMemNV(
    buffer: Int,
    offset: Long,
    size: Long,
    memory: Int,
    memOffset: Long,
    commit: Boolean,
): Unit = GLWrapper.instance.NVMemoryObjectSparse.glNamedBufferPageCommitmentMemNV(buffer, offset,
        size, memory, memOffset, commit)

public inline fun glTexPageCommitmentMemNV(
    target: Int,
    layer: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    memory: Int,
    offset: Long,
    commit: Boolean,
): Unit = GLWrapper.instance.NVMemoryObjectSparse.glTexPageCommitmentMemNV(target, layer, level,
        xoffset, yoffset, zoffset, width, height, depth, memory, offset, commit)

public inline fun glTexturePageCommitmentMemNV(
    texture: Int,
    layer: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    memory: Int,
    offset: Long,
    commit: Boolean,
): Unit = GLWrapper.instance.NVMemoryObjectSparse.glTexturePageCommitmentMemNV(texture, layer,
        level, xoffset, yoffset, zoffset, width, height, depth, memory, offset, commit)
