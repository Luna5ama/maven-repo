@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress

public interface EXTWin32KeyedMutex : GLBase {
    public fun glAcquireKeyedMutexWin32EXT(
        memory: Int,
        key: Long,
        timeout: Int,
    ): Boolean

    public fun glReleaseKeyedMutexWin32EXT(memory: Int, key: Long): Boolean
}

public inline fun glAcquireKeyedMutexWin32EXT(
    memory: Int,
    key: Long,
    timeout: Int,
): Boolean = GLWrapper.instance.EXTWin32KeyedMutex.glAcquireKeyedMutexWin32EXT(memory, key, timeout)

public inline fun glReleaseKeyedMutexWin32EXT(memory: Int, key: Long): Boolean =
        GLWrapper.instance.EXTWin32KeyedMutex.glReleaseKeyedMutexWin32EXT(memory, key)
