@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTTimerQuery : GLBase {
    @PtrParameter([2])
    public fun glGetQueryObjecti64vEXT(
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetQueryObjecti64vEXT(
        id: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetQueryObjectui64vEXT(
        id: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetQueryObjectui64vEXT(
        id: Int,
        pname: Int,
        params: Long,
    )
}

public const val GL_TIME_ELAPSED_EXT: Int = 35_007

public inline fun glGetQueryObjecti64vEXT(
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTTimerQuery.glGetQueryObjecti64vEXT(id, pname, params)

public inline fun glGetQueryObjecti64vEXT(
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTTimerQuery.glGetQueryObjecti64vEXT(id, pname, params)

public inline fun glGetQueryObjectui64vEXT(
    id: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTTimerQuery.glGetQueryObjectui64vEXT(id, pname, params)

public inline fun glGetQueryObjectui64vEXT(
    id: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTTimerQuery.glGetQueryObjectui64vEXT(id, pname, params)
