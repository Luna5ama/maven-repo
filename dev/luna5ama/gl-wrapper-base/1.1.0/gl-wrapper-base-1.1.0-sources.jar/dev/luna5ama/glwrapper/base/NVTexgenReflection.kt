@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVTexgenReflection : GLBase

public const val GL_NORMAL_MAP_NV: Int = 34_065

public const val GL_REFLECTION_MAP_NV: Int = 34_066
