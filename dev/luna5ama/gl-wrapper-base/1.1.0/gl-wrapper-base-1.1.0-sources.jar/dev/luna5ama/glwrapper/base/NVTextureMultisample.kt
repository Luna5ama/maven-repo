@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVTextureMultisample : GLBase {
    public fun glTexImage2DMultisampleCoverageNV(
        target: Int,
        coverageSamples: Int,
        colorSamples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        fixedSampleLocations: Boolean,
    )

    public fun glTexImage3DMultisampleCoverageNV(
        target: Int,
        coverageSamples: Int,
        colorSamples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        depth: Int,
        fixedSampleLocations: Boolean,
    )

    public fun glTextureImage2DMultisampleNV(
        texture: Int,
        target: Int,
        samples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        fixedSampleLocations: Boolean,
    )

    public fun glTextureImage3DMultisampleNV(
        texture: Int,
        target: Int,
        samples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        depth: Int,
        fixedSampleLocations: Boolean,
    )

    public fun glTextureImage2DMultisampleCoverageNV(
        texture: Int,
        target: Int,
        coverageSamples: Int,
        colorSamples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        fixedSampleLocations: Boolean,
    )

    public fun glTextureImage3DMultisampleCoverageNV(
        texture: Int,
        target: Int,
        coverageSamples: Int,
        colorSamples: Int,
        internalFormat: Int,
        width: Int,
        height: Int,
        depth: Int,
        fixedSampleLocations: Boolean,
    )
}

public const val GL_TEXTURE_COVERAGE_SAMPLES_NV: Int = 36_933

public const val GL_TEXTURE_COLOR_SAMPLES_NV: Int = 36_934

public inline fun glTexImage2DMultisampleCoverageNV(
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
): Unit = GLWrapper.instance.NVTextureMultisample.glTexImage2DMultisampleCoverageNV(target,
        coverageSamples, colorSamples, internalFormat, width, height, fixedSampleLocations)

public inline fun glTexImage3DMultisampleCoverageNV(
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
): Unit = GLWrapper.instance.NVTextureMultisample.glTexImage3DMultisampleCoverageNV(target,
        coverageSamples, colorSamples, internalFormat, width, height, depth, fixedSampleLocations)

public inline fun glTextureImage2DMultisampleNV(
    texture: Int,
    target: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
): Unit = GLWrapper.instance.NVTextureMultisample.glTextureImage2DMultisampleNV(texture, target,
        samples, internalFormat, width, height, fixedSampleLocations)

public inline fun glTextureImage3DMultisampleNV(
    texture: Int,
    target: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
): Unit = GLWrapper.instance.NVTextureMultisample.glTextureImage3DMultisampleNV(texture, target,
        samples, internalFormat, width, height, depth, fixedSampleLocations)

public inline fun glTextureImage2DMultisampleCoverageNV(
    texture: Int,
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
): Unit = GLWrapper.instance.NVTextureMultisample.glTextureImage2DMultisampleCoverageNV(texture,
        target, coverageSamples, colorSamples, internalFormat, width, height, fixedSampleLocations)

public inline fun glTextureImage3DMultisampleCoverageNV(
    texture: Int,
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
): Unit = GLWrapper.instance.NVTextureMultisample.glTextureImage3DMultisampleCoverageNV(texture,
        target, coverageSamples, colorSamples, internalFormat, width, height, depth,
        fixedSampleLocations)
