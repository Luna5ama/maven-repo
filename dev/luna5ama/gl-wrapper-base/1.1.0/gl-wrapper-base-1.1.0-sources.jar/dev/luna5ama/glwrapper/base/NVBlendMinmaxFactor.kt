@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVBlendMinmaxFactor : GLBase

public const val GL_FACTOR_MIN_AMD: Int = 36_892

public const val GL_FACTOR_MAX_AMD: Int = 36_893
