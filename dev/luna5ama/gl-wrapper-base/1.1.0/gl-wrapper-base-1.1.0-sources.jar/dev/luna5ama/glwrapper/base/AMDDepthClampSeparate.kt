@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface AMDDepthClampSeparate : GLBase

public const val GL_DEPTH_CLAMP_NEAR_AMD: Int = 36_894

public const val GL_DEPTH_CLAMP_FAR_AMD: Int = 36_895
