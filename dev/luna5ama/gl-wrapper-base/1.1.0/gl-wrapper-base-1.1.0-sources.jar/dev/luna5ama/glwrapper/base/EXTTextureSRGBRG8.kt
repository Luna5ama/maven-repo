@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureSRGBRG8 : GLBase

public const val GL_SRG8_EXT: Int = 36_798
