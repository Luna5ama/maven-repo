@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL44 : GLBase {
    @PtrParameter([2])
    public fun glBufferStorage(
        target: Int,
        size: Long,
        `data`: Ptr,
        flags: Int,
    )

    @Unsafe
    public fun glBufferStorage(
        target: Int,
        size: Long,
        `data`: Long,
        flags: Int,
    )

    @PtrParameter([10])
    public fun glClearTexSubImage(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glClearTexSubImage(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        format: Int,
        type: Int,
        `data`: Long,
    )

    @PtrParameter([4])
    public fun glClearTexImage(
        texture: Int,
        level: Int,
        format: Int,
        type: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glClearTexImage(
        texture: Int,
        level: Int,
        format: Int,
        type: Int,
        `data`: Long,
    )

    @PtrParameter([3])
    public fun glBindBuffersBase(
        target: Int,
        first: Int,
        count: Int,
        buffers: Ptr,
    )

    @Unsafe
    public fun glBindBuffersBase(
        target: Int,
        first: Int,
        count: Int,
        buffers: Long,
    )

    @PtrParameter([3, 4, 5])
    public fun glBindBuffersRange(
        target: Int,
        first: Int,
        count: Int,
        buffers: Ptr,
        offsets: Ptr,
        sizes: Ptr,
    )

    @Unsafe
    public fun glBindBuffersRange(
        target: Int,
        first: Int,
        count: Int,
        buffers: Long,
        offsets: Long,
        sizes: Long,
    )

    @PtrParameter([2])
    public fun glBindTextures(
        first: Int,
        count: Int,
        textures: Ptr,
    )

    @Unsafe
    public fun glBindTextures(
        first: Int,
        count: Int,
        textures: Long,
    )

    @PtrParameter([2])
    public fun glBindSamplers(
        first: Int,
        count: Int,
        samplers: Ptr,
    )

    @Unsafe
    public fun glBindSamplers(
        first: Int,
        count: Int,
        samplers: Long,
    )

    @PtrParameter([2])
    public fun glBindImageTextures(
        first: Int,
        count: Int,
        textures: Ptr,
    )

    @Unsafe
    public fun glBindImageTextures(
        first: Int,
        count: Int,
        textures: Long,
    )

    @PtrParameter([2, 3, 4])
    public fun glBindVertexBuffers(
        first: Int,
        count: Int,
        buffers: Ptr,
        offsets: Ptr,
        strides: Ptr,
    )

    @Unsafe
    public fun glBindVertexBuffers(
        first: Int,
        count: Int,
        buffers: Long,
        offsets: Long,
        strides: Long,
    )
}

public const val GL_MAX_VERTEX_ATTRIB_STRIDE: Int = 33_509

public const val GL_PRIMITIVE_RESTART_FOR_PATCHES_SUPPORTED: Int = 33_313

public const val GL_TEXTURE_BUFFER_BINDING: Int = 35_882

public const val GL_MAP_PERSISTENT_BIT: Int = 64

public const val GL_MAP_COHERENT_BIT: Int = 128

public const val GL_DYNAMIC_STORAGE_BIT: Int = 256

public const val GL_CLIENT_STORAGE_BIT: Int = 512

public const val GL_BUFFER_IMMUTABLE_STORAGE: Int = 33_311

public const val GL_BUFFER_STORAGE_FLAGS: Int = 33_312

public const val GL_CLIENT_MAPPED_BUFFER_BARRIER_BIT: Int = 16_384

public const val GL_CLEAR_TEXTURE: Int = 37_733

public const val GL_LOCATION_COMPONENT: Int = 37_706

public const val GL_TRANSFORM_FEEDBACK_BUFFER_INDEX: Int = 37_707

public const val GL_TRANSFORM_FEEDBACK_BUFFER_STRIDE: Int = 37_708

public const val GL_QUERY_RESULT_NO_WAIT: Int = 37_268

public const val GL_QUERY_BUFFER: Int = 37_266

public const val GL_QUERY_BUFFER_BINDING: Int = 37_267

public const val GL_QUERY_BUFFER_BARRIER_BIT: Int = 32_768

public const val GL_MIRROR_CLAMP_TO_EDGE: Int = 34_627

public inline fun glBufferStorage(
    target: Int,
    size: Long,
    `data`: Ptr,
    flags: Int,
): Unit = GLWrapper.instance.GL44.glBufferStorage(target, size, `data`, flags)

public inline fun glBufferStorage(
    target: Int,
    size: Long,
    `data`: Long,
    flags: Int,
): Unit = GLWrapper.instance.GL44.glBufferStorage(target, size, `data`, flags)

public inline fun glClearTexSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL44.glClearTexSubImage(texture, level, xoffset, yoffset, zoffset,
        width, height, depth, format, type, `data`)

public inline fun glClearTexSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL44.glClearTexSubImage(texture, level, xoffset, yoffset, zoffset,
        width, height, depth, format, type, `data`)

public inline fun glClearTexImage(
    texture: Int,
    level: Int,
    format: Int,
    type: Int,
    `data`: Ptr,
): Unit = GLWrapper.instance.GL44.glClearTexImage(texture, level, format, type, `data`)

public inline fun glClearTexImage(
    texture: Int,
    level: Int,
    format: Int,
    type: Int,
    `data`: Long,
): Unit = GLWrapper.instance.GL44.glClearTexImage(texture, level, format, type, `data`)

public inline fun glBindBuffersBase(
    target: Int,
    first: Int,
    count: Int,
    buffers: Ptr,
): Unit = GLWrapper.instance.GL44.glBindBuffersBase(target, first, count, buffers)

public inline fun glBindBuffersBase(
    target: Int,
    first: Int,
    count: Int,
    buffers: Long,
): Unit = GLWrapper.instance.GL44.glBindBuffersBase(target, first, count, buffers)

public inline fun glBindBuffersRange(
    target: Int,
    first: Int,
    count: Int,
    buffers: Ptr,
    offsets: Ptr,
    sizes: Ptr,
): Unit = GLWrapper.instance.GL44.glBindBuffersRange(target, first, count, buffers, offsets, sizes)

public inline fun glBindBuffersRange(
    target: Int,
    first: Int,
    count: Int,
    buffers: Long,
    offsets: Long,
    sizes: Long,
): Unit = GLWrapper.instance.GL44.glBindBuffersRange(target, first, count, buffers, offsets, sizes)

public inline fun glBindTextures(
    first: Int,
    count: Int,
    textures: Ptr,
): Unit = GLWrapper.instance.GL44.glBindTextures(first, count, textures)

public inline fun glBindTextures(
    first: Int,
    count: Int,
    textures: Long,
): Unit = GLWrapper.instance.GL44.glBindTextures(first, count, textures)

public inline fun glBindSamplers(
    first: Int,
    count: Int,
    samplers: Ptr,
): Unit = GLWrapper.instance.GL44.glBindSamplers(first, count, samplers)

public inline fun glBindSamplers(
    first: Int,
    count: Int,
    samplers: Long,
): Unit = GLWrapper.instance.GL44.glBindSamplers(first, count, samplers)

public inline fun glBindImageTextures(
    first: Int,
    count: Int,
    textures: Ptr,
): Unit = GLWrapper.instance.GL44.glBindImageTextures(first, count, textures)

public inline fun glBindImageTextures(
    first: Int,
    count: Int,
    textures: Long,
): Unit = GLWrapper.instance.GL44.glBindImageTextures(first, count, textures)

public inline fun glBindVertexBuffers(
    first: Int,
    count: Int,
    buffers: Ptr,
    offsets: Ptr,
    strides: Ptr,
): Unit = GLWrapper.instance.GL44.glBindVertexBuffers(first, count, buffers, offsets, strides)

public inline fun glBindVertexBuffers(
    first: Int,
    count: Int,
    buffers: Long,
    offsets: Long,
    strides: Long,
): Unit = GLWrapper.instance.GL44.glBindVertexBuffers(first, count, buffers, offsets, strides)
