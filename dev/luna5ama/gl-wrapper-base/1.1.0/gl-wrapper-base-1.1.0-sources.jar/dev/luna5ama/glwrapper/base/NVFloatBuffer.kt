@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVFloatBuffer : GLBase

public const val GL_FLOAT_R_NV: Int = 34_944

public const val GL_FLOAT_RG_NV: Int = 34_945

public const val GL_FLOAT_RGB_NV: Int = 34_946

public const val GL_FLOAT_RGBA_NV: Int = 34_947

public const val GL_FLOAT_R16_NV: Int = 34_948

public const val GL_FLOAT_R32_NV: Int = 34_949

public const val GL_FLOAT_RG16_NV: Int = 34_950

public const val GL_FLOAT_RG32_NV: Int = 34_951

public const val GL_FLOAT_RGB16_NV: Int = 34_952

public const val GL_FLOAT_RGB32_NV: Int = 34_953

public const val GL_FLOAT_RGBA16_NV: Int = 34_954

public const val GL_FLOAT_RGBA32_NV: Int = 34_955

public const val GL_TEXTURE_FLOAT_COMPONENTS_NV: Int = 34_956

public const val GL_FLOAT_CLEAR_COLOR_VALUE_NV: Int = 34_957

public const val GL_FLOAT_RGBA_MODE_NV: Int = 34_958
