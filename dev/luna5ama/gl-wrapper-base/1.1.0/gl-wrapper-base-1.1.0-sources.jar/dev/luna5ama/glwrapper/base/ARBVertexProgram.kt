@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBVertexProgram : GLBase {
    @PtrParameter([1])
    public fun glVertexAttrib1svARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib1svARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib1fvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib1fvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib1dvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib1dvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib2svARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib2svARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib2fvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib2fvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib2dvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib2dvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib3svARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib3svARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib3fvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib3fvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib3dvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib3dvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4fvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4fvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4bvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4bvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4svARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4svARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4ivARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4ivARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4ubvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4ubvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4usvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4usvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4uivARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4uivARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4dvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4dvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4NbvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4NbvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4NsvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4NsvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4NivARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4NivARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4NubvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4NubvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4NusvARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4NusvARB(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4NuivARB(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4NuivARB(index: Int, v: Long)

    @PtrParameter([5])
    public fun glVertexAttribPointerARB(
        index: Int,
        size: Int,
        type: Int,
        normalized: Boolean,
        stride: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glVertexAttribPointerARB(
        index: Int,
        size: Int,
        type: Int,
        normalized: Boolean,
        stride: Int,
        pointer: Long,
    )

    @PtrParameter([3])
    public fun glProgramStringARB(
        target: Int,
        format: Int,
        len: Int,
        string: Ptr,
    )

    @Unsafe
    public fun glProgramStringARB(
        target: Int,
        format: Int,
        len: Int,
        string: Long,
    )

    public fun glBindProgramARB(target: Int, program: Int)

    @PtrParameter([1])
    public fun glDeleteProgramsARB(n: Int, programs: Ptr)

    @Unsafe
    public fun glDeleteProgramsARB(n: Int, programs: Long)

    @PtrParameter([1])
    public fun glGenProgramsARB(n: Int, programs: Ptr)

    @Unsafe
    public fun glGenProgramsARB(n: Int, programs: Long)

    public fun glProgramEnvParameter4dARB(
        target: Int,
        index: Int,
        x: Double,
        y: Double,
        z: Double,
        w: Double,
    )

    @PtrParameter([2])
    public fun glProgramEnvParameter4dvARB(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glProgramEnvParameter4dvARB(
        target: Int,
        index: Int,
        params: Long,
    )

    public fun glProgramEnvParameter4fARB(
        target: Int,
        index: Int,
        x: Float,
        y: Float,
        z: Float,
        w: Float,
    )

    @PtrParameter([2])
    public fun glProgramEnvParameter4fvARB(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glProgramEnvParameter4fvARB(
        target: Int,
        index: Int,
        params: Long,
    )

    public fun glProgramLocalParameter4dARB(
        target: Int,
        index: Int,
        x: Double,
        y: Double,
        z: Double,
        w: Double,
    )

    @PtrParameter([2])
    public fun glProgramLocalParameter4dvARB(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glProgramLocalParameter4dvARB(
        target: Int,
        index: Int,
        params: Long,
    )

    public fun glProgramLocalParameter4fARB(
        target: Int,
        index: Int,
        x: Float,
        y: Float,
        z: Float,
        w: Float,
    )

    @PtrParameter([2])
    public fun glProgramLocalParameter4fvARB(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glProgramLocalParameter4fvARB(
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetProgramEnvParameterfvARB(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramEnvParameterfvARB(
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetProgramEnvParameterdvARB(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramEnvParameterdvARB(
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetProgramLocalParameterfvARB(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramLocalParameterfvARB(
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetProgramLocalParameterdvARB(
        target: Int,
        index: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramLocalParameterdvARB(
        target: Int,
        index: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetProgramivARB(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramivARB(
        target: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetProgramStringARB(
        target: Int,
        pname: Int,
        string: Ptr,
    )

    @Unsafe
    public fun glGetProgramStringARB(
        target: Int,
        pname: Int,
        string: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribfvARB(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribfvARB(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribdvARB(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribdvARB(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribivARB(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribivARB(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribPointervARB(
        index: Int,
        pname: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribPointervARB(
        index: Int,
        pname: Int,
        pointer: Long,
    )

    public fun glIsProgramARB(program: Int): Boolean
}

public const val GL_VERTEX_PROGRAM_ARB: Int = 34_336

public const val GL_VERTEX_PROGRAM_POINT_SIZE_ARB: Int = 34_370

public const val GL_VERTEX_PROGRAM_TWO_SIDE_ARB: Int = 34_371

public const val GL_COLOR_SUM_ARB: Int = 33_880

public const val GL_PROGRAM_FORMAT_ASCII_ARB: Int = 34_933

public const val GL_VERTEX_ATTRIB_ARRAY_ENABLED_ARB: Int = 34_338

public const val GL_VERTEX_ATTRIB_ARRAY_SIZE_ARB: Int = 34_339

public const val GL_VERTEX_ATTRIB_ARRAY_STRIDE_ARB: Int = 34_340

public const val GL_VERTEX_ATTRIB_ARRAY_TYPE_ARB: Int = 34_341

public const val GL_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB: Int = 34_922

public const val GL_CURRENT_VERTEX_ATTRIB_ARB: Int = 34_342

public const val GL_VERTEX_ATTRIB_ARRAY_POINTER_ARB: Int = 34_373

public const val GL_PROGRAM_LENGTH_ARB: Int = 34_343

public const val GL_PROGRAM_FORMAT_ARB: Int = 34_934

public const val GL_PROGRAM_BINDING_ARB: Int = 34_423

public const val GL_PROGRAM_INSTRUCTIONS_ARB: Int = 34_976

public const val GL_MAX_PROGRAM_INSTRUCTIONS_ARB: Int = 34_977

public const val GL_PROGRAM_NATIVE_INSTRUCTIONS_ARB: Int = 34_978

public const val GL_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB: Int = 34_979

public const val GL_PROGRAM_TEMPORARIES_ARB: Int = 34_980

public const val GL_MAX_PROGRAM_TEMPORARIES_ARB: Int = 34_981

public const val GL_PROGRAM_NATIVE_TEMPORARIES_ARB: Int = 34_982

public const val GL_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB: Int = 34_983

public const val GL_PROGRAM_PARAMETERS_ARB: Int = 34_984

public const val GL_MAX_PROGRAM_PARAMETERS_ARB: Int = 34_985

public const val GL_PROGRAM_NATIVE_PARAMETERS_ARB: Int = 34_986

public const val GL_MAX_PROGRAM_NATIVE_PARAMETERS_ARB: Int = 34_987

public const val GL_PROGRAM_ATTRIBS_ARB: Int = 34_988

public const val GL_MAX_PROGRAM_ATTRIBS_ARB: Int = 34_989

public const val GL_PROGRAM_NATIVE_ATTRIBS_ARB: Int = 34_990

public const val GL_MAX_PROGRAM_NATIVE_ATTRIBS_ARB: Int = 34_991

public const val GL_PROGRAM_ADDRESS_REGISTERS_ARB: Int = 34_992

public const val GL_MAX_PROGRAM_ADDRESS_REGISTERS_ARB: Int = 34_993

public const val GL_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB: Int = 34_994

public const val GL_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB: Int = 34_995

public const val GL_MAX_PROGRAM_LOCAL_PARAMETERS_ARB: Int = 34_996

public const val GL_MAX_PROGRAM_ENV_PARAMETERS_ARB: Int = 34_997

public const val GL_PROGRAM_UNDER_NATIVE_LIMITS_ARB: Int = 34_998

public const val GL_PROGRAM_STRING_ARB: Int = 34_344

public const val GL_PROGRAM_ERROR_POSITION_ARB: Int = 34_379

public const val GL_CURRENT_MATRIX_ARB: Int = 34_369

public const val GL_TRANSPOSE_CURRENT_MATRIX_ARB: Int = 34_999

public const val GL_CURRENT_MATRIX_STACK_DEPTH_ARB: Int = 34_368

public const val GL_MAX_VERTEX_ATTRIBS_ARB: Int = 34_921

public const val GL_MAX_PROGRAM_MATRICES_ARB: Int = 34_351

public const val GL_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB: Int = 34_350

public const val GL_PROGRAM_ERROR_STRING_ARB: Int = 34_932

public const val GL_MATRIX0_ARB: Int = 35_008

public const val GL_MATRIX1_ARB: Int = 35_009

public const val GL_MATRIX2_ARB: Int = 35_010

public const val GL_MATRIX3_ARB: Int = 35_011

public const val GL_MATRIX4_ARB: Int = 35_012

public const val GL_MATRIX5_ARB: Int = 35_013

public const val GL_MATRIX6_ARB: Int = 35_014

public const val GL_MATRIX7_ARB: Int = 35_015

public const val GL_MATRIX8_ARB: Int = 35_016

public const val GL_MATRIX9_ARB: Int = 35_017

public const val GL_MATRIX10_ARB: Int = 35_018

public const val GL_MATRIX11_ARB: Int = 35_019

public const val GL_MATRIX12_ARB: Int = 35_020

public const val GL_MATRIX13_ARB: Int = 35_021

public const val GL_MATRIX14_ARB: Int = 35_022

public const val GL_MATRIX15_ARB: Int = 35_023

public const val GL_MATRIX16_ARB: Int = 35_024

public const val GL_MATRIX17_ARB: Int = 35_025

public const val GL_MATRIX18_ARB: Int = 35_026

public const val GL_MATRIX19_ARB: Int = 35_027

public const val GL_MATRIX20_ARB: Int = 35_028

public const val GL_MATRIX21_ARB: Int = 35_029

public const val GL_MATRIX22_ARB: Int = 35_030

public const val GL_MATRIX23_ARB: Int = 35_031

public const val GL_MATRIX24_ARB: Int = 35_032

public const val GL_MATRIX25_ARB: Int = 35_033

public const val GL_MATRIX26_ARB: Int = 35_034

public const val GL_MATRIX27_ARB: Int = 35_035

public const val GL_MATRIX28_ARB: Int = 35_036

public const val GL_MATRIX29_ARB: Int = 35_037

public const val GL_MATRIX30_ARB: Int = 35_038

public const val GL_MATRIX31_ARB: Int = 35_039

public inline fun glVertexAttrib1svARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib1svARB(index, v)

public inline fun glVertexAttrib1svARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib1svARB(index, v)

public inline fun glVertexAttrib1fvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib1fvARB(index, v)

public inline fun glVertexAttrib1fvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib1fvARB(index, v)

public inline fun glVertexAttrib1dvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib1dvARB(index, v)

public inline fun glVertexAttrib1dvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib1dvARB(index, v)

public inline fun glVertexAttrib2svARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib2svARB(index, v)

public inline fun glVertexAttrib2svARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib2svARB(index, v)

public inline fun glVertexAttrib2fvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib2fvARB(index, v)

public inline fun glVertexAttrib2fvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib2fvARB(index, v)

public inline fun glVertexAttrib2dvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib2dvARB(index, v)

public inline fun glVertexAttrib2dvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib2dvARB(index, v)

public inline fun glVertexAttrib3svARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib3svARB(index, v)

public inline fun glVertexAttrib3svARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib3svARB(index, v)

public inline fun glVertexAttrib3fvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib3fvARB(index, v)

public inline fun glVertexAttrib3fvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib3fvARB(index, v)

public inline fun glVertexAttrib3dvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib3dvARB(index, v)

public inline fun glVertexAttrib3dvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib3dvARB(index, v)

public inline fun glVertexAttrib4fvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4fvARB(index, v)

public inline fun glVertexAttrib4fvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4fvARB(index, v)

public inline fun glVertexAttrib4bvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4bvARB(index, v)

public inline fun glVertexAttrib4bvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4bvARB(index, v)

public inline fun glVertexAttrib4svARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4svARB(index, v)

public inline fun glVertexAttrib4svARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4svARB(index, v)

public inline fun glVertexAttrib4ivARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4ivARB(index, v)

public inline fun glVertexAttrib4ivARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4ivARB(index, v)

public inline fun glVertexAttrib4ubvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4ubvARB(index, v)

public inline fun glVertexAttrib4ubvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4ubvARB(index, v)

public inline fun glVertexAttrib4usvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4usvARB(index, v)

public inline fun glVertexAttrib4usvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4usvARB(index, v)

public inline fun glVertexAttrib4uivARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4uivARB(index, v)

public inline fun glVertexAttrib4uivARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4uivARB(index, v)

public inline fun glVertexAttrib4dvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4dvARB(index, v)

public inline fun glVertexAttrib4dvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4dvARB(index, v)

public inline fun glVertexAttrib4NbvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NbvARB(index, v)

public inline fun glVertexAttrib4NbvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NbvARB(index, v)

public inline fun glVertexAttrib4NsvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NsvARB(index, v)

public inline fun glVertexAttrib4NsvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NsvARB(index, v)

public inline fun glVertexAttrib4NivARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NivARB(index, v)

public inline fun glVertexAttrib4NivARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NivARB(index, v)

public inline fun glVertexAttrib4NubvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NubvARB(index, v)

public inline fun glVertexAttrib4NubvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NubvARB(index, v)

public inline fun glVertexAttrib4NusvARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NusvARB(index, v)

public inline fun glVertexAttrib4NusvARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NusvARB(index, v)

public inline fun glVertexAttrib4NuivARB(index: Int, v: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NuivARB(index, v)

public inline fun glVertexAttrib4NuivARB(index: Int, v: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glVertexAttrib4NuivARB(index, v)

public inline fun glVertexAttribPointerARB(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glVertexAttribPointerARB(index, size, type,
        normalized, stride, pointer)

public inline fun glVertexAttribPointerARB(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    pointer: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glVertexAttribPointerARB(index, size, type,
        normalized, stride, pointer)

public inline fun glProgramStringARB(
    target: Int,
    format: Int,
    len: Int,
    string: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramStringARB(target, format, len, string)

public inline fun glProgramStringARB(
    target: Int,
    format: Int,
    len: Int,
    string: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramStringARB(target, format, len, string)

public inline fun glBindProgramARB(target: Int, program: Int): Unit =
        GLWrapper.instance.ARBVertexProgram.glBindProgramARB(target, program)

public inline fun glDeleteProgramsARB(n: Int, programs: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glDeleteProgramsARB(n, programs)

public inline fun glDeleteProgramsARB(n: Int, programs: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glDeleteProgramsARB(n, programs)

public inline fun glGenProgramsARB(n: Int, programs: Ptr): Unit =
        GLWrapper.instance.ARBVertexProgram.glGenProgramsARB(n, programs)

public inline fun glGenProgramsARB(n: Int, programs: Long): Unit =
        GLWrapper.instance.ARBVertexProgram.glGenProgramsARB(n, programs)

public inline fun glProgramEnvParameter4dARB(
    target: Int,
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramEnvParameter4dARB(target, index, x, y, z, w)

public inline fun glProgramEnvParameter4dvARB(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramEnvParameter4dvARB(target, index, params)

public inline fun glProgramEnvParameter4dvARB(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramEnvParameter4dvARB(target, index, params)

public inline fun glProgramEnvParameter4fARB(
    target: Int,
    index: Int,
    x: Float,
    y: Float,
    z: Float,
    w: Float,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramEnvParameter4fARB(target, index, x, y, z, w)

public inline fun glProgramEnvParameter4fvARB(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramEnvParameter4fvARB(target, index, params)

public inline fun glProgramEnvParameter4fvARB(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramEnvParameter4fvARB(target, index, params)

public inline fun glProgramLocalParameter4dARB(
    target: Int,
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramLocalParameter4dARB(target, index, x, y, z,
        w)

public inline fun glProgramLocalParameter4dvARB(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramLocalParameter4dvARB(target, index, params)

public inline fun glProgramLocalParameter4dvARB(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramLocalParameter4dvARB(target, index, params)

public inline fun glProgramLocalParameter4fARB(
    target: Int,
    index: Int,
    x: Float,
    y: Float,
    z: Float,
    w: Float,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramLocalParameter4fARB(target, index, x, y, z,
        w)

public inline fun glProgramLocalParameter4fvARB(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramLocalParameter4fvARB(target, index, params)

public inline fun glProgramLocalParameter4fvARB(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glProgramLocalParameter4fvARB(target, index, params)

public inline fun glGetProgramEnvParameterfvARB(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramEnvParameterfvARB(target, index, params)

public inline fun glGetProgramEnvParameterfvARB(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramEnvParameterfvARB(target, index, params)

public inline fun glGetProgramEnvParameterdvARB(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramEnvParameterdvARB(target, index, params)

public inline fun glGetProgramEnvParameterdvARB(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramEnvParameterdvARB(target, index, params)

public inline fun glGetProgramLocalParameterfvARB(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramLocalParameterfvARB(target, index, params)

public inline fun glGetProgramLocalParameterfvARB(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramLocalParameterfvARB(target, index, params)

public inline fun glGetProgramLocalParameterdvARB(
    target: Int,
    index: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramLocalParameterdvARB(target, index, params)

public inline fun glGetProgramLocalParameterdvARB(
    target: Int,
    index: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramLocalParameterdvARB(target, index, params)

public inline fun glGetProgramivARB(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramivARB(target, pname, params)

public inline fun glGetProgramivARB(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramivARB(target, pname, params)

public inline fun glGetProgramStringARB(
    target: Int,
    pname: Int,
    string: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramStringARB(target, pname, string)

public inline fun glGetProgramStringARB(
    target: Int,
    pname: Int,
    string: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetProgramStringARB(target, pname, string)

public inline fun glGetVertexAttribfvARB(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetVertexAttribfvARB(index, pname, params)

public inline fun glGetVertexAttribfvARB(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetVertexAttribfvARB(index, pname, params)

public inline fun glGetVertexAttribdvARB(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetVertexAttribdvARB(index, pname, params)

public inline fun glGetVertexAttribdvARB(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetVertexAttribdvARB(index, pname, params)

public inline fun glGetVertexAttribivARB(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetVertexAttribivARB(index, pname, params)

public inline fun glGetVertexAttribivARB(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetVertexAttribivARB(index, pname, params)

public inline fun glGetVertexAttribPointervARB(
    index: Int,
    pname: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetVertexAttribPointervARB(index, pname, pointer)

public inline fun glGetVertexAttribPointervARB(
    index: Int,
    pname: Int,
    pointer: Long,
): Unit = GLWrapper.instance.ARBVertexProgram.glGetVertexAttribPointervARB(index, pname, pointer)

public inline fun glIsProgramARB(program: Int): Boolean =
        GLWrapper.instance.ARBVertexProgram.glIsProgramARB(program)
