@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTRasterMultisample : GLBase {
    public fun glRasterSamplesEXT(samples: Int, fixedsamplelocations: Boolean)
}

public const val GL_RASTER_MULTISAMPLE_EXT: Int = 37_671

public const val GL_RASTER_SAMPLES_EXT: Int = 37_672

public const val GL_MAX_RASTER_SAMPLES_EXT: Int = 37_673

public const val GL_RASTER_FIXED_SAMPLE_LOCATIONS_EXT: Int = 37_674

public const val GL_MULTISAMPLE_RASTERIZATION_ALLOWED_EXT: Int = 37_675

public const val GL_EFFECTIVE_RASTER_SAMPLES_EXT: Int = 37_676

public inline fun glRasterSamplesEXT(samples: Int, fixedsamplelocations: Boolean): Unit =
        GLWrapper.instance.EXTRasterMultisample.glRasterSamplesEXT(samples, fixedsamplelocations)
