@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVRobustnessVideoMemoryPurge : GLBase

public const val GL_PURGED_CONTEXT_RESET_NV: Int = 37_563
