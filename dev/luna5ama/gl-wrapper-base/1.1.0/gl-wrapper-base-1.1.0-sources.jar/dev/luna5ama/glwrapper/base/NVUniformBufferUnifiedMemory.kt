@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVUniformBufferUnifiedMemory : GLBase

public const val GL_UNIFORM_BUFFER_UNIFIED_NV: Int = 37_742

public const val GL_UNIFORM_BUFFER_ADDRESS_NV: Int = 37_743

public const val GL_UNIFORM_BUFFER_LENGTH_NV: Int = 37_744
