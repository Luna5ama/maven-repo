@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface AMDDrawBuffersBlend : GLBase {
    public fun glBlendFuncIndexedAMD(
        buf: Int,
        src: Int,
        dst: Int,
    )

    public fun glBlendFuncSeparateIndexedAMD(
        buf: Int,
        srcRGB: Int,
        dstRGB: Int,
        srcAlpha: Int,
        dstAlpha: Int,
    )

    public fun glBlendEquationIndexedAMD(buf: Int, mode: Int)

    public fun glBlendEquationSeparateIndexedAMD(
        buf: Int,
        modeRGB: Int,
        modeAlpha: Int,
    )
}

public inline fun glBlendFuncIndexedAMD(
    buf: Int,
    src: Int,
    dst: Int,
): Unit = GLWrapper.instance.AMDDrawBuffersBlend.glBlendFuncIndexedAMD(buf, src, dst)

public inline fun glBlendFuncSeparateIndexedAMD(
    buf: Int,
    srcRGB: Int,
    dstRGB: Int,
    srcAlpha: Int,
    dstAlpha: Int,
): Unit = GLWrapper.instance.AMDDrawBuffersBlend.glBlendFuncSeparateIndexedAMD(buf, srcRGB, dstRGB,
        srcAlpha, dstAlpha)

public inline fun glBlendEquationIndexedAMD(buf: Int, mode: Int): Unit =
        GLWrapper.instance.AMDDrawBuffersBlend.glBlendEquationIndexedAMD(buf, mode)

public inline fun glBlendEquationSeparateIndexedAMD(
    buf: Int,
    modeRGB: Int,
    modeAlpha: Int,
): Unit = GLWrapper.instance.AMDDrawBuffersBlend.glBlendEquationSeparateIndexedAMD(buf, modeRGB,
        modeAlpha)
