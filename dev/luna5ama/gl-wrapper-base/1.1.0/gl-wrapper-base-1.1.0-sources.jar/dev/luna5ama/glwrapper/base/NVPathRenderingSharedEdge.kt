@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVPathRenderingSharedEdge : GLBase

public const val GL_SHARED_EDGE_NV: Int = 192
