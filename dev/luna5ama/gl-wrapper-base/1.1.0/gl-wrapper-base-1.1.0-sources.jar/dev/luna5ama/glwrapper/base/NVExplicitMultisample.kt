@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVExplicitMultisample : GLBase {
    @PtrParameter([2])
    public fun glGetMultisamplefvNV(
        pname: Int,
        index: Int,
        `val`: Ptr,
    )

    @Unsafe
    public fun glGetMultisamplefvNV(
        pname: Int,
        index: Int,
        `val`: Long,
    )

    public fun glSampleMaskIndexedNV(index: Int, mask: Int)

    public fun glTexRenderbufferNV(target: Int, renderbuffer: Int)
}

public const val GL_SAMPLE_POSITION_NV: Int = 36_432

public const val GL_SAMPLE_MASK_NV: Int = 36_433

public const val GL_SAMPLE_MASK_VALUE_NV: Int = 36_434

public const val GL_TEXTURE_BINDING_RENDERBUFFER_NV: Int = 36_435

public const val GL_TEXTURE_RENDERBUFFER_DATA_STORE_BINDING_NV: Int = 36_436

public const val GL_MAX_SAMPLE_MASK_WORDS_NV: Int = 36_441

public const val GL_TEXTURE_RENDERBUFFER_NV: Int = 36_437

public const val GL_SAMPLER_RENDERBUFFER_NV: Int = 36_438

public const val GL_INT_SAMPLER_RENDERBUFFER_NV: Int = 36_439

public const val GL_UNSIGNED_INT_SAMPLER_RENDERBUFFER_NV: Int = 36_440

public inline fun glGetMultisamplefvNV(
    pname: Int,
    index: Int,
    `val`: Ptr,
): Unit = GLWrapper.instance.NVExplicitMultisample.glGetMultisamplefvNV(pname, index, `val`)

public inline fun glGetMultisamplefvNV(
    pname: Int,
    index: Int,
    `val`: Long,
): Unit = GLWrapper.instance.NVExplicitMultisample.glGetMultisamplefvNV(pname, index, `val`)

public inline fun glSampleMaskIndexedNV(index: Int, mask: Int): Unit =
        GLWrapper.instance.NVExplicitMultisample.glSampleMaskIndexedNV(index, mask)

public inline fun glTexRenderbufferNV(target: Int, renderbuffer: Int): Unit =
        GLWrapper.instance.NVExplicitMultisample.glTexRenderbufferNV(target, renderbuffer)
