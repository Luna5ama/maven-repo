@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVGPUShader5 : GLBase {
    public fun glUniform1i64NV(location: Int, x: Long)

    public fun glUniform2i64NV(
        location: Int,
        x: Long,
        y: Long,
    )

    public fun glUniform3i64NV(
        location: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    public fun glUniform4i64NV(
        location: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([2])
    public fun glUniform1i64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1i64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform2i64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2i64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform3i64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3i64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform4i64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4i64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glUniform1ui64NV(location: Int, x: Long)

    public fun glUniform2ui64NV(
        location: Int,
        x: Long,
        y: Long,
    )

    public fun glUniform3ui64NV(
        location: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    public fun glUniform4ui64NV(
        location: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([2])
    public fun glUniform1ui64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1ui64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform2ui64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2ui64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform3ui64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3ui64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform4ui64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4ui64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformi64vNV(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformi64vNV(
        program: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformui64vNV(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformui64vNV(
        program: Int,
        location: Int,
        params: Long,
    )

    public fun glProgramUniform1i64NV(
        program: Int,
        location: Int,
        x: Long,
    )

    public fun glProgramUniform2i64NV(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
    )

    public fun glProgramUniform3i64NV(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    public fun glProgramUniform4i64NV(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    public fun glProgramUniform1ui64NV(
        program: Int,
        location: Int,
        x: Long,
    )

    public fun glProgramUniform2ui64NV(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
    )

    public fun glProgramUniform3ui64NV(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
        z: Long,
    )

    public fun glProgramUniform4ui64NV(
        program: Int,
        location: Int,
        x: Long,
        y: Long,
        z: Long,
        w: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )
}

public const val GL_INT64_NV: Int = 5_134

public const val GL_UNSIGNED_INT64_NV: Int = 5_135

public const val GL_INT8_NV: Int = 36_832

public const val GL_INT8_VEC2_NV: Int = 36_833

public const val GL_INT8_VEC3_NV: Int = 36_834

public const val GL_INT8_VEC4_NV: Int = 36_835

public const val GL_INT16_NV: Int = 36_836

public const val GL_INT16_VEC2_NV: Int = 36_837

public const val GL_INT16_VEC3_NV: Int = 36_838

public const val GL_INT16_VEC4_NV: Int = 36_839

public const val GL_INT64_VEC2_NV: Int = 36_841

public const val GL_INT64_VEC3_NV: Int = 36_842

public const val GL_INT64_VEC4_NV: Int = 36_843

public const val GL_UNSIGNED_INT8_NV: Int = 36_844

public const val GL_UNSIGNED_INT8_VEC2_NV: Int = 36_845

public const val GL_UNSIGNED_INT8_VEC3_NV: Int = 36_846

public const val GL_UNSIGNED_INT8_VEC4_NV: Int = 36_847

public const val GL_UNSIGNED_INT16_NV: Int = 36_848

public const val GL_UNSIGNED_INT16_VEC2_NV: Int = 36_849

public const val GL_UNSIGNED_INT16_VEC3_NV: Int = 36_850

public const val GL_UNSIGNED_INT16_VEC4_NV: Int = 36_851

public const val GL_UNSIGNED_INT64_VEC2_NV: Int = 36_853

public const val GL_UNSIGNED_INT64_VEC3_NV: Int = 36_854

public const val GL_UNSIGNED_INT64_VEC4_NV: Int = 36_855

public const val GL_FLOAT16_NV: Int = 36_856

public const val GL_FLOAT16_VEC2_NV: Int = 36_857

public const val GL_FLOAT16_VEC3_NV: Int = 36_858

public const val GL_FLOAT16_VEC4_NV: Int = 36_859

public inline fun glUniform1i64NV(location: Int, x: Long): Unit =
        GLWrapper.instance.NVGPUShader5.glUniform1i64NV(location, x)

public inline fun glUniform2i64NV(
    location: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform2i64NV(location, x, y)

public inline fun glUniform3i64NV(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform3i64NV(location, x, y, z)

public inline fun glUniform4i64NV(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform4i64NV(location, x, y, z, w)

public inline fun glUniform1i64vNV(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform1i64vNV(location, count, `value`)

public inline fun glUniform1i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform1i64vNV(location, count, `value`)

public inline fun glUniform2i64vNV(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform2i64vNV(location, count, `value`)

public inline fun glUniform2i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform2i64vNV(location, count, `value`)

public inline fun glUniform3i64vNV(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform3i64vNV(location, count, `value`)

public inline fun glUniform3i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform3i64vNV(location, count, `value`)

public inline fun glUniform4i64vNV(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform4i64vNV(location, count, `value`)

public inline fun glUniform4i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform4i64vNV(location, count, `value`)

public inline fun glUniform1ui64NV(location: Int, x: Long): Unit =
        GLWrapper.instance.NVGPUShader5.glUniform1ui64NV(location, x)

public inline fun glUniform2ui64NV(
    location: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform2ui64NV(location, x, y)

public inline fun glUniform3ui64NV(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform3ui64NV(location, x, y, z)

public inline fun glUniform4ui64NV(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform4ui64NV(location, x, y, z, w)

public inline fun glUniform1ui64vNV(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform1ui64vNV(location, count, `value`)

public inline fun glUniform1ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform1ui64vNV(location, count, `value`)

public inline fun glUniform2ui64vNV(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform2ui64vNV(location, count, `value`)

public inline fun glUniform2ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform2ui64vNV(location, count, `value`)

public inline fun glUniform3ui64vNV(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform3ui64vNV(location, count, `value`)

public inline fun glUniform3ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform3ui64vNV(location, count, `value`)

public inline fun glUniform4ui64vNV(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform4ui64vNV(location, count, `value`)

public inline fun glUniform4ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glUniform4ui64vNV(location, count, `value`)

public inline fun glGetUniformi64vNV(
    program: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glGetUniformi64vNV(program, location, params)

public inline fun glGetUniformi64vNV(
    program: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glGetUniformi64vNV(program, location, params)

public inline fun glGetUniformui64vNV(
    program: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glGetUniformui64vNV(program, location, params)

public inline fun glGetUniformui64vNV(
    program: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glGetUniformui64vNV(program, location, params)

public inline fun glProgramUniform1i64NV(
    program: Int,
    location: Int,
    x: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform1i64NV(program, location, x)

public inline fun glProgramUniform2i64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform2i64NV(program, location, x, y)

public inline fun glProgramUniform3i64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform3i64NV(program, location, x, y, z)

public inline fun glProgramUniform4i64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform4i64NV(program, location, x, y, z, w)

public inline fun glProgramUniform1i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform1i64vNV(program, location, count, `value`)

public inline fun glProgramUniform1i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform1i64vNV(program, location, count, `value`)

public inline fun glProgramUniform2i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform2i64vNV(program, location, count, `value`)

public inline fun glProgramUniform2i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform2i64vNV(program, location, count, `value`)

public inline fun glProgramUniform3i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform3i64vNV(program, location, count, `value`)

public inline fun glProgramUniform3i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform3i64vNV(program, location, count, `value`)

public inline fun glProgramUniform4i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform4i64vNV(program, location, count, `value`)

public inline fun glProgramUniform4i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform4i64vNV(program, location, count, `value`)

public inline fun glProgramUniform1ui64NV(
    program: Int,
    location: Int,
    x: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform1ui64NV(program, location, x)

public inline fun glProgramUniform2ui64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform2ui64NV(program, location, x, y)

public inline fun glProgramUniform3ui64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform3ui64NV(program, location, x, y, z)

public inline fun glProgramUniform4ui64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform4ui64NV(program, location, x, y, z, w)

public inline fun glProgramUniform1ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform1ui64vNV(program, location, count,
        `value`)

public inline fun glProgramUniform1ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform1ui64vNV(program, location, count,
        `value`)

public inline fun glProgramUniform2ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform2ui64vNV(program, location, count,
        `value`)

public inline fun glProgramUniform2ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform2ui64vNV(program, location, count,
        `value`)

public inline fun glProgramUniform3ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform3ui64vNV(program, location, count,
        `value`)

public inline fun glProgramUniform3ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform3ui64vNV(program, location, count,
        `value`)

public inline fun glProgramUniform4ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform4ui64vNV(program, location, count,
        `value`)

public inline fun glProgramUniform4ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVGPUShader5.glProgramUniform4ui64vNV(program, location, count,
        `value`)
