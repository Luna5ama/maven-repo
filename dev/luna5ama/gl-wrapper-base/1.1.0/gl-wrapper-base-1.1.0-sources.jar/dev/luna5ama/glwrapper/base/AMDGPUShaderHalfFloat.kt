@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface AMDGPUShaderHalfFloat : GLBase

public const val GL_FLOAT16_MAT2_AMD: Int = 37_317

public const val GL_FLOAT16_MAT3_AMD: Int = 37_318

public const val GL_FLOAT16_MAT4_AMD: Int = 37_319

public const val GL_FLOAT16_MAT2x3_AMD: Int = 37_320

public const val GL_FLOAT16_MAT2x4_AMD: Int = 37_321

public const val GL_FLOAT16_MAT3x2_AMD: Int = 37_322

public const val GL_FLOAT16_MAT3x4_AMD: Int = 37_323

public const val GL_FLOAT16_MAT4x2_AMD: Int = 37_324

public const val GL_FLOAT16_MAT4x3_AMD: Int = 37_325
