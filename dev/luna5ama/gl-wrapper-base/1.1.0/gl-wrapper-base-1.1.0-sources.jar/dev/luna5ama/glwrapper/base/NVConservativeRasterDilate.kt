@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVConservativeRasterDilate : GLBase {
    public fun glConservativeRasterParameterfNV(pname: Int, `value`: Float)
}

public const val GL_CONSERVATIVE_RASTER_DILATE_NV: Int = 37_753

public const val GL_CONSERVATIVE_RASTER_DILATE_RANGE_NV: Int = 37_754

public const val GL_CONSERVATIVE_RASTER_DILATE_GRANULARITY_NV: Int = 37_755

public inline fun glConservativeRasterParameterfNV(pname: Int, `value`: Float): Unit =
        GLWrapper.instance.NVConservativeRasterDilate.glConservativeRasterParameterfNV(pname,
        `value`)
