@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTSemaphore : GLBase {
    @PtrParameter([1])
    public fun glGetUnsignedBytevEXT(pname: Int, `data`: Ptr)

    @Unsafe
    public fun glGetUnsignedBytevEXT(pname: Int, `data`: Long)

    @PtrParameter([2])
    public fun glGetUnsignedBytei_vEXT(
        target: Int,
        index: Int,
        `data`: Ptr,
    )

    @Unsafe
    public fun glGetUnsignedBytei_vEXT(
        target: Int,
        index: Int,
        `data`: Long,
    )

    @PtrParameter([1])
    public fun glGenSemaphoresEXT(n: Int, semaphores: Ptr)

    @Unsafe
    public fun glGenSemaphoresEXT(n: Int, semaphores: Long)

    @PtrParameter([1])
    public fun glDeleteSemaphoresEXT(n: Int, semaphores: Ptr)

    @Unsafe
    public fun glDeleteSemaphoresEXT(n: Int, semaphores: Long)

    public fun glIsSemaphoreEXT(semaphore: Int): Boolean

    @PtrParameter([2])
    public fun glSemaphoreParameterui64vEXT(
        semaphore: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glSemaphoreParameterui64vEXT(
        semaphore: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetSemaphoreParameterui64vEXT(
        semaphore: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetSemaphoreParameterui64vEXT(
        semaphore: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2, 4, 5])
    public fun glWaitSemaphoreEXT(
        semaphore: Int,
        numBufferBarriers: Int,
        buffers: Ptr,
        numTextureBarriers: Int,
        textures: Ptr,
        srcLayouts: Ptr,
    )

    @Unsafe
    public fun glWaitSemaphoreEXT(
        semaphore: Int,
        numBufferBarriers: Int,
        buffers: Long,
        numTextureBarriers: Int,
        textures: Long,
        srcLayouts: Long,
    )

    @PtrParameter([2, 4, 5])
    public fun glSignalSemaphoreEXT(
        semaphore: Int,
        numBufferBarriers: Int,
        buffers: Ptr,
        numTextureBarriers: Int,
        textures: Ptr,
        dstLayouts: Ptr,
    )

    @Unsafe
    public fun glSignalSemaphoreEXT(
        semaphore: Int,
        numBufferBarriers: Int,
        buffers: Long,
        numTextureBarriers: Int,
        textures: Long,
        dstLayouts: Long,
    )
}

public const val GL_LAYOUT_GENERAL_EXT: Int = 38_285

public const val GL_LAYOUT_COLOR_ATTACHMENT_EXT: Int = 38_286

public const val GL_LAYOUT_DEPTH_STENCIL_ATTACHMENT_EXT: Int = 38_287

public const val GL_LAYOUT_DEPTH_STENCIL_READ_ONLY_EXT: Int = 38_288

public const val GL_LAYOUT_SHADER_READ_ONLY_EXT: Int = 38_289

public const val GL_LAYOUT_TRANSFER_SRC_EXT: Int = 38_290

public const val GL_LAYOUT_TRANSFER_DST_EXT: Int = 38_291

public const val GL_LAYOUT_DEPTH_READ_ONLY_STENCIL_ATTACHMENT_EXT: Int = 38_192

public const val GL_LAYOUT_DEPTH_ATTACHMENT_STENCIL_READ_ONLY_EXT: Int = 38_193

public inline fun glGenSemaphoresEXT(n: Int, semaphores: Ptr): Unit =
        GLWrapper.instance.EXTSemaphore.glGenSemaphoresEXT(n, semaphores)

public inline fun glGenSemaphoresEXT(n: Int, semaphores: Long): Unit =
        GLWrapper.instance.EXTSemaphore.glGenSemaphoresEXT(n, semaphores)

public inline fun glDeleteSemaphoresEXT(n: Int, semaphores: Ptr): Unit =
        GLWrapper.instance.EXTSemaphore.glDeleteSemaphoresEXT(n, semaphores)

public inline fun glDeleteSemaphoresEXT(n: Int, semaphores: Long): Unit =
        GLWrapper.instance.EXTSemaphore.glDeleteSemaphoresEXT(n, semaphores)

public inline fun glIsSemaphoreEXT(semaphore: Int): Boolean =
        GLWrapper.instance.EXTSemaphore.glIsSemaphoreEXT(semaphore)

public inline fun glSemaphoreParameterui64vEXT(
    semaphore: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTSemaphore.glSemaphoreParameterui64vEXT(semaphore, pname, params)

public inline fun glSemaphoreParameterui64vEXT(
    semaphore: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTSemaphore.glSemaphoreParameterui64vEXT(semaphore, pname, params)

public inline fun glGetSemaphoreParameterui64vEXT(
    semaphore: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTSemaphore.glGetSemaphoreParameterui64vEXT(semaphore, pname, params)

public inline fun glGetSemaphoreParameterui64vEXT(
    semaphore: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTSemaphore.glGetSemaphoreParameterui64vEXT(semaphore, pname, params)

public inline fun glWaitSemaphoreEXT(
    semaphore: Int,
    numBufferBarriers: Int,
    buffers: Ptr,
    numTextureBarriers: Int,
    textures: Ptr,
    srcLayouts: Ptr,
): Unit = GLWrapper.instance.EXTSemaphore.glWaitSemaphoreEXT(semaphore, numBufferBarriers, buffers,
        numTextureBarriers, textures, srcLayouts)

public inline fun glWaitSemaphoreEXT(
    semaphore: Int,
    numBufferBarriers: Int,
    buffers: Long,
    numTextureBarriers: Int,
    textures: Long,
    srcLayouts: Long,
): Unit = GLWrapper.instance.EXTSemaphore.glWaitSemaphoreEXT(semaphore, numBufferBarriers, buffers,
        numTextureBarriers, textures, srcLayouts)

public inline fun glSignalSemaphoreEXT(
    semaphore: Int,
    numBufferBarriers: Int,
    buffers: Ptr,
    numTextureBarriers: Int,
    textures: Ptr,
    dstLayouts: Ptr,
): Unit = GLWrapper.instance.EXTSemaphore.glSignalSemaphoreEXT(semaphore, numBufferBarriers,
        buffers, numTextureBarriers, textures, dstLayouts)

public inline fun glSignalSemaphoreEXT(
    semaphore: Int,
    numBufferBarriers: Int,
    buffers: Long,
    numTextureBarriers: Int,
    textures: Long,
    dstLayouts: Long,
): Unit = GLWrapper.instance.EXTSemaphore.glSignalSemaphoreEXT(semaphore, numBufferBarriers,
        buffers, numTextureBarriers, textures, dstLayouts)
