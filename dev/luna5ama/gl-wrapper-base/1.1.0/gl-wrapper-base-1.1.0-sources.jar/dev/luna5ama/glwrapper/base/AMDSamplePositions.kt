@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface AMDSamplePositions : GLBase {
    @PtrParameter([2])
    public fun glSetMultisamplefvAMD(
        pname: Int,
        index: Int,
        `val`: Ptr,
    )

    @Unsafe
    public fun glSetMultisamplefvAMD(
        pname: Int,
        index: Int,
        `val`: Long,
    )
}

public const val GL_SUBSAMPLE_DISTANCE_AMD: Int = 34_879

public inline fun glSetMultisamplefvAMD(
    pname: Int,
    index: Int,
    `val`: Ptr,
): Unit = GLWrapper.instance.AMDSamplePositions.glSetMultisamplefvAMD(pname, index, `val`)

public inline fun glSetMultisamplefvAMD(
    pname: Int,
    index: Int,
    `val`: Long,
): Unit = GLWrapper.instance.AMDSamplePositions.glSetMultisamplefvAMD(pname, index, `val`)
