@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVBindlessTexture : GLBase {
    public fun glGetTextureHandleNV(texture: Int): Long

    public fun glGetTextureSamplerHandleNV(texture: Int, sampler: Int): Long

    public fun glMakeTextureHandleResidentNV(handle: Long)

    public fun glMakeTextureHandleNonResidentNV(handle: Long)

    public fun glGetImageHandleNV(
        texture: Int,
        level: Int,
        layered: Boolean,
        layer: Int,
        format: Int,
    ): Long

    public fun glMakeImageHandleResidentNV(handle: Long, access: Int)

    public fun glMakeImageHandleNonResidentNV(handle: Long)

    public fun glUniformHandleui64NV(location: Int, `value`: Long)

    @PtrParameter([2])
    public fun glUniformHandleui64vNV(
        location: Int,
        count: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glUniformHandleui64vNV(
        location: Int,
        count: Int,
        values: Long,
    )

    public fun glProgramUniformHandleui64NV(
        program: Int,
        location: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniformHandleui64vNV(
        program: Int,
        location: Int,
        count: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glProgramUniformHandleui64vNV(
        program: Int,
        location: Int,
        count: Int,
        values: Long,
    )

    public fun glIsTextureHandleResidentNV(handle: Long): Boolean

    public fun glIsImageHandleResidentNV(handle: Long): Boolean
}

public inline fun glGetTextureHandleNV(texture: Int): Long =
        GLWrapper.instance.NVBindlessTexture.glGetTextureHandleNV(texture)

public inline fun glGetTextureSamplerHandleNV(texture: Int, sampler: Int): Long =
        GLWrapper.instance.NVBindlessTexture.glGetTextureSamplerHandleNV(texture, sampler)

public inline fun glMakeTextureHandleResidentNV(handle: Long): Unit =
        GLWrapper.instance.NVBindlessTexture.glMakeTextureHandleResidentNV(handle)

public inline fun glMakeTextureHandleNonResidentNV(handle: Long): Unit =
        GLWrapper.instance.NVBindlessTexture.glMakeTextureHandleNonResidentNV(handle)

public inline fun glGetImageHandleNV(
    texture: Int,
    level: Int,
    layered: Boolean,
    layer: Int,
    format: Int,
): Long = GLWrapper.instance.NVBindlessTexture.glGetImageHandleNV(texture, level, layered, layer,
        format)

public inline fun glMakeImageHandleResidentNV(handle: Long, access: Int): Unit =
        GLWrapper.instance.NVBindlessTexture.glMakeImageHandleResidentNV(handle, access)

public inline fun glMakeImageHandleNonResidentNV(handle: Long): Unit =
        GLWrapper.instance.NVBindlessTexture.glMakeImageHandleNonResidentNV(handle)

public inline fun glUniformHandleui64NV(location: Int, `value`: Long): Unit =
        GLWrapper.instance.NVBindlessTexture.glUniformHandleui64NV(location, `value`)

public inline fun glUniformHandleui64vNV(
    location: Int,
    count: Int,
    values: Ptr,
): Unit = GLWrapper.instance.NVBindlessTexture.glUniformHandleui64vNV(location, count, values)

public inline fun glUniformHandleui64vNV(
    location: Int,
    count: Int,
    values: Long,
): Unit = GLWrapper.instance.NVBindlessTexture.glUniformHandleui64vNV(location, count, values)

public inline fun glProgramUniformHandleui64NV(
    program: Int,
    location: Int,
    `value`: Long,
): Unit = GLWrapper.instance.NVBindlessTexture.glProgramUniformHandleui64NV(program, location,
        `value`)

public inline fun glProgramUniformHandleui64vNV(
    program: Int,
    location: Int,
    count: Int,
    values: Ptr,
): Unit = GLWrapper.instance.NVBindlessTexture.glProgramUniformHandleui64vNV(program, location,
        count, values)

public inline fun glProgramUniformHandleui64vNV(
    program: Int,
    location: Int,
    count: Int,
    values: Long,
): Unit = GLWrapper.instance.NVBindlessTexture.glProgramUniformHandleui64vNV(program, location,
        count, values)

public inline fun glIsTextureHandleResidentNV(handle: Long): Boolean =
        GLWrapper.instance.NVBindlessTexture.glIsTextureHandleResidentNV(handle)

public inline fun glIsImageHandleResidentNV(handle: Long): Boolean =
        GLWrapper.instance.NVBindlessTexture.glIsImageHandleResidentNV(handle)
