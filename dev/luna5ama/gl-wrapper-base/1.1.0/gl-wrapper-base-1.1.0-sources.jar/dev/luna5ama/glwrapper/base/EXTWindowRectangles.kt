@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTWindowRectangles : GLBase {
    @PtrParameter([2])
    public fun glWindowRectanglesEXT(
        mode: Int,
        count: Int,
        box: Ptr,
    )

    @Unsafe
    public fun glWindowRectanglesEXT(
        mode: Int,
        count: Int,
        box: Long,
    )
}

public const val GL_INCLUSIVE_EXT: Int = 36_624

public const val GL_EXCLUSIVE_EXT: Int = 36_625

public const val GL_WINDOW_RECTANGLE_EXT: Int = 36_626

public const val GL_WINDOW_RECTANGLE_MODE_EXT: Int = 36_627

public const val GL_MAX_WINDOW_RECTANGLES_EXT: Int = 36_628

public const val GL_NUM_WINDOW_RECTANGLES_EXT: Int = 36_629

public inline fun glWindowRectanglesEXT(
    mode: Int,
    count: Int,
    box: Ptr,
): Unit = GLWrapper.instance.EXTWindowRectangles.glWindowRectanglesEXT(mode, count, box)

public inline fun glWindowRectanglesEXT(
    mode: Int,
    count: Int,
    box: Long,
): Unit = GLWrapper.instance.EXTWindowRectangles.glWindowRectanglesEXT(mode, count, box)
