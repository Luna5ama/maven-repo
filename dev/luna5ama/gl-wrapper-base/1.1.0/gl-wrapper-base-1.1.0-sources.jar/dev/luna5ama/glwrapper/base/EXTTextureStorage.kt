@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTTextureStorage : GLBase {
    public fun glTexStorage1DEXT(
        target: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
    )

    public fun glTexStorage2DEXT(
        target: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    public fun glTexStorage3DEXT(
        target: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
    )

    public fun glTextureStorage1DEXT(
        texture: Int,
        target: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
    )

    public fun glTextureStorage2DEXT(
        texture: Int,
        target: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    public fun glTextureStorage3DEXT(
        texture: Int,
        target: Int,
        levels: Int,
        internalformat: Int,
        width: Int,
        height: Int,
        depth: Int,
    )
}

public const val GL_TEXTURE_IMMUTABLE_FORMAT_EXT: Int = 37_167

public const val GL_ALPHA8_EXT: Int = 32_828

public const val GL_LUMINANCE8_EXT: Int = 32_832

public const val GL_LUMINANCE8_ALPHA8_EXT: Int = 32_837

public const val GL_RGBA32F_EXT: Int = 34_836

public const val GL_RGB32F_EXT: Int = 34_837

public const val GL_ALPHA32F_EXT: Int = 34_838

public const val GL_LUMINANCE32F_EXT: Int = 34_840

public const val GL_LUMINANCE_ALPHA32F_EXT: Int = 34_841

public const val GL_RGBA16F_EXT: Int = 34_842

public const val GL_RGB16F_EXT: Int = 34_843

public const val GL_ALPHA16F_EXT: Int = 34_844

public const val GL_LUMINANCE16F_EXT: Int = 34_846

public const val GL_LUMINANCE_ALPHA16F_EXT: Int = 34_847

public const val GL_RGB10_A2_EXT: Int = 32_857

public const val GL_RGB10_EXT: Int = 32_850

public const val GL_BGRA8_EXT: Int = 37_793

public const val GL_R8_EXT: Int = 33_321

public const val GL_RG8_EXT: Int = 33_323

public const val GL_R32F_EXT: Int = 33_326

public const val GL_RG32F_EXT: Int = 33_328

public const val GL_R16F_EXT: Int = 33_325

public const val GL_RG16F_EXT: Int = 33_327

public const val GL_RGB_RAW_422_APPLE: Int = 35_409

public inline fun glTexStorage1DEXT(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
): Unit = GLWrapper.instance.EXTTextureStorage.glTexStorage1DEXT(target, levels, internalformat,
        width)

public inline fun glTexStorage2DEXT(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.EXTTextureStorage.glTexStorage2DEXT(target, levels, internalformat,
        width, height)

public inline fun glTexStorage3DEXT(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
): Unit = GLWrapper.instance.EXTTextureStorage.glTexStorage3DEXT(target, levels, internalformat,
        width, height, depth)

public inline fun glTextureStorage1DEXT(
    texture: Int,
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
): Unit = GLWrapper.instance.EXTTextureStorage.glTextureStorage1DEXT(texture, target, levels,
        internalformat, width)

public inline fun glTextureStorage2DEXT(
    texture: Int,
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.EXTTextureStorage.glTextureStorage2DEXT(texture, target, levels,
        internalformat, width, height)

public inline fun glTextureStorage3DEXT(
    texture: Int,
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
): Unit = GLWrapper.instance.EXTTextureStorage.glTextureStorage3DEXT(texture, target, levels,
        internalformat, width, height, depth)
