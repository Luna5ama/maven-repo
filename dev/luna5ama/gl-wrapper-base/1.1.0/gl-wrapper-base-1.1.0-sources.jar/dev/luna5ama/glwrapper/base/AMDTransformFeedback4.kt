@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface AMDTransformFeedback4 : GLBase

public const val GL_STREAM_RASTERIZATION_AMD: Int = 37_280
