@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVMultisampleFilterHint : GLBase

public const val GL_MULTISAMPLE_FILTER_HINT_NV: Int = 34_100
