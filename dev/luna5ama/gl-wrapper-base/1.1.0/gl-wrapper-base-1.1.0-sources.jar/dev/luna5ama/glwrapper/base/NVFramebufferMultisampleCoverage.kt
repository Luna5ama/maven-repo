@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVFramebufferMultisampleCoverage : GLBase {
    public fun glRenderbufferStorageMultisampleCoverageNV(
        target: Int,
        coverageSamples: Int,
        colorSamples: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )
}

public const val GL_RENDERBUFFER_COVERAGE_SAMPLES_NV: Int = 36_011

public const val GL_RENDERBUFFER_COLOR_SAMPLES_NV: Int = 36_368

public const val GL_MAX_MULTISAMPLE_COVERAGE_MODES_NV: Int = 36_369

public const val GL_MULTISAMPLE_COVERAGE_MODES_NV: Int = 36_370

public inline fun glRenderbufferStorageMultisampleCoverageNV(
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit =
        GLWrapper.instance.NVFramebufferMultisampleCoverage.glRenderbufferStorageMultisampleCoverageNV(target,
        coverageSamples, colorSamples, internalformat, width, height)
