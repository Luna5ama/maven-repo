@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTSharedTexturePalette : GLBase

public const val GL_SHARED_TEXTURE_PALETTE_EXT: Int = 33_275
