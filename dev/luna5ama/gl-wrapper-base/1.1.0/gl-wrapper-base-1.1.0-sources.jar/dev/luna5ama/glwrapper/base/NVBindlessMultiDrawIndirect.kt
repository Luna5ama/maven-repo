@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVBindlessMultiDrawIndirect : GLBase {
    @PtrParameter([1])
    public fun glMultiDrawArraysIndirectBindlessNV(
        mode: Int,
        indirect: Ptr,
        drawCount: Int,
        stride: Int,
        vertexBufferCount: Int,
    )

    @Unsafe
    public fun glMultiDrawArraysIndirectBindlessNV(
        mode: Int,
        indirect: Long,
        drawCount: Int,
        stride: Int,
        vertexBufferCount: Int,
    )

    @PtrParameter([2])
    public fun glMultiDrawElementsIndirectBindlessNV(
        mode: Int,
        type: Int,
        indirect: Ptr,
        drawCount: Int,
        stride: Int,
        vertexBufferCount: Int,
    )

    @Unsafe
    public fun glMultiDrawElementsIndirectBindlessNV(
        mode: Int,
        type: Int,
        indirect: Long,
        drawCount: Int,
        stride: Int,
        vertexBufferCount: Int,
    )
}

public inline fun glMultiDrawArraysIndirectBindlessNV(
    mode: Int,
    indirect: Ptr,
    drawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
): Unit = GLWrapper.instance.NVBindlessMultiDrawIndirect.glMultiDrawArraysIndirectBindlessNV(mode,
        indirect, drawCount, stride, vertexBufferCount)

public inline fun glMultiDrawArraysIndirectBindlessNV(
    mode: Int,
    indirect: Long,
    drawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
): Unit = GLWrapper.instance.NVBindlessMultiDrawIndirect.glMultiDrawArraysIndirectBindlessNV(mode,
        indirect, drawCount, stride, vertexBufferCount)

public inline fun glMultiDrawElementsIndirectBindlessNV(
    mode: Int,
    type: Int,
    indirect: Ptr,
    drawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
): Unit = GLWrapper.instance.NVBindlessMultiDrawIndirect.glMultiDrawElementsIndirectBindlessNV(mode,
        type, indirect, drawCount, stride, vertexBufferCount)

public inline fun glMultiDrawElementsIndirectBindlessNV(
    mode: Int,
    type: Int,
    indirect: Long,
    drawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
): Unit = GLWrapper.instance.NVBindlessMultiDrawIndirect.glMultiDrawElementsIndirectBindlessNV(mode,
        type, indirect, drawCount, stride, vertexBufferCount)
