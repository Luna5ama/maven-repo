@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVViewportSwizzle : GLBase {
    public fun glViewportSwizzleNV(
        index: Int,
        swizzlex: Int,
        swizzley: Int,
        swizzlez: Int,
        swizzlew: Int,
    )
}

public const val GL_VIEWPORT_SWIZZLE_POSITIVE_X_NV: Int = 37_712

public const val GL_VIEWPORT_SWIZZLE_NEGATIVE_X_NV: Int = 37_713

public const val GL_VIEWPORT_SWIZZLE_POSITIVE_Y_NV: Int = 37_714

public const val GL_VIEWPORT_SWIZZLE_NEGATIVE_Y_NV: Int = 37_715

public const val GL_VIEWPORT_SWIZZLE_POSITIVE_Z_NV: Int = 37_716

public const val GL_VIEWPORT_SWIZZLE_NEGATIVE_Z_NV: Int = 37_717

public const val GL_VIEWPORT_SWIZZLE_POSITIVE_W_NV: Int = 37_718

public const val GL_VIEWPORT_SWIZZLE_NEGATIVE_W_NV: Int = 37_719

public const val GL_VIEWPORT_SWIZZLE_X_NV: Int = 37_720

public const val GL_VIEWPORT_SWIZZLE_Y_NV: Int = 37_721

public const val GL_VIEWPORT_SWIZZLE_Z_NV: Int = 37_722

public const val GL_VIEWPORT_SWIZZLE_W_NV: Int = 37_723

public inline fun glViewportSwizzleNV(
    index: Int,
    swizzlex: Int,
    swizzley: Int,
    swizzlez: Int,
    swizzlew: Int,
): Unit = GLWrapper.instance.NVViewportSwizzle.glViewportSwizzleNV(index, swizzlex, swizzley,
        swizzlez, swizzlew)
