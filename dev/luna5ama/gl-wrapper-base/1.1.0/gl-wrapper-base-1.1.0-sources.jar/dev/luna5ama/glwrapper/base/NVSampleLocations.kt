@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVSampleLocations : GLBase {
    @PtrParameter([3])
    public fun glFramebufferSampleLocationsfvNV(
        target: Int,
        start: Int,
        count: Int,
        v: Ptr,
    )

    @Unsafe
    public fun glFramebufferSampleLocationsfvNV(
        target: Int,
        start: Int,
        count: Int,
        v: Long,
    )

    @PtrParameter([3])
    public fun glNamedFramebufferSampleLocationsfvNV(
        framebuffer: Int,
        start: Int,
        count: Int,
        v: Ptr,
    )

    @Unsafe
    public fun glNamedFramebufferSampleLocationsfvNV(
        framebuffer: Int,
        start: Int,
        count: Int,
        v: Long,
    )

    public fun glResolveDepthValuesNV()
}

public const val GL_SAMPLE_LOCATION_SUBPIXEL_BITS_NV: Int = 37_693

public const val GL_SAMPLE_LOCATION_PIXEL_GRID_WIDTH_NV: Int = 37_694

public const val GL_SAMPLE_LOCATION_PIXEL_GRID_HEIGHT_NV: Int = 37_695

public const val GL_PROGRAMMABLE_SAMPLE_LOCATION_TABLE_SIZE_NV: Int = 37_696

public const val GL_SAMPLE_LOCATION_NV: Int = 36_432

public const val GL_PROGRAMMABLE_SAMPLE_LOCATION_NV: Int = 37_697

public const val GL_FRAMEBUFFER_PROGRAMMABLE_SAMPLE_LOCATIONS_NV: Int = 37_698

public const val GL_FRAMEBUFFER_SAMPLE_LOCATION_PIXEL_GRID_NV: Int = 37_699

public inline fun glFramebufferSampleLocationsfvNV(
    target: Int,
    start: Int,
    count: Int,
    v: Ptr,
): Unit = GLWrapper.instance.NVSampleLocations.glFramebufferSampleLocationsfvNV(target, start,
        count, v)

public inline fun glFramebufferSampleLocationsfvNV(
    target: Int,
    start: Int,
    count: Int,
    v: Long,
): Unit = GLWrapper.instance.NVSampleLocations.glFramebufferSampleLocationsfvNV(target, start,
        count, v)

public inline fun glNamedFramebufferSampleLocationsfvNV(
    framebuffer: Int,
    start: Int,
    count: Int,
    v: Ptr,
): Unit = GLWrapper.instance.NVSampleLocations.glNamedFramebufferSampleLocationsfvNV(framebuffer,
        start, count, v)

public inline fun glNamedFramebufferSampleLocationsfvNV(
    framebuffer: Int,
    start: Int,
    count: Int,
    v: Long,
): Unit = GLWrapper.instance.NVSampleLocations.glNamedFramebufferSampleLocationsfvNV(framebuffer,
        start, count, v)

public inline fun glResolveDepthValuesNV(): Unit =
        GLWrapper.instance.NVSampleLocations.glResolveDepthValuesNV()
