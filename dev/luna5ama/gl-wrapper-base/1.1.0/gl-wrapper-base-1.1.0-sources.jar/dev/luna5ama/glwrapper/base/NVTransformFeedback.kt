@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVTransformFeedback : GLBase {
    public fun glBeginTransformFeedbackNV(primitiveMode: Int)

    public fun glEndTransformFeedbackNV()

    @PtrParameter([1])
    public fun glTransformFeedbackAttribsNV(
        count: Int,
        attribs: Ptr,
        bufferMode: Int,
    )

    @Unsafe
    public fun glTransformFeedbackAttribsNV(
        count: Int,
        attribs: Long,
        bufferMode: Int,
    )

    public fun glBindBufferRangeNV(
        target: Int,
        index: Int,
        buffer: Int,
        offset: Long,
        size: Long,
    )

    public fun glBindBufferOffsetNV(
        target: Int,
        index: Int,
        buffer: Int,
        offset: Long,
    )

    public fun glBindBufferBaseNV(
        target: Int,
        index: Int,
        buffer: Int,
    )

    @PtrParameter([2])
    public fun glTransformFeedbackVaryingsNV(
        program: Int,
        count: Int,
        locations: Ptr,
        bufferMode: Int,
    )

    @Unsafe
    public fun glTransformFeedbackVaryingsNV(
        program: Int,
        count: Int,
        locations: Long,
        bufferMode: Int,
    )

    @PtrParameter([1])
    public fun glActiveVaryingNV(program: Int, name: Ptr)

    @Unsafe
    public fun glActiveVaryingNV(program: Int, name: Long)

    @PtrParameter([1])
    public fun glGetVaryingLocationNV(program: Int, name: Ptr): Int

    @Unsafe
    public fun glGetVaryingLocationNV(program: Int, name: Long): Int

    @PtrParameter([3, 4, 5, 6])
    public fun glGetActiveVaryingNV(
        program: Int,
        index: Int,
        bufSize: Int,
        length: Ptr,
        size: Ptr,
        type: Ptr,
        name: Ptr,
    )

    @Unsafe
    public fun glGetActiveVaryingNV(
        program: Int,
        index: Int,
        bufSize: Int,
        length: Long,
        size: Long,
        type: Long,
        name: Long,
    )

    @PtrParameter([2])
    public fun glGetTransformFeedbackVaryingNV(
        program: Int,
        index: Int,
        location: Ptr,
    )

    @Unsafe
    public fun glGetTransformFeedbackVaryingNV(
        program: Int,
        index: Int,
        location: Long,
    )

    @PtrParameter([1, 3])
    public fun glTransformFeedbackStreamAttribsNV(
        count: Int,
        attribs: Ptr,
        nbuffers: Int,
        bufstreams: Ptr,
        bufferMode: Int,
    )

    @Unsafe
    public fun glTransformFeedbackStreamAttribsNV(
        count: Int,
        attribs: Long,
        nbuffers: Int,
        bufstreams: Long,
        bufferMode: Int,
    )
}

public const val GL_TRANSFORM_FEEDBACK_BUFFER_NV: Int = 35_982

public const val GL_TRANSFORM_FEEDBACK_BUFFER_START_NV: Int = 35_972

public const val GL_TRANSFORM_FEEDBACK_BUFFER_SIZE_NV: Int = 35_973

public const val GL_TRANSFORM_FEEDBACK_RECORD_NV: Int = 35_974

public const val GL_TRANSFORM_FEEDBACK_BUFFER_BINDING_NV: Int = 35_983

public const val GL_INTERLEAVED_ATTRIBS_NV: Int = 35_980

public const val GL_SEPARATE_ATTRIBS_NV: Int = 35_981

public const val GL_PRIMITIVES_GENERATED_NV: Int = 35_975

public const val GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN_NV: Int = 35_976

public const val GL_RASTERIZER_DISCARD_NV: Int = 35_977

public const val GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS_NV: Int = 35_978

public const val GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS_NV: Int = 35_979

public const val GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS_NV: Int = 35_968

public const val GL_TRANSFORM_FEEDBACK_ATTRIBS_NV: Int = 35_966

public const val GL_ACTIVE_VARYINGS_NV: Int = 35_969

public const val GL_ACTIVE_VARYING_MAX_LENGTH_NV: Int = 35_970

public const val GL_TRANSFORM_FEEDBACK_VARYINGS_NV: Int = 35_971

public const val GL_TRANSFORM_FEEDBACK_BUFFER_MODE_NV: Int = 35_967

public const val GL_BACK_PRIMARY_COLOR_NV: Int = 35_959

public const val GL_BACK_SECONDARY_COLOR_NV: Int = 35_960

public const val GL_TEXTURE_COORD_NV: Int = 35_961

public const val GL_CLIP_DISTANCE_NV: Int = 35_962

public const val GL_VERTEX_ID_NV: Int = 35_963

public const val GL_PRIMITIVE_ID_NV: Int = 35_964

public const val GL_GENERIC_ATTRIB_NV: Int = 35_965

public const val GL_LAYER_NV: Int = 36_266

public inline fun glBeginTransformFeedbackNV(primitiveMode: Int): Unit =
        GLWrapper.instance.NVTransformFeedback.glBeginTransformFeedbackNV(primitiveMode)

public inline fun glEndTransformFeedbackNV(): Unit =
        GLWrapper.instance.NVTransformFeedback.glEndTransformFeedbackNV()

public inline fun glTransformFeedbackAttribsNV(
    count: Int,
    attribs: Ptr,
    bufferMode: Int,
): Unit = GLWrapper.instance.NVTransformFeedback.glTransformFeedbackAttribsNV(count, attribs,
        bufferMode)

public inline fun glTransformFeedbackAttribsNV(
    count: Int,
    attribs: Long,
    bufferMode: Int,
): Unit = GLWrapper.instance.NVTransformFeedback.glTransformFeedbackAttribsNV(count, attribs,
        bufferMode)

public inline fun glBindBufferRangeNV(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
    size: Long,
): Unit = GLWrapper.instance.NVTransformFeedback.glBindBufferRangeNV(target, index, buffer, offset,
        size)

public inline fun glBindBufferOffsetNV(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
): Unit = GLWrapper.instance.NVTransformFeedback.glBindBufferOffsetNV(target, index, buffer, offset)

public inline fun glBindBufferBaseNV(
    target: Int,
    index: Int,
    buffer: Int,
): Unit = GLWrapper.instance.NVTransformFeedback.glBindBufferBaseNV(target, index, buffer)

public inline fun glTransformFeedbackVaryingsNV(
    program: Int,
    count: Int,
    locations: Ptr,
    bufferMode: Int,
): Unit = GLWrapper.instance.NVTransformFeedback.glTransformFeedbackVaryingsNV(program, count,
        locations, bufferMode)

public inline fun glTransformFeedbackVaryingsNV(
    program: Int,
    count: Int,
    locations: Long,
    bufferMode: Int,
): Unit = GLWrapper.instance.NVTransformFeedback.glTransformFeedbackVaryingsNV(program, count,
        locations, bufferMode)

public inline fun glActiveVaryingNV(program: Int, name: Ptr): Unit =
        GLWrapper.instance.NVTransformFeedback.glActiveVaryingNV(program, name)

public inline fun glActiveVaryingNV(program: Int, name: Long): Unit =
        GLWrapper.instance.NVTransformFeedback.glActiveVaryingNV(program, name)

public inline fun glGetVaryingLocationNV(program: Int, name: Ptr): Int =
        GLWrapper.instance.NVTransformFeedback.glGetVaryingLocationNV(program, name)

public inline fun glGetVaryingLocationNV(program: Int, name: Long): Int =
        GLWrapper.instance.NVTransformFeedback.glGetVaryingLocationNV(program, name)

public inline fun glGetActiveVaryingNV(
    program: Int,
    index: Int,
    bufSize: Int,
    length: Ptr,
    size: Ptr,
    type: Ptr,
    name: Ptr,
): Unit = GLWrapper.instance.NVTransformFeedback.glGetActiveVaryingNV(program, index, bufSize,
        length, size, type, name)

public inline fun glGetActiveVaryingNV(
    program: Int,
    index: Int,
    bufSize: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
): Unit = GLWrapper.instance.NVTransformFeedback.glGetActiveVaryingNV(program, index, bufSize,
        length, size, type, name)

public inline fun glGetTransformFeedbackVaryingNV(
    program: Int,
    index: Int,
    location: Ptr,
): Unit = GLWrapper.instance.NVTransformFeedback.glGetTransformFeedbackVaryingNV(program, index,
        location)

public inline fun glGetTransformFeedbackVaryingNV(
    program: Int,
    index: Int,
    location: Long,
): Unit = GLWrapper.instance.NVTransformFeedback.glGetTransformFeedbackVaryingNV(program, index,
        location)

public inline fun glTransformFeedbackStreamAttribsNV(
    count: Int,
    attribs: Ptr,
    nbuffers: Int,
    bufstreams: Ptr,
    bufferMode: Int,
): Unit = GLWrapper.instance.NVTransformFeedback.glTransformFeedbackStreamAttribsNV(count, attribs,
        nbuffers, bufstreams, bufferMode)

public inline fun glTransformFeedbackStreamAttribsNV(
    count: Int,
    attribs: Long,
    nbuffers: Int,
    bufstreams: Long,
    bufferMode: Int,
): Unit = GLWrapper.instance.NVTransformFeedback.glTransformFeedbackStreamAttribsNV(count, attribs,
        nbuffers, bufstreams, bufferMode)
