@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVBlendEquationAdvanced : GLBase {
    public fun glBlendParameteriNV(pname: Int, `value`: Int)

    public fun glBlendBarrierNV()
}

public const val GL_BLEND_PREMULTIPLIED_SRC_NV: Int = 37_504

public const val GL_BLEND_OVERLAP_NV: Int = 37_505

public const val GL_UNCORRELATED_NV: Int = 34_081

public const val GL_DISJOINT_NV: Int = 37_507

public const val GL_CONJOINT_NV: Int = 37_508

public const val GL_SRC_NV: Int = 37_510

public const val GL_DST_NV: Int = 37_511

public const val GL_SRC_OVER_NV: Int = 37_512

public const val GL_DST_OVER_NV: Int = 37_513

public const val GL_SRC_IN_NV: Int = 37_514

public const val GL_DST_IN_NV: Int = 37_515

public const val GL_SRC_OUT_NV: Int = 37_516

public const val GL_DST_OUT_NV: Int = 37_517

public const val GL_SRC_ATOP_NV: Int = 37_518

public const val GL_DST_ATOP_NV: Int = 37_519

public const val GL_XOR_NV: Int = 5_382

public const val GL_MULTIPLY_NV: Int = 37_524

public const val GL_SCREEN_NV: Int = 37_525

public const val GL_OVERLAY_NV: Int = 37_526

public const val GL_DARKEN_NV: Int = 37_527

public const val GL_LIGHTEN_NV: Int = 37_528

public const val GL_COLORDODGE_NV: Int = 37_529

public const val GL_COLORBURN_NV: Int = 37_530

public const val GL_HARDLIGHT_NV: Int = 37_531

public const val GL_SOFTLIGHT_NV: Int = 37_532

public const val GL_DIFFERENCE_NV: Int = 37_534

public const val GL_EXCLUSION_NV: Int = 37_536

public const val GL_INVERT_RGB_NV: Int = 37_539

public const val GL_LINEARDODGE_NV: Int = 37_540

public const val GL_LINEARBURN_NV: Int = 37_541

public const val GL_VIVIDLIGHT_NV: Int = 37_542

public const val GL_LINEARLIGHT_NV: Int = 37_543

public const val GL_PINLIGHT_NV: Int = 37_544

public const val GL_HARDMIX_NV: Int = 37_545

public const val GL_HSL_HUE_NV: Int = 37_549

public const val GL_HSL_SATURATION_NV: Int = 37_550

public const val GL_HSL_COLOR_NV: Int = 37_551

public const val GL_HSL_LUMINOSITY_NV: Int = 37_552

public const val GL_PLUS_NV: Int = 37_521

public const val GL_PLUS_CLAMPED_NV: Int = 37_553

public const val GL_PLUS_CLAMPED_ALPHA_NV: Int = 37_554

public const val GL_PLUS_DARKER_NV: Int = 37_522

public const val GL_MINUS_NV: Int = 37_535

public const val GL_MINUS_CLAMPED_NV: Int = 37_555

public const val GL_CONTRAST_NV: Int = 37_537

public const val GL_INVERT_OVG_NV: Int = 37_556

public const val GL_RED_NV: Int = 6_403

public const val GL_GREEN_NV: Int = 6_404

public const val GL_BLUE_NV: Int = 6_405

public inline fun glBlendParameteriNV(pname: Int, `value`: Int): Unit =
        GLWrapper.instance.NVBlendEquationAdvanced.glBlendParameteriNV(pname, `value`)

public inline fun glBlendBarrierNV(): Unit =
        GLWrapper.instance.NVBlendEquationAdvanced.glBlendBarrierNV()
