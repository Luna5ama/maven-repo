@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureSwizzle : GLBase

public const val GL_TEXTURE_SWIZZLE_R_EXT: Int = 36_418

public const val GL_TEXTURE_SWIZZLE_G_EXT: Int = 36_419

public const val GL_TEXTURE_SWIZZLE_B_EXT: Int = 36_420

public const val GL_TEXTURE_SWIZZLE_A_EXT: Int = 36_421

public const val GL_TEXTURE_SWIZZLE_RGBA_EXT: Int = 36_422
