@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface ARBMatrixPalette : GLBase {
    public fun glCurrentPaletteMatrixARB(index: Int)

    @PtrParameter([1])
    public fun glMatrixIndexuivARB(size: Int, indices: Ptr)

    @Unsafe
    public fun glMatrixIndexuivARB(size: Int, indices: Long)

    @PtrParameter([1])
    public fun glMatrixIndexubvARB(size: Int, indices: Ptr)

    @Unsafe
    public fun glMatrixIndexubvARB(size: Int, indices: Long)

    @PtrParameter([1])
    public fun glMatrixIndexusvARB(size: Int, indices: Ptr)

    @Unsafe
    public fun glMatrixIndexusvARB(size: Int, indices: Long)

    @PtrParameter([3])
    public fun glMatrixIndexPointerARB(
        size: Int,
        type: Int,
        stride: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glMatrixIndexPointerARB(
        size: Int,
        type: Int,
        stride: Int,
        pointer: Long,
    )
}

public const val GL_MATRIX_PALETTE_ARB: Int = 34_880

public const val GL_MAX_MATRIX_PALETTE_STACK_DEPTH_ARB: Int = 34_881

public const val GL_MAX_PALETTE_MATRICES_ARB: Int = 34_882

public const val GL_CURRENT_PALETTE_MATRIX_ARB: Int = 34_883

public const val GL_MATRIX_INDEX_ARRAY_ARB: Int = 34_884

public const val GL_CURRENT_MATRIX_INDEX_ARB: Int = 34_885

public const val GL_MATRIX_INDEX_ARRAY_SIZE_ARB: Int = 34_886

public const val GL_MATRIX_INDEX_ARRAY_TYPE_ARB: Int = 34_887

public const val GL_MATRIX_INDEX_ARRAY_STRIDE_ARB: Int = 34_888

public const val GL_MATRIX_INDEX_ARRAY_POINTER_ARB: Int = 34_889

public inline fun glCurrentPaletteMatrixARB(index: Int): Unit =
        GLWrapper.instance.ARBMatrixPalette.glCurrentPaletteMatrixARB(index)

public inline fun glMatrixIndexuivARB(size: Int, indices: Ptr): Unit =
        GLWrapper.instance.ARBMatrixPalette.glMatrixIndexuivARB(size, indices)

public inline fun glMatrixIndexuivARB(size: Int, indices: Long): Unit =
        GLWrapper.instance.ARBMatrixPalette.glMatrixIndexuivARB(size, indices)

public inline fun glMatrixIndexubvARB(size: Int, indices: Ptr): Unit =
        GLWrapper.instance.ARBMatrixPalette.glMatrixIndexubvARB(size, indices)

public inline fun glMatrixIndexubvARB(size: Int, indices: Long): Unit =
        GLWrapper.instance.ARBMatrixPalette.glMatrixIndexubvARB(size, indices)

public inline fun glMatrixIndexusvARB(size: Int, indices: Ptr): Unit =
        GLWrapper.instance.ARBMatrixPalette.glMatrixIndexusvARB(size, indices)

public inline fun glMatrixIndexusvARB(size: Int, indices: Long): Unit =
        GLWrapper.instance.ARBMatrixPalette.glMatrixIndexusvARB(size, indices)

public inline fun glMatrixIndexPointerARB(
    size: Int,
    type: Int,
    stride: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.ARBMatrixPalette.glMatrixIndexPointerARB(size, type, stride, pointer)

public inline fun glMatrixIndexPointerARB(
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
): Unit = GLWrapper.instance.ARBMatrixPalette.glMatrixIndexPointerARB(size, type, stride, pointer)
