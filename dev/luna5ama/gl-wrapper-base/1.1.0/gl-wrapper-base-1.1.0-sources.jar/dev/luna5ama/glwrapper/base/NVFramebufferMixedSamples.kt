@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVFramebufferMixedSamples : GLBase {
    @PtrParameter([1])
    public fun glCoverageModulationTableNV(n: Int, v: Ptr)

    @Unsafe
    public fun glCoverageModulationTableNV(n: Int, v: Long)

    @PtrParameter([1])
    public fun glGetCoverageModulationTableNV(bufsize: Int, v: Ptr)

    @Unsafe
    public fun glGetCoverageModulationTableNV(bufsize: Int, v: Long)

    public fun glCoverageModulationNV(components: Int)
}

public const val GL_COVERAGE_MODULATION_TABLE_NV: Int = 37_681

public const val GL_COLOR_SAMPLES_NV: Int = 36_384

public const val GL_DEPTH_SAMPLES_NV: Int = 37_677

public const val GL_STENCIL_SAMPLES_NV: Int = 37_678

public const val GL_MIXED_DEPTH_SAMPLES_SUPPORTED_NV: Int = 37_679

public const val GL_MIXED_STENCIL_SAMPLES_SUPPORTED_NV: Int = 37_680

public const val GL_COVERAGE_MODULATION_NV: Int = 37_682

public const val GL_COVERAGE_MODULATION_TABLE_SIZE_NV: Int = 37_683

public inline fun glCoverageModulationTableNV(n: Int, v: Ptr): Unit =
        GLWrapper.instance.NVFramebufferMixedSamples.glCoverageModulationTableNV(n, v)

public inline fun glCoverageModulationTableNV(n: Int, v: Long): Unit =
        GLWrapper.instance.NVFramebufferMixedSamples.glCoverageModulationTableNV(n, v)

public inline fun glGetCoverageModulationTableNV(bufsize: Int, v: Ptr): Unit =
        GLWrapper.instance.NVFramebufferMixedSamples.glGetCoverageModulationTableNV(bufsize, v)

public inline fun glGetCoverageModulationTableNV(bufsize: Int, v: Long): Unit =
        GLWrapper.instance.NVFramebufferMixedSamples.glGetCoverageModulationTableNV(bufsize, v)

public inline fun glCoverageModulationNV(components: Int): Unit =
        GLWrapper.instance.NVFramebufferMixedSamples.glCoverageModulationNV(components)
