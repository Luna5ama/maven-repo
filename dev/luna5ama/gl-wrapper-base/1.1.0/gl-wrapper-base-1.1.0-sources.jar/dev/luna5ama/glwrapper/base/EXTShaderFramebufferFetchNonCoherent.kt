@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Suppress
import kotlin.Unit

public interface EXTShaderFramebufferFetchNonCoherent : GLBase {
    public fun glFramebufferFetchBarrierEXT()
}

public inline fun glFramebufferFetchBarrierEXT(): Unit =
        GLWrapper.instance.EXTShaderFramebufferFetchNonCoherent.glFramebufferFetchBarrierEXT()
