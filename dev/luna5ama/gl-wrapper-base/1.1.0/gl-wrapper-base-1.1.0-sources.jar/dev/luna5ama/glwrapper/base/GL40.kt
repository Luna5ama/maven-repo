@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.CharSequence
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface GL40 : GLBase {
    public fun glBlendEquationi(buf: Int, mode: Int)

    public fun glBlendEquationSeparatei(
        buf: Int,
        modeRGB: Int,
        modeAlpha: Int,
    )

    public fun glBlendFunci(
        buf: Int,
        sfactor: Int,
        dfactor: Int,
    )

    public fun glBlendFuncSeparatei(
        buf: Int,
        srcRGB: Int,
        dstRGB: Int,
        srcAlpha: Int,
        dstAlpha: Int,
    )

    @PtrParameter([1])
    public fun glDrawArraysIndirect(mode: Int, indirect: Ptr)

    @Unsafe
    public fun glDrawArraysIndirect(mode: Int, indirect: Long)

    @PtrParameter([2])
    public fun glDrawElementsIndirect(
        mode: Int,
        type: Int,
        indirect: Ptr,
    )

    @Unsafe
    public fun glDrawElementsIndirect(
        mode: Int,
        type: Int,
        indirect: Long,
    )

    public fun glUniform1d(location: Int, x: Double)

    public fun glUniform2d(
        location: Int,
        x: Double,
        y: Double,
    )

    public fun glUniform3d(
        location: Int,
        x: Double,
        y: Double,
        z: Double,
    )

    public fun glUniform4d(
        location: Int,
        x: Double,
        y: Double,
        z: Double,
        w: Double,
    )

    @PtrParameter([2])
    public fun glUniform1dv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1dv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform2dv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2dv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform3dv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3dv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform4dv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4dv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix2dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix2dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix3dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix3dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix4dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix4dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix2x3dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix2x3dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix2x4dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix2x4dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix3x2dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix3x2dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix3x4dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix3x4dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix4x2dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix4x2dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix4x3dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix4x3dv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformdv(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformdv(
        program: Int,
        location: Int,
        params: Long,
    )

    public fun glMinSampleShading(`value`: Float)

    @PtrParameter([2])
    public fun glGetSubroutineUniformLocation(
        program: Int,
        shadertype: Int,
        name: Ptr,
    ): Int

    @Unsafe
    public fun glGetSubroutineUniformLocation(
        program: Int,
        shadertype: Int,
        name: Long,
    ): Int

    @PtrParameter([2])
    public fun glGetSubroutineIndex(
        program: Int,
        shadertype: Int,
        name: Ptr,
    ): Int

    @Unsafe
    public fun glGetSubroutineIndex(
        program: Int,
        shadertype: Int,
        name: Long,
    ): Int

    @PtrParameter([4])
    public fun glGetActiveSubroutineUniformiv(
        program: Int,
        shadertype: Int,
        index: Int,
        pname: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glGetActiveSubroutineUniformiv(
        program: Int,
        shadertype: Int,
        index: Int,
        pname: Int,
        values: Long,
    )

    @PtrParameter([4, 5])
    public fun glGetActiveSubroutineUniformName(
        program: Int,
        shadertype: Int,
        index: Int,
        bufsize: Int,
        length: Ptr,
        name: Ptr,
    )

    @Unsafe
    public fun glGetActiveSubroutineUniformName(
        program: Int,
        shadertype: Int,
        index: Int,
        bufsize: Int,
        length: Long,
        name: Long,
    )

    @PtrParameter([4, 5])
    public fun glGetActiveSubroutineName(
        program: Int,
        shadertype: Int,
        index: Int,
        bufsize: Int,
        length: Ptr,
        name: Ptr,
    )

    @Unsafe
    public fun glGetActiveSubroutineName(
        program: Int,
        shadertype: Int,
        index: Int,
        bufsize: Int,
        length: Long,
        name: Long,
    )

    @PtrParameter([2])
    public fun glUniformSubroutinesuiv(
        shadertype: Int,
        count: Int,
        indices: Ptr,
    )

    @Unsafe
    public fun glUniformSubroutinesuiv(
        shadertype: Int,
        count: Int,
        indices: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformSubroutineuiv(
        shadertype: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformSubroutineuiv(
        shadertype: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glGetProgramStageiv(
        program: Int,
        shadertype: Int,
        pname: Int,
        values: Ptr,
    )

    @Unsafe
    public fun glGetProgramStageiv(
        program: Int,
        shadertype: Int,
        pname: Int,
        values: Long,
    )

    public fun glPatchParameteri(pname: Int, `value`: Int)

    @PtrParameter([1])
    public fun glPatchParameterfv(pname: Int, values: Ptr)

    @Unsafe
    public fun glPatchParameterfv(pname: Int, values: Long)

    public fun glBindTransformFeedback(target: Int, id: Int)

    @PtrParameter([1])
    public fun glDeleteTransformFeedbacks(n: Int, ids: Ptr)

    @Unsafe
    public fun glDeleteTransformFeedbacks(n: Int, ids: Long)

    @PtrParameter([1])
    public fun glGenTransformFeedbacks(n: Int, ids: Ptr)

    @Unsafe
    public fun glGenTransformFeedbacks(n: Int, ids: Long)

    public fun glIsTransformFeedback(id: Int): Boolean

    public fun glPauseTransformFeedback()

    public fun glResumeTransformFeedback()

    public fun glDrawTransformFeedback(mode: Int, id: Int)

    public fun glDrawTransformFeedbackStream(
        mode: Int,
        id: Int,
        stream: Int,
    )

    public fun glBeginQueryIndexed(
        target: Int,
        index: Int,
        id: Int,
    )

    public fun glEndQueryIndexed(target: Int, index: Int)

    @PtrParameter([3])
    public fun glGetQueryIndexediv(
        target: Int,
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetQueryIndexediv(
        target: Int,
        index: Int,
        pname: Int,
        params: Long,
    )

    public fun glGetSubroutineIndex(
        program: Int,
        shadertype: Int,
        name: CharSequence,
    ): Int

    public fun glDeleteTransformFeedbacks(transformFeedback: Int)
}

public const val GL_DRAW_INDIRECT_BUFFER: Int = 36_671

public const val GL_DRAW_INDIRECT_BUFFER_BINDING: Int = 36_675

public const val GL_GEOMETRY_SHADER_INVOCATIONS: Int = 34_943

public const val GL_MAX_GEOMETRY_SHADER_INVOCATIONS: Int = 36_442

public const val GL_MIN_FRAGMENT_INTERPOLATION_OFFSET: Int = 36_443

public const val GL_MAX_FRAGMENT_INTERPOLATION_OFFSET: Int = 36_444

public const val GL_FRAGMENT_INTERPOLATION_OFFSET_BITS: Int = 36_445

public const val GL_DOUBLE_VEC2: Int = 36_860

public const val GL_DOUBLE_VEC3: Int = 36_861

public const val GL_DOUBLE_VEC4: Int = 36_862

public const val GL_DOUBLE_MAT2: Int = 36_678

public const val GL_DOUBLE_MAT3: Int = 36_679

public const val GL_DOUBLE_MAT4: Int = 36_680

public const val GL_DOUBLE_MAT2x3: Int = 36_681

public const val GL_DOUBLE_MAT2x4: Int = 36_682

public const val GL_DOUBLE_MAT3x2: Int = 36_683

public const val GL_DOUBLE_MAT3x4: Int = 36_684

public const val GL_DOUBLE_MAT4x2: Int = 36_685

public const val GL_DOUBLE_MAT4x3: Int = 36_686

public const val GL_SAMPLE_SHADING: Int = 35_894

public const val GL_MIN_SAMPLE_SHADING_VALUE: Int = 35_895

public const val GL_ACTIVE_SUBROUTINES: Int = 36_325

public const val GL_ACTIVE_SUBROUTINE_UNIFORMS: Int = 36_326

public const val GL_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS: Int = 36_423

public const val GL_ACTIVE_SUBROUTINE_MAX_LENGTH: Int = 36_424

public const val GL_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH: Int = 36_425

public const val GL_MAX_SUBROUTINES: Int = 36_327

public const val GL_MAX_SUBROUTINE_UNIFORM_LOCATIONS: Int = 36_328

public const val GL_NUM_COMPATIBLE_SUBROUTINES: Int = 36_426

public const val GL_COMPATIBLE_SUBROUTINES: Int = 36_427

public const val GL_PATCHES: Int = 14

public const val GL_PATCH_VERTICES: Int = 36_466

public const val GL_PATCH_DEFAULT_INNER_LEVEL: Int = 36_467

public const val GL_PATCH_DEFAULT_OUTER_LEVEL: Int = 36_468

public const val GL_TESS_CONTROL_OUTPUT_VERTICES: Int = 36_469

public const val GL_TESS_GEN_MODE: Int = 36_470

public const val GL_TESS_GEN_SPACING: Int = 36_471

public const val GL_TESS_GEN_VERTEX_ORDER: Int = 36_472

public const val GL_TESS_GEN_POINT_MODE: Int = 36_473

public const val GL_ISOLINES: Int = 36_474

public const val GL_FRACTIONAL_ODD: Int = 36_475

public const val GL_FRACTIONAL_EVEN: Int = 36_476

public const val GL_MAX_PATCH_VERTICES: Int = 36_477

public const val GL_MAX_TESS_GEN_LEVEL: Int = 36_478

public const val GL_MAX_TESS_CONTROL_UNIFORM_COMPONENTS: Int = 36_479

public const val GL_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS: Int = 36_480

public const val GL_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS: Int = 36_481

public const val GL_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS: Int = 36_482

public const val GL_MAX_TESS_CONTROL_OUTPUT_COMPONENTS: Int = 36_483

public const val GL_MAX_TESS_PATCH_COMPONENTS: Int = 36_484

public const val GL_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS: Int = 36_485

public const val GL_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS: Int = 36_486

public const val GL_MAX_TESS_CONTROL_UNIFORM_BLOCKS: Int = 36_489

public const val GL_MAX_TESS_EVALUATION_UNIFORM_BLOCKS: Int = 36_490

public const val GL_MAX_TESS_CONTROL_INPUT_COMPONENTS: Int = 34_924

public const val GL_MAX_TESS_EVALUATION_INPUT_COMPONENTS: Int = 34_925

public const val GL_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS: Int = 36_382

public const val GL_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS: Int = 36_383

public const val GL_UNIFORM_BLOCK_REFERENCED_BY_TESS_CONTROL_SHADER: Int = 34_032

public const val GL_UNIFORM_BLOCK_REFERENCED_BY_TESS_EVALUATION_SHADER: Int = 34_033

public const val GL_TESS_EVALUATION_SHADER: Int = 36_487

public const val GL_TESS_CONTROL_SHADER: Int = 36_488

public const val GL_TEXTURE_CUBE_MAP_ARRAY: Int = 36_873

public const val GL_TEXTURE_BINDING_CUBE_MAP_ARRAY: Int = 36_874

public const val GL_PROXY_TEXTURE_CUBE_MAP_ARRAY: Int = 36_875

public const val GL_SAMPLER_CUBE_MAP_ARRAY: Int = 36_876

public const val GL_SAMPLER_CUBE_MAP_ARRAY_SHADOW: Int = 36_877

public const val GL_INT_SAMPLER_CUBE_MAP_ARRAY: Int = 36_878

public const val GL_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY: Int = 36_879

public const val GL_MIN_PROGRAM_TEXTURE_GATHER_OFFSET: Int = 36_446

public const val GL_MAX_PROGRAM_TEXTURE_GATHER_OFFSET: Int = 36_447

public const val GL_TRANSFORM_FEEDBACK: Int = 36_386

public const val GL_TRANSFORM_FEEDBACK_BUFFER_PAUSED: Int = 36_387

public const val GL_TRANSFORM_FEEDBACK_BUFFER_ACTIVE: Int = 36_388

public const val GL_TRANSFORM_FEEDBACK_BINDING: Int = 36_389

public const val GL_MAX_TRANSFORM_FEEDBACK_BUFFERS: Int = 36_464

public const val GL_MAX_VERTEX_STREAMS: Int = 36_465

public inline fun glBlendEquationi(buf: Int, mode: Int): Unit =
        GLWrapper.instance.GL40.glBlendEquationi(buf, mode)

public inline fun glBlendEquationSeparatei(
    buf: Int,
    modeRGB: Int,
    modeAlpha: Int,
): Unit = GLWrapper.instance.GL40.glBlendEquationSeparatei(buf, modeRGB, modeAlpha)

public inline fun glBlendFunci(
    buf: Int,
    sfactor: Int,
    dfactor: Int,
): Unit = GLWrapper.instance.GL40.glBlendFunci(buf, sfactor, dfactor)

public inline fun glBlendFuncSeparatei(
    buf: Int,
    srcRGB: Int,
    dstRGB: Int,
    srcAlpha: Int,
    dstAlpha: Int,
): Unit = GLWrapper.instance.GL40.glBlendFuncSeparatei(buf, srcRGB, dstRGB, srcAlpha, dstAlpha)

public inline fun glDrawArraysIndirect(mode: Int, indirect: Ptr): Unit =
        GLWrapper.instance.GL40.glDrawArraysIndirect(mode, indirect)

public inline fun glDrawArraysIndirect(mode: Int, indirect: Long): Unit =
        GLWrapper.instance.GL40.glDrawArraysIndirect(mode, indirect)

public inline fun glDrawElementsIndirect(
    mode: Int,
    type: Int,
    indirect: Ptr,
): Unit = GLWrapper.instance.GL40.glDrawElementsIndirect(mode, type, indirect)

public inline fun glDrawElementsIndirect(
    mode: Int,
    type: Int,
    indirect: Long,
): Unit = GLWrapper.instance.GL40.glDrawElementsIndirect(mode, type, indirect)

public inline fun glUniform1d(location: Int, x: Double): Unit =
        GLWrapper.instance.GL40.glUniform1d(location, x)

public inline fun glUniform2d(
    location: Int,
    x: Double,
    y: Double,
): Unit = GLWrapper.instance.GL40.glUniform2d(location, x, y)

public inline fun glUniform3d(
    location: Int,
    x: Double,
    y: Double,
    z: Double,
): Unit = GLWrapper.instance.GL40.glUniform3d(location, x, y, z)

public inline fun glUniform4d(
    location: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
): Unit = GLWrapper.instance.GL40.glUniform4d(location, x, y, z, w)

public inline fun glUniform1dv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniform1dv(location, count, `value`)

public inline fun glUniform1dv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniform1dv(location, count, `value`)

public inline fun glUniform2dv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniform2dv(location, count, `value`)

public inline fun glUniform2dv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniform2dv(location, count, `value`)

public inline fun glUniform3dv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniform3dv(location, count, `value`)

public inline fun glUniform3dv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniform3dv(location, count, `value`)

public inline fun glUniform4dv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniform4dv(location, count, `value`)

public inline fun glUniform4dv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniform4dv(location, count, `value`)

public inline fun glUniformMatrix2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformMatrix2dv(location, count, transpose, `value`)

public inline fun glUniformMatrix2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniformMatrix2dv(location, count, transpose, `value`)

public inline fun glUniformMatrix3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformMatrix3dv(location, count, transpose, `value`)

public inline fun glUniformMatrix3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniformMatrix3dv(location, count, transpose, `value`)

public inline fun glUniformMatrix4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformMatrix4dv(location, count, transpose, `value`)

public inline fun glUniformMatrix4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniformMatrix4dv(location, count, transpose, `value`)

public inline fun glUniformMatrix2x3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformMatrix2x3dv(location, count, transpose, `value`)

public inline fun glUniformMatrix2x3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniformMatrix2x3dv(location, count, transpose, `value`)

public inline fun glUniformMatrix2x4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformMatrix2x4dv(location, count, transpose, `value`)

public inline fun glUniformMatrix2x4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniformMatrix2x4dv(location, count, transpose, `value`)

public inline fun glUniformMatrix3x2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformMatrix3x2dv(location, count, transpose, `value`)

public inline fun glUniformMatrix3x2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniformMatrix3x2dv(location, count, transpose, `value`)

public inline fun glUniformMatrix3x4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformMatrix3x4dv(location, count, transpose, `value`)

public inline fun glUniformMatrix3x4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniformMatrix3x4dv(location, count, transpose, `value`)

public inline fun glUniformMatrix4x2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformMatrix4x2dv(location, count, transpose, `value`)

public inline fun glUniformMatrix4x2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniformMatrix4x2dv(location, count, transpose, `value`)

public inline fun glUniformMatrix4x3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformMatrix4x3dv(location, count, transpose, `value`)

public inline fun glUniformMatrix4x3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL40.glUniformMatrix4x3dv(location, count, transpose, `value`)

public inline fun glGetUniformdv(
    program: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL40.glGetUniformdv(program, location, params)

public inline fun glGetUniformdv(
    program: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.GL40.glGetUniformdv(program, location, params)

public inline fun glMinSampleShading(`value`: Float): Unit =
        GLWrapper.instance.GL40.glMinSampleShading(`value`)

public inline fun glGetSubroutineUniformLocation(
    program: Int,
    shadertype: Int,
    name: Ptr,
): Int = GLWrapper.instance.GL40.glGetSubroutineUniformLocation(program, shadertype, name)

public inline fun glGetSubroutineUniformLocation(
    program: Int,
    shadertype: Int,
    name: Long,
): Int = GLWrapper.instance.GL40.glGetSubroutineUniformLocation(program, shadertype, name)

public inline fun glGetSubroutineIndex(
    program: Int,
    shadertype: Int,
    name: Ptr,
): Int = GLWrapper.instance.GL40.glGetSubroutineIndex(program, shadertype, name)

public inline fun glGetSubroutineIndex(
    program: Int,
    shadertype: Int,
    name: Long,
): Int = GLWrapper.instance.GL40.glGetSubroutineIndex(program, shadertype, name)

public inline fun glGetActiveSubroutineUniformiv(
    program: Int,
    shadertype: Int,
    index: Int,
    pname: Int,
    values: Ptr,
): Unit = GLWrapper.instance.GL40.glGetActiveSubroutineUniformiv(program, shadertype, index, pname,
        values)

public inline fun glGetActiveSubroutineUniformiv(
    program: Int,
    shadertype: Int,
    index: Int,
    pname: Int,
    values: Long,
): Unit = GLWrapper.instance.GL40.glGetActiveSubroutineUniformiv(program, shadertype, index, pname,
        values)

public inline fun glGetActiveSubroutineUniformName(
    program: Int,
    shadertype: Int,
    index: Int,
    bufsize: Int,
    length: Ptr,
    name: Ptr,
): Unit = GLWrapper.instance.GL40.glGetActiveSubroutineUniformName(program, shadertype, index,
        bufsize, length, name)

public inline fun glGetActiveSubroutineUniformName(
    program: Int,
    shadertype: Int,
    index: Int,
    bufsize: Int,
    length: Long,
    name: Long,
): Unit = GLWrapper.instance.GL40.glGetActiveSubroutineUniformName(program, shadertype, index,
        bufsize, length, name)

public inline fun glGetActiveSubroutineName(
    program: Int,
    shadertype: Int,
    index: Int,
    bufsize: Int,
    length: Ptr,
    name: Ptr,
): Unit = GLWrapper.instance.GL40.glGetActiveSubroutineName(program, shadertype, index, bufsize,
        length, name)

public inline fun glGetActiveSubroutineName(
    program: Int,
    shadertype: Int,
    index: Int,
    bufsize: Int,
    length: Long,
    name: Long,
): Unit = GLWrapper.instance.GL40.glGetActiveSubroutineName(program, shadertype, index, bufsize,
        length, name)

public inline fun glUniformSubroutinesuiv(
    shadertype: Int,
    count: Int,
    indices: Ptr,
): Unit = GLWrapper.instance.GL40.glUniformSubroutinesuiv(shadertype, count, indices)

public inline fun glUniformSubroutinesuiv(
    shadertype: Int,
    count: Int,
    indices: Long,
): Unit = GLWrapper.instance.GL40.glUniformSubroutinesuiv(shadertype, count, indices)

public inline fun glGetUniformSubroutineuiv(
    shadertype: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL40.glGetUniformSubroutineuiv(shadertype, location, params)

public inline fun glGetUniformSubroutineuiv(
    shadertype: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.GL40.glGetUniformSubroutineuiv(shadertype, location, params)

public inline fun glGetProgramStageiv(
    program: Int,
    shadertype: Int,
    pname: Int,
    values: Ptr,
): Unit = GLWrapper.instance.GL40.glGetProgramStageiv(program, shadertype, pname, values)

public inline fun glGetProgramStageiv(
    program: Int,
    shadertype: Int,
    pname: Int,
    values: Long,
): Unit = GLWrapper.instance.GL40.glGetProgramStageiv(program, shadertype, pname, values)

public inline fun glPatchParameteri(pname: Int, `value`: Int): Unit =
        GLWrapper.instance.GL40.glPatchParameteri(pname, `value`)

public inline fun glPatchParameterfv(pname: Int, values: Ptr): Unit =
        GLWrapper.instance.GL40.glPatchParameterfv(pname, values)

public inline fun glPatchParameterfv(pname: Int, values: Long): Unit =
        GLWrapper.instance.GL40.glPatchParameterfv(pname, values)

public inline fun glBindTransformFeedback(target: Int, id: Int): Unit =
        GLWrapper.instance.GL40.glBindTransformFeedback(target, id)

public inline fun glDeleteTransformFeedbacks(n: Int, ids: Ptr): Unit =
        GLWrapper.instance.GL40.glDeleteTransformFeedbacks(n, ids)

public inline fun glDeleteTransformFeedbacks(n: Int, ids: Long): Unit =
        GLWrapper.instance.GL40.glDeleteTransformFeedbacks(n, ids)

public inline fun glGenTransformFeedbacks(n: Int, ids: Ptr): Unit =
        GLWrapper.instance.GL40.glGenTransformFeedbacks(n, ids)

public inline fun glGenTransformFeedbacks(n: Int, ids: Long): Unit =
        GLWrapper.instance.GL40.glGenTransformFeedbacks(n, ids)

public inline fun glIsTransformFeedback(id: Int): Boolean =
        GLWrapper.instance.GL40.glIsTransformFeedback(id)

public inline fun glPauseTransformFeedback(): Unit =
        GLWrapper.instance.GL40.glPauseTransformFeedback()

public inline fun glResumeTransformFeedback(): Unit =
        GLWrapper.instance.GL40.glResumeTransformFeedback()

public inline fun glDrawTransformFeedback(mode: Int, id: Int): Unit =
        GLWrapper.instance.GL40.glDrawTransformFeedback(mode, id)

public inline fun glDrawTransformFeedbackStream(
    mode: Int,
    id: Int,
    stream: Int,
): Unit = GLWrapper.instance.GL40.glDrawTransformFeedbackStream(mode, id, stream)

public inline fun glBeginQueryIndexed(
    target: Int,
    index: Int,
    id: Int,
): Unit = GLWrapper.instance.GL40.glBeginQueryIndexed(target, index, id)

public inline fun glEndQueryIndexed(target: Int, index: Int): Unit =
        GLWrapper.instance.GL40.glEndQueryIndexed(target, index)

public inline fun glGetQueryIndexediv(
    target: Int,
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL40.glGetQueryIndexediv(target, index, pname, params)

public inline fun glGetQueryIndexediv(
    target: Int,
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL40.glGetQueryIndexediv(target, index, pname, params)

public inline fun glGetSubroutineIndex(
    program: Int,
    shadertype: Int,
    name: CharSequence,
): Int = GLWrapper.instance.GL40.glGetSubroutineIndex(program, shadertype, name)

public inline fun glDeleteTransformFeedbacks(transformFeedback: Int): Unit =
        GLWrapper.instance.GL40.glDeleteTransformFeedbacks(transformFeedback)
