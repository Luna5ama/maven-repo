@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVVertexArrayRange : GLBase {
    @PtrParameter([1])
    public fun glVertexArrayRangeNV(length: Int, pointer: Ptr)

    @Unsafe
    public fun glVertexArrayRangeNV(length: Int, pointer: Long)

    public fun glFlushVertexArrayRangeNV()
}

public const val GL_VERTEX_ARRAY_RANGE_NV: Int = 34_077

public const val GL_VERTEX_ARRAY_RANGE_LENGTH_NV: Int = 34_078

public const val GL_VERTEX_ARRAY_RANGE_VALID_NV: Int = 34_079

public const val GL_MAX_VERTEX_ARRAY_RANGE_ELEMENT_NV: Int = 34_080

public const val GL_VERTEX_ARRAY_RANGE_POINTER_NV: Int = 34_081

public inline fun glVertexArrayRangeNV(length: Int, pointer: Ptr): Unit =
        GLWrapper.instance.NVVertexArrayRange.glVertexArrayRangeNV(length, pointer)

public inline fun glVertexArrayRangeNV(length: Int, pointer: Long): Unit =
        GLWrapper.instance.NVVertexArrayRange.glVertexArrayRangeNV(length, pointer)

public inline fun glFlushVertexArrayRangeNV(): Unit =
        GLWrapper.instance.NVVertexArrayRange.glFlushVertexArrayRangeNV()
