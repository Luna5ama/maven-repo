@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTTextureBufferObject : GLBase {
    public fun glTexBufferEXT(
        target: Int,
        internalformat: Int,
        buffer: Int,
    )
}

public const val GL_TEXTURE_BUFFER_EXT: Int = 35_882

public const val GL_MAX_TEXTURE_BUFFER_SIZE_EXT: Int = 35_883

public const val GL_TEXTURE_BINDING_BUFFER_EXT: Int = 35_884

public const val GL_TEXTURE_BUFFER_DATA_STORE_BINDING_EXT: Int = 35_885

public const val GL_TEXTURE_BUFFER_FORMAT_EXT: Int = 35_886

public inline fun glTexBufferEXT(
    target: Int,
    internalformat: Int,
    buffer: Int,
): Unit = GLWrapper.instance.EXTTextureBufferObject.glTexBufferEXT(target, internalformat, buffer)
