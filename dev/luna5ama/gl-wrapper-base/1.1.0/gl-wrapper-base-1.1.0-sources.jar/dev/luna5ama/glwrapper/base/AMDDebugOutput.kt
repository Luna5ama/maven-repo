@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface AMDDebugOutput : GLBase {
    @PtrParameter([3])
    public fun glDebugMessageEnableAMD(
        category: Int,
        severity: Int,
        count: Int,
        ids: Ptr,
        enabled: Boolean,
    )

    @Unsafe
    public fun glDebugMessageEnableAMD(
        category: Int,
        severity: Int,
        count: Int,
        ids: Long,
        enabled: Boolean,
    )

    @PtrParameter([4])
    public fun glDebugMessageInsertAMD(
        category: Int,
        severity: Int,
        id: Int,
        length: Int,
        buf: Ptr,
    )

    @Unsafe
    public fun glDebugMessageInsertAMD(
        category: Int,
        severity: Int,
        id: Int,
        length: Int,
        buf: Long,
    )

    @PtrParameter([1])
    public fun glDebugMessageCallbackAMD(callback: Long, userParam: Ptr)

    @Unsafe
    public fun glDebugMessageCallbackAMD(callback: Long, userParam: Long)

    @PtrParameter([2, 3, 4, 5, 6])
    public fun glGetDebugMessageLogAMD(
        count: Int,
        bufsize: Int,
        categories: Ptr,
        severities: Ptr,
        ids: Ptr,
        lengths: Ptr,
        messageLog: Ptr,
    ): Int

    @Unsafe
    public fun glGetDebugMessageLogAMD(
        count: Int,
        bufsize: Int,
        categories: Long,
        severities: Long,
        ids: Long,
        lengths: Long,
        messageLog: Long,
    ): Int
}

public const val GL_MAX_DEBUG_MESSAGE_LENGTH_AMD: Int = 37_187

public const val GL_MAX_DEBUG_LOGGED_MESSAGES_AMD: Int = 37_188

public const val GL_DEBUG_LOGGED_MESSAGES_AMD: Int = 37_189

public const val GL_DEBUG_SEVERITY_HIGH_AMD: Int = 37_190

public const val GL_DEBUG_SEVERITY_MEDIUM_AMD: Int = 37_191

public const val GL_DEBUG_SEVERITY_LOW_AMD: Int = 37_192

public const val GL_DEBUG_CATEGORY_API_ERROR_AMD: Int = 37_193

public const val GL_DEBUG_CATEGORY_WINDOW_SYSTEM_AMD: Int = 37_194

public const val GL_DEBUG_CATEGORY_DEPRECATION_AMD: Int = 37_195

public const val GL_DEBUG_CATEGORY_UNDEFINED_BEHAVIOR_AMD: Int = 37_196

public const val GL_DEBUG_CATEGORY_PERFORMANCE_AMD: Int = 37_197

public const val GL_DEBUG_CATEGORY_SHADER_COMPILER_AMD: Int = 37_198

public const val GL_DEBUG_CATEGORY_APPLICATION_AMD: Int = 37_199

public const val GL_DEBUG_CATEGORY_OTHER_AMD: Int = 37_200

public inline fun glDebugMessageEnableAMD(
    category: Int,
    severity: Int,
    count: Int,
    ids: Ptr,
    enabled: Boolean,
): Unit = GLWrapper.instance.AMDDebugOutput.glDebugMessageEnableAMD(category, severity, count, ids,
        enabled)

public inline fun glDebugMessageEnableAMD(
    category: Int,
    severity: Int,
    count: Int,
    ids: Long,
    enabled: Boolean,
): Unit = GLWrapper.instance.AMDDebugOutput.glDebugMessageEnableAMD(category, severity, count, ids,
        enabled)

public inline fun glDebugMessageInsertAMD(
    category: Int,
    severity: Int,
    id: Int,
    length: Int,
    buf: Ptr,
): Unit = GLWrapper.instance.AMDDebugOutput.glDebugMessageInsertAMD(category, severity, id, length,
        buf)

public inline fun glDebugMessageInsertAMD(
    category: Int,
    severity: Int,
    id: Int,
    length: Int,
    buf: Long,
): Unit = GLWrapper.instance.AMDDebugOutput.glDebugMessageInsertAMD(category, severity, id, length,
        buf)

public inline fun glDebugMessageCallbackAMD(callback: Long, userParam: Ptr): Unit =
        GLWrapper.instance.AMDDebugOutput.glDebugMessageCallbackAMD(callback, userParam)

public inline fun glDebugMessageCallbackAMD(callback: Long, userParam: Long): Unit =
        GLWrapper.instance.AMDDebugOutput.glDebugMessageCallbackAMD(callback, userParam)

public inline fun glGetDebugMessageLogAMD(
    count: Int,
    bufsize: Int,
    categories: Ptr,
    severities: Ptr,
    ids: Ptr,
    lengths: Ptr,
    messageLog: Ptr,
): Int = GLWrapper.instance.AMDDebugOutput.glGetDebugMessageLogAMD(count, bufsize, categories,
        severities, ids, lengths, messageLog)

public inline fun glGetDebugMessageLogAMD(
    count: Int,
    bufsize: Int,
    categories: Long,
    severities: Long,
    ids: Long,
    lengths: Long,
    messageLog: Long,
): Int = GLWrapper.instance.AMDDebugOutput.glGetDebugMessageLogAMD(count, bufsize, categories,
        severities, ids, lengths, messageLog)
