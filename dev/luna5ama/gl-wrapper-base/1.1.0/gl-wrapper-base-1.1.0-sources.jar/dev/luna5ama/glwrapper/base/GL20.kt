@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import dev.luna5ama.kmogus.ensureCapacity
import kotlin.Boolean
import kotlin.Byte
import kotlin.CharSequence
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Short
import kotlin.String
import kotlin.Suppress
import kotlin.Unit

public interface GL20 : GLBase {
    public fun glCreateProgram(): Int

    public fun glDeleteProgram(program: Int)

    public fun glIsProgram(program: Int): Boolean

    public fun glCreateShader(type: Int): Int

    public fun glDeleteShader(shader: Int)

    public fun glIsShader(shader: Int): Boolean

    public fun glAttachShader(program: Int, shader: Int)

    public fun glDetachShader(program: Int, shader: Int)

    @PtrParameter([2, 3])
    public fun glShaderSource(
        shader: Int,
        count: Int,
        strings: Ptr,
        length: Ptr,
    )

    @Unsafe
    public fun glShaderSource(
        shader: Int,
        count: Int,
        strings: Long,
        length: Long,
    )

    public fun glCompileShader(shader: Int)

    public fun glLinkProgram(program: Int)

    public fun glUseProgram(program: Int)

    public fun glValidateProgram(program: Int)

    public fun glUniform1f(location: Int, v0: Float)

    public fun glUniform2f(
        location: Int,
        v0: Float,
        v1: Float,
    )

    public fun glUniform3f(
        location: Int,
        v0: Float,
        v1: Float,
        v2: Float,
    )

    public fun glUniform4f(
        location: Int,
        v0: Float,
        v1: Float,
        v2: Float,
        v3: Float,
    )

    public fun glUniform1i(location: Int, v0: Int)

    public fun glUniform2i(
        location: Int,
        v0: Int,
        v1: Int,
    )

    public fun glUniform3i(
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
    )

    public fun glUniform4i(
        location: Int,
        v0: Int,
        v1: Int,
        v2: Int,
        v3: Int,
    )

    @PtrParameter([2])
    public fun glUniform1fv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1fv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform2fv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2fv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform3fv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3fv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform4fv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4fv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform1iv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1iv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform2iv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2iv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform3iv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3iv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform4iv(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4iv(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix2fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix2fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix3fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix3fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glUniformMatrix4fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniformMatrix4fv(
        location: Int,
        count: Int,
        transpose: Boolean,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetShaderiv(
        shader: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetShaderiv(
        shader: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetProgramiv(
        program: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetProgramiv(
        program: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2, 3])
    public fun glGetShaderInfoLog(
        shader: Int,
        maxLength: Int,
        length: Ptr,
        infoLog: Ptr,
    )

    @Unsafe
    public fun glGetShaderInfoLog(
        shader: Int,
        maxLength: Int,
        length: Long,
        infoLog: Long,
    )

    @PtrParameter([2, 3])
    public fun glGetProgramInfoLog(
        program: Int,
        maxLength: Int,
        length: Ptr,
        infoLog: Ptr,
    )

    @Unsafe
    public fun glGetProgramInfoLog(
        program: Int,
        maxLength: Int,
        length: Long,
        infoLog: Long,
    )

    @PtrParameter([2, 3])
    public fun glGetAttachedShaders(
        program: Int,
        maxCount: Int,
        count: Ptr,
        shaders: Ptr,
    )

    @Unsafe
    public fun glGetAttachedShaders(
        program: Int,
        maxCount: Int,
        count: Long,
        shaders: Long,
    )

    @PtrParameter([1])
    public fun glGetUniformLocation(program: Int, name: Ptr): Int

    @Unsafe
    public fun glGetUniformLocation(program: Int, name: Long): Int

    @PtrParameter([3, 4, 5, 6])
    public fun glGetActiveUniform(
        program: Int,
        index: Int,
        maxLength: Int,
        length: Ptr,
        size: Ptr,
        type: Ptr,
        name: Ptr,
    )

    @Unsafe
    public fun glGetActiveUniform(
        program: Int,
        index: Int,
        maxLength: Int,
        length: Long,
        size: Long,
        type: Long,
        name: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformfv(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformfv(
        program: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformiv(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformiv(
        program: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([2, 3])
    public fun glGetShaderSource(
        shader: Int,
        maxLength: Int,
        length: Ptr,
        source: Ptr,
    )

    @Unsafe
    public fun glGetShaderSource(
        shader: Int,
        maxLength: Int,
        length: Long,
        source: Long,
    )

    public fun glVertexAttrib1f(index: Int, v0: Float)

    public fun glVertexAttrib1s(index: Int, v0: Short)

    public fun glVertexAttrib1d(index: Int, v0: Double)

    public fun glVertexAttrib2f(
        index: Int,
        v0: Float,
        v1: Float,
    )

    public fun glVertexAttrib2s(
        index: Int,
        v0: Short,
        v1: Short,
    )

    public fun glVertexAttrib2d(
        index: Int,
        v0: Double,
        v1: Double,
    )

    public fun glVertexAttrib3f(
        index: Int,
        v0: Float,
        v1: Float,
        v2: Float,
    )

    public fun glVertexAttrib3s(
        index: Int,
        v0: Short,
        v1: Short,
        v2: Short,
    )

    public fun glVertexAttrib3d(
        index: Int,
        v0: Double,
        v1: Double,
        v2: Double,
    )

    public fun glVertexAttrib4f(
        index: Int,
        v0: Float,
        v1: Float,
        v2: Float,
        v3: Float,
    )

    public fun glVertexAttrib4s(
        index: Int,
        v0: Short,
        v1: Short,
        v2: Short,
        v3: Short,
    )

    public fun glVertexAttrib4d(
        index: Int,
        v0: Double,
        v1: Double,
        v2: Double,
        v3: Double,
    )

    public fun glVertexAttrib4Nub(
        index: Int,
        x: Byte,
        y: Byte,
        z: Byte,
        w: Byte,
    )

    @PtrParameter([1])
    public fun glVertexAttrib1fv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib1fv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib1sv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib1sv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib1dv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib1dv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib2fv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib2fv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib2sv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib2sv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib2dv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib2dv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib3fv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib3fv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib3sv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib3sv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib3dv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib3dv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4fv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4fv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4sv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4sv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4dv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4dv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4iv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4iv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4bv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4bv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4ubv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4ubv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4usv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4usv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4uiv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4uiv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4Nbv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4Nbv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4Nsv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4Nsv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4Niv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4Niv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4Nubv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4Nubv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4Nusv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4Nusv(index: Int, v: Long)

    @PtrParameter([1])
    public fun glVertexAttrib4Nuiv(index: Int, v: Ptr)

    @Unsafe
    public fun glVertexAttrib4Nuiv(index: Int, v: Long)

    @PtrParameter([5])
    public fun glVertexAttribPointer(
        index: Int,
        size: Int,
        type: Int,
        normalized: Boolean,
        stride: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glVertexAttribPointer(
        index: Int,
        size: Int,
        type: Int,
        normalized: Boolean,
        stride: Int,
        pointer: Long,
    )

    public fun glEnableVertexAttribArray(index: Int)

    public fun glDisableVertexAttribArray(index: Int)

    @PtrParameter([2])
    public fun glBindAttribLocation(
        program: Int,
        index: Int,
        name: Ptr,
    )

    @Unsafe
    public fun glBindAttribLocation(
        program: Int,
        index: Int,
        name: Long,
    )

    @PtrParameter([3, 4, 5, 6])
    public fun glGetActiveAttrib(
        program: Int,
        index: Int,
        maxLength: Int,
        length: Ptr,
        size: Ptr,
        type: Ptr,
        name: Ptr,
    )

    @Unsafe
    public fun glGetActiveAttrib(
        program: Int,
        index: Int,
        maxLength: Int,
        length: Long,
        size: Long,
        type: Long,
        name: Long,
    )

    @PtrParameter([1])
    public fun glGetAttribLocation(program: Int, name: Ptr): Int

    @Unsafe
    public fun glGetAttribLocation(program: Int, name: Long): Int

    @PtrParameter([2])
    public fun glGetVertexAttribiv(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribiv(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribfv(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribfv(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribdv(
        index: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribdv(
        index: Int,
        pname: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetVertexAttribPointerv(
        index: Int,
        pname: Int,
        pointer: Ptr,
    )

    @Unsafe
    public fun glGetVertexAttribPointerv(
        index: Int,
        pname: Int,
        pointer: Long,
    )

    @PtrParameter([1])
    public fun glDrawBuffers(n: Int, bufs: Ptr)

    @Unsafe
    public fun glDrawBuffers(n: Int, bufs: Long)

    public fun glBlendEquationSeparate(modeRGB: Int, modeAlpha: Int)

    public fun glStencilOpSeparate(
        face: Int,
        sfail: Int,
        dpfail: Int,
        dppass: Int,
    )

    public fun glStencilFuncSeparate(
        face: Int,
        func: Int,
        ref: Int,
        mask: Int,
    )

    public fun glStencilMaskSeparate(face: Int, mask: Int)

    @CoreOverload
    public fun glGetShaderi(shader: Int, pname: Int): Int {
        tempArr.ensureCapacity(4, false)
        glGetShaderiv(shader, pname, tempArr.ptr)
        return tempArr.ptr.getInt()
    }

    @CoreOverload
    public fun glGetProgrami(program: Int, pname: Int): Int {
        tempArr.ensureCapacity(4, false)
        glGetProgramiv(program, pname, tempArr.ptr)
        return tempArr.ptr.getInt()
    }

    public fun glGetShaderInfoLog(shader: Int, maxLength: Int): String

    public fun glGetProgramInfoLog(program: Int, maxLength: Int): String

    public fun glGetUniformLocation(program: Int, name: CharSequence): Int

    public fun glShaderSource(shader: Int, string: CharSequence)
}

public const val GL_SHADING_LANGUAGE_VERSION: Int = 35_724

public const val GL_CURRENT_PROGRAM: Int = 35_725

public const val GL_SHADER_TYPE: Int = 35_663

public const val GL_DELETE_STATUS: Int = 35_712

public const val GL_COMPILE_STATUS: Int = 35_713

public const val GL_LINK_STATUS: Int = 35_714

public const val GL_VALIDATE_STATUS: Int = 35_715

public const val GL_INFO_LOG_LENGTH: Int = 35_716

public const val GL_ATTACHED_SHADERS: Int = 35_717

public const val GL_ACTIVE_UNIFORMS: Int = 35_718

public const val GL_ACTIVE_UNIFORM_MAX_LENGTH: Int = 35_719

public const val GL_ACTIVE_ATTRIBUTES: Int = 35_721

public const val GL_ACTIVE_ATTRIBUTE_MAX_LENGTH: Int = 35_722

public const val GL_SHADER_SOURCE_LENGTH: Int = 35_720

public const val GL_FLOAT_VEC2: Int = 35_664

public const val GL_FLOAT_VEC3: Int = 35_665

public const val GL_FLOAT_VEC4: Int = 35_666

public const val GL_INT_VEC2: Int = 35_667

public const val GL_INT_VEC3: Int = 35_668

public const val GL_INT_VEC4: Int = 35_669

public const val GL_BOOL: Int = 35_670

public const val GL_BOOL_VEC2: Int = 35_671

public const val GL_BOOL_VEC3: Int = 35_672

public const val GL_BOOL_VEC4: Int = 35_673

public const val GL_FLOAT_MAT2: Int = 35_674

public const val GL_FLOAT_MAT3: Int = 35_675

public const val GL_FLOAT_MAT4: Int = 35_676

public const val GL_SAMPLER_1D: Int = 35_677

public const val GL_SAMPLER_2D: Int = 35_678

public const val GL_SAMPLER_3D: Int = 35_679

public const val GL_SAMPLER_CUBE: Int = 35_680

public const val GL_SAMPLER_1D_SHADOW: Int = 35_681

public const val GL_SAMPLER_2D_SHADOW: Int = 35_682

public const val GL_VERTEX_SHADER: Int = 35_633

public const val GL_MAX_VERTEX_UNIFORM_COMPONENTS: Int = 35_658

public const val GL_MAX_VARYING_FLOATS: Int = 35_659

public const val GL_MAX_VERTEX_ATTRIBS: Int = 34_921

public const val GL_MAX_TEXTURE_IMAGE_UNITS: Int = 34_930

public const val GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS: Int = 35_660

public const val GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS: Int = 35_661

public const val GL_VERTEX_PROGRAM_POINT_SIZE: Int = 34_370

public const val GL_VERTEX_ATTRIB_ARRAY_ENABLED: Int = 34_338

public const val GL_VERTEX_ATTRIB_ARRAY_SIZE: Int = 34_339

public const val GL_VERTEX_ATTRIB_ARRAY_STRIDE: Int = 34_340

public const val GL_VERTEX_ATTRIB_ARRAY_TYPE: Int = 34_341

public const val GL_VERTEX_ATTRIB_ARRAY_NORMALIZED: Int = 34_922

public const val GL_CURRENT_VERTEX_ATTRIB: Int = 34_342

public const val GL_VERTEX_ATTRIB_ARRAY_POINTER: Int = 34_373

public const val GL_FRAGMENT_SHADER: Int = 35_632

public const val GL_MAX_FRAGMENT_UNIFORM_COMPONENTS: Int = 35_657

public const val GL_FRAGMENT_SHADER_DERIVATIVE_HINT: Int = 35_723

public const val GL_MAX_DRAW_BUFFERS: Int = 34_852

public const val GL_DRAW_BUFFER0: Int = 34_853

public const val GL_DRAW_BUFFER1: Int = 34_854

public const val GL_DRAW_BUFFER2: Int = 34_855

public const val GL_DRAW_BUFFER3: Int = 34_856

public const val GL_DRAW_BUFFER4: Int = 34_857

public const val GL_DRAW_BUFFER5: Int = 34_858

public const val GL_DRAW_BUFFER6: Int = 34_859

public const val GL_DRAW_BUFFER7: Int = 34_860

public const val GL_DRAW_BUFFER8: Int = 34_861

public const val GL_DRAW_BUFFER9: Int = 34_862

public const val GL_DRAW_BUFFER10: Int = 34_863

public const val GL_DRAW_BUFFER11: Int = 34_864

public const val GL_DRAW_BUFFER12: Int = 34_865

public const val GL_DRAW_BUFFER13: Int = 34_866

public const val GL_DRAW_BUFFER14: Int = 34_867

public const val GL_DRAW_BUFFER15: Int = 34_868

public const val GL_POINT_SPRITE_COORD_ORIGIN: Int = 36_000

public const val GL_LOWER_LEFT: Int = 36_001

public const val GL_UPPER_LEFT: Int = 36_002

public const val GL_BLEND_EQUATION_RGB: Int = 32_777

public const val GL_BLEND_EQUATION_ALPHA: Int = 34_877

public const val GL_STENCIL_BACK_FUNC: Int = 34_816

public const val GL_STENCIL_BACK_FAIL: Int = 34_817

public const val GL_STENCIL_BACK_PASS_DEPTH_FAIL: Int = 34_818

public const val GL_STENCIL_BACK_PASS_DEPTH_PASS: Int = 34_819

public const val GL_STENCIL_BACK_REF: Int = 36_003

public const val GL_STENCIL_BACK_VALUE_MASK: Int = 36_004

public const val GL_STENCIL_BACK_WRITEMASK: Int = 36_005

public inline fun glCreateProgram(): Int = GLWrapper.instance.GL20.glCreateProgram()

public inline fun glDeleteProgram(program: Int): Unit =
        GLWrapper.instance.GL20.glDeleteProgram(program)

public inline fun glIsProgram(program: Int): Boolean = GLWrapper.instance.GL20.glIsProgram(program)

public inline fun glCreateShader(type: Int): Int = GLWrapper.instance.GL20.glCreateShader(type)

public inline fun glDeleteShader(shader: Int): Unit = GLWrapper.instance.GL20.glDeleteShader(shader)

public inline fun glIsShader(shader: Int): Boolean = GLWrapper.instance.GL20.glIsShader(shader)

public inline fun glAttachShader(program: Int, shader: Int): Unit =
        GLWrapper.instance.GL20.glAttachShader(program, shader)

public inline fun glDetachShader(program: Int, shader: Int): Unit =
        GLWrapper.instance.GL20.glDetachShader(program, shader)

public inline fun glShaderSource(
    shader: Int,
    count: Int,
    strings: Ptr,
    length: Ptr,
): Unit = GLWrapper.instance.GL20.glShaderSource(shader, count, strings, length)

public inline fun glShaderSource(
    shader: Int,
    count: Int,
    strings: Long,
    length: Long,
): Unit = GLWrapper.instance.GL20.glShaderSource(shader, count, strings, length)

public inline fun glCompileShader(shader: Int): Unit =
        GLWrapper.instance.GL20.glCompileShader(shader)

public inline fun glLinkProgram(program: Int): Unit = GLWrapper.instance.GL20.glLinkProgram(program)

public inline fun glUseProgram(program: Int): Unit = GLWrapper.instance.GL20.glUseProgram(program)

public inline fun glValidateProgram(program: Int): Unit =
        GLWrapper.instance.GL20.glValidateProgram(program)

public inline fun glUniform1f(location: Int, v0: Float): Unit =
        GLWrapper.instance.GL20.glUniform1f(location, v0)

public inline fun glUniform2f(
    location: Int,
    v0: Float,
    v1: Float,
): Unit = GLWrapper.instance.GL20.glUniform2f(location, v0, v1)

public inline fun glUniform3f(
    location: Int,
    v0: Float,
    v1: Float,
    v2: Float,
): Unit = GLWrapper.instance.GL20.glUniform3f(location, v0, v1, v2)

public inline fun glUniform4f(
    location: Int,
    v0: Float,
    v1: Float,
    v2: Float,
    v3: Float,
): Unit = GLWrapper.instance.GL20.glUniform4f(location, v0, v1, v2, v3)

public inline fun glUniform1i(location: Int, v0: Int): Unit =
        GLWrapper.instance.GL20.glUniform1i(location, v0)

public inline fun glUniform2i(
    location: Int,
    v0: Int,
    v1: Int,
): Unit = GLWrapper.instance.GL20.glUniform2i(location, v0, v1)

public inline fun glUniform3i(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
): Unit = GLWrapper.instance.GL20.glUniform3i(location, v0, v1, v2)

public inline fun glUniform4i(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
): Unit = GLWrapper.instance.GL20.glUniform4i(location, v0, v1, v2, v3)

public inline fun glUniform1fv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniform1fv(location, count, `value`)

public inline fun glUniform1fv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniform1fv(location, count, `value`)

public inline fun glUniform2fv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniform2fv(location, count, `value`)

public inline fun glUniform2fv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniform2fv(location, count, `value`)

public inline fun glUniform3fv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniform3fv(location, count, `value`)

public inline fun glUniform3fv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniform3fv(location, count, `value`)

public inline fun glUniform4fv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniform4fv(location, count, `value`)

public inline fun glUniform4fv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniform4fv(location, count, `value`)

public inline fun glUniform1iv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniform1iv(location, count, `value`)

public inline fun glUniform1iv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniform1iv(location, count, `value`)

public inline fun glUniform2iv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniform2iv(location, count, `value`)

public inline fun glUniform2iv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniform2iv(location, count, `value`)

public inline fun glUniform3iv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniform3iv(location, count, `value`)

public inline fun glUniform3iv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniform3iv(location, count, `value`)

public inline fun glUniform4iv(
    location: Int,
    count: Int,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniform4iv(location, count, `value`)

public inline fun glUniform4iv(
    location: Int,
    count: Int,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniform4iv(location, count, `value`)

public inline fun glUniformMatrix2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniformMatrix2fv(location, count, transpose, `value`)

public inline fun glUniformMatrix2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniformMatrix2fv(location, count, transpose, `value`)

public inline fun glUniformMatrix3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniformMatrix3fv(location, count, transpose, `value`)

public inline fun glUniformMatrix3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniformMatrix3fv(location, count, transpose, `value`)

public inline fun glUniformMatrix4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Ptr,
): Unit = GLWrapper.instance.GL20.glUniformMatrix4fv(location, count, transpose, `value`)

public inline fun glUniformMatrix4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
): Unit = GLWrapper.instance.GL20.glUniformMatrix4fv(location, count, transpose, `value`)

public inline fun glGetShaderiv(
    shader: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL20.glGetShaderiv(shader, pname, params)

public inline fun glGetShaderiv(
    shader: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL20.glGetShaderiv(shader, pname, params)

public inline fun glGetProgramiv(
    program: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL20.glGetProgramiv(program, pname, params)

public inline fun glGetProgramiv(
    program: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL20.glGetProgramiv(program, pname, params)

public inline fun glGetShaderInfoLog(
    shader: Int,
    maxLength: Int,
    length: Ptr,
    infoLog: Ptr,
): Unit = GLWrapper.instance.GL20.glGetShaderInfoLog(shader, maxLength, length, infoLog)

public inline fun glGetShaderInfoLog(
    shader: Int,
    maxLength: Int,
    length: Long,
    infoLog: Long,
): Unit = GLWrapper.instance.GL20.glGetShaderInfoLog(shader, maxLength, length, infoLog)

public inline fun glGetProgramInfoLog(
    program: Int,
    maxLength: Int,
    length: Ptr,
    infoLog: Ptr,
): Unit = GLWrapper.instance.GL20.glGetProgramInfoLog(program, maxLength, length, infoLog)

public inline fun glGetProgramInfoLog(
    program: Int,
    maxLength: Int,
    length: Long,
    infoLog: Long,
): Unit = GLWrapper.instance.GL20.glGetProgramInfoLog(program, maxLength, length, infoLog)

public inline fun glGetAttachedShaders(
    program: Int,
    maxCount: Int,
    count: Ptr,
    shaders: Ptr,
): Unit = GLWrapper.instance.GL20.glGetAttachedShaders(program, maxCount, count, shaders)

public inline fun glGetAttachedShaders(
    program: Int,
    maxCount: Int,
    count: Long,
    shaders: Long,
): Unit = GLWrapper.instance.GL20.glGetAttachedShaders(program, maxCount, count, shaders)

public inline fun glGetUniformLocation(program: Int, name: Ptr): Int =
        GLWrapper.instance.GL20.glGetUniformLocation(program, name)

public inline fun glGetUniformLocation(program: Int, name: Long): Int =
        GLWrapper.instance.GL20.glGetUniformLocation(program, name)

public inline fun glGetActiveUniform(
    program: Int,
    index: Int,
    maxLength: Int,
    length: Ptr,
    size: Ptr,
    type: Ptr,
    name: Ptr,
): Unit = GLWrapper.instance.GL20.glGetActiveUniform(program, index, maxLength, length, size, type,
        name)

public inline fun glGetActiveUniform(
    program: Int,
    index: Int,
    maxLength: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
): Unit = GLWrapper.instance.GL20.glGetActiveUniform(program, index, maxLength, length, size, type,
        name)

public inline fun glGetUniformfv(
    program: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL20.glGetUniformfv(program, location, params)

public inline fun glGetUniformfv(
    program: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.GL20.glGetUniformfv(program, location, params)

public inline fun glGetUniformiv(
    program: Int,
    location: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL20.glGetUniformiv(program, location, params)

public inline fun glGetUniformiv(
    program: Int,
    location: Int,
    params: Long,
): Unit = GLWrapper.instance.GL20.glGetUniformiv(program, location, params)

public inline fun glGetShaderSource(
    shader: Int,
    maxLength: Int,
    length: Ptr,
    source: Ptr,
): Unit = GLWrapper.instance.GL20.glGetShaderSource(shader, maxLength, length, source)

public inline fun glGetShaderSource(
    shader: Int,
    maxLength: Int,
    length: Long,
    source: Long,
): Unit = GLWrapper.instance.GL20.glGetShaderSource(shader, maxLength, length, source)

public inline fun glVertexAttrib1f(index: Int, v0: Float): Unit =
        GLWrapper.instance.GL20.glVertexAttrib1f(index, v0)

public inline fun glVertexAttrib1s(index: Int, v0: Short): Unit =
        GLWrapper.instance.GL20.glVertexAttrib1s(index, v0)

public inline fun glVertexAttrib1d(index: Int, v0: Double): Unit =
        GLWrapper.instance.GL20.glVertexAttrib1d(index, v0)

public inline fun glVertexAttrib2f(
    index: Int,
    v0: Float,
    v1: Float,
): Unit = GLWrapper.instance.GL20.glVertexAttrib2f(index, v0, v1)

public inline fun glVertexAttrib2s(
    index: Int,
    v0: Short,
    v1: Short,
): Unit = GLWrapper.instance.GL20.glVertexAttrib2s(index, v0, v1)

public inline fun glVertexAttrib2d(
    index: Int,
    v0: Double,
    v1: Double,
): Unit = GLWrapper.instance.GL20.glVertexAttrib2d(index, v0, v1)

public inline fun glVertexAttrib3f(
    index: Int,
    v0: Float,
    v1: Float,
    v2: Float,
): Unit = GLWrapper.instance.GL20.glVertexAttrib3f(index, v0, v1, v2)

public inline fun glVertexAttrib3s(
    index: Int,
    v0: Short,
    v1: Short,
    v2: Short,
): Unit = GLWrapper.instance.GL20.glVertexAttrib3s(index, v0, v1, v2)

public inline fun glVertexAttrib3d(
    index: Int,
    v0: Double,
    v1: Double,
    v2: Double,
): Unit = GLWrapper.instance.GL20.glVertexAttrib3d(index, v0, v1, v2)

public inline fun glVertexAttrib4f(
    index: Int,
    v0: Float,
    v1: Float,
    v2: Float,
    v3: Float,
): Unit = GLWrapper.instance.GL20.glVertexAttrib4f(index, v0, v1, v2, v3)

public inline fun glVertexAttrib4s(
    index: Int,
    v0: Short,
    v1: Short,
    v2: Short,
    v3: Short,
): Unit = GLWrapper.instance.GL20.glVertexAttrib4s(index, v0, v1, v2, v3)

public inline fun glVertexAttrib4d(
    index: Int,
    v0: Double,
    v1: Double,
    v2: Double,
    v3: Double,
): Unit = GLWrapper.instance.GL20.glVertexAttrib4d(index, v0, v1, v2, v3)

public inline fun glVertexAttrib4Nub(
    index: Int,
    x: Byte,
    y: Byte,
    z: Byte,
    w: Byte,
): Unit = GLWrapper.instance.GL20.glVertexAttrib4Nub(index, x, y, z, w)

public inline fun glVertexAttrib1fv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib1fv(index, v)

public inline fun glVertexAttrib1fv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib1fv(index, v)

public inline fun glVertexAttrib1sv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib1sv(index, v)

public inline fun glVertexAttrib1sv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib1sv(index, v)

public inline fun glVertexAttrib1dv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib1dv(index, v)

public inline fun glVertexAttrib1dv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib1dv(index, v)

public inline fun glVertexAttrib2fv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib2fv(index, v)

public inline fun glVertexAttrib2fv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib2fv(index, v)

public inline fun glVertexAttrib2sv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib2sv(index, v)

public inline fun glVertexAttrib2sv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib2sv(index, v)

public inline fun glVertexAttrib2dv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib2dv(index, v)

public inline fun glVertexAttrib2dv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib2dv(index, v)

public inline fun glVertexAttrib3fv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib3fv(index, v)

public inline fun glVertexAttrib3fv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib3fv(index, v)

public inline fun glVertexAttrib3sv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib3sv(index, v)

public inline fun glVertexAttrib3sv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib3sv(index, v)

public inline fun glVertexAttrib3dv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib3dv(index, v)

public inline fun glVertexAttrib3dv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib3dv(index, v)

public inline fun glVertexAttrib4fv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4fv(index, v)

public inline fun glVertexAttrib4fv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4fv(index, v)

public inline fun glVertexAttrib4sv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4sv(index, v)

public inline fun glVertexAttrib4sv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4sv(index, v)

public inline fun glVertexAttrib4dv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4dv(index, v)

public inline fun glVertexAttrib4dv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4dv(index, v)

public inline fun glVertexAttrib4iv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4iv(index, v)

public inline fun glVertexAttrib4iv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4iv(index, v)

public inline fun glVertexAttrib4bv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4bv(index, v)

public inline fun glVertexAttrib4bv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4bv(index, v)

public inline fun glVertexAttrib4ubv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4ubv(index, v)

public inline fun glVertexAttrib4ubv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4ubv(index, v)

public inline fun glVertexAttrib4usv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4usv(index, v)

public inline fun glVertexAttrib4usv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4usv(index, v)

public inline fun glVertexAttrib4uiv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4uiv(index, v)

public inline fun glVertexAttrib4uiv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4uiv(index, v)

public inline fun glVertexAttrib4Nbv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nbv(index, v)

public inline fun glVertexAttrib4Nbv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nbv(index, v)

public inline fun glVertexAttrib4Nsv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nsv(index, v)

public inline fun glVertexAttrib4Nsv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nsv(index, v)

public inline fun glVertexAttrib4Niv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Niv(index, v)

public inline fun glVertexAttrib4Niv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Niv(index, v)

public inline fun glVertexAttrib4Nubv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nubv(index, v)

public inline fun glVertexAttrib4Nubv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nubv(index, v)

public inline fun glVertexAttrib4Nusv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nusv(index, v)

public inline fun glVertexAttrib4Nusv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nusv(index, v)

public inline fun glVertexAttrib4Nuiv(index: Int, v: Ptr): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nuiv(index, v)

public inline fun glVertexAttrib4Nuiv(index: Int, v: Long): Unit =
        GLWrapper.instance.GL20.glVertexAttrib4Nuiv(index, v)

public inline fun glVertexAttribPointer(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.GL20.glVertexAttribPointer(index, size, type, normalized, stride,
        pointer)

public inline fun glVertexAttribPointer(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    pointer: Long,
): Unit = GLWrapper.instance.GL20.glVertexAttribPointer(index, size, type, normalized, stride,
        pointer)

public inline fun glEnableVertexAttribArray(index: Int): Unit =
        GLWrapper.instance.GL20.glEnableVertexAttribArray(index)

public inline fun glDisableVertexAttribArray(index: Int): Unit =
        GLWrapper.instance.GL20.glDisableVertexAttribArray(index)

public inline fun glBindAttribLocation(
    program: Int,
    index: Int,
    name: Ptr,
): Unit = GLWrapper.instance.GL20.glBindAttribLocation(program, index, name)

public inline fun glBindAttribLocation(
    program: Int,
    index: Int,
    name: Long,
): Unit = GLWrapper.instance.GL20.glBindAttribLocation(program, index, name)

public inline fun glGetActiveAttrib(
    program: Int,
    index: Int,
    maxLength: Int,
    length: Ptr,
    size: Ptr,
    type: Ptr,
    name: Ptr,
): Unit = GLWrapper.instance.GL20.glGetActiveAttrib(program, index, maxLength, length, size, type,
        name)

public inline fun glGetActiveAttrib(
    program: Int,
    index: Int,
    maxLength: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
): Unit = GLWrapper.instance.GL20.glGetActiveAttrib(program, index, maxLength, length, size, type,
        name)

public inline fun glGetAttribLocation(program: Int, name: Ptr): Int =
        GLWrapper.instance.GL20.glGetAttribLocation(program, name)

public inline fun glGetAttribLocation(program: Int, name: Long): Int =
        GLWrapper.instance.GL20.glGetAttribLocation(program, name)

public inline fun glGetVertexAttribiv(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL20.glGetVertexAttribiv(index, pname, params)

public inline fun glGetVertexAttribiv(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL20.glGetVertexAttribiv(index, pname, params)

public inline fun glGetVertexAttribfv(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL20.glGetVertexAttribfv(index, pname, params)

public inline fun glGetVertexAttribfv(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL20.glGetVertexAttribfv(index, pname, params)

public inline fun glGetVertexAttribdv(
    index: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.GL20.glGetVertexAttribdv(index, pname, params)

public inline fun glGetVertexAttribdv(
    index: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.GL20.glGetVertexAttribdv(index, pname, params)

public inline fun glGetVertexAttribPointerv(
    index: Int,
    pname: Int,
    pointer: Ptr,
): Unit = GLWrapper.instance.GL20.glGetVertexAttribPointerv(index, pname, pointer)

public inline fun glGetVertexAttribPointerv(
    index: Int,
    pname: Int,
    pointer: Long,
): Unit = GLWrapper.instance.GL20.glGetVertexAttribPointerv(index, pname, pointer)

public inline fun glDrawBuffers(n: Int, bufs: Ptr): Unit = GLWrapper.instance.GL20.glDrawBuffers(n,
        bufs)

public inline fun glDrawBuffers(n: Int, bufs: Long): Unit = GLWrapper.instance.GL20.glDrawBuffers(n,
        bufs)

public inline fun glBlendEquationSeparate(modeRGB: Int, modeAlpha: Int): Unit =
        GLWrapper.instance.GL20.glBlendEquationSeparate(modeRGB, modeAlpha)

public inline fun glStencilOpSeparate(
    face: Int,
    sfail: Int,
    dpfail: Int,
    dppass: Int,
): Unit = GLWrapper.instance.GL20.glStencilOpSeparate(face, sfail, dpfail, dppass)

public inline fun glStencilFuncSeparate(
    face: Int,
    func: Int,
    ref: Int,
    mask: Int,
): Unit = GLWrapper.instance.GL20.glStencilFuncSeparate(face, func, ref, mask)

public inline fun glStencilMaskSeparate(face: Int, mask: Int): Unit =
        GLWrapper.instance.GL20.glStencilMaskSeparate(face, mask)

public inline fun glGetShaderi(shader: Int, pname: Int): Int =
        GLWrapper.instance.GL20.glGetShaderi(shader, pname)

public inline fun glGetProgrami(program: Int, pname: Int): Int =
        GLWrapper.instance.GL20.glGetProgrami(program, pname)

public inline fun glGetShaderInfoLog(shader: Int, maxLength: Int): String =
        GLWrapper.instance.GL20.glGetShaderInfoLog(shader, maxLength)

public inline fun glGetProgramInfoLog(program: Int, maxLength: Int): String =
        GLWrapper.instance.GL20.glGetProgramInfoLog(program, maxLength)

public inline fun glGetUniformLocation(program: Int, name: CharSequence): Int =
        GLWrapper.instance.GL20.glGetUniformLocation(program, name)

public inline fun glShaderSource(shader: Int, string: CharSequence): Unit =
        GLWrapper.instance.GL20.glShaderSource(shader, string)
