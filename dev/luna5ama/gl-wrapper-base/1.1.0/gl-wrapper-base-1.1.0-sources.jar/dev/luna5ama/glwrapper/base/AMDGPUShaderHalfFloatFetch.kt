@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface AMDGPUShaderHalfFloatFetch : GLBase

public const val GL_FLOAT16_SAMPLER_1D_AMD: Int = 37_326

public const val GL_FLOAT16_SAMPLER_2D_AMD: Int = 37_327

public const val GL_FLOAT16_SAMPLER_3D_AMD: Int = 37_328

public const val GL_FLOAT16_SAMPLER_CUBE_AMD: Int = 37_329

public const val GL_FLOAT16_SAMPLER_2D_RECT_AMD: Int = 37_330

public const val GL_FLOAT16_SAMPLER_1D_ARRAY_AMD: Int = 37_331

public const val GL_FLOAT16_SAMPLER_2D_ARRAY_AMD: Int = 37_332

public const val GL_FLOAT16_SAMPLER_CUBE_MAP_ARRAY_AMD: Int = 37_333

public const val GL_FLOAT16_SAMPLER_BUFFER_AMD: Int = 37_334

public const val GL_FLOAT16_SAMPLER_2D_MULTISAMPLE_AMD: Int = 37_335

public const val GL_FLOAT16_SAMPLER_2D_MULTISAMPLE_ARRAY_AMD: Int = 37_336

public const val GL_FLOAT16_SAMPLER_1D_SHADOW_AMD: Int = 37_337

public const val GL_FLOAT16_SAMPLER_2D_SHADOW_AMD: Int = 37_338

public const val GL_FLOAT16_SAMPLER_2D_RECT_SHADOW_AMD: Int = 37_339

public const val GL_FLOAT16_SAMPLER_1D_ARRAY_SHADOW_AMD: Int = 37_340

public const val GL_FLOAT16_SAMPLER_2D_ARRAY_SHADOW_AMD: Int = 37_341

public const val GL_FLOAT16_SAMPLER_CUBE_SHADOW_AMD: Int = 37_342

public const val GL_FLOAT16_SAMPLER_CUBE_MAP_ARRAY_SHADOW_AMD: Int = 37_343

public const val GL_FLOAT16_IMAGE_1D_AMD: Int = 37_344

public const val GL_FLOAT16_IMAGE_2D_AMD: Int = 37_345

public const val GL_FLOAT16_IMAGE_3D_AMD: Int = 37_346

public const val GL_FLOAT16_IMAGE_2D_RECT_AMD: Int = 37_347

public const val GL_FLOAT16_IMAGE_CUBE_AMD: Int = 37_348

public const val GL_FLOAT16_IMAGE_1D_ARRAY_AMD: Int = 37_349

public const val GL_FLOAT16_IMAGE_2D_ARRAY_AMD: Int = 37_350

public const val GL_FLOAT16_IMAGE_CUBE_MAP_ARRAY_AMD: Int = 37_351

public const val GL_FLOAT16_IMAGE_BUFFER_AMD: Int = 37_352

public const val GL_FLOAT16_IMAGE_2D_MULTISAMPLE_AMD: Int = 37_353

public const val GL_FLOAT16_IMAGE_2D_MULTISAMPLE_ARRAY_AMD: Int = 37_354
