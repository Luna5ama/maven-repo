@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTTextureCompressionLATC : GLBase

public const val GL_COMPRESSED_LUMINANCE_LATC1_EXT: Int = 35_952

public const val GL_COMPRESSED_SIGNED_LUMINANCE_LATC1_EXT: Int = 35_953

public const val GL_COMPRESSED_LUMINANCE_ALPHA_LATC2_EXT: Int = 35_954

public const val GL_COMPRESSED_SIGNED_LUMINANCE_ALPHA_LATC2_EXT: Int = 35_955
