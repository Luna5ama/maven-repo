@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTPointParameters : GLBase {
    public fun glPointParameterfEXT(pname: Int, `param`: Float)

    @PtrParameter([1])
    public fun glPointParameterfvEXT(pname: Int, params: Ptr)

    @Unsafe
    public fun glPointParameterfvEXT(pname: Int, params: Long)
}

public const val GL_POINT_SIZE_MIN_EXT: Int = 33_062

public const val GL_POINT_SIZE_MAX_EXT: Int = 33_063

public const val GL_POINT_FADE_THRESHOLD_SIZE_EXT: Int = 33_064

public const val GL_DISTANCE_ATTENUATION_EXT: Int = 33_065

public inline fun glPointParameterfEXT(pname: Int, `param`: Float): Unit =
        GLWrapper.instance.EXTPointParameters.glPointParameterfEXT(pname, `param`)

public inline fun glPointParameterfvEXT(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.EXTPointParameters.glPointParameterfvEXT(pname, params)

public inline fun glPointParameterfvEXT(pname: Int, params: Long): Unit =
        GLWrapper.instance.EXTPointParameters.glPointParameterfvEXT(pname, params)
