@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface AMDOcclusionQueryEvent : GLBase {
    public fun glQueryObjectParameteruiAMD(
        target: Int,
        id: Int,
        pname: Int,
        `param`: Int,
    )
}

public const val GL_OCCLUSION_QUERY_EVENT_MASK_AMD: Int = 34_639

public const val GL_QUERY_DEPTH_PASS_EVENT_BIT_AMD: Int = 1

public const val GL_QUERY_DEPTH_FAIL_EVENT_BIT_AMD: Int = 2

public const val GL_QUERY_STENCIL_FAIL_EVENT_BIT_AMD: Int = 4

public const val GL_QUERY_DEPTH_BOUNDS_FAIL_EVENT_BIT_AMD: Int = 8

public const val GL_QUERY_ALL_EVENT_BITS_AMD: Int = 1

public inline fun glQueryObjectParameteruiAMD(
    target: Int,
    id: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.AMDOcclusionQueryEvent.glQueryObjectParameteruiAMD(target, id, pname,
        `param`)
