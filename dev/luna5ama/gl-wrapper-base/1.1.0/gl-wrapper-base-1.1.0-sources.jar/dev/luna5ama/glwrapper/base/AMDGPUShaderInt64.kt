@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress

public interface AMDGPUShaderInt64 : GLBase {
    @PtrParameter([2])
    public fun glUniform1i64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1i64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform2i64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2i64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform3i64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3i64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform4i64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4i64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform1ui64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform1ui64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform2ui64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform2ui64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform3ui64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform3ui64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glUniform4ui64vNV(
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glUniform4ui64vNV(
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformi64vNV(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformi64vNV(
        program: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([2])
    public fun glGetUniformui64vNV(
        program: Int,
        location: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetUniformui64vNV(
        program: Int,
        location: Int,
        params: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4i64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform1ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform1ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform2ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform2ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform3ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform3ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )

    @PtrParameter([3])
    public fun glProgramUniform4ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Ptr,
    )

    @Unsafe
    public fun glProgramUniform4ui64vNV(
        program: Int,
        location: Int,
        count: Int,
        `value`: Long,
    )
}
