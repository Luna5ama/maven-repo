@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVScissorExclusive : GLBase {
    @PtrParameter([2])
    public fun glScissorExclusiveArrayvNV(
        first: Int,
        count: Int,
        v: Ptr,
    )

    @Unsafe
    public fun glScissorExclusiveArrayvNV(
        first: Int,
        count: Int,
        v: Long,
    )

    public fun glScissorExclusiveNV(
        x: Int,
        y: Int,
        width: Int,
        height: Int,
    )
}

public const val GL_SCISSOR_TEST_EXCLUSIVE_NV: Int = 38_229

public const val GL_SCISSOR_BOX_EXCLUSIVE_NV: Int = 38_230

public inline fun glScissorExclusiveArrayvNV(
    first: Int,
    count: Int,
    v: Ptr,
): Unit = GLWrapper.instance.NVScissorExclusive.glScissorExclusiveArrayvNV(first, count, v)

public inline fun glScissorExclusiveArrayvNV(
    first: Int,
    count: Int,
    v: Long,
): Unit = GLWrapper.instance.NVScissorExclusive.glScissorExclusiveArrayvNV(first, count, v)

public inline fun glScissorExclusiveNV(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.NVScissorExclusive.glScissorExclusiveNV(x, y, width, height)
