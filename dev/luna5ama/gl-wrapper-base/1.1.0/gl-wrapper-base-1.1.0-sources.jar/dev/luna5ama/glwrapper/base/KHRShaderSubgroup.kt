@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface KHRShaderSubgroup : GLBase

public const val GL_SUBGROUP_SIZE_KHR: Int = 38_194

public const val GL_SUBGROUP_SUPPORTED_STAGES_KHR: Int = 38_195

public const val GL_SUBGROUP_SUPPORTED_FEATURES_KHR: Int = 38_196

public const val GL_SUBGROUP_QUAD_ALL_STAGES_KHR: Int = 38_197

public const val GL_SUBGROUP_FEATURE_BASIC_BIT_KHR: Int = 1

public const val GL_SUBGROUP_FEATURE_VOTE_BIT_KHR: Int = 2

public const val GL_SUBGROUP_FEATURE_ARITHMETIC_BIT_KHR: Int = 4

public const val GL_SUBGROUP_FEATURE_BALLOT_BIT_KHR: Int = 8

public const val GL_SUBGROUP_FEATURE_SHUFFLE_BIT_KHR: Int = 16

public const val GL_SUBGROUP_FEATURE_SHUFFLE_RELATIVE_BIT_KHR: Int = 32

public const val GL_SUBGROUP_FEATURE_CLUSTERED_BIT_KHR: Int = 64

public const val GL_SUBGROUP_FEATURE_QUAD_BIT_KHR: Int = 128
