@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVFence : GLBase {
    @PtrParameter([1])
    public fun glDeleteFencesNV(n: Int, fences: Ptr)

    @Unsafe
    public fun glDeleteFencesNV(n: Int, fences: Long)

    @PtrParameter([1])
    public fun glGenFencesNV(n: Int, fences: Ptr)

    @Unsafe
    public fun glGenFencesNV(n: Int, fences: Long)

    public fun glIsFenceNV(fence: Int): Boolean

    public fun glTestFenceNV(fence: Int): Boolean

    @PtrParameter([2])
    public fun glGetFenceivNV(
        fence: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetFenceivNV(
        fence: Int,
        pname: Int,
        params: Long,
    )

    public fun glFinishFenceNV(fence: Int)

    public fun glSetFenceNV(fence: Int, condition: Int)
}

public const val GL_ALL_COMPLETED_NV: Int = 34_034

public const val GL_FENCE_STATUS_NV: Int = 34_035

public const val GL_FENCE_CONDITION_NV: Int = 34_036

public inline fun glDeleteFencesNV(n: Int, fences: Ptr): Unit =
        GLWrapper.instance.NVFence.glDeleteFencesNV(n, fences)

public inline fun glDeleteFencesNV(n: Int, fences: Long): Unit =
        GLWrapper.instance.NVFence.glDeleteFencesNV(n, fences)

public inline fun glGenFencesNV(n: Int, fences: Ptr): Unit =
        GLWrapper.instance.NVFence.glGenFencesNV(n, fences)

public inline fun glGenFencesNV(n: Int, fences: Long): Unit =
        GLWrapper.instance.NVFence.glGenFencesNV(n, fences)

public inline fun glIsFenceNV(fence: Int): Boolean = GLWrapper.instance.NVFence.glIsFenceNV(fence)

public inline fun glTestFenceNV(fence: Int): Boolean =
        GLWrapper.instance.NVFence.glTestFenceNV(fence)

public inline fun glGetFenceivNV(
    fence: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.NVFence.glGetFenceivNV(fence, pname, params)

public inline fun glGetFenceivNV(
    fence: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.NVFence.glGetFenceivNV(fence, pname, params)

public inline fun glFinishFenceNV(fence: Int): Unit =
        GLWrapper.instance.NVFence.glFinishFenceNV(fence)

public inline fun glSetFenceNV(fence: Int, condition: Int): Unit =
        GLWrapper.instance.NVFence.glSetFenceNV(fence, condition)
