@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVConservativeRasterPreSnapTriangles : GLBase {
    public fun glConservativeRasterParameteriNV(pname: Int, `param`: Int)
}

public const val GL_CONSERVATIVE_RASTER_MODE_NV: Int = 38_221

public const val GL_CONSERVATIVE_RASTER_MODE_POST_SNAP_NV: Int = 38_222

public const val GL_CONSERVATIVE_RASTER_MODE_PRE_SNAP_TRIANGLES_NV: Int = 38_223

public inline fun glConservativeRasterParameteriNV(pname: Int, `param`: Int): Unit =
        GLWrapper.instance.NVConservativeRasterPreSnapTriangles.glConservativeRasterParameteriNV(pname,
        `param`)
