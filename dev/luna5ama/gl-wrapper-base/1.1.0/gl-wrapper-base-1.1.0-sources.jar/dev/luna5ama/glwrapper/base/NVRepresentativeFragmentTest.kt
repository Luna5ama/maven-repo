@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVRepresentativeFragmentTest : GLBase

public const val GL_REPRESENTATIVE_FRAGMENT_TEST_NV: Int = 37_759
