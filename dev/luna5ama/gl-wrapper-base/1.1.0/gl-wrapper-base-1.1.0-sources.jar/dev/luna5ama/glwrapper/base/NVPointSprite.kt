@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVPointSprite : GLBase {
    public fun glPointParameteriNV(pname: Int, `param`: Int)

    @PtrParameter([1])
    public fun glPointParameterivNV(pname: Int, params: Ptr)

    @Unsafe
    public fun glPointParameterivNV(pname: Int, params: Long)
}

public const val GL_POINT_SPRITE_NV: Int = 34_913

public const val GL_COORD_REPLACE_NV: Int = 34_914

public const val GL_POINT_SPRITE_R_MODE_NV: Int = 34_915

public inline fun glPointParameteriNV(pname: Int, `param`: Int): Unit =
        GLWrapper.instance.NVPointSprite.glPointParameteriNV(pname, `param`)

public inline fun glPointParameterivNV(pname: Int, params: Ptr): Unit =
        GLWrapper.instance.NVPointSprite.glPointParameterivNV(pname, params)

public inline fun glPointParameterivNV(pname: Int, params: Long): Unit =
        GLWrapper.instance.NVPointSprite.glPointParameterivNV(pname, params)
