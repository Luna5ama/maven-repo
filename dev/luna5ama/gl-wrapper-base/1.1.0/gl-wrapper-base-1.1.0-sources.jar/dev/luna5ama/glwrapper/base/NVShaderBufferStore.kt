@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVShaderBufferStore : GLBase

public const val GL_SHADER_GLOBAL_ACCESS_BARRIER_BIT_NV: Int = 16
