@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXT422Pixels : GLBase

public const val GL_422_EXT: Int = 32_972

public const val GL_422_REV_EXT: Int = 32_973

public const val GL_422_AVERAGE_EXT: Int = 32_974

public const val GL_422_REV_AVERAGE_EXT: Int = 32_975
