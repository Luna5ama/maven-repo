@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface EXTPolygonOffsetClamp : GLBase {
    public fun glPolygonOffsetClampEXT(
        factor: Float,
        units: Float,
        clamp: Float,
    )
}

public const val GL_POLYGON_OFFSET_CLAMP_EXT: Int = 36_379

public inline fun glPolygonOffsetClampEXT(
    factor: Float,
    units: Float,
    clamp: Float,
): Unit = GLWrapper.instance.EXTPolygonOffsetClamp.glPolygonOffsetClampEXT(factor, units, clamp)
