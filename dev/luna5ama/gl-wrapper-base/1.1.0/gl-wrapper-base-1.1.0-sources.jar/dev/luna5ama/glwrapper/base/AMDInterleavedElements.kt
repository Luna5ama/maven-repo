@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface AMDInterleavedElements : GLBase {
    public fun glVertexAttribParameteriAMD(
        index: Int,
        pname: Int,
        `param`: Int,
    )
}

public const val GL_VERTEX_ELEMENT_SWIZZLE_AMD: Int = 37_284

public const val GL_VERTEX_ID_SWIZZLE_AMD: Int = 37_285

public inline fun glVertexAttribParameteriAMD(
    index: Int,
    pname: Int,
    `param`: Int,
): Unit = GLWrapper.instance.AMDInterleavedElements.glVertexAttribParameteriAMD(index, pname,
        `param`)
