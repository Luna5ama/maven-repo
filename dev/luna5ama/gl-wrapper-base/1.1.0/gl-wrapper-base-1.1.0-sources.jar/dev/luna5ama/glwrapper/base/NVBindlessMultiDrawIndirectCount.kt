@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVBindlessMultiDrawIndirectCount : GLBase {
    @PtrParameter([1])
    public fun glMultiDrawArraysIndirectBindlessCountNV(
        mode: Int,
        indirect: Ptr,
        drawCount: Long,
        maxDrawCount: Int,
        stride: Int,
        vertexBufferCount: Int,
    )

    @Unsafe
    public fun glMultiDrawArraysIndirectBindlessCountNV(
        mode: Int,
        indirect: Long,
        drawCount: Long,
        maxDrawCount: Int,
        stride: Int,
        vertexBufferCount: Int,
    )

    @PtrParameter([2])
    public fun glMultiDrawElementsIndirectBindlessCountNV(
        mode: Int,
        type: Int,
        indirect: Ptr,
        drawCount: Long,
        maxDrawCount: Int,
        stride: Int,
        vertexBufferCount: Int,
    )

    @Unsafe
    public fun glMultiDrawElementsIndirectBindlessCountNV(
        mode: Int,
        type: Int,
        indirect: Long,
        drawCount: Long,
        maxDrawCount: Int,
        stride: Int,
        vertexBufferCount: Int,
    )
}

public inline fun glMultiDrawArraysIndirectBindlessCountNV(
    mode: Int,
    indirect: Ptr,
    drawCount: Long,
    maxDrawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
): Unit =
        GLWrapper.instance.NVBindlessMultiDrawIndirectCount.glMultiDrawArraysIndirectBindlessCountNV(mode,
        indirect, drawCount, maxDrawCount, stride, vertexBufferCount)

public inline fun glMultiDrawArraysIndirectBindlessCountNV(
    mode: Int,
    indirect: Long,
    drawCount: Long,
    maxDrawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
): Unit =
        GLWrapper.instance.NVBindlessMultiDrawIndirectCount.glMultiDrawArraysIndirectBindlessCountNV(mode,
        indirect, drawCount, maxDrawCount, stride, vertexBufferCount)

public inline fun glMultiDrawElementsIndirectBindlessCountNV(
    mode: Int,
    type: Int,
    indirect: Ptr,
    drawCount: Long,
    maxDrawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
): Unit =
        GLWrapper.instance.NVBindlessMultiDrawIndirectCount.glMultiDrawElementsIndirectBindlessCountNV(mode,
        type, indirect, drawCount, maxDrawCount, stride, vertexBufferCount)

public inline fun glMultiDrawElementsIndirectBindlessCountNV(
    mode: Int,
    type: Int,
    indirect: Long,
    drawCount: Long,
    maxDrawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
): Unit =
        GLWrapper.instance.NVBindlessMultiDrawIndirectCount.glMultiDrawElementsIndirectBindlessCountNV(mode,
        type, indirect, drawCount, maxDrawCount, stride, vertexBufferCount)
