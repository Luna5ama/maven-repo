@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface KHRParallelShaderCompile : GLBase {
    public fun glMaxShaderCompilerThreadsKHR(count: Int)
}

public const val GL_MAX_SHADER_COMPILER_THREADS_KHR: Int = 37_296

public const val GL_COMPLETION_STATUS_KHR: Int = 37_297

public inline fun glMaxShaderCompilerThreadsKHR(count: Int): Unit =
        GLWrapper.instance.KHRParallelShaderCompile.glMaxShaderCompilerThreadsKHR(count)
