@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface ARBSparseTexture : GLBase {
    public fun glTexPageCommitmentARB(
        target: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        commit: Boolean,
    )

    public fun glTexturePageCommitmentEXT(
        texture: Int,
        level: Int,
        xoffset: Int,
        yoffset: Int,
        zoffset: Int,
        width: Int,
        height: Int,
        depth: Int,
        commit: Boolean,
    )
}

public const val GL_TEXTURE_SPARSE_ARB: Int = 37_286

public const val GL_VIRTUAL_PAGE_SIZE_INDEX_ARB: Int = 37_287

public const val GL_NUM_SPARSE_LEVELS_ARB: Int = 37_290

public const val GL_NUM_VIRTUAL_PAGE_SIZES_ARB: Int = 37_288

public const val GL_VIRTUAL_PAGE_SIZE_X_ARB: Int = 37_269

public const val GL_VIRTUAL_PAGE_SIZE_Y_ARB: Int = 37_270

public const val GL_VIRTUAL_PAGE_SIZE_Z_ARB: Int = 37_271

public const val GL_MAX_SPARSE_TEXTURE_SIZE_ARB: Int = 37_272

public const val GL_MAX_SPARSE_3D_TEXTURE_SIZE_ARB: Int = 37_273

public const val GL_MAX_SPARSE_ARRAY_TEXTURE_LAYERS_ARB: Int = 37_274

public const val GL_SPARSE_TEXTURE_FULL_ARRAY_CUBE_MIPMAPS_ARB: Int = 37_289

public inline fun glTexPageCommitmentARB(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    commit: Boolean,
): Unit = GLWrapper.instance.ARBSparseTexture.glTexPageCommitmentARB(target, level, xoffset,
        yoffset, zoffset, width, height, depth, commit)

public inline fun glTexturePageCommitmentEXT(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    commit: Boolean,
): Unit = GLWrapper.instance.ARBSparseTexture.glTexturePageCommitmentEXT(texture, level, xoffset,
        yoffset, zoffset, width, height, depth, commit)
