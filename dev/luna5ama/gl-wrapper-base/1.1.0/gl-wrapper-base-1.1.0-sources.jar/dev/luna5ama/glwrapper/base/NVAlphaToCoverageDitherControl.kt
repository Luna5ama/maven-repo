@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress
import kotlin.Unit

public interface NVAlphaToCoverageDitherControl : GLBase {
    public fun glAlphaToCoverageDitherControlNV(mode: Int)
}

public const val GL_ALPHA_TO_COVERAGE_DITHER_DEFAULT_NV: Int = 37_709

public const val GL_ALPHA_TO_COVERAGE_DITHER_ENABLE_NV: Int = 37_710

public const val GL_ALPHA_TO_COVERAGE_DITHER_DISABLE_NV: Int = 37_711

public const val GL_ALPHA_TO_COVERAGE_DITHER_MODE_NV: Int = 37_567

public inline fun glAlphaToCoverageDitherControlNV(mode: Int): Unit =
        GLWrapper.instance.NVAlphaToCoverageDitherControl.glAlphaToCoverageDitherControlNV(mode)
