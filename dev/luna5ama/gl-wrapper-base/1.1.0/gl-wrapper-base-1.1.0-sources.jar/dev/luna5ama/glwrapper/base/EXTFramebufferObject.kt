@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface EXTFramebufferObject : GLBase {
    public fun glIsRenderbufferEXT(renderbuffer: Int): Boolean

    public fun glBindRenderbufferEXT(target: Int, renderbuffer: Int)

    @PtrParameter([1])
    public fun glDeleteRenderbuffersEXT(n: Int, renderbuffers: Ptr)

    @Unsafe
    public fun glDeleteRenderbuffersEXT(n: Int, renderbuffers: Long)

    @PtrParameter([1])
    public fun glGenRenderbuffersEXT(n: Int, renderbuffers: Ptr)

    @Unsafe
    public fun glGenRenderbuffersEXT(n: Int, renderbuffers: Long)

    public fun glRenderbufferStorageEXT(
        target: Int,
        internalformat: Int,
        width: Int,
        height: Int,
    )

    @PtrParameter([2])
    public fun glGetRenderbufferParameterivEXT(
        target: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetRenderbufferParameterivEXT(
        target: Int,
        pname: Int,
        params: Long,
    )

    public fun glIsFramebufferEXT(framebuffer: Int): Boolean

    public fun glBindFramebufferEXT(target: Int, framebuffer: Int)

    @PtrParameter([1])
    public fun glDeleteFramebuffersEXT(n: Int, framebuffers: Ptr)

    @Unsafe
    public fun glDeleteFramebuffersEXT(n: Int, framebuffers: Long)

    @PtrParameter([1])
    public fun glGenFramebuffersEXT(n: Int, framebuffers: Ptr)

    @Unsafe
    public fun glGenFramebuffersEXT(n: Int, framebuffers: Long)

    public fun glCheckFramebufferStatusEXT(target: Int): Int

    public fun glFramebufferTexture1DEXT(
        target: Int,
        attachment: Int,
        textarget: Int,
        texture: Int,
        level: Int,
    )

    public fun glFramebufferTexture2DEXT(
        target: Int,
        attachment: Int,
        textarget: Int,
        texture: Int,
        level: Int,
    )

    public fun glFramebufferTexture3DEXT(
        target: Int,
        attachment: Int,
        textarget: Int,
        texture: Int,
        level: Int,
        zoffset: Int,
    )

    public fun glFramebufferRenderbufferEXT(
        target: Int,
        attachment: Int,
        renderbuffertarget: Int,
        renderbuffer: Int,
    )

    @PtrParameter([3])
    public fun glGetFramebufferAttachmentParameterivEXT(
        target: Int,
        attachment: Int,
        pname: Int,
        params: Ptr,
    )

    @Unsafe
    public fun glGetFramebufferAttachmentParameterivEXT(
        target: Int,
        attachment: Int,
        pname: Int,
        params: Long,
    )

    public fun glGenerateMipmapEXT(target: Int)
}

public const val GL_FRAMEBUFFER_EXT: Int = 36_160

public const val GL_RENDERBUFFER_EXT: Int = 36_161

public const val GL_STENCIL_INDEX1_EXT: Int = 36_166

public const val GL_STENCIL_INDEX4_EXT: Int = 36_167

public const val GL_STENCIL_INDEX8_EXT: Int = 36_168

public const val GL_STENCIL_INDEX16_EXT: Int = 36_169

public const val GL_RENDERBUFFER_WIDTH_EXT: Int = 36_162

public const val GL_RENDERBUFFER_HEIGHT_EXT: Int = 36_163

public const val GL_RENDERBUFFER_INTERNAL_FORMAT_EXT: Int = 36_164

public const val GL_RENDERBUFFER_RED_SIZE_EXT: Int = 36_176

public const val GL_RENDERBUFFER_GREEN_SIZE_EXT: Int = 36_177

public const val GL_RENDERBUFFER_BLUE_SIZE_EXT: Int = 36_178

public const val GL_RENDERBUFFER_ALPHA_SIZE_EXT: Int = 36_179

public const val GL_RENDERBUFFER_DEPTH_SIZE_EXT: Int = 36_180

public const val GL_RENDERBUFFER_STENCIL_SIZE_EXT: Int = 36_181

public const val GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE_EXT: Int = 36_048

public const val GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME_EXT: Int = 36_049

public const val GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL_EXT: Int = 36_050

public const val GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE_EXT: Int = 36_051

public const val GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_3D_ZOFFSET_EXT: Int = 36_052

public const val GL_COLOR_ATTACHMENT0_EXT: Int = 36_064

public const val GL_COLOR_ATTACHMENT1_EXT: Int = 36_065

public const val GL_COLOR_ATTACHMENT2_EXT: Int = 36_066

public const val GL_COLOR_ATTACHMENT3_EXT: Int = 36_067

public const val GL_COLOR_ATTACHMENT4_EXT: Int = 36_068

public const val GL_COLOR_ATTACHMENT5_EXT: Int = 36_069

public const val GL_COLOR_ATTACHMENT6_EXT: Int = 36_070

public const val GL_COLOR_ATTACHMENT7_EXT: Int = 36_071

public const val GL_COLOR_ATTACHMENT8_EXT: Int = 36_072

public const val GL_COLOR_ATTACHMENT9_EXT: Int = 36_073

public const val GL_COLOR_ATTACHMENT10_EXT: Int = 36_074

public const val GL_COLOR_ATTACHMENT11_EXT: Int = 36_075

public const val GL_COLOR_ATTACHMENT12_EXT: Int = 36_076

public const val GL_COLOR_ATTACHMENT13_EXT: Int = 36_077

public const val GL_COLOR_ATTACHMENT14_EXT: Int = 36_078

public const val GL_COLOR_ATTACHMENT15_EXT: Int = 36_079

public const val GL_DEPTH_ATTACHMENT_EXT: Int = 36_096

public const val GL_STENCIL_ATTACHMENT_EXT: Int = 36_128

public const val GL_FRAMEBUFFER_COMPLETE_EXT: Int = 36_053

public const val GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT: Int = 36_054

public const val GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT: Int = 36_055

public const val GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT: Int = 36_057

public const val GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT: Int = 36_058

public const val GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT: Int = 36_059

public const val GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT: Int = 36_060

public const val GL_FRAMEBUFFER_UNSUPPORTED_EXT: Int = 36_061

public const val GL_FRAMEBUFFER_BINDING_EXT: Int = 36_006

public const val GL_RENDERBUFFER_BINDING_EXT: Int = 36_007

public const val GL_MAX_COLOR_ATTACHMENTS_EXT: Int = 36_063

public const val GL_MAX_RENDERBUFFER_SIZE_EXT: Int = 34_024

public const val GL_INVALID_FRAMEBUFFER_OPERATION_EXT: Int = 1_286

public inline fun glIsRenderbufferEXT(renderbuffer: Int): Boolean =
        GLWrapper.instance.EXTFramebufferObject.glIsRenderbufferEXT(renderbuffer)

public inline fun glBindRenderbufferEXT(target: Int, renderbuffer: Int): Unit =
        GLWrapper.instance.EXTFramebufferObject.glBindRenderbufferEXT(target, renderbuffer)

public inline fun glDeleteRenderbuffersEXT(n: Int, renderbuffers: Ptr): Unit =
        GLWrapper.instance.EXTFramebufferObject.glDeleteRenderbuffersEXT(n, renderbuffers)

public inline fun glDeleteRenderbuffersEXT(n: Int, renderbuffers: Long): Unit =
        GLWrapper.instance.EXTFramebufferObject.glDeleteRenderbuffersEXT(n, renderbuffers)

public inline fun glGenRenderbuffersEXT(n: Int, renderbuffers: Ptr): Unit =
        GLWrapper.instance.EXTFramebufferObject.glGenRenderbuffersEXT(n, renderbuffers)

public inline fun glGenRenderbuffersEXT(n: Int, renderbuffers: Long): Unit =
        GLWrapper.instance.EXTFramebufferObject.glGenRenderbuffersEXT(n, renderbuffers)

public inline fun glRenderbufferStorageEXT(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
): Unit = GLWrapper.instance.EXTFramebufferObject.glRenderbufferStorageEXT(target, internalformat,
        width, height)

public inline fun glGetRenderbufferParameterivEXT(
    target: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTFramebufferObject.glGetRenderbufferParameterivEXT(target, pname,
        params)

public inline fun glGetRenderbufferParameterivEXT(
    target: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTFramebufferObject.glGetRenderbufferParameterivEXT(target, pname,
        params)

public inline fun glIsFramebufferEXT(framebuffer: Int): Boolean =
        GLWrapper.instance.EXTFramebufferObject.glIsFramebufferEXT(framebuffer)

public inline fun glBindFramebufferEXT(target: Int, framebuffer: Int): Unit =
        GLWrapper.instance.EXTFramebufferObject.glBindFramebufferEXT(target, framebuffer)

public inline fun glDeleteFramebuffersEXT(n: Int, framebuffers: Ptr): Unit =
        GLWrapper.instance.EXTFramebufferObject.glDeleteFramebuffersEXT(n, framebuffers)

public inline fun glDeleteFramebuffersEXT(n: Int, framebuffers: Long): Unit =
        GLWrapper.instance.EXTFramebufferObject.glDeleteFramebuffersEXT(n, framebuffers)

public inline fun glGenFramebuffersEXT(n: Int, framebuffers: Ptr): Unit =
        GLWrapper.instance.EXTFramebufferObject.glGenFramebuffersEXT(n, framebuffers)

public inline fun glGenFramebuffersEXT(n: Int, framebuffers: Long): Unit =
        GLWrapper.instance.EXTFramebufferObject.glGenFramebuffersEXT(n, framebuffers)

public inline fun glCheckFramebufferStatusEXT(target: Int): Int =
        GLWrapper.instance.EXTFramebufferObject.glCheckFramebufferStatusEXT(target)

public inline fun glFramebufferTexture1DEXT(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.EXTFramebufferObject.glFramebufferTexture1DEXT(target, attachment,
        textarget, texture, level)

public inline fun glFramebufferTexture2DEXT(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
): Unit = GLWrapper.instance.EXTFramebufferObject.glFramebufferTexture2DEXT(target, attachment,
        textarget, texture, level)

public inline fun glFramebufferTexture3DEXT(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
    zoffset: Int,
): Unit = GLWrapper.instance.EXTFramebufferObject.glFramebufferTexture3DEXT(target, attachment,
        textarget, texture, level, zoffset)

public inline fun glFramebufferRenderbufferEXT(
    target: Int,
    attachment: Int,
    renderbuffertarget: Int,
    renderbuffer: Int,
): Unit = GLWrapper.instance.EXTFramebufferObject.glFramebufferRenderbufferEXT(target, attachment,
        renderbuffertarget, renderbuffer)

public inline fun glGetFramebufferAttachmentParameterivEXT(
    target: Int,
    attachment: Int,
    pname: Int,
    params: Ptr,
): Unit = GLWrapper.instance.EXTFramebufferObject.glGetFramebufferAttachmentParameterivEXT(target,
        attachment, pname, params)

public inline fun glGetFramebufferAttachmentParameterivEXT(
    target: Int,
    attachment: Int,
    pname: Int,
    params: Long,
): Unit = GLWrapper.instance.EXTFramebufferObject.glGetFramebufferAttachmentParameterivEXT(target,
        attachment, pname, params)

public inline fun glGenerateMipmapEXT(target: Int): Unit =
        GLWrapper.instance.EXTFramebufferObject.glGenerateMipmapEXT(target)
