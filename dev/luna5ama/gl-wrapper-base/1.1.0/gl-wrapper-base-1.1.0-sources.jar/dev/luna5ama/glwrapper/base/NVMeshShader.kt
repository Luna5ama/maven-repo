@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Suppress
import kotlin.Unit

public interface NVMeshShader : GLBase {
    public fun glDrawMeshTasksNV(first: Int, count: Int)

    public fun glDrawMeshTasksIndirectNV(indirect: Long)

    public fun glMultiDrawMeshTasksIndirectNV(
        indirect: Long,
        drawcount: Int,
        stride: Int,
    )

    public fun glMultiDrawMeshTasksIndirectCountNV(
        indirect: Long,
        drawcount: Long,
        maxdrawcount: Int,
        stride: Int,
    )
}

public const val GL_MESH_SHADER_NV: Int = 38_233

public const val GL_TASK_SHADER_NV: Int = 38_234

public const val GL_MAX_MESH_UNIFORM_BLOCKS_NV: Int = 36_448

public const val GL_MAX_MESH_TEXTURE_IMAGE_UNITS_NV: Int = 36_449

public const val GL_MAX_MESH_IMAGE_UNIFORMS_NV: Int = 36_450

public const val GL_MAX_MESH_UNIFORM_COMPONENTS_NV: Int = 36_451

public const val GL_MAX_MESH_ATOMIC_COUNTER_BUFFERS_NV: Int = 36_452

public const val GL_MAX_MESH_ATOMIC_COUNTERS_NV: Int = 36_453

public const val GL_MAX_MESH_SHADER_STORAGE_BLOCKS_NV: Int = 36_454

public const val GL_MAX_COMBINED_MESH_UNIFORM_COMPONENTS_NV: Int = 36_455

public const val GL_MAX_TASK_UNIFORM_BLOCKS_NV: Int = 36_456

public const val GL_MAX_TASK_TEXTURE_IMAGE_UNITS_NV: Int = 36_457

public const val GL_MAX_TASK_IMAGE_UNIFORMS_NV: Int = 36_458

public const val GL_MAX_TASK_UNIFORM_COMPONENTS_NV: Int = 36_459

public const val GL_MAX_TASK_ATOMIC_COUNTER_BUFFERS_NV: Int = 36_460

public const val GL_MAX_TASK_ATOMIC_COUNTERS_NV: Int = 36_461

public const val GL_MAX_TASK_SHADER_STORAGE_BLOCKS_NV: Int = 36_462

public const val GL_MAX_COMBINED_TASK_UNIFORM_COMPONENTS_NV: Int = 36_463

public const val GL_MAX_MESH_WORK_GROUP_INVOCATIONS_NV: Int = 38_306

public const val GL_MAX_TASK_WORK_GROUP_INVOCATIONS_NV: Int = 38_307

public const val GL_MAX_MESH_TOTAL_MEMORY_SIZE_NV: Int = 38_198

public const val GL_MAX_TASK_TOTAL_MEMORY_SIZE_NV: Int = 38_199

public const val GL_MAX_MESH_OUTPUT_VERTICES_NV: Int = 38_200

public const val GL_MAX_MESH_OUTPUT_PRIMITIVES_NV: Int = 38_201

public const val GL_MAX_TASK_OUTPUT_COUNT_NV: Int = 38_202

public const val GL_MAX_DRAW_MESH_TASKS_COUNT_NV: Int = 38_205

public const val GL_MAX_MESH_VIEWS_NV: Int = 38_231

public const val GL_MESH_OUTPUT_PER_VERTEX_GRANULARITY_NV: Int = 37_599

public const val GL_MESH_OUTPUT_PER_PRIMITIVE_GRANULARITY_NV: Int = 38_211

public const val GL_MAX_MESH_WORK_GROUP_SIZE_NV: Int = 38_203

public const val GL_MAX_TASK_WORK_GROUP_SIZE_NV: Int = 38_204

public const val GL_MESH_WORK_GROUP_SIZE_NV: Int = 38_206

public const val GL_TASK_WORK_GROUP_SIZE_NV: Int = 38_207

public const val GL_MESH_VERTICES_OUT_NV: Int = 38_265

public const val GL_MESH_PRIMITIVES_OUT_NV: Int = 38_266

public const val GL_MESH_OUTPUT_TYPE_NV: Int = 38_267

public const val GL_UNIFORM_BLOCK_REFERENCED_BY_MESH_SHADER_NV: Int = 38_300

public const val GL_UNIFORM_BLOCK_REFERENCED_BY_TASK_SHADER_NV: Int = 38_301

public const val GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_MESH_SHADER_NV: Int = 38_302

public const val GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_TASK_SHADER_NV: Int = 38_303

public const val GL_REFERENCED_BY_MESH_SHADER_NV: Int = 38_304

public const val GL_REFERENCED_BY_TASK_SHADER_NV: Int = 38_305

public const val GL_MESH_SUBROUTINE_NV: Int = 38_268

public const val GL_TASK_SUBROUTINE_NV: Int = 38_269

public const val GL_MESH_SUBROUTINE_UNIFORM_NV: Int = 38_270

public const val GL_TASK_SUBROUTINE_UNIFORM_NV: Int = 38_271

public const val GL_MESH_SHADER_BIT_NV: Int = 64

public const val GL_TASK_SHADER_BIT_NV: Int = 128

public inline fun glDrawMeshTasksNV(first: Int, count: Int): Unit =
        GLWrapper.instance.NVMeshShader.glDrawMeshTasksNV(first, count)

public inline fun glDrawMeshTasksIndirectNV(indirect: Long): Unit =
        GLWrapper.instance.NVMeshShader.glDrawMeshTasksIndirectNV(indirect)

public inline fun glMultiDrawMeshTasksIndirectNV(
    indirect: Long,
    drawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.NVMeshShader.glMultiDrawMeshTasksIndirectNV(indirect, drawcount,
        stride)

public inline fun glMultiDrawMeshTasksIndirectCountNV(
    indirect: Long,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
): Unit = GLWrapper.instance.NVMeshShader.glMultiDrawMeshTasksIndirectCountNV(indirect, drawcount,
        maxdrawcount, stride)
