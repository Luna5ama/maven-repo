@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVCopyDepthToColor : GLBase

public const val GL_DEPTH_STENCIL_TO_RGBA_NV: Int = 34_926

public const val GL_DEPTH_STENCIL_TO_BGRA_NV: Int = 34_927
