@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface EXTABGR : GLBase

public const val GL_ABGR_EXT: Int = 32_768
