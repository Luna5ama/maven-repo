@file:Suppress(
    "NOTHING_TO_INLINE",
    "unused",
    "RedundantVisibilityModifier",
)

package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Suppress

public interface NVDepthClamp : GLBase

public const val GL_DEPTH_CLAMP_NV: Int = 34_383
