package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTDebugLabelLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTDebugLabel {
  override fun glGetObjectLabelEXT(
    type: Int,
    `object`: Int,
    bufSize: Int,
    length: Long,
    label: Long,
  ): Unit = org.lwjgl.opengl.EXTDebugLabel.nglGetObjectLabelEXT(type, `object`, bufSize, length,
      label)

  @PtrParameter([3])
  override fun glLabelObjectEXT(
    type: Int,
    `object`: Int,
    length: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDebugLabel.nglLabelObjectEXT(type, `object`, length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`.address)

  @PtrParameter([3, 4])
  override fun glGetObjectLabelEXT(
    type: Int,
    `object`: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDebugLabel.nglGetObjectLabelEXT(type, `object`, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`.address)

  override fun glLabelObjectEXT(
    type: Int,
    `object`: Int,
    length: Int,
    label: Long,
  ): Unit = org.lwjgl.opengl.EXTDebugLabel.nglLabelObjectEXT(type, `object`, length, label)
}
