package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTExternalBufferLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTExternalBuffer {
  override fun glNamedBufferStorageExternalEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    clientBuffer: Long,
    flags: Int,
  ): Unit = org.lwjgl.opengl.EXTExternalBuffer.nglNamedBufferStorageExternalEXT(buffer, offset,
      size, clientBuffer, flags)

  override fun glBufferStorageExternalEXT(
    target: Int,
    offset: Long,
    size: Long,
    clientBuffer: Long,
    flags: Int,
  ): Unit = org.lwjgl.opengl.EXTExternalBuffer.nglBufferStorageExternalEXT(target, offset, size,
      clientBuffer, flags)
}
