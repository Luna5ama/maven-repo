package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTProvokingVertexLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTProvokingVertex {
  override fun glProvokingVertexEXT(mode: Int): Unit =
      org.lwjgl.opengl.EXTProvokingVertex.glProvokingVertexEXT(mode)
}
