package dev.luna5ama.glwrapper.base

public class KHRBlendEquationAdvancedCoherentLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : KHRBlendEquationAdvancedCoherent
