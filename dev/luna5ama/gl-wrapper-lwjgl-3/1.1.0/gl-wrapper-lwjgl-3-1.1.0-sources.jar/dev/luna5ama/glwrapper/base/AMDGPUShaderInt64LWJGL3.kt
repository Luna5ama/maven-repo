package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class AMDGPUShaderInt64LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDGPUShaderInt64 {
  @PtrParameter([2])
  override fun glUniform2i64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform2i64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform1ui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform1ui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform2ui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform2ui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glGetUniformi64vNV(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglGetUniformi64vNV(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform1i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform1i64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform1i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform1i64vNV(program, location, count,
      `value`)

  @PtrParameter([2])
  override fun glUniform3ui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform3ui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform4ui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform4ui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glGetUniformui64vNV(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglGetUniformui64vNV(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glUniform4i64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform4i64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetUniformui64vNV(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglGetUniformui64vNV(program, location, params)

  @PtrParameter([3])
  override fun glProgramUniform2i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform2i64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform1i64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform1i64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform3i64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform3i64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform4i64vNV(program, location, count,
      `value`)

  override fun glProgramUniform3i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform3i64vNV(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform4ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform4ui64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform3ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform3ui64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform3ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform3ui64vNV(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform3i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform3i64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform1ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform1ui64vNV(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform2ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform2ui64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform2i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform2i64vNV(program, location, count,
      `value`)

  override fun glProgramUniform2ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform2ui64vNV(program, location, count,
      `value`)

  override fun glProgramUniform4ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform4ui64vNV(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform1ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform1ui64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform4i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglProgramUniform4i64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniform1i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform1i64vNV(location, count, `value`)

  override fun glUniform2i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform2i64vNV(location, count, `value`)

  override fun glUniform3i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform3i64vNV(location, count, `value`)

  override fun glGetUniformi64vNV(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglGetUniformi64vNV(program, location, params)

  override fun glUniform1ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform1ui64vNV(location, count, `value`)

  override fun glUniform3ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform3ui64vNV(location, count, `value`)

  override fun glUniform4i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform4i64vNV(location, count, `value`)

  override fun glUniform4ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform4ui64vNV(location, count, `value`)

  override fun glUniform2ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.AMDGPUShaderInt64.nglUniform2ui64vNV(location, count, `value`)
}
