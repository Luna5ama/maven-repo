package dev.luna5ama.glwrapper.base

public class NVShaderSubgroupPartitionedLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVShaderSubgroupPartitioned
