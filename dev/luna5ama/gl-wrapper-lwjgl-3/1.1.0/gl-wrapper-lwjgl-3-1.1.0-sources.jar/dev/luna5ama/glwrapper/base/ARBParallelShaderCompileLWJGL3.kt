package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class ARBParallelShaderCompileLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBParallelShaderCompile {
  override fun glMaxShaderCompilerThreadsARB(count: Int): Unit =
      org.lwjgl.opengl.ARBParallelShaderCompile.glMaxShaderCompilerThreadsARB(count)
}
