package dev.luna5ama.glwrapper.base

public class EXTTextureSRGBR8LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureSRGBR8
