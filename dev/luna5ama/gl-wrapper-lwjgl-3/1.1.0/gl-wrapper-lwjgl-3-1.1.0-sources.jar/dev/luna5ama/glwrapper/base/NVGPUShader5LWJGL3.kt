package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVGPUShader5LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVGPUShader5 {
  @PtrParameter([2])
  override fun glUniform2i64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform2i64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform1ui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform1ui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform2ui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform2ui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glGetUniformi64vNV(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglGetUniformi64vNV(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform1i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform1i64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform1i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform1i64vNV(program, location, count,
      `value`)

  @PtrParameter([2])
  override fun glUniform3ui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform3ui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform4ui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform4ui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glGetUniformui64vNV(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglGetUniformui64vNV(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glUniform4i64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform4i64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetUniformui64vNV(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglGetUniformui64vNV(program, location, params)

  @PtrParameter([3])
  override fun glProgramUniform2i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform2i64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform1i64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform1i64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform3i64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform3i64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform4i64vNV(program, location, count,
      `value`)

  override fun glProgramUniform3i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform3i64vNV(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform4ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform4ui64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform3ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform3ui64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform3ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform3ui64vNV(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform3i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform3i64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform1ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform1ui64vNV(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform2ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform2ui64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform2i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform2i64vNV(program, location, count,
      `value`)

  override fun glProgramUniform2ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform2ui64vNV(program, location, count,
      `value`)

  override fun glProgramUniform4ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform4ui64vNV(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform1ui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform1ui64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform4i64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglProgramUniform4i64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniform1i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform1i64vNV(location, count, `value`)

  override fun glUniform2i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform2i64vNV(location, count, `value`)

  override fun glUniform3i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform3i64vNV(location, count, `value`)

  override fun glGetUniformi64vNV(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglGetUniformi64vNV(program, location, params)

  override fun glUniform1ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform1ui64vNV(location, count, `value`)

  override fun glUniform3ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform3ui64vNV(location, count, `value`)

  override fun glUniform4i64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform4i64vNV(location, count, `value`)

  override fun glUniform4ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform4ui64vNV(location, count, `value`)

  override fun glUniform2ui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.nglUniform2ui64vNV(location, count, `value`)

  override fun glProgramUniform3ui64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glProgramUniform3ui64NV(program, location, x, y, z)

  override fun glProgramUniform4ui64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glProgramUniform4ui64NV(program, location, x, y, z, w)

  override fun glProgramUniform4i64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glProgramUniform4i64NV(program, location, x, y, z, w)

  override fun glProgramUniform2i64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glProgramUniform2i64NV(program, location, x, y)

  override fun glProgramUniform3i64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glProgramUniform3i64NV(program, location, x, y, z)

  override fun glProgramUniform1i64NV(
    program: Int,
    location: Int,
    x: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glProgramUniform1i64NV(program, location, x)

  override fun glProgramUniform2ui64NV(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glProgramUniform2ui64NV(program, location, x, y)

  override fun glProgramUniform1ui64NV(
    program: Int,
    location: Int,
    x: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glProgramUniform1ui64NV(program, location, x)

  override fun glUniform2ui64NV(
    location: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glUniform2ui64NV(location, x, y)

  override fun glUniform4ui64NV(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glUniform4ui64NV(location, x, y, z, w)

  override fun glUniform1ui64NV(location: Int, x: Long): Unit =
      org.lwjgl.opengl.NVGPUShader5.glUniform1ui64NV(location, x)

  override fun glUniform3i64NV(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glUniform3i64NV(location, x, y, z)

  override fun glUniform3ui64NV(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glUniform3ui64NV(location, x, y, z)

  override fun glUniform1i64NV(location: Int, x: Long): Unit =
      org.lwjgl.opengl.NVGPUShader5.glUniform1i64NV(location, x)

  override fun glUniform4i64NV(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glUniform4i64NV(location, x, y, z, w)

  override fun glUniform2i64NV(
    location: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.NVGPUShader5.glUniform2i64NV(location, x, y)
}
