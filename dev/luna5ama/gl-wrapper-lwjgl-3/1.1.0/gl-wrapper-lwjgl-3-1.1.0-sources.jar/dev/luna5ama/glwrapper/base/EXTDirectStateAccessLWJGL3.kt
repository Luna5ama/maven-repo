package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTDirectStateAccessLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTDirectStateAccess {
  @PtrParameter([3])
  override fun glGetNamedFramebufferAttachmentParameterivEXT(
    framebuffer: Int,
    attachment: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedFramebufferAttachmentParameterivEXT(framebuffer,
      attachment, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetMultiTexParameterfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexParameterfvEXT(texunit, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix4fvEXT(program, location,
      count, transpose, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix3x2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix3x2fvEXT(program, location,
      count, transpose, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glGetMultiTexLevelParameterfvEXT(
    texunit: Int,
    target: Int,
    level: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexLevelParameterfvEXT(texunit, target,
      level, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetNamedProgramLocalParameterfvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramLocalParameterfvEXT(program,
      target, index, params)

  @PtrParameter([9])
  override fun glCompressedTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureSubImage2DEXT(texture, target,
      level, xoffset, yoffset, width, height, format, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([3])
  override fun glGetCompressedTextureImageEXT(
    texture: Int,
    target: Int,
    level: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetCompressedTextureImageEXT(texture, target,
      level, `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`.address)

  @PtrParameter([7])
  override fun glCompressedMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexImage1DEXT(texunit, target,
      level, internalformat, width, border, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([2])
  override fun glGetNamedBufferParameterivEXT(
    buffer: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedBufferParameterivEXT(buffer, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix2x3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix2x3fvEXT(program, location,
      count, transpose, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([7])
  override fun glCompressedTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureImage1DEXT(texture, target,
      level, internalformat, width, border, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([11])
  override fun glCompressedTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureSubImage3DEXT(texture, target,
      level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix2x4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix2x4fvEXT(program, location,
      count, transpose, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix4x2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix4x2fvEXT(program, location,
      count, transpose, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix3x4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix3x4fvEXT(program, location,
      count, transpose, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glGetTextureLevelParameterivEXT(
    texture: Int,
    target: Int,
    level: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureLevelParameterivEXT(texture, target,
      level, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([4])
  override fun glGetMultiTexLevelParameterivEXT(
    texunit: Int,
    target: Int,
    level: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexLevelParameterivEXT(texunit, target,
      level, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([7])
  override fun glCompressedTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureSubImage1DEXT(texture, target,
      level, xoffset, width, format, imageSize, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([7])
  override fun glCompressedMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexSubImage1DEXT(texunit,
      target, level, xoffset, width, format, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([3])
  override fun glGetNamedProgramLocalParameterdvEXT(
    program: Int,
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramLocalParameterdvEXT(program,
      target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetCompressedMultiTexImageEXT(
    texunit: Int,
    target: Int,
    level: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetCompressedMultiTexImageEXT(texunit, target,
      level, `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix4x3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix4x3fvEXT(program, location,
      count, transpose, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glGetTextureParameterIivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureParameterIivEXT(texture, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([4])
  override fun glGetTextureLevelParameterfvEXT(
    texture: Int,
    target: Int,
    level: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureLevelParameterfvEXT(texture, target,
      level, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetNamedProgramLocalParameterfvEXT(
    program: Int,
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramLocalParameterfvEXT(program,
      target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glNamedProgramLocalParameter4dvEXT(
    program: Int,
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameter4dvEXT(program,
      target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glNamedProgramLocalParameter4fvEXT(
    program: Int,
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameter4fvEXT(program,
      target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([8])
  override fun glCompressedTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureImage2DEXT(texture, target,
      level, internalformat, width, height, border, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([8])
  override fun glCompressedMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexImage2DEXT(texunit, target,
      level, internalformat, width, height, border, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glGetNamedProgramLocalParameterdvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramLocalParameterdvEXT(program,
      target, index, params)

  @PtrParameter([9])
  override fun glCompressedMultiTexImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexImage3DEXT(texunit, target,
      level, internalformat, width, height, depth, border, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([11])
  override fun glCompressedMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexSubImage3DEXT(texunit,
      target, level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([9])
  override fun glCompressedMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexSubImage2DEXT(texunit,
      target, level, xoffset, yoffset, width, height, format, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([3])
  override fun glGetMultiTexParameterivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexParameterivEXT(texunit, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([9])
  override fun glCompressedTextureImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureImage3DEXT(texture, target,
      level, internalformat, width, height, depth, border, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix2fvEXT(program, location,
      count, transpose, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix3fvEXT(program, location,
      count, transpose, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glVertexArrayMultiTexCoordOffsetEXT(
    vaobj: Int,
    buffer: Int,
    texunit: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayMultiTexCoordOffsetEXT(vaobj, buffer,
      texunit, size, type, stride, offset)

  override fun glNamedProgramLocalParameterI4uivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameterI4uivEXT(program,
      target, index, params)

  @PtrParameter([3])
  override fun glGetMultiTexParameterIuivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexParameterIuivEXT(texunit, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetVertexArrayIntegervEXT(
    vaobj: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetVertexArrayIntegervEXT(vaobj, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrParameter([2])
  override fun glGetVertexArrayPointervEXT(
    vaobj: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetVertexArrayPointervEXT(vaobj, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrParameter([4])
  override fun glNamedProgramLocalParametersI4uivEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParametersI4uivEXT(program,
      target, index, count, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glNamedProgramLocalParameters4fvEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameters4fvEXT(program,
      target, index, count, params)

  @PtrParameter([3])
  override fun glNamedProgramLocalParameterI4ivEXT(
    program: Int,
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameterI4ivEXT(program,
      target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([4])
  override fun glNamedProgramLocalParametersI4ivEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParametersI4ivEXT(program,
      target, index, count, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetNamedProgramLocalParameterIuivEXT(
    program: Int,
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramLocalParameterIuivEXT(program,
      target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glVertexArrayVertexAttribIOffsetEXT(
    vaobj: Int,
    buffer: Int,
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayVertexAttribIOffsetEXT(vaobj, buffer,
      index, size, type, stride, offset)

  override fun glGetNamedRenderbufferParameterivEXT(
    renderbuffer: Int,
    pname: Int,
    params: Long,
  ): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedRenderbufferParameterivEXT(renderbuffer,
      pname, params)

  @PtrParameter([3])
  override fun glGetVertexArrayIntegeri_vEXT(
    vaobj: Int,
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetVertexArrayIntegeri_vEXT(vaobj, index,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  override fun glGetNamedProgramLocalParameterIivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramLocalParameterIivEXT(program,
      target, index, params)

  @PtrParameter([4])
  override fun glNamedProgramLocalParameters4fvEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameters4fvEXT(program,
      target, index, count, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetNamedRenderbufferParameterivEXT(
    renderbuffer: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedRenderbufferParameterivEXT(renderbuffer,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetVertexArrayPointeri_vEXT(
    vaobj: Int,
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetVertexArrayPointeri_vEXT(vaobj, index,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrParameter([2])
  override fun glFramebufferDrawBuffersEXT(
    framebuffer: Int,
    n: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-bufs$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglFramebufferDrawBuffersEXT(framebuffer, n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-bufs$0`.address)

  @PtrParameter([3])
  override fun glGetTextureParameterIuivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureParameterIuivEXT(texture, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glNamedProgramLocalParameterI4uiEXT(
    program: Int,
    target: Int,
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedProgramLocalParameterI4uiEXT(program,
      target, index, x, y, z, w)

  override fun glGetNamedFramebufferAttachmentParameterivEXT(
    framebuffer: Int,
    attachment: Int,
    pname: Int,
    params: Long,
  ): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedFramebufferAttachmentParameterivEXT(framebuffer,
      attachment, pname, params)

  @PtrParameter([3])
  override fun glNamedProgramLocalParameterI4uivEXT(
    program: Int,
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameterI4uivEXT(program,
      target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glNamedProgramLocalParametersI4uivEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParametersI4uivEXT(program,
      target, index, count, params)

  @PtrParameter([3])
  override fun glGetNamedProgramLocalParameterIivEXT(
    program: Int,
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramLocalParameterIivEXT(program,
      target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetNamedProgramLocalParameterIuivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramLocalParameterIuivEXT(program,
      target, index, params)

  @PtrParameter([3])
  override fun glGetMultiTexParameterIivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexParameterIivEXT(texunit, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glNamedRenderbufferStorageMultisampleEXT(
    renderbuffer: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glNamedRenderbufferStorageMultisampleEXT(renderbuffer,
      samples, internalformat, width, height)

  override fun glNamedProgramLocalParametersI4ivEXT(
    program: Int,
    target: Int,
    index: Int,
    count: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParametersI4ivEXT(program,
      target, index, count, params)

  override fun glNamedRenderbufferStorageMultisampleCoverageEXT(
    renderbuffer: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glNamedRenderbufferStorageMultisampleCoverageEXT(renderbuffer,
      coverageSamples, colorSamples, internalformat, width, height)

  @PtrParameter([2])
  override fun glGetFramebufferParameterivEXT(
    framebuffer: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetFramebufferParameterivEXT(framebuffer,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  override fun glVertexArraySecondaryColorOffsetEXT(
    vaobj: Int,
    buffer: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArraySecondaryColorOffsetEXT(vaobj,
      buffer, size, type, stride, offset)

  override fun glNamedProgramLocalParameterI4ivEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameterI4ivEXT(program,
      target, index, params)

  override fun glTextureParameterfEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glTextureParameterfEXT(texture, target, pname,
      `param`)

  override fun glMatrixTranslatefEXT(
    matrixMode: Int,
    x: Float,
    y: Float,
    z: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMatrixTranslatefEXT(matrixMode, x, y, z)

  @PtrParameter([1])
  override fun glMatrixMultdEXT(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixMultdEXT(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  override fun glClientAttribDefaultEXT(mask: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glClientAttribDefaultEXT(mask)

  @PtrParameter([1])
  override fun glMatrixLoadfEXT(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixLoadfEXT(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  override fun glPushClientAttribDefaultEXT(mask: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glPushClientAttribDefaultEXT(mask)

  @PtrParameter([1])
  override fun glMatrixLoaddEXT(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixLoaddEXT(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  @PtrParameter([1])
  override fun glMatrixMultfEXT(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixMultfEXT(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  override fun glMatrixLoadIdentityEXT(matrixMode: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glMatrixLoadIdentityEXT(matrixMode)

  override fun glMatrixTranslatedEXT(
    matrixMode: Int,
    x: Double,
    y: Double,
    z: Double,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMatrixTranslatedEXT(matrixMode, x, y, z)

  override fun glTextureParameteriEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glTextureParameteriEXT(texture, target, pname,
      `param`)

  @PtrParameter([3])
  override fun glTextureParameterivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureParameterivEXT(texture, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  override fun glTextureParameterivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureParameterivEXT(texture, target, pname,
      `param`)

  override fun glGetMultiTexGenfvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexGenfvEXT(texunit, coord, pname,
      params)

  override fun glGetMultiTexGenivEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexGenivEXT(texunit, coord, pname,
      params)

  override fun glCopyTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyTextureSubImage2DEXT(texture, target, level,
      xoffset, yoffset, x, y, width, height)

  override fun glMultiTexParameteriEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMultiTexParameteriEXT(texunit, target, pname,
      `param`)

  @PtrParameter([9])
  override fun glTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureImage2DEXT(texture, target, level,
      internalformat, width, height, border, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([10])
  override fun glTextureImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureImage3DEXT(texture, target, level,
      internalformat, width, height, depth, border, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureSubImage1DEXT(texture, target, level,
      xoffset, width, format, type, pixels)

  override fun glGetTextureLevelParameterfvEXT(
    texture: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureLevelParameterfvEXT(texture, target,
      level, pname, params)

  @PtrParameter([5])
  override fun glGetTextureImageEXT(
    texture: Int,
    target: Int,
    level: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureImageEXT(texture, target, level,
      format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([4])
  override fun glMultiTexCoordPointerEXT(
    texunit: Int,
    size: Int,
    type: Int,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexCoordPointerEXT(texunit, size, type,
      stride, `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  override fun glGetMultiTexEnvivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexEnvivEXT(texunit, target, pname,
      params)

  override fun glMultiTexParameterivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexParameterivEXT(texunit, target, pname,
      `param`)

  override fun glMultiTexParameterfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexParameterfvEXT(texunit, target, pname,
      `param`)

  override fun glGetMultiTexEnvfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexEnvfvEXT(texunit, target, pname,
      params)

  override fun glMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexImage1DEXT(texunit, target, level,
      internalformat, width, border, format, type, pixels)

  @PtrParameter([9])
  override fun glMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexImage2DEXT(texunit, target, level,
      internalformat, width, height, border, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexSubImage1DEXT(texunit, target, level,
      xoffset, width, format, type, pixels)

  override fun glMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexSubImage2DEXT(texunit, target, level,
      xoffset, yoffset, width, height, format, type, pixels)

  @PtrParameter([9])
  override fun glTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureSubImage2DEXT(texture, target, level,
      xoffset, yoffset, width, height, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureImage1DEXT(texture, target, level,
      internalformat, width, border, format, type, pixels)

  override fun glBindMultiTextureEXT(
    texunit: Int,
    target: Int,
    texture: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glBindMultiTextureEXT(texunit, target, texture)

  override fun glMultiTexCoordPointerEXT(
    texunit: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexCoordPointerEXT(texunit, size, type,
      stride, pointer)

  @PtrParameter([8])
  override fun glTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureImage1DEXT(texture, target, level,
      internalformat, width, border, format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([7])
  override fun glMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexSubImage1DEXT(texunit, target, level,
      xoffset, width, format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glCopyMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    border: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyMultiTexImage1DEXT(texunit, target, level,
      internalformat, x, y, width, border)

  override fun glCopyMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    x: Int,
    y: Int,
    width: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyMultiTexSubImage1DEXT(texunit, target,
      level, xoffset, x, y, width)

  override fun glGetTextureLevelParameterivEXT(
    texture: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureLevelParameterivEXT(texture, target,
      level, pname, params)

  override fun glCopyMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyMultiTexSubImage2DEXT(texunit, target,
      level, xoffset, yoffset, x, y, width, height)

  @PtrParameter([5])
  override fun glGetMultiTexImageEXT(
    texunit: Int,
    target: Int,
    level: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexImageEXT(texunit, target, level,
      format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glCopyTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    border: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyTextureImage2DEXT(texture, target, level,
      internalformat, x, y, width, height, border)

  override fun glGetTextureParameterivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureParameterivEXT(texture, target,
      pname, params)

  @PtrParameter([3])
  override fun glMultiTexGendvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexGendvEXT(texunit, coord, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glMultiTexParameterfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexParameterfvEXT(texunit, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  override fun glGetTextureImageEXT(
    texture: Int,
    target: Int,
    level: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureImageEXT(texture, target, level,
      format, type, pixels)

  @PtrParameter([3])
  override fun glGetTextureParameterfvEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureParameterfvEXT(texture, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetTextureParameterivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureParameterivEXT(texture, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([8])
  override fun glMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexImage1DEXT(texunit, target, level,
      internalformat, width, border, format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([3])
  override fun glGetMultiTexGenfvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexGenfvEXT(texunit, coord, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetTextureParameterfvEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureParameterfvEXT(texture, target,
      pname, params)

  @PtrParameter([3])
  override fun glMultiTexGenivEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexGenivEXT(texunit, coord, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetMultiTexGenivEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexGenivEXT(texunit, coord, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glMultiTexParameterivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexParameterivEXT(texunit, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrParameter([9])
  override fun glMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexSubImage2DEXT(texunit, target, level,
      xoffset, yoffset, width, height, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureImage2DEXT(texture, target, level,
      internalformat, width, height, border, format, type, pixels)

  override fun glCopyTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    x: Int,
    y: Int,
    width: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyTextureSubImage1DEXT(texture, target, level,
      xoffset, x, y, width)

  override fun glCopyMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    border: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyMultiTexImage2DEXT(texunit, target, level,
      internalformat, x, y, width, height, border)

  override fun glTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureSubImage3DEXT(texture, target, level,
      xoffset, yoffset, zoffset, width, height, depth, format, type, pixels)

  @PtrParameter([3])
  override fun glGetMultiTexGendvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexGendvEXT(texunit, coord, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glMultiTexParameterfEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMultiTexParameterfEXT(texunit, target, pname,
      `param`)

  override fun glMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexImage2DEXT(texunit, target, level,
      internalformat, width, height, border, format, type, pixels)

  @PtrParameter([3])
  override fun glGetMultiTexEnvfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexEnvfvEXT(texunit, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glTextureParameterfvEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureParameterfvEXT(texture, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrParameter([7])
  override fun glTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureSubImage1DEXT(texture, target, level,
      xoffset, width, format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureSubImage2DEXT(texture, target, level,
      xoffset, yoffset, width, height, format, type, pixels)

  override fun glCopyTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    border: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyTextureImage1DEXT(texture, target, level,
      internalformat, x, y, width, border)

  override fun glTextureImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureImage3DEXT(texture, target, level,
      internalformat, width, height, depth, border, format, type, pixels)

  @PtrParameter([3])
  override fun glMultiTexEnvfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexEnvfvEXT(texunit, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glCopyTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyTextureSubImage3DEXT(texture, target, level,
      xoffset, yoffset, zoffset, x, y, width, height)

  @PtrParameter([3])
  override fun glMultiTexEnvivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexEnvivEXT(texunit, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glMultiTexGenfvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexGenfvEXT(texunit, coord, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetMultiTexEnvivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexEnvivEXT(texunit, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetMultiTexGendvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexGendvEXT(texunit, coord, pname,
      params)

  override fun glTextureParameterfvEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `param`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureParameterfvEXT(texture, target, pname,
      `param`)

  @PtrParameter([11])
  override fun glTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureSubImage3DEXT(texture, target, level,
      xoffset, yoffset, zoffset, width, height, depth, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glGetBooleanIndexedvEXT(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetBooleanIndexedvEXT(target, index, `data`)

  @PtrParameter([3])
  override fun glNamedBufferSubDataEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedBufferSubDataEXT(buffer, offset, size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrReturn
  override fun glMapNamedBufferEXT(buffer: Int, access: Int): Ptr =
      Ptr(org.lwjgl.opengl.EXTDirectStateAccess.nglMapNamedBufferEXT(buffer, access))

  override fun glNamedProgramLocalParameter4dEXT(
    program: Int,
    target: Int,
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedProgramLocalParameter4dEXT(program, target,
      index, x, y, z, w)

  override fun glMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexSubImage3DEXT(texunit, target, level,
      xoffset, yoffset, zoffset, width, height, depth, format, type, pixels)

  override fun glGetMultiTexLevelParameterivEXT(
    texunit: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexLevelParameterivEXT(texunit, target,
      level, pname, params)

  override fun glCompressedTextureImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureImage3DEXT(texture, target,
      level, internalformat, width, height, depth, border, imageSize, `data`)

  @PtrParameter([2])
  override fun glGetFloatIndexedvEXT(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetFloatIndexedvEXT(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetCompressedMultiTexImageEXT(
    texunit: Int,
    target: Int,
    level: Int,
    img: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetCompressedMultiTexImageEXT(texunit, target,
      level, img)

  override fun glMatrixLoadTransposedEXT(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixLoadTransposedEXT(matrixMode, m)

  override fun glCompressedTextureImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureImage2DEXT(texture, target,
      level, internalformat, width, height, border, imageSize, `data`)

  override fun glCompressedTextureImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureImage1DEXT(texture, target,
      level, internalformat, width, border, imageSize, `data`)

  @PtrParameter([11])
  override fun glMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexSubImage3DEXT(texunit, target, level,
      xoffset, yoffset, zoffset, width, height, depth, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glCopyMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glCopyMultiTexSubImage3DEXT(texunit, target,
      level, xoffset, yoffset, zoffset, x, y, width, height)

  override fun glNamedProgramLocalParameter4fvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameter4fvEXT(program,
      target, index, params)

  override fun glCompressedTextureSubImage1DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureSubImage1DEXT(texture, target,
      level, xoffset, width, format, imageSize, `data`)

  @PtrParameter([4])
  override fun glNamedProgramStringEXT(
    program: Int,
    target: Int,
    format: Int,
    len: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramStringEXT(program, target, format,
      len, `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`.address)

  override fun glGetCompressedTextureImageEXT(
    texture: Int,
    target: Int,
    level: Int,
    img: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetCompressedTextureImageEXT(texture, target,
      level, img)

  override fun glGetNamedProgramivEXT(
    program: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramivEXT(program, target, pname,
      params)

  @PtrParameter([1])
  override fun glMatrixLoadTransposefEXT(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixLoadTransposefEXT(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  @PtrParameter([1])
  override fun glMatrixMultTransposedEXT(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixMultTransposedEXT(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  override fun glGetMultiTexImageEXT(
    texunit: Int,
    target: Int,
    level: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexImageEXT(texunit, target, level,
      format, type, pixels)

  override fun glGetMultiTexLevelParameterfvEXT(
    texunit: Int,
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexLevelParameterfvEXT(texunit, target,
      level, pname, params)

  override fun glGetMultiTexParameterfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexParameterfvEXT(texunit, target,
      pname, params)

  @PtrParameter([2])
  override fun glGetBooleanIndexedvEXT(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetBooleanIndexedvEXT(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glDisableClientStateIndexedEXT(array: Int, index: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glDisableClientStateIndexedEXT(array, index)

  override fun glCompressedMultiTexImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexImage3DEXT(texunit, target,
      level, internalformat, width, height, depth, border, imageSize, `data`)

  @PtrParameter([2])
  override fun glGetDoublei_vEXT(
    pname: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetDoublei_vEXT(pname, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glCompressedTextureSubImage3DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureSubImage3DEXT(texture, target,
      level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize, `data`)

  override fun glMatrixMultTransposedEXT(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixMultTransposedEXT(matrixMode, m)

  @PtrParameter([2])
  override fun glNamedBufferDataEXT(
    buffer: Int,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
    usage: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedBufferDataEXT(buffer, size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address, usage)

  override fun glNamedProgramLocalParameter4dvEXT(
    program: Int,
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramLocalParameter4dvEXT(program,
      target, index, params)

  override fun glMultiTexImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexImage3DEXT(texunit, target, level,
      internalformat, width, height, depth, border, format, type, pixels)

  @PtrParameter([2])
  override fun glGetFloati_vEXT(
    pname: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetFloati_vEXT(pname, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glCompressedMultiTexSubImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexSubImage1DEXT(texunit,
      target, level, xoffset, width, format, imageSize, `data`)

  override fun glDisableClientStateiEXT(array: Int, index: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glDisableClientStateiEXT(array, index)

  override fun glGetFloatIndexedvEXT(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetFloatIndexedvEXT(target, index, params)

  override fun glCompressedMultiTexImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexImage2DEXT(texunit, target,
      level, internalformat, width, height, border, imageSize, `data`)

  override fun glCompressedMultiTexImage1DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexImage1DEXT(texunit, target,
      level, internalformat, width, border, imageSize, `data`)

  @PtrParameter([1])
  override fun glMatrixLoadTransposedEXT(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixLoadTransposedEXT(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  @PtrParameter([3])
  override fun glGetNamedProgramivEXT(
    program: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramivEXT(program, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetNamedProgramStringEXT(
    program: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramStringEXT(program, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`.address)

  override fun glEnableClientStateiEXT(array: Int, index: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glEnableClientStateiEXT(array, index)

  override fun glGetDoubleIndexedvEXT(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetDoubleIndexedvEXT(target, index, params)

  @PtrParameter([2])
  override fun glGetDoubleIndexedvEXT(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetDoubleIndexedvEXT(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetPointerIndexedvEXT(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetPointerIndexedvEXT(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetPointeri_vEXT(
    pname: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetPointeri_vEXT(pname, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glCompressedMultiTexSubImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexSubImage3DEXT(texunit,
      target, level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize, `data`)

  override fun glGetPointerIndexedvEXT(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetPointerIndexedvEXT(target, index, params)

  override fun glGetMultiTexParameterivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexParameterivEXT(texunit, target,
      pname, params)

  override fun glGetIntegerIndexedvEXT(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetIntegerIndexedvEXT(target, index, `data`)

  override fun glNamedProgramStringEXT(
    program: Int,
    target: Int,
    format: Int,
    len: Int,
    string: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedProgramStringEXT(program, target, format,
      len, string)

  override fun glEnableClientStateIndexedEXT(array: Int, index: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glEnableClientStateIndexedEXT(array, index)

  override fun glCompressedMultiTexSubImage2DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedMultiTexSubImage2DEXT(texunit,
      target, level, xoffset, yoffset, width, height, format, imageSize, `data`)

  @PtrParameter([2])
  override fun glGetIntegerIndexedvEXT(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetIntegerIndexedvEXT(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glGetNamedProgramStringEXT(
    program: Int,
    target: Int,
    pname: Int,
    string: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedProgramStringEXT(program, target,
      pname, string)

  override fun glMatrixLoadTransposefEXT(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixLoadTransposefEXT(matrixMode, m)

  override fun glNamedProgramLocalParameter4fEXT(
    program: Int,
    target: Int,
    index: Int,
    x: Float,
    y: Float,
    z: Float,
    w: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedProgramLocalParameter4fEXT(program, target,
      index, x, y, z, w)

  @PtrParameter([1])
  override fun glMatrixMultTransposefEXT(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixMultTransposefEXT(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  override fun glMatrixMultTransposefEXT(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixMultTransposefEXT(matrixMode, m)

  override fun glNamedBufferDataEXT(
    buffer: Int,
    size: Long,
    `data`: Long,
    usage: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedBufferDataEXT(buffer, size, `data`, usage)

  override fun glNamedBufferSubDataEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglNamedBufferSubDataEXT(buffer, offset, size,
      `data`)

  @PtrParameter([10])
  override fun glMultiTexImage3DEXT(
    texunit: Int,
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexImage3DEXT(texunit, target, level,
      internalformat, width, height, depth, border, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glCompressedTextureSubImage2DEXT(
    texture: Int,
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglCompressedTextureSubImage2DEXT(texture, target,
      level, xoffset, yoffset, width, height, format, imageSize, `data`)

  override fun glProgramUniform1ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform1ivEXT(program, location, count,
      `value`)

  override fun glProgramUniform2fEXT(
    program: Int,
    location: Int,
    v0: Float,
    v1: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform2fEXT(program, location, v0, v1)

  override fun glProgramUniform3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform3fvEXT(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform4fvEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform3ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform3ivEXT(program, location, count,
      `value`)

  override fun glProgramUniform3iEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform3iEXT(program, location, v0, v1,
      v2)

  override fun glProgramUniformMatrix4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix4fvEXT(program, location,
      count, transpose, `value`)

  override fun glProgramUniformMatrix4x3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix4x3fvEXT(program, location,
      count, transpose, `value`)

  override fun glMultiTexBufferEXT(
    texunit: Int,
    target: Int,
    internalformat: Int,
    buffer: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMultiTexBufferEXT(texunit, target,
      internalformat, buffer)

  override fun glProgramUniform1fEXT(
    program: Int,
    location: Int,
    v0: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform1fEXT(program, location, v0)

  override fun glUnmapNamedBufferEXT(buffer: Int): Boolean =
      org.lwjgl.opengl.EXTDirectStateAccess.glUnmapNamedBufferEXT(buffer)

  override fun glProgramUniformMatrix2x4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix2x4fvEXT(program, location,
      count, transpose, `value`)

  @PtrParameter([3])
  override fun glGetNamedBufferSubDataEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedBufferSubDataEXT(buffer, offset, size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([3])
  override fun glTextureParameterIivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureParameterIivEXT(texture, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glProgramUniform2iEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform2iEXT(program, location, v0, v1)

  override fun glProgramUniform2ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform2ivEXT(program, location, count,
      `value`)

  override fun glProgramUniform1fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform1fvEXT(program, location, count,
      `value`)

  override fun glGetNamedBufferSubDataEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedBufferSubDataEXT(buffer, offset, size,
      `data`)

  @PtrParameter([3])
  override fun glProgramUniform2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform2fvEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetNamedBufferParameterivEXT(
    buffer: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetNamedBufferParameterivEXT(buffer, pname,
      params)

  @PtrParameter([3])
  override fun glProgramUniform1fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform1fvEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform4fvEXT(program, location, count,
      `value`)

  override fun glProgramUniform4iEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform4iEXT(program, location, v0, v1,
      v2, v3)

  override fun glProgramUniform2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform2fvEXT(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform2ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform2ivEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform3fvEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform3ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform3ivEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4fEXT(
    program: Int,
    location: Int,
    v0: Float,
    v1: Float,
    v2: Float,
    v3: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform4fEXT(program, location, v0, v1,
      v2, v3)

  @PtrParameter([3])
  override fun glProgramUniform4ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform4ivEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform1iEXT(
    program: Int,
    location: Int,
    v0: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform1iEXT(program, location, v0)

  override fun glProgramUniform4ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform4ivEXT(program, location, count,
      `value`)

  override fun glProgramUniformMatrix2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix2fvEXT(program, location,
      count, transpose, `value`)

  override fun glProgramUniformMatrix3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix3fvEXT(program, location,
      count, transpose, `value`)

  override fun glProgramUniformMatrix2x3fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix2x3fvEXT(program, location,
      count, transpose, `value`)

  override fun glProgramUniform3fEXT(
    program: Int,
    location: Int,
    v0: Float,
    v1: Float,
    v2: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform3fEXT(program, location, v0, v1,
      v2)

  @PtrParameter([3])
  override fun glProgramUniform1ivEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform1ivEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniformMatrix3x2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix3x2fvEXT(program, location,
      count, transpose, `value`)

  override fun glProgramUniformMatrix4x2fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix4x2fvEXT(program, location,
      count, transpose, `value`)

  override fun glProgramUniformMatrix3x4fvEXT(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniformMatrix3x4fvEXT(program, location,
      count, transpose, `value`)

  override fun glTextureBufferEXT(
    texture: Int,
    target: Int,
    internalformat: Int,
    buffer: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glTextureBufferEXT(texture, target,
      internalformat, buffer)

  override fun glGetDoublei_vEXT(
    pname: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetDoublei_vEXT(pname, index, params)

  override fun glGetPointeri_vEXT(
    pname: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetPointeri_vEXT(pname, index, params)

  override fun glGetFloati_vEXT(
    pname: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetFloati_vEXT(pname, index, params)

  override fun glMatrixRotatedEXT(
    matrixMode: Int,
    angle: Double,
    x: Double,
    y: Double,
    z: Double,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMatrixRotatedEXT(matrixMode, angle, x, y, z)

  override fun glMatrixScaledEXT(
    matrixMode: Int,
    x: Double,
    y: Double,
    z: Double,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMatrixScaledEXT(matrixMode, x, y, z)

  override fun glMatrixPopEXT(matrixMode: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glMatrixPopEXT(matrixMode)

  override fun glMatrixOrthoEXT(
    matrixMode: Int,
    l: Double,
    r: Double,
    b: Double,
    t: Double,
    n: Double,
    f: Double,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMatrixOrthoEXT(matrixMode, l, r, b, t, n, f)

  override fun glMatrixLoaddEXT(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixLoaddEXT(matrixMode, m)

  override fun glMatrixMultdEXT(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixMultdEXT(matrixMode, m)

  override fun glMatrixRotatefEXT(
    matrixMode: Int,
    angle: Float,
    x: Float,
    y: Float,
    z: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMatrixRotatefEXT(matrixMode, angle, x, y, z)

  override fun glMatrixMultfEXT(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixMultfEXT(matrixMode, m)

  override fun glMatrixLoadfEXT(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.nglMatrixLoadfEXT(matrixMode, m)

  override fun glMatrixScalefEXT(
    matrixMode: Int,
    x: Float,
    y: Float,
    z: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMatrixScalefEXT(matrixMode, x, y, z)

  override fun glMatrixFrustumEXT(
    matrixMode: Int,
    l: Double,
    r: Double,
    b: Double,
    t: Double,
    n: Double,
    f: Double,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMatrixFrustumEXT(matrixMode, l, r, b, t, n, f)

  override fun glMatrixPushEXT(matrixMode: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glMatrixPushEXT(matrixMode)

  override fun glMultiTexGendvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexGendvEXT(texunit, coord, pname, params)

  override fun glMultiTexEnvfvEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexEnvfvEXT(texunit, target, pname,
      params)

  override fun glMultiTexEnviEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMultiTexEnviEXT(texunit, target, pname, `param`)

  override fun glMultiTexGendEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `param`: Double,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMultiTexGendEXT(texunit, coord, pname, `param`)

  override fun glMultiTexEnvfEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `param`: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMultiTexEnvfEXT(texunit, target, pname, `param`)

  override fun glMultiTexEnvivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexEnvivEXT(texunit, target, pname,
      params)

  override fun glMultiTexGeniEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `param`: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMultiTexGeniEXT(texunit, coord, pname, `param`)

  override fun glMultiTexGenfEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    `param`: Float,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMultiTexGenfEXT(texunit, coord, pname, `param`)

  override fun glMultiTexGenivEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexGenivEXT(texunit, coord, pname, params)

  override fun glMultiTexGenfvEXT(
    texunit: Int,
    coord: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexGenfvEXT(texunit, coord, pname, params)

  override fun glGenerateMultiTexMipmapEXT(texunit: Int, target: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glGenerateMultiTexMipmapEXT(texunit, target)

  override fun glNamedCopyBufferSubDataEXT(
    readBuffer: Int,
    writeBuffer: Int,
    readOffset: Long,
    writeOffset: Long,
    size: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedCopyBufferSubDataEXT(readBuffer,
      writeBuffer, readOffset, writeOffset, size)

  override fun glEnableVertexArrayAttribEXT(vaobj: Int, index: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glEnableVertexArrayAttribEXT(vaobj, index)

  override fun glGetVertexArrayPointervEXT(
    vaobj: Int,
    pname: Int,
    `param`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetVertexArrayPointervEXT(vaobj, pname,
      `param`)

  @PtrParameter([3])
  override fun glProgramUniform4uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform4uivEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glDisableVertexArrayEXT(vaobj: Int, array: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glDisableVertexArrayEXT(vaobj, array)

  override fun glGetVertexArrayIntegervEXT(
    vaobj: Int,
    pname: Int,
    `param`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetVertexArrayIntegervEXT(vaobj, pname,
      `param`)

  override fun glGetTextureParameterIivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureParameterIivEXT(texture, target,
      pname, params)

  override fun glNamedFramebufferTexture3DEXT(
    framebuffer: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
    zoffset: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedFramebufferTexture3DEXT(framebuffer,
      attachment, textarget, texture, level, zoffset)

  override fun glGetVertexArrayIntegeri_vEXT(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetVertexArrayIntegeri_vEXT(vaobj, index,
      pname, `param`)

  override fun glGetVertexArrayPointeri_vEXT(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetVertexArrayPointeri_vEXT(vaobj, index,
      pname, `param`)

  @PtrReturn
  override fun glMapNamedBufferRangeEXT(
    buffer: Int,
    offset: Long,
    length: Long,
    access: Int,
  ): Ptr = Ptr(org.lwjgl.opengl.EXTDirectStateAccess.nglMapNamedBufferRangeEXT(buffer, offset,
      length, access))

  override fun glFlushMappedNamedBufferRangeEXT(
    buffer: Int,
    offset: Long,
    length: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glFlushMappedNamedBufferRangeEXT(buffer, offset,
      length)

  override fun glProgramUniform2uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform2uivEXT(program, location, count,
      `value`)

  override fun glTextureRenderbufferEXT(
    texture: Int,
    target: Int,
    renderbuffer: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glTextureRenderbufferEXT(texture, target,
      renderbuffer)

  @PtrParameter([3])
  override fun glProgramUniform2uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform2uivEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glNamedProgramLocalParameterI4iEXT(
    program: Int,
    target: Int,
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedProgramLocalParameterI4iEXT(program,
      target, index, x, y, z, w)

  override fun glNamedFramebufferTexture2DEXT(
    framebuffer: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedFramebufferTexture2DEXT(framebuffer,
      attachment, textarget, texture, level)

  override fun glNamedFramebufferTextureFaceEXT(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    face: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedFramebufferTextureFaceEXT(framebuffer,
      attachment, texture, level, face)

  override fun glVertexArrayIndexOffsetEXT(
    vaobj: Int,
    buffer: Int,
    type: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayIndexOffsetEXT(vaobj, buffer, type,
      stride, offset)

  override fun glVertexArrayNormalOffsetEXT(
    vaobj: Int,
    buffer: Int,
    type: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayNormalOffsetEXT(vaobj, buffer, type,
      stride, offset)

  override fun glVertexArrayTexCoordOffsetEXT(
    vaobj: Int,
    buffer: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayTexCoordOffsetEXT(vaobj, buffer,
      size, type, stride, offset)

  override fun glVertexArrayFogCoordOffsetEXT(
    vaobj: Int,
    buffer: Int,
    type: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayFogCoordOffsetEXT(vaobj, buffer,
      type, stride, offset)

  override fun glCheckNamedFramebufferStatusEXT(framebuffer: Int, target: Int): Int =
      org.lwjgl.opengl.EXTDirectStateAccess.glCheckNamedFramebufferStatusEXT(framebuffer, target)

  override fun glEnableVertexArrayEXT(vaobj: Int, array: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glEnableVertexArrayEXT(vaobj, array)

  override fun glProgramUniform1uiEXT(
    program: Int,
    location: Int,
    v0: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform1uiEXT(program, location, v0)

  override fun glNamedRenderbufferStorageEXT(
    renderbuffer: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedRenderbufferStorageEXT(renderbuffer,
      internalformat, width, height)

  override fun glFramebufferReadBufferEXT(framebuffer: Int, mode: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glFramebufferReadBufferEXT(framebuffer, mode)

  override fun glProgramUniform3uiEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform3uiEXT(program, location, v0, v1,
      v2)

  override fun glProgramUniform4uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform4uivEXT(program, location, count,
      `value`)

  override fun glGetFramebufferParameterivEXT(
    framebuffer: Int,
    pname: Int,
    `param`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetFramebufferParameterivEXT(framebuffer,
      pname, `param`)

  override fun glVertexArrayColorOffsetEXT(
    vaobj: Int,
    buffer: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayColorOffsetEXT(vaobj, buffer, size,
      type, stride, offset)

  @PtrParameter([3])
  override fun glMultiTexParameterIivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexParameterIivEXT(texunit, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform3uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform3uivEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glMultiTexRenderbufferEXT(
    texunit: Int,
    target: Int,
    renderbuffer: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glMultiTexRenderbufferEXT(texunit, target,
      renderbuffer)

  override fun glTextureParameterIuivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureParameterIuivEXT(texture, target, pname,
      params)

  @PtrParameter([3])
  override fun glMultiTexParameterIuivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexParameterIuivEXT(texunit, target,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetMultiTexParameterIivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexParameterIivEXT(texunit, target,
      pname, params)

  override fun glGenerateTextureMipmapEXT(texture: Int, target: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glGenerateTextureMipmapEXT(texture, target)

  override fun glVertexArrayEdgeFlagOffsetEXT(
    vaobj: Int,
    buffer: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayEdgeFlagOffsetEXT(vaobj, buffer,
      stride, offset)

  override fun glDisableVertexArrayAttribEXT(vaobj: Int, index: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glDisableVertexArrayAttribEXT(vaobj, index)

  override fun glProgramUniform1uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform1uivEXT(program, location, count,
      `value`)

  override fun glGetMultiTexParameterIuivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetMultiTexParameterIuivEXT(texunit, target,
      pname, params)

  override fun glProgramUniform3uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform3uivEXT(program, location, count,
      `value`)

  override fun glNamedFramebufferRenderbufferEXT(
    framebuffer: Int,
    attachment: Int,
    renderbuffertarget: Int,
    renderbuffer: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedFramebufferRenderbufferEXT(framebuffer,
      attachment, renderbuffertarget, renderbuffer)

  override fun glFramebufferDrawBuffersEXT(
    framebuffer: Int,
    n: Int,
    bufs: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglFramebufferDrawBuffersEXT(framebuffer, n, bufs)

  override fun glMultiTexParameterIivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexParameterIivEXT(texunit, target, pname,
      params)

  @PtrParameter([3])
  override fun glProgramUniform1uivEXT(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglProgramUniform1uivEXT(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glNamedFramebufferTextureEXT(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedFramebufferTextureEXT(framebuffer,
      attachment, texture, level)

  override fun glNamedFramebufferTextureLayerEXT(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    layer: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedFramebufferTextureLayerEXT(framebuffer,
      attachment, texture, level, layer)

  override fun glGetTextureParameterIuivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglGetTextureParameterIuivEXT(texture, target,
      pname, params)

  override fun glFramebufferDrawBufferEXT(framebuffer: Int, mode: Int): Unit =
      org.lwjgl.opengl.EXTDirectStateAccess.glFramebufferDrawBufferEXT(framebuffer, mode)

  override fun glProgramUniform2uiEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform2uiEXT(program, location, v0, v1)

  override fun glVertexArrayVertexOffsetEXT(
    vaobj: Int,
    buffer: Int,
    size: Int,
    type: Int,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayVertexOffsetEXT(vaobj, buffer, size,
      type, stride, offset)

  @PtrParameter([3])
  override fun glTextureParameterIuivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureParameterIuivEXT(texture, target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glNamedFramebufferTexture1DEXT(
    framebuffer: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glNamedFramebufferTexture1DEXT(framebuffer,
      attachment, textarget, texture, level)

  override fun glVertexArrayVertexAttribOffsetEXT(
    vaobj: Int,
    buffer: Int,
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glVertexArrayVertexAttribOffsetEXT(vaobj, buffer,
      index, size, type, normalized, stride, offset)

  override fun glProgramUniform4uiEXT(
    program: Int,
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.glProgramUniform4uiEXT(program, location, v0, v1,
      v2, v3)

  override fun glMultiTexParameterIuivEXT(
    texunit: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglMultiTexParameterIuivEXT(texunit, target,
      pname, params)

  override fun glTextureParameterIivEXT(
    texture: Int,
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTDirectStateAccess.nglTextureParameterIivEXT(texture, target, pname,
      params)
}
