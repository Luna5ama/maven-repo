package dev.luna5ama.glwrapper.base

public class EXTFramebufferMultisampleBlitScaledLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTFramebufferMultisampleBlitScaled
