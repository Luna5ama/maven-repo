package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTMemoryObjectWin32LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTMemoryObjectWin32 {
  @PtrParameter([3])
  override fun glImportMemoryWin32HandleEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-handle$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTMemoryObjectWin32.nglImportMemoryWin32HandleEXT(memory, size,
      handleType, `$v$c$dev-luna5ama-kmogus-Ptr$-handle$0`.address)

  override fun glImportMemoryWin32NameEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    name: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObjectWin32.nglImportMemoryWin32NameEXT(memory, size,
      handleType, name)

  @PtrParameter([3])
  override fun glImportMemoryWin32NameEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTMemoryObjectWin32.nglImportMemoryWin32NameEXT(memory, size,
      handleType, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glImportMemoryWin32HandleEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    handle: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObjectWin32.nglImportMemoryWin32HandleEXT(memory, size,
      handleType, handle)
}
