package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTMemoryObjectLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTMemoryObject {
  override fun glTextureStorageMem2DMultisampleEXT(
    texture: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTextureStorageMem2DMultisampleEXT(texture, samples,
      internalFormat, width, height, fixedSampleLocations, memory, offset)

  @PtrParameter([2])
  override fun glMemoryObjectParameterivEXT(
    memoryObject: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.nglMemoryObjectParameterivEXT(memoryObject, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetMemoryObjectParameterivEXT(
    memoryObject: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.nglGetMemoryObjectParameterivEXT(memoryObject, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glTextureStorageMem3DMultisampleEXT(
    texture: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTextureStorageMem3DMultisampleEXT(texture, samples,
      internalFormat, width, height, depth, fixedSampleLocations, memory, offset)

  @PtrParameter([2])
  override fun glGetUnsignedBytei_vEXT(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.nglGetUnsignedBytei_vEXT(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glGetMemoryObjectParameterivEXT(
    memoryObject: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.nglGetMemoryObjectParameterivEXT(memoryObject, pname,
      params)

  override fun glTexStorageMem2DMultisampleEXT(
    target: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTexStorageMem2DMultisampleEXT(target, samples,
      internalFormat, width, height, fixedSampleLocations, memory, offset)

  override fun glTexStorageMem3DEXT(
    target: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTexStorageMem3DEXT(target, levels, internalFormat,
      width, height, depth, memory, offset)

  override fun glDeleteMemoryObjectsEXT(n: Int, memoryObjects: Long): Unit =
      org.lwjgl.opengl.EXTMemoryObject.nglDeleteMemoryObjectsEXT(n, memoryObjects)

  override fun glMemoryObjectParameterivEXT(
    memoryObject: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.nglMemoryObjectParameterivEXT(memoryObject, pname,
      params)

  @PtrParameter([1])
  override fun glDeleteMemoryObjectsEXT(n: Int,
      `$v$c$dev-luna5ama-kmogus-Ptr$-memoryObjects$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTMemoryObject.nglDeleteMemoryObjectsEXT(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-memoryObjects$0`.address)

  override fun glBufferStorageMemEXT(
    target: Int,
    size: Long,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glBufferStorageMemEXT(target, size, memory, offset)

  override fun glGetUnsignedBytei_vEXT(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.nglGetUnsignedBytei_vEXT(target, index, `data`)

  override fun glTextureStorageMem3DEXT(
    texture: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTextureStorageMem3DEXT(texture, levels,
      internalFormat, width, height, depth, memory, offset)

  override fun glIsMemoryObjectEXT(memoryObject: Int): Boolean =
      org.lwjgl.opengl.EXTMemoryObject.glIsMemoryObjectEXT(memoryObject)

  override fun glNamedBufferStorageMemEXT(
    buffer: Int,
    size: Long,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glNamedBufferStorageMemEXT(buffer, size, memory,
      offset)

  override fun glGetUnsignedBytevEXT(pname: Int, `data`: Long): Unit =
      org.lwjgl.opengl.EXTMemoryObject.nglGetUnsignedBytevEXT(pname, `data`)

  override fun glTexStorageMem3DMultisampleEXT(
    target: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTexStorageMem3DMultisampleEXT(target, samples,
      internalFormat, width, height, depth, fixedSampleLocations, memory, offset)

  override fun glCreateMemoryObjectsEXT(n: Int, memoryObjects: Long): Unit =
      org.lwjgl.opengl.EXTMemoryObject.nglCreateMemoryObjectsEXT(n, memoryObjects)

  override fun glTexStorageMem1DEXT(
    target: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTexStorageMem1DEXT(target, levels, internalFormat,
      width, memory, offset)

  override fun glTextureStorageMem2DEXT(
    texture: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTextureStorageMem2DEXT(texture, levels,
      internalFormat, width, height, memory, offset)

  override fun glTextureStorageMem1DEXT(
    texture: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTextureStorageMem1DEXT(texture, levels,
      internalFormat, width, memory, offset)

  @PtrParameter([1])
  override fun glGetUnsignedBytevEXT(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr): Unit
      = org.lwjgl.opengl.EXTMemoryObject.nglGetUnsignedBytevEXT(pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([1])
  override fun glCreateMemoryObjectsEXT(n: Int,
      `$v$c$dev-luna5ama-kmogus-Ptr$-memoryObjects$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTMemoryObject.nglCreateMemoryObjectsEXT(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-memoryObjects$0`.address)

  override fun glTexStorageMem2DEXT(
    target: Int,
    levels: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTMemoryObject.glTexStorageMem2DEXT(target, levels, internalFormat,
      width, height, memory, offset)
}
