package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTEGLImageStorageLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTEGLImageStorage {
  @PtrParameter([2])
  override fun glEGLImageTargetTexStorageEXT(
    target: Int,
    image: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-attrib_list$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTEGLImageStorage.nglEGLImageTargetTexStorageEXT(target, image,
      `$v$c$dev-luna5ama-kmogus-Ptr$-attrib_list$0`.address)

  @PtrParameter([2])
  override fun glEGLImageTargetTextureStorageEXT(
    texture: Int,
    image: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-attrib_list$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTEGLImageStorage.nglEGLImageTargetTextureStorageEXT(texture, image,
      `$v$c$dev-luna5ama-kmogus-Ptr$-attrib_list$0`.address)

  override fun glEGLImageTargetTextureStorageEXT(
    texture: Int,
    image: Long,
    attrib_list: Long,
  ): Unit = org.lwjgl.opengl.EXTEGLImageStorage.nglEGLImageTargetTextureStorageEXT(texture, image,
      attrib_list)

  override fun glEGLImageTargetTexStorageEXT(
    target: Int,
    image: Long,
    attrib_list: Long,
  ): Unit = org.lwjgl.opengl.EXTEGLImageStorage.nglEGLImageTargetTexStorageEXT(target, image,
      attrib_list)
}
