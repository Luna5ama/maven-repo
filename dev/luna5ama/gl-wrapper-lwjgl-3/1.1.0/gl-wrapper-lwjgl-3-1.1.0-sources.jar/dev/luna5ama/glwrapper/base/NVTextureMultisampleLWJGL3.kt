package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Unit

public class NVTextureMultisampleLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVTextureMultisample {
  override fun glTextureImage2DMultisampleCoverageNV(
    texture: Int,
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
  ): Unit = org.lwjgl.opengl.NVTextureMultisample.glTextureImage2DMultisampleCoverageNV(texture,
      target, coverageSamples, colorSamples, internalFormat, width, height, fixedSampleLocations)

  override fun glTextureImage3DMultisampleCoverageNV(
    texture: Int,
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
  ): Unit = org.lwjgl.opengl.NVTextureMultisample.glTextureImage3DMultisampleCoverageNV(texture,
      target, coverageSamples, colorSamples, internalFormat, width, height, depth,
      fixedSampleLocations)

  override fun glTexImage2DMultisampleCoverageNV(
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
  ): Unit = org.lwjgl.opengl.NVTextureMultisample.glTexImage2DMultisampleCoverageNV(target,
      coverageSamples, colorSamples, internalFormat, width, height, fixedSampleLocations)

  override fun glTexImage3DMultisampleCoverageNV(
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
  ): Unit = org.lwjgl.opengl.NVTextureMultisample.glTexImage3DMultisampleCoverageNV(target,
      coverageSamples, colorSamples, internalFormat, width, height, depth, fixedSampleLocations)

  override fun glTextureImage2DMultisampleNV(
    texture: Int,
    target: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    fixedSampleLocations: Boolean,
  ): Unit = org.lwjgl.opengl.NVTextureMultisample.glTextureImage2DMultisampleNV(texture, target,
      samples, internalFormat, width, height, fixedSampleLocations)

  override fun glTextureImage3DMultisampleNV(
    texture: Int,
    target: Int,
    samples: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedSampleLocations: Boolean,
  ): Unit = org.lwjgl.opengl.NVTextureMultisample.glTextureImage3DMultisampleNV(texture, target,
      samples, internalFormat, width, height, depth, fixedSampleLocations)
}
