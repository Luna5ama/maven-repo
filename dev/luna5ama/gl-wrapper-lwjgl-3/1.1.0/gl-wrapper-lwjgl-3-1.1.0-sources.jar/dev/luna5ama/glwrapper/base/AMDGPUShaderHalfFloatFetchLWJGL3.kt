package dev.luna5ama.glwrapper.base

public class AMDGPUShaderHalfFloatFetchLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDGPUShaderHalfFloatFetch
