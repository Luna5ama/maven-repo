package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTBlendEquationSeparateLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTBlendEquationSeparate {
  override fun glBlendEquationSeparateEXT(modeRGB: Int, modeAlpha: Int): Unit =
      org.lwjgl.opengl.EXTBlendEquationSeparate.glBlendEquationSeparateEXT(modeRGB, modeAlpha)
}
