package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL42C

public class GL42LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL42 {
  @PtrParameter([3])
  override fun glDrawElementsInstancedBaseVertexBaseInstance(
    mode: Int,
    count: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
    primcount: Int,
    basevertex: Int,
    baseinstance: Int,
  ): Unit = GL42C.nglDrawElementsInstancedBaseVertexBaseInstance(mode, count, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address, primcount, basevertex, baseinstance)

  override fun glDrawTransformFeedbackStreamInstanced(
    mode: Int,
    id: Int,
    stream: Int,
    primcount: Int,
  ): Unit = GL42C.glDrawTransformFeedbackStreamInstanced(mode, id, stream, primcount)

  override fun glDrawElementsInstancedBaseVertexBaseInstance(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
    basevertex: Int,
    baseinstance: Int,
  ): Unit = GL42C.nglDrawElementsInstancedBaseVertexBaseInstance(mode, count, type, indices,
      primcount, basevertex, baseinstance)

  @PtrParameter([3])
  override fun glGetActiveAtomicCounterBufferiv(
    program: Int,
    bufferIndex: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL42C.nglGetActiveAtomicCounterBufferiv(program, bufferIndex, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glDrawElementsInstancedBaseInstance(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
    baseinstance: Int,
  ): Unit = GL42C.nglDrawElementsInstancedBaseInstance(mode, count, type, indices, primcount,
      baseinstance)

  @PtrParameter([3])
  override fun glDrawElementsInstancedBaseInstance(
    mode: Int,
    count: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
    primcount: Int,
    baseinstance: Int,
  ): Unit = GL42C.nglDrawElementsInstancedBaseInstance(mode, count, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address, primcount, baseinstance)

  override fun glGetInternalformativ(
    target: Int,
    internalformat: Int,
    pname: Int,
    bufSize: Int,
    params: Long,
  ): Unit = GL42C.nglGetInternalformativ(target, internalformat, pname, bufSize, params)

  override fun glDrawArraysInstancedBaseInstance(
    mode: Int,
    first: Int,
    count: Int,
    primcount: Int,
    baseinstance: Int,
  ): Unit = GL42C.glDrawArraysInstancedBaseInstance(mode, first, count, primcount, baseinstance)

  override fun glDrawTransformFeedbackInstanced(
    mode: Int,
    id: Int,
    primcount: Int,
  ): Unit = GL42C.glDrawTransformFeedbackInstanced(mode, id, primcount)

  override fun glGetActiveAtomicCounterBufferiv(
    program: Int,
    bufferIndex: Int,
    pname: Int,
    params: Long,
  ): Unit = GL42C.nglGetActiveAtomicCounterBufferiv(program, bufferIndex, pname, params)

  @PtrParameter([4])
  override fun glGetInternalformativ(
    target: Int,
    internalformat: Int,
    pname: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL42C.nglGetInternalformativ(target, internalformat, pname, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glTexStorage3D(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
  ): Unit = GL42C.glTexStorage3D(target, levels, internalformat, width, height, depth)

  override fun glTexStorage1D(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
  ): Unit = GL42C.glTexStorage1D(target, levels, internalformat, width)

  override fun glTexStorage2D(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = GL42C.glTexStorage2D(target, levels, internalformat, width, height)

  override fun glMemoryBarrier(barriers: Int): Unit = GL42C.glMemoryBarrier(barriers)

  override fun glBindImageTexture(
    unit: Int,
    texture: Int,
    level: Int,
    layered: Boolean,
    layer: Int,
    access: Int,
    format: Int,
  ): Unit = GL42C.glBindImageTexture(unit, texture, level, layered, layer, access, format)
}
