package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTDebugMarkerLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTDebugMarker {
  override fun glInsertEventMarkerEXT(length: Int, marker: Long): Unit =
      org.lwjgl.opengl.EXTDebugMarker.nglInsertEventMarkerEXT(length, marker)

  override fun glPopGroupMarkerEXT(): Unit = org.lwjgl.opengl.EXTDebugMarker.glPopGroupMarkerEXT()

  @PtrParameter([1])
  override fun glPushGroupMarkerEXT(length: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-marker$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTDebugMarker.nglPushGroupMarkerEXT(length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-marker$0`.address)

  override fun glPushGroupMarkerEXT(length: Int, marker: Long): Unit =
      org.lwjgl.opengl.EXTDebugMarker.nglPushGroupMarkerEXT(length, marker)

  @PtrParameter([1])
  override fun glInsertEventMarkerEXT(length: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-marker$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTDebugMarker.nglInsertEventMarkerEXT(length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-marker$0`.address)
}
