package dev.luna5ama.glwrapper.base

public class ARBSeamlessCubemapPerTextureLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBSeamlessCubemapPerTexture
