package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL41C

public class GL41LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL41 {
  @PtrParameter([4])
  override fun glProgramUniformMatrix2x3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix2x3fv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix4x2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix4x2fv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix2x4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix2x4fv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix3x2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix3x2fv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix4x3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix4x3fv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix2x3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix2x3dv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix3x2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix3x2dv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix2x4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix2x4dv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix4x2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix4x2dv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix3x4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix3x4dv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix3x4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix3x4fv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2, 3])
  override fun glGetProgramPipelineInfoLog(
    pipeline: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-infoLog$0`: Ptr,
  ): Unit = GL41C.nglGetProgramPipelineInfoLog(pipeline, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-infoLog$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix4x3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix4x3dv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glReleaseShaderCompiler(): Unit = GL41C.glReleaseShaderCompiler()

  @PtrParameter([1, 3])
  override fun glShaderBinary(
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-shaders$0`: Ptr,
    binaryformat: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-binary$0`: Ptr,
    length: Int,
  ): Unit = GL41C.nglShaderBinary(count, `$v$c$dev-luna5ama-kmogus-Ptr$-shaders$0`.address,
      binaryformat, `$v$c$dev-luna5ama-kmogus-Ptr$-binary$0`.address, length)

  override fun glGetShaderPrecisionFormat(
    shadertype: Int,
    precisiontype: Int,
    range: Long,
    precision: Long,
  ): Unit = GL41C.nglGetShaderPrecisionFormat(shadertype, precisiontype, range, precision)

  @PtrParameter([2, 3, 4])
  override fun glGetProgramBinary(
    program: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-binaryFormat$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-binary$0`: Ptr,
  ): Unit = GL41C.nglGetProgramBinary(program, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-binaryFormat$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-binary$0`.address)

  @PtrParameter([2])
  override fun glProgramBinary(
    program: Int,
    binaryFormat: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-binary$0`: Ptr,
    length: Int,
  ): Unit = GL41C.nglProgramBinary(program, binaryFormat,
      `$v$c$dev-luna5ama-kmogus-Ptr$-binary$0`.address, length)

  override fun glProgramParameteri(
    program: Int,
    pname: Int,
    `value`: Int,
  ): Unit = GL41C.glProgramParameteri(program, pname, `value`)

  override fun glActiveShaderProgram(pipeline: Int, program: Int): Unit =
      GL41C.glActiveShaderProgram(pipeline, program)

  @PtrParameter([2, 3])
  override fun glGetShaderPrecisionFormat(
    shadertype: Int,
    precisiontype: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-range$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-precision$0`: Ptr,
  ): Unit = GL41C.nglGetShaderPrecisionFormat(shadertype, precisiontype,
      `$v$c$dev-luna5ama-kmogus-Ptr$-range$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-precision$0`.address)

  @PtrParameter([2])
  override fun glCreateShaderProgramv(
    type: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-strings$0`: Ptr,
  ): Int = GL41C.nglCreateShaderProgramv(type, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-strings$0`.address)

  override fun glCreateShaderProgramv(
    type: Int,
    count: Int,
    strings: Long,
  ): Int = GL41C.nglCreateShaderProgramv(type, count, strings)

  override fun glProgramUniformMatrix2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix2fv(program, location, count, transpose, `value`)

  override fun glProgramUniformMatrix4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix4fv(program, location, count, transpose, `value`)

  @PtrParameter([3])
  override fun glProgramUniform2fv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform2fv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform4fv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform4fv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform2uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform2uiv(program, location, count, `value`)

  override fun glProgramUniformMatrix4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix4dv(program, location, count, transpose, `value`)

  override fun glProgramUniform4iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform4iv(program, location, count, `value`)

  override fun glProgramUniform1iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform1iv(program, location, count, `value`)

  override fun glProgramUniform1fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform1fv(program, location, count, `value`)

  @PtrParameter([3])
  override fun glProgramUniform2dv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform2dv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform2dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform2dv(program, location, count, `value`)

  override fun glProgramUniformMatrix2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix2dv(program, location, count, transpose, `value`)

  override fun glProgramUniformMatrix3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix3fv(program, location, count, transpose, `value`)

  override fun glProgramUniformMatrix2x3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix2x3fv(program, location, count, transpose, `value`)

  override fun glProgramUniformMatrix2x4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix2x4fv(program, location, count, transpose, `value`)

  override fun glProgramUniformMatrix4x2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix4x2fv(program, location, count, transpose, `value`)

  override fun glProgramUniformMatrix3x4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix3x4fv(program, location, count, transpose, `value`)

  override fun glProgramUniformMatrix3x2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix3x2dv(program, location, count, transpose, `value`)

  override fun glProgramUniformMatrix3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix3dv(program, location, count, transpose, `value`)

  override fun glProgramUniform3fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform3fv(program, location, count, `value`)

  override fun glProgramUniform3dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform3dv(program, location, count, `value`)

  override fun glProgramUniformMatrix3x2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix3x2fv(program, location, count, transpose, `value`)

  override fun glGenProgramPipelines(n: Int, pipelines: Long): Unit =
      GL41C.nglGenProgramPipelines(n, pipelines)

  override fun glProgramUniform2ui(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
  ): Unit = GL41C.glProgramUniform2ui(program, location, x, y)

  override fun glProgramUniform3ui(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
    z: Int,
  ): Unit = GL41C.glProgramUniform3ui(program, location, x, y, z)

  @PtrParameter([3])
  override fun glProgramUniform1iv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform1iv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glBindProgramPipeline(pipeline: Int): Unit = GL41C.glBindProgramPipeline(pipeline)

  @PtrParameter([3])
  override fun glProgramUniform4iv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform4iv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform4uiv(program, location, count, `value`)

  @PtrParameter([1])
  override fun glGenProgramPipelines(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-pipelines$0`: Ptr): Unit
      = GL41C.nglGenProgramPipelines(n, `$v$c$dev-luna5ama-kmogus-Ptr$-pipelines$0`.address)

  override fun glProgramUniform3uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform3uiv(program, location, count, `value`)

  @PtrParameter([2])
  override fun glGetProgramPipelineiv(
    pipeline: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL41C.nglGetProgramPipelineiv(pipeline, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform3fv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform3fv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform2iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform2iv(program, location, count, `value`)

  override fun glGetProgramPipelineiv(
    pipeline: Int,
    pname: Int,
    params: Long,
  ): Unit = GL41C.nglGetProgramPipelineiv(pipeline, pname, params)

  @PtrParameter([3])
  override fun glProgramUniform1uiv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform1uiv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform3uiv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform3uiv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform4dv(program, location, count, `value`)

  @PtrParameter([4])
  override fun glProgramUniformMatrix4fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix4fv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform1ui(
    program: Int,
    location: Int,
    x: Int,
  ): Unit = GL41C.glProgramUniform1ui(program, location, x)

  @PtrParameter([4])
  override fun glProgramUniformMatrix3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix3dv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform4fv(program, location, count, `value`)

  @PtrParameter([4])
  override fun glProgramUniformMatrix2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix2dv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix4dv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniformMatrix4x3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix4x3fv(program, location, count, transpose, `value`)

  override fun glProgramUniformMatrix2x3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix2x3dv(program, location, count, transpose, `value`)

  @PtrParameter([3])
  override fun glProgramUniform4dv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform4dv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform2uiv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform2uiv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([1])
  override fun glDeleteProgramPipelines(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-pipelines$0`: Ptr):
      Unit = GL41C.nglDeleteProgramPipelines(n, `$v$c$dev-luna5ama-kmogus-Ptr$-pipelines$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform1fv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform1fv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix3fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix3fv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glDeleteProgramPipelines(n: Int, pipelines: Long): Unit =
      GL41C.nglDeleteProgramPipelines(n, pipelines)

  override fun glDeleteProgramPipelines(pipeline: Int): Unit =
      GL41C.glDeleteProgramPipelines(pipeline)

  override fun glIsProgramPipeline(pipeline: Int): Boolean = GL41C.glIsProgramPipeline(pipeline)

  override fun glProgramUniform3iv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform3iv(program, location, count, `value`)

  override fun glProgramUniform1uiv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform1uiv(program, location, count, `value`)

  @PtrParameter([3])
  override fun glProgramUniform4uiv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform4uiv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform1dv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform1dv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform2iv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform2iv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform2fv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform2fv(program, location, count, `value`)

  override fun glProgramUniform1dv(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniform1dv(program, location, count, `value`)

  @PtrParameter([3])
  override fun glProgramUniform3dv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform3dv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4ui(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
  ): Unit = GL41C.glProgramUniform4ui(program, location, x, y, z, w)

  @PtrParameter([3])
  override fun glProgramUniform3iv(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniform3iv(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glProgramUniformMatrix2fv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL41C.nglProgramUniformMatrix2fv(program, location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniformMatrix3x4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix3x4dv(program, location, count, transpose, `value`)

  override fun glGetProgramPipelineInfoLog(
    pipeline: Int,
    bufSize: Int,
    length: Long,
    infoLog: Long,
  ): Unit = GL41C.nglGetProgramPipelineInfoLog(pipeline, bufSize, length, infoLog)

  override fun glProgramUniformMatrix4x3dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix4x3dv(program, location, count, transpose, `value`)

  @PtrParameter([1])
  override fun glVertexAttribL4dv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL41C.nglVertexAttribL4dv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glViewportIndexedfv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL41C.nglViewportIndexedfv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glViewportIndexedfv(index: Int, v: Long): Unit = GL41C.nglViewportIndexedfv(index, v)

  @PtrParameter([2])
  override fun glGetVertexAttribLdv(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL41C.nglGetVertexAttribLdv(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glProgramUniformMatrix2x4dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix2x4dv(program, location, count, transpose, `value`)

  @PtrParameter([1])
  override fun glVertexAttribL1dv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL41C.nglVertexAttribL1dv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glGetFloati_v(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL41C.nglGetFloati_v(target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glProgramUniformMatrix4x2dv(
    program: Int,
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL41C.nglProgramUniformMatrix4x2dv(program, location, count, transpose, `value`)

  @PtrParameter([4])
  override fun glVertexAttribLPointer(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = GL41C.nglVertexAttribLPointer(index, size, type, stride,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  override fun glVertexAttribLPointer(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
  ): Unit = GL41C.nglVertexAttribLPointer(index, size, type, stride, pointer)

  @PtrParameter([2])
  override fun glGetDoublei_v(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL41C.nglGetDoublei_v(target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([2])
  override fun glDepthRangeArrayv(
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr,
  ): Unit = GL41C.nglDepthRangeArrayv(first, count, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glScissorIndexedv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL41C.nglScissorIndexedv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttribL3dv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL41C.nglVertexAttribL3dv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glGetVertexAttribLdv(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = GL41C.nglGetVertexAttribLdv(index, pname, params)

  override fun glValidateProgramPipeline(pipeline: Int): Unit =
      GL41C.glValidateProgramPipeline(pipeline)

  @PtrParameter([1])
  override fun glVertexAttribL2dv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL41C.nglVertexAttribL2dv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glViewportArrayv(
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr,
  ): Unit = GL41C.nglViewportArrayv(first, count, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glDepthRangeIndexed(
    index: Int,
    zNear: Double,
    zFar: Double,
  ): Unit = GL41C.glDepthRangeIndexed(index, zNear, zFar)

  @PtrParameter([2])
  override fun glScissorArrayv(
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr,
  ): Unit = GL41C.nglScissorArrayv(first, count, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glProgramBinary(
    program: Int,
    binaryFormat: Int,
    binary: Long,
    length: Int,
  ): Unit = GL41C.nglProgramBinary(program, binaryFormat, binary, length)

  override fun glProgramUniform2i(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
  ): Unit = GL41C.glProgramUniform2i(program, location, x, y)

  override fun glProgramUniform3i(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
    z: Int,
  ): Unit = GL41C.glProgramUniform3i(program, location, x, y, z)

  override fun glProgramUniform4i(
    program: Int,
    location: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
  ): Unit = GL41C.glProgramUniform4i(program, location, x, y, z, w)

  override fun glUseProgramStages(
    pipeline: Int,
    stages: Int,
    program: Int,
  ): Unit = GL41C.glUseProgramStages(pipeline, stages, program)

  override fun glProgramUniform1i(
    program: Int,
    location: Int,
    x: Int,
  ): Unit = GL41C.glProgramUniform1i(program, location, x)

  override fun glClearDepthf(depth: Float): Unit = GL41C.glClearDepthf(depth)

  override fun glDepthRangef(zNear: Float, zFar: Float): Unit = GL41C.glDepthRangef(zNear, zFar)

  override fun glShaderBinary(
    count: Int,
    shaders: Long,
    binaryformat: Int,
    binary: Long,
    length: Int,
  ): Unit = GL41C.nglShaderBinary(count, shaders, binaryformat, binary, length)

  override fun glGetProgramBinary(
    program: Int,
    bufSize: Int,
    length: Long,
    binaryFormat: Long,
    binary: Long,
  ): Unit = GL41C.nglGetProgramBinary(program, bufSize, length, binaryFormat, binary)

  override fun glProgramUniform4d(
    program: Int,
    location: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
  ): Unit = GL41C.glProgramUniform4d(program, location, x, y, z, w)

  override fun glProgramUniform4f(
    program: Int,
    location: Int,
    x: Float,
    y: Float,
    z: Float,
    w: Float,
  ): Unit = GL41C.glProgramUniform4f(program, location, x, y, z, w)

  override fun glProgramUniform1f(
    program: Int,
    location: Int,
    x: Float,
  ): Unit = GL41C.glProgramUniform1f(program, location, x)

  override fun glProgramUniform1d(
    program: Int,
    location: Int,
    x: Double,
  ): Unit = GL41C.glProgramUniform1d(program, location, x)

  override fun glProgramUniform3d(
    program: Int,
    location: Int,
    x: Double,
    y: Double,
    z: Double,
  ): Unit = GL41C.glProgramUniform3d(program, location, x, y, z)

  override fun glProgramUniform3f(
    program: Int,
    location: Int,
    x: Float,
    y: Float,
    z: Float,
  ): Unit = GL41C.glProgramUniform3f(program, location, x, y, z)

  override fun glProgramUniform2d(
    program: Int,
    location: Int,
    x: Double,
    y: Double,
  ): Unit = GL41C.glProgramUniform2d(program, location, x, y)

  override fun glProgramUniform2f(
    program: Int,
    location: Int,
    x: Float,
    y: Float,
  ): Unit = GL41C.glProgramUniform2f(program, location, x, y)

  override fun glVertexAttribL4d(
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
  ): Unit = GL41C.glVertexAttribL4d(index, x, y, z, w)

  override fun glViewportArrayv(
    first: Int,
    count: Int,
    v: Long,
  ): Unit = GL41C.nglViewportArrayv(first, count, v)

  override fun glViewportIndexedf(
    index: Int,
    x: Float,
    y: Float,
    w: Float,
    h: Float,
  ): Unit = GL41C.glViewportIndexedf(index, x, y, w, h)

  override fun glVertexAttribL1d(index: Int, x: Double): Unit = GL41C.glVertexAttribL1d(index, x)

  override fun glVertexAttribL3dv(index: Int, v: Long): Unit = GL41C.nglVertexAttribL3dv(index, v)

  override fun glVertexAttribL3d(
    index: Int,
    x: Double,
    y: Double,
    z: Double,
  ): Unit = GL41C.glVertexAttribL3d(index, x, y, z)

  override fun glVertexAttribL1dv(index: Int, v: Long): Unit = GL41C.nglVertexAttribL1dv(index, v)

  override fun glVertexAttribL2dv(index: Int, v: Long): Unit = GL41C.nglVertexAttribL2dv(index, v)

  override fun glVertexAttribL2d(
    index: Int,
    x: Double,
    y: Double,
  ): Unit = GL41C.glVertexAttribL2d(index, x, y)

  override fun glVertexAttribL4dv(index: Int, v: Long): Unit = GL41C.nglVertexAttribL4dv(index, v)

  override fun glGetDoublei_v(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = GL41C.nglGetDoublei_v(target, index, `data`)

  override fun glScissorIndexedv(index: Int, v: Long): Unit = GL41C.nglScissorIndexedv(index, v)

  override fun glDepthRangeArrayv(
    first: Int,
    count: Int,
    v: Long,
  ): Unit = GL41C.nglDepthRangeArrayv(first, count, v)

  override fun glScissorArrayv(
    first: Int,
    count: Int,
    v: Long,
  ): Unit = GL41C.nglScissorArrayv(first, count, v)

  override fun glGetFloati_v(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = GL41C.nglGetFloati_v(target, index, `data`)

  override fun glScissorIndexed(
    index: Int,
    left: Int,
    bottom: Int,
    width: Int,
    height: Int,
  ): Unit = GL41C.glScissorIndexed(index, left, bottom, width, height)
}
