package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTTextureBufferObjectLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureBufferObject {
  override fun glTexBufferEXT(
    target: Int,
    internalformat: Int,
    buffer: Int,
  ): Unit = org.lwjgl.opengl.EXTTextureBufferObject.glTexBufferEXT(target, internalformat, buffer)
}
