package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTGPUShader4LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTGPUShader4 {
  override fun glVertexAttribI3uivEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI3uivEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribI2ivEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI2ivEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI2uivEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI2uivEXT(index, v)

  override fun glVertexAttribI4uivEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4uivEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribI4bvEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4bvEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI4svEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4svEXT(index, v)

  override fun glVertexAttribI2iEXT(
    index: Int,
    x: Int,
    y: Int,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.glVertexAttribI2iEXT(index, x, y)

  override fun glVertexAttribI1uiEXT(index: Int, x: Int): Unit =
      org.lwjgl.opengl.EXTGPUShader4.glVertexAttribI1uiEXT(index, x)

  @PtrParameter([1])
  override fun glVertexAttribI4svEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4svEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttribI4ivEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4ivEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttribI2uivEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI2uivEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI3ivEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI3ivEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribI4ubvEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4ubvEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI4ubvEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4ubvEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribI4usvEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4usvEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI4usvEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4usvEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribI1uivEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI1uivEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI4ivEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4ivEXT(index, v)

  override fun glVertexAttribI1uivEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI1uivEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribI4uivEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4uivEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI1iEXT(index: Int, x: Int): Unit =
      org.lwjgl.opengl.EXTGPUShader4.glVertexAttribI1iEXT(index, x)

  override fun glVertexAttribI4bvEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI4bvEXT(index, v)

  override fun glVertexAttribI4iEXT(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.glVertexAttribI4iEXT(index, x, y, z, w)

  override fun glVertexAttribI3uiEXT(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.glVertexAttribI3uiEXT(index, x, y, z)

  override fun glVertexAttribI3iEXT(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.glVertexAttribI3iEXT(index, x, y, z)

  override fun glVertexAttribI1ivEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI1ivEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribI3ivEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI3ivEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI2uiEXT(
    index: Int,
    x: Int,
    y: Int,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.glVertexAttribI2uiEXT(index, x, y)

  override fun glVertexAttribI4uiEXT(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.glVertexAttribI4uiEXT(index, x, y, z, w)

  @PtrParameter([1])
  override fun glVertexAttribI1ivEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI1ivEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI2ivEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI2ivEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribI3uivEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribI3uivEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glGetFragDataLocationEXT(program: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr):
      Int = org.lwjgl.opengl.EXTGPUShader4.nglGetFragDataLocationEXT(program,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([2])
  override fun glUniform1uivEXT(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglUniform1uivEXT(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetFragDataLocationEXT(program: Int, name: Long): Int =
      org.lwjgl.opengl.EXTGPUShader4.nglGetFragDataLocationEXT(program, name)

  @PtrParameter([2])
  override fun glGetVertexAttribIuivEXT(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglGetVertexAttribIuivEXT(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([4])
  override fun glVertexAttribIPointerEXT(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribIPointerEXT(index, size, type, stride,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  @PtrParameter([2])
  override fun glGetUniformuivEXT(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglGetUniformuivEXT(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glUniform4uivEXT(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglUniform4uivEXT(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform2uivEXT(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglUniform2uivEXT(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glVertexAttribIPointerEXT(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglVertexAttribIPointerEXT(index, size, type, stride,
      pointer)

  @PtrParameter([2])
  override fun glUniform3uivEXT(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglUniform3uivEXT(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetVertexAttribIuivEXT(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglGetVertexAttribIuivEXT(index, pname, params)

  override fun glGetVertexAttribIivEXT(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglGetVertexAttribIivEXT(index, pname, params)

  @PtrParameter([2])
  override fun glGetVertexAttribIivEXT(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglGetVertexAttribIivEXT(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glBindFragDataLocationEXT(
    program: Int,
    color: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglBindFragDataLocationEXT(program, color,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glBindFragDataLocationEXT(
    program: Int,
    color: Int,
    name: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglBindFragDataLocationEXT(program, color, name)

  override fun glUniform4uiEXT(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.glUniform4uiEXT(location, v0, v1, v2, v3)

  override fun glUniform2uiEXT(
    location: Int,
    v0: Int,
    v1: Int,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.glUniform2uiEXT(location, v0, v1)

  override fun glUniform3uiEXT(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.glUniform3uiEXT(location, v0, v1, v2)

  override fun glUniform1uivEXT(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglUniform1uivEXT(location, count, `value`)

  override fun glUniform2uivEXT(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglUniform2uivEXT(location, count, `value`)

  override fun glUniform3uivEXT(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglUniform3uivEXT(location, count, `value`)

  override fun glGetUniformuivEXT(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglGetUniformuivEXT(program, location, params)

  override fun glUniform1uiEXT(location: Int, v0: Int): Unit =
      org.lwjgl.opengl.EXTGPUShader4.glUniform1uiEXT(location, v0)

  override fun glUniform4uivEXT(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUShader4.nglUniform4uivEXT(location, count, `value`)
}
