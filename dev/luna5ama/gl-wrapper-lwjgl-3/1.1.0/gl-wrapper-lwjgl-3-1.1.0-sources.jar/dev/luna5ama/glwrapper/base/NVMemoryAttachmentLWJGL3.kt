package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVMemoryAttachmentLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVMemoryAttachment {
  override fun glGetMemoryObjectDetachedResourcesuivNV(
    memory: Int,
    pname: Int,
    first: Int,
    count: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVMemoryAttachment.nglGetMemoryObjectDetachedResourcesuivNV(memory,
      pname, first, count, params)

  @PtrParameter([4])
  override fun glGetMemoryObjectDetachedResourcesuivNV(
    memory: Int,
    pname: Int,
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVMemoryAttachment.nglGetMemoryObjectDetachedResourcesuivNV(memory,
      pname, first, count, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glBufferAttachMemoryNV(
    target: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.NVMemoryAttachment.glBufferAttachMemoryNV(target, memory, offset)

  override fun glNamedBufferAttachMemoryNV(
    buffer: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.NVMemoryAttachment.glNamedBufferAttachMemoryNV(buffer, memory, offset)

  override fun glTextureAttachMemoryNV(
    texture: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.NVMemoryAttachment.glTextureAttachMemoryNV(texture, memory, offset)

  override fun glResetMemoryObjectParameterNV(memory: Int, pname: Int): Unit =
      org.lwjgl.opengl.NVMemoryAttachment.glResetMemoryObjectParameterNV(memory, pname)

  override fun glTexAttachMemoryNV(
    target: Int,
    memory: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.NVMemoryAttachment.glTexAttachMemoryNV(target, memory, offset)
}
