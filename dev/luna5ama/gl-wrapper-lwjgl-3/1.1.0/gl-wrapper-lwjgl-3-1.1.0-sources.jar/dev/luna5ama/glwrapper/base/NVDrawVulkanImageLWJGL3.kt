package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVDrawVulkanImageLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVDrawVulkanImage {
  override fun glWaitVkSemaphoreNV(vkSemaphore: Long): Unit =
      org.lwjgl.opengl.NVDrawVulkanImage.glWaitVkSemaphoreNV(vkSemaphore)

  @PtrParameter([0])
  override fun glGetVkProcAddrNV(`$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr): Long =
      org.lwjgl.opengl.NVDrawVulkanImage.nglGetVkProcAddrNV(`$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glSignalVkSemaphoreNV(vkSemaphore: Long): Unit =
      org.lwjgl.opengl.NVDrawVulkanImage.glSignalVkSemaphoreNV(vkSemaphore)

  override fun glDrawVkImageNV(
    vkImage: Long,
    sampler: Int,
    x0: Float,
    y0: Float,
    x1: Float,
    y1: Float,
    z: Float,
    s0: Float,
    t0: Float,
    s1: Float,
    t1: Float,
  ): Unit = org.lwjgl.opengl.NVDrawVulkanImage.glDrawVkImageNV(vkImage, sampler, x0, y0, x1, y1, z,
      s0, t0, s1, t1)

  override fun glSignalVkFenceNV(vkFence: Long): Unit =
      org.lwjgl.opengl.NVDrawVulkanImage.glSignalVkFenceNV(vkFence)

  override fun glGetVkProcAddrNV(name: Long): Long =
      org.lwjgl.opengl.NVDrawVulkanImage.nglGetVkProcAddrNV(name)
}
