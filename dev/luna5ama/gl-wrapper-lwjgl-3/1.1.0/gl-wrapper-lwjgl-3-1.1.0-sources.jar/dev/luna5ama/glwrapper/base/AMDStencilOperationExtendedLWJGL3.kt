package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class AMDStencilOperationExtendedLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDStencilOperationExtended {
  override fun glStencilOpValueAMD(face: Int, `value`: Int): Unit =
      org.lwjgl.opengl.AMDStencilOperationExtended.glStencilOpValueAMD(face, `value`)
}
