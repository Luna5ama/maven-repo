package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class NVFragmentCoverageToColorLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVFragmentCoverageToColor {
  override fun glFragmentCoverageColorNV(color: Int): Unit =
      org.lwjgl.opengl.NVFragmentCoverageToColor.glFragmentCoverageColorNV(color)
}
