package dev.luna5ama.glwrapper.base

public class EXTClipVolumeHintLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTClipVolumeHint
