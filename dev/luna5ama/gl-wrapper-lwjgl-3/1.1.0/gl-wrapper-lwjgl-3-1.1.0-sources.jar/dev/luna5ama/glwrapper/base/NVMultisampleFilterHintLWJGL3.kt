package dev.luna5ama.glwrapper.base

public class NVMultisampleFilterHintLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVMultisampleFilterHint
