package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVQueryResourceTagLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVQueryResourceTag {
  override fun glGenQueryResourceTagNV(n: Int, tagIds: Long): Unit =
      org.lwjgl.opengl.NVQueryResourceTag.nglGenQueryResourceTagNV(n, tagIds)

  override fun glQueryResourceTagNV(tagId: Int, tagString: Long): Unit =
      org.lwjgl.opengl.NVQueryResourceTag.nglQueryResourceTagNV(tagId, tagString)

  @PtrParameter([1])
  override fun glGenQueryResourceTagNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-tagIds$0`: Ptr): Unit
      = org.lwjgl.opengl.NVQueryResourceTag.nglGenQueryResourceTagNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-tagIds$0`.address)

  @PtrParameter([1])
  override fun glDeleteQueryResourceTagNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-tagIds$0`: Ptr):
      Unit = org.lwjgl.opengl.NVQueryResourceTag.nglDeleteQueryResourceTagNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-tagIds$0`.address)

  @PtrParameter([1])
  override fun glQueryResourceTagNV(tagId: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-tagString$0`: Ptr):
      Unit = org.lwjgl.opengl.NVQueryResourceTag.nglQueryResourceTagNV(tagId,
      `$v$c$dev-luna5ama-kmogus-Ptr$-tagString$0`.address)

  override fun glDeleteQueryResourceTagNV(n: Int, tagIds: Long): Unit =
      org.lwjgl.opengl.NVQueryResourceTag.nglDeleteQueryResourceTagNV(n, tagIds)
}
