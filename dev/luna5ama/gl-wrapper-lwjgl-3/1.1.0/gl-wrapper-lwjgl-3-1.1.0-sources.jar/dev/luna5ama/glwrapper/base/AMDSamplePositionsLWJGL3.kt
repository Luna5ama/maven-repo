package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class AMDSamplePositionsLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDSamplePositions {
  @PtrParameter([2])
  override fun glSetMultisamplefvAMD(
    pname: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-val$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDSamplePositions.nglSetMultisamplefvAMD(pname, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-val$0`.address)

  override fun glSetMultisamplefvAMD(
    pname: Int,
    index: Int,
    `val`: Long,
  ): Unit = org.lwjgl.opengl.AMDSamplePositions.nglSetMultisamplefvAMD(pname, index, `val`)
}
