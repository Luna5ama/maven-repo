package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Long

public class EXTWin32KeyedMutexLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTWin32KeyedMutex {
  override fun glAcquireKeyedMutexWin32EXT(
    memory: Int,
    key: Long,
    timeout: Int,
  ): Boolean = org.lwjgl.opengl.EXTWin32KeyedMutex.glAcquireKeyedMutexWin32EXT(memory, key, timeout)

  override fun glReleaseKeyedMutexWin32EXT(memory: Int, key: Long): Boolean =
      org.lwjgl.opengl.EXTWin32KeyedMutex.glReleaseKeyedMutexWin32EXT(memory, key)
}
