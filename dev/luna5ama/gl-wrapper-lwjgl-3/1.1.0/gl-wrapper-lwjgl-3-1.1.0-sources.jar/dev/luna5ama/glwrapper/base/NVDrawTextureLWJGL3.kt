package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Unit

public class NVDrawTextureLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVDrawTexture {
  override fun glDrawTextureNV(
    texture: Int,
    sampler: Int,
    x0: Float,
    y0: Float,
    x1: Float,
    y1: Float,
    z: Float,
    s0: Float,
    t0: Float,
    s1: Float,
    t1: Float,
  ): Unit = org.lwjgl.opengl.NVDrawTexture.glDrawTextureNV(texture, sampler, x0, y0, x1, y1, z, s0,
      t0, s1, t1)
}
