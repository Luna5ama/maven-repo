package dev.luna5ama.glwrapper.base

public class NVPackedDepthStencilLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVPackedDepthStencil
