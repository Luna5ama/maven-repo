package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVBindlessTextureLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVBindlessTexture {
  @PtrParameter([3])
  override fun glProgramUniformHandleui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVBindlessTexture.nglProgramUniformHandleui64vNV(program, location,
      count, `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  @PtrParameter([2])
  override fun glUniformHandleui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVBindlessTexture.nglUniformHandleui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  override fun glMakeTextureHandleResidentNV(handle: Long): Unit =
      org.lwjgl.opengl.NVBindlessTexture.glMakeTextureHandleResidentNV(handle)

  override fun glMakeImageHandleResidentNV(handle: Long, access: Int): Unit =
      org.lwjgl.opengl.NVBindlessTexture.glMakeImageHandleResidentNV(handle, access)

  override fun glProgramUniformHandleui64NV(
    program: Int,
    location: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVBindlessTexture.glProgramUniformHandleui64NV(program, location,
      `value`)

  override fun glUniformHandleui64NV(location: Int, `value`: Long): Unit =
      org.lwjgl.opengl.NVBindlessTexture.glUniformHandleui64NV(location, `value`)

  override fun glUniformHandleui64vNV(
    location: Int,
    count: Int,
    values: Long,
  ): Unit = org.lwjgl.opengl.NVBindlessTexture.nglUniformHandleui64vNV(location, count, values)

  override fun glMakeImageHandleNonResidentNV(handle: Long): Unit =
      org.lwjgl.opengl.NVBindlessTexture.glMakeImageHandleNonResidentNV(handle)

  override fun glIsImageHandleResidentNV(handle: Long): Boolean =
      org.lwjgl.opengl.NVBindlessTexture.glIsImageHandleResidentNV(handle)

  override fun glProgramUniformHandleui64vNV(
    program: Int,
    location: Int,
    count: Int,
    values: Long,
  ): Unit = org.lwjgl.opengl.NVBindlessTexture.nglProgramUniformHandleui64vNV(program, location,
      count, values)

  override fun glMakeTextureHandleNonResidentNV(handle: Long): Unit =
      org.lwjgl.opengl.NVBindlessTexture.glMakeTextureHandleNonResidentNV(handle)

  override fun glGetTextureHandleNV(texture: Int): Long =
      org.lwjgl.opengl.NVBindlessTexture.glGetTextureHandleNV(texture)

  override fun glGetTextureSamplerHandleNV(texture: Int, sampler: Int): Long =
      org.lwjgl.opengl.NVBindlessTexture.glGetTextureSamplerHandleNV(texture, sampler)

  override fun glIsTextureHandleResidentNV(handle: Long): Boolean =
      org.lwjgl.opengl.NVBindlessTexture.glIsTextureHandleResidentNV(handle)

  override fun glGetImageHandleNV(
    texture: Int,
    level: Int,
    layered: Boolean,
    layer: Int,
    format: Int,
  ): Long = org.lwjgl.opengl.NVBindlessTexture.glGetImageHandleNV(texture, level, layered, layer,
      format)
}
