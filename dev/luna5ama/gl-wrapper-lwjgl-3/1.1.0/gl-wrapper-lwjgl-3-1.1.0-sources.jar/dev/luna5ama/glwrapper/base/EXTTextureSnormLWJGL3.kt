package dev.luna5ama.glwrapper.base

public class EXTTextureSnormLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureSnorm
