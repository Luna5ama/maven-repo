package dev.luna5ama.glwrapper.base

public class EXTTextureFilterMinmaxLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureFilterMinmax
