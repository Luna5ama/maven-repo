package dev.luna5ama.glwrapper.base

public class AMDQueryBufferObjectLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDQueryBufferObject
