package dev.luna5ama.glwrapper.base

public class NVLightMaxExponentLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVLightMaxExponent
