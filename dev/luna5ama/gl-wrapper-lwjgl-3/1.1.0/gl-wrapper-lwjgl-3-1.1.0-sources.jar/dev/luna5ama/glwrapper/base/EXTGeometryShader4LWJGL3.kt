package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTGeometryShader4LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTGeometryShader4 {
  override fun glProgramParameteriEXT(
    program: Int,
    pname: Int,
    `value`: Int,
  ): Unit = org.lwjgl.opengl.EXTGeometryShader4.glProgramParameteriEXT(program, pname, `value`)

  override fun glFramebufferTextureEXT(
    target: Int,
    attachment: Int,
    texture: Int,
    level: Int,
  ): Unit = org.lwjgl.opengl.EXTGeometryShader4.glFramebufferTextureEXT(target, attachment, texture,
      level)

  override fun glFramebufferTextureFaceEXT(
    target: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    face: Int,
  ): Unit = org.lwjgl.opengl.EXTGeometryShader4.glFramebufferTextureFaceEXT(target, attachment,
      texture, level, face)
}
