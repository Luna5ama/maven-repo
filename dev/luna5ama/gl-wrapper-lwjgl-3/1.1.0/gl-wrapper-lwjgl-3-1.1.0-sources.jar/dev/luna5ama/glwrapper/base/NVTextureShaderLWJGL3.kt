package dev.luna5ama.glwrapper.base

public class NVTextureShaderLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVTextureShader
