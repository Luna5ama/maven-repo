package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVSampleLocationsLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVSampleLocations {
  override fun glNamedFramebufferSampleLocationsfvNV(
    framebuffer: Int,
    start: Int,
    count: Int,
    v: Long,
  ): Unit = org.lwjgl.opengl.NVSampleLocations.nglNamedFramebufferSampleLocationsfvNV(framebuffer,
      start, count, v)

  @PtrParameter([3])
  override fun glNamedFramebufferSampleLocationsfvNV(
    framebuffer: Int,
    start: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVSampleLocations.nglNamedFramebufferSampleLocationsfvNV(framebuffer,
      start, count, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([3])
  override fun glFramebufferSampleLocationsfvNV(
    target: Int,
    start: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVSampleLocations.nglFramebufferSampleLocationsfvNV(target, start,
      count, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glFramebufferSampleLocationsfvNV(
    target: Int,
    start: Int,
    count: Int,
    v: Long,
  ): Unit = org.lwjgl.opengl.NVSampleLocations.nglFramebufferSampleLocationsfvNV(target, start,
      count, v)

  override fun glResolveDepthValuesNV(): Unit =
      org.lwjgl.opengl.NVSampleLocations.glResolveDepthValuesNV()
}
