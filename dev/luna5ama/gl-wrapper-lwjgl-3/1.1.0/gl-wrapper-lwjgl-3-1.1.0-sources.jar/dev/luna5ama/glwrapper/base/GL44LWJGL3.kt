package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL44C

public class GL44LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL44 {
  override fun glBindBuffersBase(
    target: Int,
    first: Int,
    count: Int,
    buffers: Long,
  ): Unit = GL44C.nglBindBuffersBase(target, first, count, buffers)

  override fun glClearTexSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    `data`: Long,
  ): Unit = GL44C.nglClearTexSubImage(texture, level, xoffset, yoffset, zoffset, width, height,
      depth, format, type, `data`)

  override fun glBufferStorage(
    target: Int,
    size: Long,
    `data`: Long,
    flags: Int,
  ): Unit = GL44C.nglBufferStorage(target, size, `data`, flags)

  override fun glClearTexImage(
    texture: Int,
    level: Int,
    format: Int,
    type: Int,
    `data`: Long,
  ): Unit = GL44C.nglClearTexImage(texture, level, format, type, `data`)

  override fun glBindBuffersRange(
    target: Int,
    first: Int,
    count: Int,
    buffers: Long,
    offsets: Long,
    sizes: Long,
  ): Unit = GL44C.nglBindBuffersRange(target, first, count, buffers, offsets, sizes)

  override fun glBindTextures(
    first: Int,
    count: Int,
    textures: Long,
  ): Unit = GL44C.nglBindTextures(first, count, textures)

  override fun glBindSamplers(
    first: Int,
    count: Int,
    samplers: Long,
  ): Unit = GL44C.nglBindSamplers(first, count, samplers)

  @PtrParameter([2, 3, 4])
  override fun glBindVertexBuffers(
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-offsets$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-strides$0`: Ptr,
  ): Unit = GL44C.nglBindVertexBuffers(first, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-offsets$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-strides$0`.address)

  @PtrParameter([3])
  override fun glBindBuffersBase(
    target: Int,
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`: Ptr,
  ): Unit = GL44C.nglBindBuffersBase(target, first, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`.address)

  @PtrParameter([2])
  override fun glBindTextures(
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`: Ptr,
  ): Unit = GL44C.nglBindTextures(first, count, `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`.address)

  @PtrParameter([10])
  override fun glClearTexSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL44C.nglClearTexSubImage(texture, level, xoffset, yoffset, zoffset, width, height,
      depth, format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glBindImageTextures(
    first: Int,
    count: Int,
    textures: Long,
  ): Unit = GL44C.nglBindImageTextures(first, count, textures)

  @PtrParameter([2])
  override fun glBufferStorage(
    target: Int,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
    flags: Int,
  ): Unit = GL44C.nglBufferStorage(target, size, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address,
      flags)

  @PtrParameter([2])
  override fun glBindSamplers(
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-samplers$0`: Ptr,
  ): Unit = GL44C.nglBindSamplers(first, count, `$v$c$dev-luna5ama-kmogus-Ptr$-samplers$0`.address)

  override fun glBindVertexBuffers(
    first: Int,
    count: Int,
    buffers: Long,
    offsets: Long,
    strides: Long,
  ): Unit = GL44C.nglBindVertexBuffers(first, count, buffers, offsets, strides)

  @PtrParameter([4])
  override fun glClearTexImage(
    texture: Int,
    level: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL44C.nglClearTexImage(texture, level, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([3, 4, 5])
  override fun glBindBuffersRange(
    target: Int,
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-offsets$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`: Ptr,
  ): Unit = GL44C.nglBindBuffersRange(target, first, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-offsets$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`.address)

  @PtrParameter([2])
  override fun glBindImageTextures(
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`: Ptr,
  ): Unit = GL44C.nglBindImageTextures(first, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`.address)
}
