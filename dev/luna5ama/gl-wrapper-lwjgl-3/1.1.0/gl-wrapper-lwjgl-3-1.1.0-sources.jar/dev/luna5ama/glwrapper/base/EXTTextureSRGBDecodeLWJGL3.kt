package dev.luna5ama.glwrapper.base

public class EXTTextureSRGBDecodeLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureSRGBDecode
