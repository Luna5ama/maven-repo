package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTFramebufferBlitLayersLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTFramebufferBlitLayers {
  override fun glBlitFramebufferLayerEXT(
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    srcLayer: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    dstLayer: Int,
    mask: Int,
    filter: Int,
  ): Unit = org.lwjgl.opengl.EXTFramebufferBlitLayers.glBlitFramebufferLayerEXT(srcX0, srcY0, srcX1,
      srcY1, srcLayer, dstX0, dstY0, dstX1, dstY1, dstLayer, mask, filter)

  override fun glBlitFramebufferLayersEXT(
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    mask: Int,
    filter: Int,
  ): Unit = org.lwjgl.opengl.EXTFramebufferBlitLayers.glBlitFramebufferLayersEXT(srcX0, srcY0,
      srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter)
}
