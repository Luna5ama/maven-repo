package dev.luna5ama.glwrapper.base

public class KHRShaderSubgroupLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : KHRShaderSubgroup
