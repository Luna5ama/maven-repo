package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTPointParametersLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTPointParameters {
  @PtrParameter([1])
  override fun glPointParameterfvEXT(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTPointParameters.nglPointParameterfvEXT(pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glPointParameterfvEXT(pname: Int, params: Long): Unit =
      org.lwjgl.opengl.EXTPointParameters.nglPointParameterfvEXT(pname, params)

  override fun glPointParameterfEXT(pname: Int, `param`: Float): Unit =
      org.lwjgl.opengl.EXTPointParameters.glPointParameterfEXT(pname, `param`)
}
