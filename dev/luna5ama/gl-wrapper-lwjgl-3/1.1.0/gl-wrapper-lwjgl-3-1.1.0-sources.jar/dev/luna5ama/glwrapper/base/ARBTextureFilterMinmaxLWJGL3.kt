package dev.luna5ama.glwrapper.base

public class ARBTextureFilterMinmaxLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBTextureFilterMinmax
