package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVShadingRateImageLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVShadingRateImage {
  @PtrParameter([2])
  override fun glShadingRateSampleOrderCustomNV(
    rate: Int,
    samples: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-locations$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVShadingRateImage.nglShadingRateSampleOrderCustomNV(rate, samples,
      `$v$c$dev-luna5ama-kmogus-Ptr$-locations$0`.address)

  @PtrParameter([2])
  override fun glGetShadingRateImagePaletteNV(
    viewport: Int,
    entry: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-rate$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVShadingRateImage.nglGetShadingRateImagePaletteNV(viewport, entry,
      `$v$c$dev-luna5ama-kmogus-Ptr$-rate$0`.address)

  @PtrParameter([3])
  override fun glShadingRateImagePaletteNV(
    viewport: Int,
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-rates$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVShadingRateImage.nglShadingRateImagePaletteNV(viewport, first, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-rates$0`.address)

  @PtrParameter([3])
  override fun glGetShadingRateSampleLocationivNV(
    rate: Int,
    samples: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-location$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVShadingRateImage.nglGetShadingRateSampleLocationivNV(rate, samples,
      index, `$v$c$dev-luna5ama-kmogus-Ptr$-location$0`.address)

  override fun glShadingRateImageBarrierNV(synchronize: Boolean): Unit =
      org.lwjgl.opengl.NVShadingRateImage.glShadingRateImageBarrierNV(synchronize)

  override fun glShadingRateImagePaletteNV(
    viewport: Int,
    first: Int,
    count: Int,
    rates: Long,
  ): Unit = org.lwjgl.opengl.NVShadingRateImage.nglShadingRateImagePaletteNV(viewport, first, count,
      rates)

  override fun glShadingRateSampleOrderNV(order: Int): Unit =
      org.lwjgl.opengl.NVShadingRateImage.glShadingRateSampleOrderNV(order)

  override fun glGetShadingRateImagePaletteNV(
    viewport: Int,
    entry: Int,
    rate: Long,
  ): Unit = org.lwjgl.opengl.NVShadingRateImage.nglGetShadingRateImagePaletteNV(viewport, entry,
      rate)

  override fun glGetShadingRateSampleLocationivNV(
    rate: Int,
    samples: Int,
    index: Int,
    location: Long,
  ): Unit = org.lwjgl.opengl.NVShadingRateImage.nglGetShadingRateSampleLocationivNV(rate, samples,
      index, location)

  override fun glBindShadingRateImageNV(texture: Int): Unit =
      org.lwjgl.opengl.NVShadingRateImage.glBindShadingRateImageNV(texture)

  override fun glShadingRateSampleOrderCustomNV(
    rate: Int,
    samples: Int,
    locations: Long,
  ): Unit = org.lwjgl.opengl.NVShadingRateImage.nglShadingRateSampleOrderCustomNV(rate, samples,
      locations)
}
