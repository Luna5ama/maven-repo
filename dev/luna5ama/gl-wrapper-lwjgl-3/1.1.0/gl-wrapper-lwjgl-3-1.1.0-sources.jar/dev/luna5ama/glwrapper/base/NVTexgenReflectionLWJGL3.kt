package dev.luna5ama.glwrapper.base

public class NVTexgenReflectionLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVTexgenReflection
