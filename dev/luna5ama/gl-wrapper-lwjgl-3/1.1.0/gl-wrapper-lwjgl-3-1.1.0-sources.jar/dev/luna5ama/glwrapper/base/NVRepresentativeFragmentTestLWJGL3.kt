package dev.luna5ama.glwrapper.base

public class NVRepresentativeFragmentTestLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVRepresentativeFragmentTest
