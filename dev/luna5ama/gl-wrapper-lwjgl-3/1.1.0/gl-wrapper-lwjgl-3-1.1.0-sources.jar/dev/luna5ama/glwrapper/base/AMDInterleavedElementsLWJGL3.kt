package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class AMDInterleavedElementsLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDInterleavedElements {
  override fun glVertexAttribParameteriAMD(
    index: Int,
    pname: Int,
    `param`: Int,
  ): Unit = org.lwjgl.opengl.AMDInterleavedElements.glVertexAttribParameteriAMD(index, pname,
      `param`)
}
