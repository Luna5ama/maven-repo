package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class NVCopyImageLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVCopyImage {
  override fun glCopyImageSubDataNV(
    srcName: Int,
    srcTarget: Int,
    srcLevel: Int,
    srcX: Int,
    srcY: Int,
    srcZ: Int,
    dstName: Int,
    dstTarget: Int,
    dstLevel: Int,
    dstX: Int,
    dstY: Int,
    dstZ: Int,
    width: Int,
    height: Int,
    depth: Int,
  ): Unit = org.lwjgl.opengl.NVCopyImage.glCopyImageSubDataNV(srcName, srcTarget, srcLevel, srcX,
      srcY, srcZ, dstName, dstTarget, dstLevel, dstX, dstY, dstZ, width, height, depth)
}
