package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL32C

public class GL32LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL32 {
  @PtrParameter([5])
  override fun glDrawRangeElementsBaseVertex(
    mode: Int,
    start: Int,
    end: Int,
    count: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
    basevertex: Int,
  ): Unit = GL32C.nglDrawRangeElementsBaseVertex(mode, start, end, count, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address, basevertex)

  @PtrParameter([1, 3, 5])
  override fun glMultiDrawElementsBaseVertex(
    mode: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-count$0`: Ptr,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
    drawcount: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-basevertex$0`: Ptr,
  ): Unit = GL32C.nglMultiDrawElementsBaseVertex(mode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-count$0`.address, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address, drawcount,
      `$v$c$dev-luna5ama-kmogus-Ptr$-basevertex$0`.address)

  @PtrParameter([3])
  override fun glDrawElementsInstancedBaseVertex(
    mode: Int,
    count: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
    primcount: Int,
    basevertex: Int,
  ): Unit = GL32C.nglDrawElementsInstancedBaseVertex(mode, count, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address, primcount, basevertex)

  @PtrParameter([2])
  override fun glGetBufferParameteri64v(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL32C.nglGetBufferParameteri64v(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetBufferParameteri64v(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL32C.nglGetBufferParameteri64v(target, pname, params)

  @PtrParameter([3])
  override fun glDrawElementsBaseVertex(
    mode: Int,
    count: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
    basevertex: Int,
  ): Unit = GL32C.nglDrawElementsBaseVertex(mode, count, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address, basevertex)

  override fun glDrawRangeElementsBaseVertex(
    mode: Int,
    start: Int,
    end: Int,
    count: Int,
    type: Int,
    indices: Long,
    basevertex: Int,
  ): Unit = GL32C.nglDrawRangeElementsBaseVertex(mode, start, end, count, type, indices, basevertex)

  override fun glDrawElementsBaseVertex(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    basevertex: Int,
  ): Unit = GL32C.nglDrawElementsBaseVertex(mode, count, type, indices, basevertex)

  override fun glDrawElementsInstancedBaseVertex(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
    basevertex: Int,
  ): Unit = GL32C.nglDrawElementsInstancedBaseVertex(mode, count, type, indices, primcount,
      basevertex)

  override fun glMultiDrawElementsBaseVertex(
    mode: Int,
    count: Long,
    type: Int,
    indices: Long,
    drawcount: Int,
    basevertex: Long,
  ): Unit = GL32C.nglMultiDrawElementsBaseVertex(mode, count, type, indices, drawcount, basevertex)

  @PtrParameter([3, 4])
  override fun glGetSynciv(
    sync: Long,
    pname: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = GL32C.nglGetSynciv(sync, pname, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  override fun glTexImage2DMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    fixedsamplelocations: Boolean,
  ): Unit = GL32C.glTexImage2DMultisample(target, samples, internalformat, width, height,
      fixedsamplelocations)

  @PtrParameter([2])
  override fun glGetMultisamplefv(
    pname: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-val$0`: Ptr,
  ): Unit = GL32C.nglGetMultisamplefv(pname, index, `$v$c$dev-luna5ama-kmogus-Ptr$-val$0`.address)

  @PtrParameter([2])
  override fun glGetInteger64i_v(
    pname: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL32C.nglGetInteger64i_v(pname, index, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glTexImage3DMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedsamplelocations: Boolean,
  ): Unit = GL32C.glTexImage3DMultisample(target, samples, internalformat, width, height, depth,
      fixedsamplelocations)

  @PtrParameter([1])
  override fun glGetInteger64v(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr): Unit =
      GL32C.nglGetInteger64v(pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glFramebufferTexture(
    target: Int,
    attachment: Int,
    texture: Int,
    level: Int,
  ): Unit = GL32C.glFramebufferTexture(target, attachment, texture, level)

  override fun glGetSynciv(
    sync: Long,
    pname: Int,
    bufSize: Int,
    length: Long,
    values: Long,
  ): Unit = GL32C.nglGetSynciv(sync, pname, bufSize, length, values)

  override fun glGetMultisamplefv(
    pname: Int,
    index: Int,
    `val`: Long,
  ): Unit = GL32C.nglGetMultisamplefv(pname, index, `val`)

  override fun glSampleMaski(index: Int, mask: Int): Unit = GL32C.glSampleMaski(index, mask)

  override fun glClientWaitSync(
    sync: Long,
    flags: Int,
    timeout: Long,
  ): Int = GL32C.nglClientWaitSync(sync, flags, timeout)

  override fun glWaitSync(
    sync: Long,
    flags: Int,
    timeout: Long,
  ): Unit = GL32C.nglWaitSync(sync, flags, timeout)

  override fun glGetInteger64v(pname: Int, params: Long): Unit = GL32C.nglGetInteger64v(pname,
      params)

  override fun glProvokingVertex(mode: Int): Unit = GL32C.glProvokingVertex(mode)

  override fun glGetInteger64i_v(
    pname: Int,
    index: Int,
    params: Long,
  ): Unit = GL32C.nglGetInteger64i_v(pname, index, params)

  override fun glFenceSync(condition: Int, flags: Int): Long = GL32C.glFenceSync(condition, flags)

  override fun glDeleteSync(sync: Long): Unit = GL32C.nglDeleteSync(sync)

  override fun glIsSync(sync: Long): Boolean = GL32C.nglIsSync(sync)
}
