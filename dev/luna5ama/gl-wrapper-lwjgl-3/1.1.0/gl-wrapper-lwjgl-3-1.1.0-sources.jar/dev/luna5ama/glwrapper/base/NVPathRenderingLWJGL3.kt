package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVPathRenderingLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVPathRendering {
  @PtrParameter([3])
  override fun glPathMemoryGlyphIndexArrayNV(
    firstPathName: Int,
    fontTarget: Int,
    fontSize: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-fontData$0`: Ptr,
    faceIndex: Int,
    firstGlyphIndex: Int,
    numGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
  ): Int = org.lwjgl.opengl.NVPathRendering.nglPathMemoryGlyphIndexArrayNV(firstPathName,
      fontTarget, fontSize, `$v$c$dev-luna5ama-kmogus-Ptr$-fontData$0`.address, faceIndex,
      firstGlyphIndex, numGlyphs, pathParameterTemplate, emScale)

  @PtrParameter([2, 7])
  override fun glStencilFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`: Ptr,
    pathBase: Int,
    fillMode: Int,
    mask: Int,
    transformType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglStencilFillPathInstancedNV(numPaths, pathNameType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`.address, pathBase, fillMode, mask, transformType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`.address)

  @PtrParameter([2, 7])
  override fun glStencilStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`: Ptr,
    pathBase: Int,
    reference: Int,
    mask: Int,
    transformType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglStencilStrokePathInstancedNV(numPaths, pathNameType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`.address, pathBase, reference, mask, transformType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`.address)

  @PtrParameter([2, 6])
  override fun glCoverStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`: Ptr,
    pathBase: Int,
    coverMode: Int,
    transformType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglCoverStrokePathInstancedNV(numPaths, pathNameType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`.address, pathBase, coverMode, transformType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`.address)

  @PtrParameter([2, 8])
  override fun glStencilThenCoverFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`: Ptr,
    pathBase: Int,
    fillMode: Int,
    mask: Int,
    coverMode: Int,
    transformType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglStencilThenCoverFillPathInstancedNV(numPaths,
      pathNameType, `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`.address, pathBase, fillMode, mask,
      coverMode, transformType, `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`.address)

  override fun glStencilThenCoverFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    fillMode: Int,
    mask: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglStencilThenCoverFillPathInstancedNV(numPaths,
      pathNameType, paths, pathBase, fillMode, mask, coverMode, transformType, transformValues)

  override fun glStencilThenCoverStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    reference: Int,
    mask: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglStencilThenCoverStrokePathInstancedNV(numPaths,
      pathNameType, paths, pathBase, reference, mask, coverMode, transformType, transformValues)

  @PtrParameter([1])
  override fun glMatrixLoadTranspose3x3fNV(matrixMode: Int,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixLoadTranspose3x3fNV(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  @PtrParameter([1])
  override fun glMatrixMultTranspose3x3fNV(matrixMode: Int,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixMultTranspose3x3fNV(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  @PtrParameter([2, 8])
  override fun glStencilThenCoverStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`: Ptr,
    pathBase: Int,
    reference: Int,
    mask: Int,
    coverMode: Int,
    transformType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglStencilThenCoverStrokePathInstancedNV(numPaths,
      pathNameType, `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`.address, pathBase, reference, mask,
      coverMode, transformType, `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`.address)

  @PtrParameter([4])
  override fun glProgramPathFragmentInputGenNV(
    program: Int,
    location: Int,
    genMode: Int,
    components: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-coeffs$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglProgramPathFragmentInputGenNV(program, location,
      genMode, components, `$v$c$dev-luna5ama-kmogus-Ptr$-coeffs$0`.address)

  override fun glStencilStrokePathNV(
    path: Int,
    reference: Int,
    mask: Int,
  ): Unit = org.lwjgl.opengl.NVPathRendering.glStencilStrokePathNV(path, reference, mask)

  @PtrParameter([3])
  override fun glPathColorGenNV(
    color: Int,
    genMode: Int,
    colorFormat: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-coeffs$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathColorGenNV(color, genMode, colorFormat,
      `$v$c$dev-luna5ama-kmogus-Ptr$-coeffs$0`.address)

  @PtrParameter([2, 6])
  override fun glPathGlyphsNV(
    firstPathName: Int,
    fontTarget: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-fontName$0`: Ptr,
    fontStyle: Int,
    numGlyphs: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-charcodes$0`: Ptr,
    handleMissingGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathGlyphsNV(firstPathName, fontTarget,
      `$v$c$dev-luna5ama-kmogus-Ptr$-fontName$0`.address, fontStyle, numGlyphs, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-charcodes$0`.address, handleMissingGlyphs,
      pathParameterTemplate, emScale)

  @PtrParameter([2, 6])
  override fun glCoverFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`: Ptr,
    pathBase: Int,
    coverMode: Int,
    transformType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglCoverFillPathInstancedNV(numPaths, pathNameType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`.address, pathBase, coverMode, transformType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`.address)

  override fun glPathGlyphIndexRangeNV(
    fontTarget: Int,
    fontName: Long,
    fontStyle: Int,
    pathParameterTemplate: Int,
    emScale: Float,
    baseAndCount: Long,
  ): Int = org.lwjgl.opengl.NVPathRendering.nglPathGlyphIndexRangeNV(fontTarget, fontName,
      fontStyle, pathParameterTemplate, emScale, baseAndCount)

  @PtrParameter([3])
  override fun glPathCoordsNV(
    path: Int,
    numCoords: Int,
    coordType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathCoordsNV(path, numCoords, coordType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`.address)

  override fun glGetPathParameterfvNV(
    path: Int,
    pname: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathParameterfvNV(path, pname, `value`)

  override fun glPathStencilDepthOffsetNV(factor: Float, units: Float): Unit =
      org.lwjgl.opengl.NVPathRendering.glPathStencilDepthOffsetNV(factor, units)

  override fun glGetPathDashArrayNV(path: Int, dashArray: Long): Unit =
      org.lwjgl.opengl.NVPathRendering.nglGetPathDashArrayNV(path, dashArray)

  @PtrParameter([3])
  override fun glPathTexGenNV(
    texCoordSet: Int,
    genMode: Int,
    components: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-coeffs$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathTexGenNV(texCoordSet, genMode, components,
      `$v$c$dev-luna5ama-kmogus-Ptr$-coeffs$0`.address)

  @PtrParameter([3, 6])
  override fun glGetPathMetricsNV(
    metricQueryMask: Int,
    numPaths: Int,
    pathNameType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`: Ptr,
    pathBase: Int,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-metrics$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathMetricsNV(metricQueryMask, numPaths,
      pathNameType, `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`.address, pathBase, stride,
      `$v$c$dev-luna5ama-kmogus-Ptr$-metrics$0`.address)

  @PtrParameter([4])
  override fun glGetPathMetricRangeNV(
    metricQueryMask: Int,
    firstPathName: Int,
    numPaths: Int,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-metrics$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathMetricRangeNV(metricQueryMask, firstPathName,
      numPaths, stride, `$v$c$dev-luna5ama-kmogus-Ptr$-metrics$0`.address)

  @PtrParameter([3, 8])
  override fun glGetPathSpacingNV(
    pathListMode: Int,
    numPaths: Int,
    pathNameType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`: Ptr,
    pathBase: Int,
    advanceScale: Float,
    kerningScale: Float,
    transformType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-returnedSpacing$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathSpacingNV(pathListMode, numPaths,
      pathNameType, `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`.address, pathBase, advanceScale,
      kerningScale, transformType, `$v$c$dev-luna5ama-kmogus-Ptr$-returnedSpacing$0`.address)

  override fun glGetPathColorGenivNV(
    color: Int,
    pname: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathColorGenivNV(color, pname, `value`)

  @PtrParameter([2])
  override fun glGetPathColorGenfvNV(
    color: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathColorGenfvNV(color, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetPathTexGenivNV(
    texCoordSet: Int,
    pname: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathTexGenivNV(texCoordSet, pname, `value`)

  override fun glGetPathTexGenfvNV(
    texCoordSet: Int,
    pname: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathTexGenfvNV(texCoordSet, pname, `value`)

  @PtrParameter([3])
  override fun glPathStringNV(
    path: Int,
    format: Int,
    length: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pathString$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathStringNV(path, format, length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pathString$0`.address)

  @PtrParameter([2])
  override fun glPathGlyphRangeNV(
    firstPathName: Int,
    fontTarget: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-fontName$0`: Ptr,
    fontStyle: Int,
    firstGlyph: Int,
    numGlyphs: Int,
    handleMissingGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathGlyphRangeNV(firstPathName, fontTarget,
      `$v$c$dev-luna5ama-kmogus-Ptr$-fontName$0`.address, fontStyle, firstGlyph, numGlyphs,
      handleMissingGlyphs, pathParameterTemplate, emScale)

  @PtrParameter([2, 5])
  override fun glPathCommandsNV(
    path: Int,
    numCommands: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-commands$0`: Ptr,
    numCoords: Int,
    coordType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathCommandsNV(path, numCommands,
      `$v$c$dev-luna5ama-kmogus-Ptr$-commands$0`.address, numCoords, coordType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`.address)

  override fun glStencilFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    fillMode: Int,
    mask: Int,
    transformType: Int,
    transformValues: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglStencilFillPathInstancedNV(numPaths, pathNameType,
      paths, pathBase, fillMode, mask, transformType, transformValues)

  override fun glInterpolatePathsNV(
    resultPath: Int,
    pathA: Int,
    pathB: Int,
    weight: Float,
  ): Unit = org.lwjgl.opengl.NVPathRendering.glInterpolatePathsNV(resultPath, pathA, pathB, weight)

  override fun glPathCoverDepthFuncNV(zfunc: Int): Unit =
      org.lwjgl.opengl.NVPathRendering.glPathCoverDepthFuncNV(zfunc)

  @PtrParameter([2])
  override fun glPathDashArrayNV(
    path: Int,
    dashCount: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-dashArray$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathDashArrayNV(path, dashCount,
      `$v$c$dev-luna5ama-kmogus-Ptr$-dashArray$0`.address)

  @PtrParameter([3])
  override fun glTransformPathNV(
    resultPath: Int,
    srcPath: Int,
    transformType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglTransformPathNV(resultPath, srcPath, transformType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-transformValues$0`.address)

  override fun glPathStencilFuncNV(
    func: Int,
    ref: Int,
    mask: Int,
  ): Unit = org.lwjgl.opengl.NVPathRendering.glPathStencilFuncNV(func, ref, mask)

  override fun glCoverStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglCoverStrokePathInstancedNV(numPaths, pathNameType,
      paths, pathBase, coverMode, transformType, transformValues)

  @PtrParameter([2])
  override fun glGetPathParameterivNV(
    path: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathParameterivNV(path, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glGetPathParameterfvNV(
    path: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathParameterfvNV(path, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glPathGlyphIndexArrayNV(
    firstPathName: Int,
    fontTarget: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-fontName$0`: Ptr,
    fontStyle: Int,
    firstGlyphIndex: Int,
    numGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
  ): Int = org.lwjgl.opengl.NVPathRendering.nglPathGlyphIndexArrayNV(firstPathName, fontTarget,
      `$v$c$dev-luna5ama-kmogus-Ptr$-fontName$0`.address, fontStyle, firstGlyphIndex, numGlyphs,
      pathParameterTemplate, emScale)

  override fun glStencilThenCoverStrokePathNV(
    path: Int,
    reference: Int,
    mask: Int,
    coverMode: Int,
  ): Unit = org.lwjgl.opengl.NVPathRendering.glStencilThenCoverStrokePathNV(path, reference, mask,
      coverMode)

  @PtrParameter([2])
  override fun glPathParameterfvNV(
    path: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathParameterfvNV(path, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([1])
  override fun glGetPathCommandsNV(path: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-commands$0`: Ptr): Unit
      = org.lwjgl.opengl.NVPathRendering.nglGetPathCommandsNV(path,
      `$v$c$dev-luna5ama-kmogus-Ptr$-commands$0`.address)

  @PtrParameter([1, 5])
  override fun glPathGlyphIndexRangeNV(
    fontTarget: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-fontName$0`: Ptr,
    fontStyle: Int,
    pathParameterTemplate: Int,
    emScale: Float,
    `$v$c$dev-luna5ama-kmogus-Ptr$-baseAndCount$0`: Ptr,
  ): Int = org.lwjgl.opengl.NVPathRendering.nglPathGlyphIndexRangeNV(fontTarget,
      `$v$c$dev-luna5ama-kmogus-Ptr$-fontName$0`.address, fontStyle, pathParameterTemplate, emScale,
      `$v$c$dev-luna5ama-kmogus-Ptr$-baseAndCount$0`.address)

  @PtrParameter([1])
  override fun glGetPathDashArrayNV(path: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-dashArray$0`: Ptr):
      Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathDashArrayNV(path,
      `$v$c$dev-luna5ama-kmogus-Ptr$-dashArray$0`.address)

  override fun glGetPathMetricRangeNV(
    metricQueryMask: Int,
    firstPathName: Int,
    numPaths: Int,
    stride: Int,
    metrics: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathMetricRangeNV(metricQueryMask, firstPathName,
      numPaths, stride, metrics)

  @PtrParameter([1])
  override fun glGetPathCoordsNV(path: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`: Ptr): Unit =
      org.lwjgl.opengl.NVPathRendering.nglGetPathCoordsNV(path,
      `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`.address)

  @PtrParameter([2])
  override fun glPathParameterivNV(
    path: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathParameterivNV(path, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glGetPathColorGenivNV(
    color: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathColorGenivNV(color, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([4])
  override fun glPathSubCoordsNV(
    path: Int,
    coordStart: Int,
    numCoords: Int,
    coordType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathSubCoordsNV(path, coordStart, numCoords,
      coordType, `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`.address)

  override fun glGetPathColorGenfvNV(
    color: Int,
    pname: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathColorGenfvNV(color, pname, `value`)

  @PtrParameter([2])
  override fun glGetPathTexGenivNV(
    texCoordSet: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathTexGenivNV(texCoordSet, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glGetPathTexGenfvNV(
    texCoordSet: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathTexGenfvNV(texCoordSet, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetPathParameterivNV(
    path: Int,
    pname: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathParameterivNV(path, pname, `value`)

  @PtrParameter([4, 7])
  override fun glPathSubCommandsNV(
    path: Int,
    commandStart: Int,
    commandsToDelete: Int,
    numCommands: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-commands$0`: Ptr,
    numCoords: Int,
    coordType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathSubCommandsNV(path, commandStart,
      commandsToDelete, numCommands, `$v$c$dev-luna5ama-kmogus-Ptr$-commands$0`.address, numCoords,
      coordType, `$v$c$dev-luna5ama-kmogus-Ptr$-coords$0`.address)

  override fun glStencilStrokePathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    reference: Int,
    mask: Int,
    transformType: Int,
    transformValues: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglStencilStrokePathInstancedNV(numPaths, pathNameType,
      paths, pathBase, reference, mask, transformType, transformValues)

  override fun glCoverStrokePathNV(path: Int, coverMode: Int): Unit =
      org.lwjgl.opengl.NVPathRendering.glCoverStrokePathNV(path, coverMode)

  override fun glProgramPathFragmentInputGenNV(
    program: Int,
    location: Int,
    genMode: Int,
    components: Int,
    coeffs: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglProgramPathFragmentInputGenNV(program, location,
      genMode, components, coeffs)

  override fun glCoverFillPathInstancedNV(
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    coverMode: Int,
    transformType: Int,
    transformValues: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglCoverFillPathInstancedNV(numPaths, pathNameType,
      paths, pathBase, coverMode, transformType, transformValues)

  override fun glStencilThenCoverFillPathNV(
    path: Int,
    fillMode: Int,
    mask: Int,
    coverMode: Int,
  ): Unit = org.lwjgl.opengl.NVPathRendering.glStencilThenCoverFillPathNV(path, fillMode, mask,
      coverMode)

  override fun glPathSubCommandsNV(
    path: Int,
    commandStart: Int,
    commandsToDelete: Int,
    numCommands: Int,
    commands: Long,
    numCoords: Int,
    coordType: Int,
    coords: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathSubCommandsNV(path, commandStart,
      commandsToDelete, numCommands, commands, numCoords, coordType, coords)

  override fun glGetPathCommandsNV(path: Int, commands: Long): Unit =
      org.lwjgl.opengl.NVPathRendering.nglGetPathCommandsNV(path, commands)

  @PtrParameter([2, 3])
  override fun glWeightPathsNV(
    resultPath: Int,
    numPaths: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglWeightPathsNV(resultPath, numPaths,
      `$v$c$dev-luna5ama-kmogus-Ptr$-paths$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`.address)

  override fun glPathGlyphIndexArrayNV(
    firstPathName: Int,
    fontTarget: Int,
    fontName: Long,
    fontStyle: Int,
    firstGlyphIndex: Int,
    numGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
  ): Int = org.lwjgl.opengl.NVPathRendering.nglPathGlyphIndexArrayNV(firstPathName, fontTarget,
      fontName, fontStyle, firstGlyphIndex, numGlyphs, pathParameterTemplate, emScale)

  override fun glPathMemoryGlyphIndexArrayNV(
    firstPathName: Int,
    fontTarget: Int,
    fontSize: Long,
    fontData: Long,
    faceIndex: Int,
    firstGlyphIndex: Int,
    numGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
  ): Int = org.lwjgl.opengl.NVPathRendering.nglPathMemoryGlyphIndexArrayNV(firstPathName,
      fontTarget, fontSize, fontData, faceIndex, firstGlyphIndex, numGlyphs, pathParameterTemplate,
      emScale)

  override fun glPathParameterivNV(
    path: Int,
    pname: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathParameterivNV(path, pname, `value`)

  override fun glStencilFillPathNV(
    path: Int,
    fillMode: Int,
    mask: Int,
  ): Unit = org.lwjgl.opengl.NVPathRendering.glStencilFillPathNV(path, fillMode, mask)

  override fun glPathParameterfvNV(
    path: Int,
    pname: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathParameterfvNV(path, pname, `value`)

  override fun glGetProgramResourcefvNV(
    program: Int,
    programInterface: Int,
    index: Int,
    propCount: Int,
    props: Long,
    bufSize: Int,
    length: Long,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetProgramResourcefvNV(program, programInterface,
      index, propCount, props, bufSize, length, params)

  @PtrParameter([1])
  override fun glMatrixMult3x3fNV(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixMult3x3fNV(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  @PtrParameter([4, 6, 7])
  override fun glGetProgramResourcefvNV(
    program: Int,
    programInterface: Int,
    index: Int,
    propCount: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-props$0`: Ptr,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetProgramResourcefvNV(program, programInterface,
      index, propCount, `$v$c$dev-luna5ama-kmogus-Ptr$-props$0`.address, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glIsPointInStrokePathNV(
    path: Int,
    x: Float,
    y: Float,
  ): Boolean = org.lwjgl.opengl.NVPathRendering.glIsPointInStrokePathNV(path, x, y)

  override fun glMatrixMultTranspose3x3fNV(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixMultTranspose3x3fNV(matrixMode, m)

  override fun glMatrixLoadTranspose3x3fNV(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixLoadTranspose3x3fNV(matrixMode, m)

  @PtrParameter([1])
  override fun glMatrixLoad3x2fNV(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixLoad3x2fNV(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  @PtrParameter([4, 5, 6, 7])
  override fun glPointAlongPathNV(
    path: Int,
    startSegment: Int,
    numSegments: Int,
    distance: Float,
    `$v$c$dev-luna5ama-kmogus-Ptr$-x$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-y$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-tangentX$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-tangentY$0`: Ptr,
  ): Boolean = org.lwjgl.opengl.NVPathRendering.nglPointAlongPathNV(path, startSegment, numSegments,
      distance, `$v$c$dev-luna5ama-kmogus-Ptr$-x$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-y$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-tangentX$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-tangentY$0`.address)

  @PtrParameter([1])
  override fun glMatrixMult3x2fNV(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixMult3x2fNV(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  override fun glIsPointInFillPathNV(
    path: Int,
    mask: Int,
    x: Float,
    y: Float,
  ): Boolean = org.lwjgl.opengl.NVPathRendering.glIsPointInFillPathNV(path, mask, x, y)

  @PtrParameter([1])
  override fun glMatrixLoad3x3fNV(matrixMode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`: Ptr): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixLoad3x3fNV(matrixMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-m$0`.address)

  override fun glPathCoordsNV(
    path: Int,
    numCoords: Int,
    coordType: Int,
    coords: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathCoordsNV(path, numCoords, coordType, coords)

  override fun glPathGlyphsNV(
    firstPathName: Int,
    fontTarget: Int,
    fontName: Long,
    fontStyle: Int,
    numGlyphs: Int,
    type: Int,
    charcodes: Long,
    handleMissingGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathGlyphsNV(firstPathName, fontTarget, fontName,
      fontStyle, numGlyphs, type, charcodes, handleMissingGlyphs, pathParameterTemplate, emScale)

  override fun glPathSubCoordsNV(
    path: Int,
    coordStart: Int,
    numCoords: Int,
    coordType: Int,
    coords: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathSubCoordsNV(path, coordStart, numCoords,
      coordType, coords)

  override fun glPathStringNV(
    path: Int,
    format: Int,
    length: Int,
    pathString: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathStringNV(path, format, length, pathString)

  override fun glPathCommandsNV(
    path: Int,
    numCommands: Int,
    commands: Long,
    numCoords: Int,
    coordType: Int,
    coords: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathCommandsNV(path, numCommands, commands,
      numCoords, coordType, coords)

  override fun glPathParameteriNV(
    path: Int,
    pname: Int,
    `value`: Int,
  ): Unit = org.lwjgl.opengl.NVPathRendering.glPathParameteriNV(path, pname, `value`)

  override fun glCopyPathNV(resultPath: Int, srcPath: Int): Unit =
      org.lwjgl.opengl.NVPathRendering.glCopyPathNV(resultPath, srcPath)

  override fun glPathParameterfNV(
    path: Int,
    pname: Int,
    `value`: Float,
  ): Unit = org.lwjgl.opengl.NVPathRendering.glPathParameterfNV(path, pname, `value`)

  override fun glPathGlyphRangeNV(
    firstPathName: Int,
    fontTarget: Int,
    fontName: Long,
    fontStyle: Int,
    firstGlyph: Int,
    numGlyphs: Int,
    handleMissingGlyphs: Int,
    pathParameterTemplate: Int,
    emScale: Float,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathGlyphRangeNV(firstPathName, fontTarget,
      fontName, fontStyle, firstGlyph, numGlyphs, handleMissingGlyphs, pathParameterTemplate,
      emScale)

  override fun glWeightPathsNV(
    resultPath: Int,
    numPaths: Int,
    paths: Long,
    weights: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglWeightPathsNV(resultPath, numPaths, paths, weights)

  override fun glTransformPathNV(
    resultPath: Int,
    srcPath: Int,
    transformType: Int,
    transformValues: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglTransformPathNV(resultPath, srcPath, transformType,
      transformValues)

  override fun glCoverFillPathNV(path: Int, coverMode: Int): Unit =
      org.lwjgl.opengl.NVPathRendering.glCoverFillPathNV(path, coverMode)

  override fun glIsPathNV(path: Int): Boolean = org.lwjgl.opengl.NVPathRendering.glIsPathNV(path)

  override fun glDeletePathsNV(path: Int, range: Int): Unit =
      org.lwjgl.opengl.NVPathRendering.glDeletePathsNV(path, range)

  override fun glPathFogGenNV(genMode: Int): Unit =
      org.lwjgl.opengl.NVPathRendering.glPathFogGenNV(genMode)

  override fun glGenPathsNV(range: Int): Int = org.lwjgl.opengl.NVPathRendering.glGenPathsNV(range)

  override fun glPathColorGenNV(
    color: Int,
    genMode: Int,
    colorFormat: Int,
    coeffs: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathColorGenNV(color, genMode, colorFormat, coeffs)

  override fun glPathDashArrayNV(
    path: Int,
    dashCount: Int,
    dashArray: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathDashArrayNV(path, dashCount, dashArray)

  override fun glPathTexGenNV(
    texCoordSet: Int,
    genMode: Int,
    components: Int,
    coeffs: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglPathTexGenNV(texCoordSet, genMode, components,
      coeffs)

  override fun glGetPathSpacingNV(
    pathListMode: Int,
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    advanceScale: Float,
    kerningScale: Float,
    transformType: Int,
    returnedSpacing: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathSpacingNV(pathListMode, numPaths,
      pathNameType, paths, pathBase, advanceScale, kerningScale, transformType, returnedSpacing)

  override fun glGetPathCoordsNV(path: Int, coords: Long): Unit =
      org.lwjgl.opengl.NVPathRendering.nglGetPathCoordsNV(path, coords)

  override fun glGetPathMetricsNV(
    metricQueryMask: Int,
    numPaths: Int,
    pathNameType: Int,
    paths: Long,
    pathBase: Int,
    stride: Int,
    metrics: Long,
  ): Unit = org.lwjgl.opengl.NVPathRendering.nglGetPathMetricsNV(metricQueryMask, numPaths,
      pathNameType, paths, pathBase, stride, metrics)

  override fun glGetPathLengthNV(
    path: Int,
    startSegment: Int,
    numSegments: Int,
  ): Float = org.lwjgl.opengl.NVPathRendering.glGetPathLengthNV(path, startSegment, numSegments)

  override fun glMatrixMult3x2fNV(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixMult3x2fNV(matrixMode, m)

  override fun glMatrixMult3x3fNV(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixMult3x3fNV(matrixMode, m)

  override fun glMatrixLoad3x2fNV(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixLoad3x2fNV(matrixMode, m)

  override fun glMatrixLoad3x3fNV(matrixMode: Int, m: Long): Unit =
      org.lwjgl.opengl.NVPathRendering.nglMatrixLoad3x3fNV(matrixMode, m)

  override fun glPointAlongPathNV(
    path: Int,
    startSegment: Int,
    numSegments: Int,
    distance: Float,
    x: Long,
    y: Long,
    tangentX: Long,
    tangentY: Long,
  ): Boolean = org.lwjgl.opengl.NVPathRendering.nglPointAlongPathNV(path, startSegment, numSegments,
      distance, x, y, tangentX, tangentY)
}
