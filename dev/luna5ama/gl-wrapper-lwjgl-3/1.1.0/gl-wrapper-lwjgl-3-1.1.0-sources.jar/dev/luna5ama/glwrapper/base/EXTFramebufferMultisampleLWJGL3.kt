package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTFramebufferMultisampleLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTFramebufferMultisample {
  override fun glRenderbufferStorageMultisampleEXT(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.EXTFramebufferMultisample.glRenderbufferStorageMultisampleEXT(target,
      samples, internalformat, width, height)
}
