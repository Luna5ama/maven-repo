package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBBindlessTextureLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBBindlessTexture {
  override fun glMakeImageHandleResidentARB(handle: Long, access: Int): Unit =
      org.lwjgl.opengl.ARBBindlessTexture.glMakeImageHandleResidentARB(handle, access)

  override fun glMakeImageHandleNonResidentARB(handle: Long): Unit =
      org.lwjgl.opengl.ARBBindlessTexture.glMakeImageHandleNonResidentARB(handle)

  override fun glGetTextureSamplerHandleARB(texture: Int, sampler: Int): Long =
      org.lwjgl.opengl.ARBBindlessTexture.glGetTextureSamplerHandleARB(texture, sampler)

  @PtrParameter([2])
  override fun glGetVertexAttribLui64vARB(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBBindlessTexture.nglGetVertexAttribLui64vARB(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glProgramUniformHandleui64vARB(
    program: Int,
    location: Int,
    count: Int,
    values: Long,
  ): Unit = org.lwjgl.opengl.ARBBindlessTexture.nglProgramUniformHandleui64vARB(program, location,
      count, values)

  override fun glProgramUniformHandleui64ARB(
    program: Int,
    location: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBBindlessTexture.glProgramUniformHandleui64ARB(program, location,
      `value`)

  override fun glMakeTextureHandleNonResidentARB(handle: Long): Unit =
      org.lwjgl.opengl.ARBBindlessTexture.glMakeTextureHandleNonResidentARB(handle)

  override fun glUniformHandleui64vARB(
    location: Int,
    count: Int,
    values: Long,
  ): Unit = org.lwjgl.opengl.ARBBindlessTexture.nglUniformHandleui64vARB(location, count, values)

  override fun glGetTextureHandleARB(texture: Int): Long =
      org.lwjgl.opengl.ARBBindlessTexture.glGetTextureHandleARB(texture)

  @PtrParameter([1])
  override fun glVertexAttribL1ui64vARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit
      = org.lwjgl.opengl.ARBBindlessTexture.nglVertexAttribL1ui64vARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glUniformHandleui64ARB(location: Int, `value`: Long): Unit =
      org.lwjgl.opengl.ARBBindlessTexture.glUniformHandleui64ARB(location, `value`)

  override fun glGetVertexAttribLui64vARB(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBBindlessTexture.nglGetVertexAttribLui64vARB(index, pname, params)

  override fun glIsImageHandleResidentARB(handle: Long): Boolean =
      org.lwjgl.opengl.ARBBindlessTexture.glIsImageHandleResidentARB(handle)

  override fun glGetImageHandleARB(
    texture: Int,
    level: Int,
    layered: Boolean,
    layer: Int,
    format: Int,
  ): Long = org.lwjgl.opengl.ARBBindlessTexture.glGetImageHandleARB(texture, level, layered, layer,
      format)

  override fun glVertexAttribL1ui64ARB(index: Int, x: Long): Unit =
      org.lwjgl.opengl.ARBBindlessTexture.glVertexAttribL1ui64ARB(index, x)

  override fun glVertexAttribL1ui64vARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBBindlessTexture.nglVertexAttribL1ui64vARB(index, v)

  override fun glIsTextureHandleResidentARB(handle: Long): Boolean =
      org.lwjgl.opengl.ARBBindlessTexture.glIsTextureHandleResidentARB(handle)

  override fun glMakeTextureHandleResidentARB(handle: Long): Unit =
      org.lwjgl.opengl.ARBBindlessTexture.glMakeTextureHandleResidentARB(handle)

  @PtrParameter([2])
  override fun glUniformHandleui64vARB(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBBindlessTexture.nglUniformHandleui64vARB(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  @PtrParameter([3])
  override fun glProgramUniformHandleui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBBindlessTexture.nglProgramUniformHandleui64vARB(program, location,
      count, `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)
}
