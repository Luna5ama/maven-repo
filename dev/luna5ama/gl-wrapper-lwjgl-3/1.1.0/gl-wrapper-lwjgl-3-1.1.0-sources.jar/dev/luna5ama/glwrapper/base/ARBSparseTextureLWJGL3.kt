package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Unit

public class ARBSparseTextureLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBSparseTexture {
  override fun glTexPageCommitmentARB(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    commit: Boolean,
  ): Unit = org.lwjgl.opengl.ARBSparseTexture.glTexPageCommitmentARB(target, level, xoffset,
      yoffset, zoffset, width, height, depth, commit)

  override fun glTexturePageCommitmentEXT(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    commit: Boolean,
  ): Unit = org.lwjgl.opengl.ARBSparseTexture.glTexturePageCommitmentEXT(texture, level, xoffset,
      yoffset, zoffset, width, height, depth, commit)
}
