package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVGPUMulticastLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVGPUMulticast {
  @PtrParameter([4])
  override fun glMulticastFramebufferSampleLocationsfvNV(
    gpu: Int,
    framebuffer: Int,
    start: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastFramebufferSampleLocationsfvNV(gpu,
      framebuffer, start, count, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glMulticastFramebufferSampleLocationsfvNV(
    gpu: Int,
    framebuffer: Int,
    start: Int,
    count: Int,
    v: Long,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastFramebufferSampleLocationsfvNV(gpu,
      framebuffer, start, count, v)

  @PtrParameter([3])
  override fun glMulticastGetQueryObjectivNV(
    gpu: Int,
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastGetQueryObjectivNV(gpu, id, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glMulticastGetQueryObjectuivNV(
    gpu: Int,
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastGetQueryObjectuivNV(gpu, id, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glMulticastGetQueryObjecti64vNV(
    gpu: Int,
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastGetQueryObjecti64vNV(gpu, id, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glMulticastGetQueryObjectui64vNV(
    gpu: Int,
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastGetQueryObjectui64vNV(gpu, id, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glMulticastBarrierNV(): Unit = org.lwjgl.opengl.NVGPUMulticast.glMulticastBarrierNV()

  override fun glMulticastGetQueryObjectivNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastGetQueryObjectivNV(gpu, id, pname, params)

  override fun glMulticastGetQueryObjecti64vNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastGetQueryObjecti64vNV(gpu, id, pname, params)

  @PtrParameter([4])
  override fun glMulticastBufferSubDataNV(
    gpuMask: Int,
    buffer: Int,
    offset: Long,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastBufferSubDataNV(gpuMask, buffer, offset,
      size, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glMulticastCopyImageSubDataNV(
    srcGpu: Int,
    dstGpuMask: Int,
    srcName: Int,
    srcTarget: Int,
    srcLevel: Int,
    srcX: Int,
    srxY: Int,
    srcZ: Int,
    dstName: Int,
    dstTarget: Int,
    dstLevel: Int,
    dstX: Int,
    dstY: Int,
    dstZ: Int,
    srcWidth: Int,
    srcHeight: Int,
    srcDepth: Int,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.glMulticastCopyImageSubDataNV(srcGpu, dstGpuMask,
      srcName, srcTarget, srcLevel, srcX, srxY, srcZ, dstName, dstTarget, dstLevel, dstX, dstY,
      dstZ, srcWidth, srcHeight, srcDepth)

  override fun glMulticastCopyBufferSubDataNV(
    readGpu: Int,
    writeGpuMask: Int,
    readBuffer: Int,
    writeBuffer: Int,
    readOffset: Long,
    writeOffset: Long,
    size: Long,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.glMulticastCopyBufferSubDataNV(readGpu, writeGpuMask,
      readBuffer, writeBuffer, readOffset, writeOffset, size)

  override fun glMulticastBlitFramebufferNV(
    srcGpu: Int,
    dstGpu: Int,
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    mask: Int,
    filter: Int,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.glMulticastBlitFramebufferNV(srcGpu, dstGpu, srcX0,
      srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter)

  override fun glMulticastGetQueryObjectui64vNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastGetQueryObjectui64vNV(gpu, id, pname,
      params)

  override fun glMulticastWaitSyncNV(signalGpu: Int, waitGpuMask: Int): Unit =
      org.lwjgl.opengl.NVGPUMulticast.glMulticastWaitSyncNV(signalGpu, waitGpuMask)

  override fun glMulticastGetQueryObjectuivNV(
    gpu: Int,
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastGetQueryObjectuivNV(gpu, id, pname, params)

  override fun glMulticastBufferSubDataNV(
    gpuMask: Int,
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.NVGPUMulticast.nglMulticastBufferSubDataNV(gpuMask, buffer, offset,
      size, `data`)

  override fun glRenderGpuMaskNV(mask: Int): Unit =
      org.lwjgl.opengl.NVGPUMulticast.glRenderGpuMaskNV(mask)
}
