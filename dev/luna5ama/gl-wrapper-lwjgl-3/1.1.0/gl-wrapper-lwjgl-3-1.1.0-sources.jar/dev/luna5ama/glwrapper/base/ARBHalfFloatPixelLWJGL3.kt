package dev.luna5ama.glwrapper.base

public class ARBHalfFloatPixelLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBHalfFloatPixel
