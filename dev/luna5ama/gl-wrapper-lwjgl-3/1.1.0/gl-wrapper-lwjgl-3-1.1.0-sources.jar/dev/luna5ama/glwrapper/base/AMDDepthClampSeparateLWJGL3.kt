package dev.luna5ama.glwrapper.base

public class AMDDepthClampSeparateLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDDepthClampSeparate
