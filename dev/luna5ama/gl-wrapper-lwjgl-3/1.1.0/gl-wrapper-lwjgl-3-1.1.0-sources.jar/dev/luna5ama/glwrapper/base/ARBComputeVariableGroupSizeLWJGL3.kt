package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class ARBComputeVariableGroupSizeLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBComputeVariableGroupSize {
  override fun glDispatchComputeGroupSizeARB(
    num_groups_x: Int,
    num_groups_y: Int,
    num_groups_z: Int,
    group_size_x: Int,
    group_size_y: Int,
    group_size_z: Int,
  ): Unit = org.lwjgl.opengl.ARBComputeVariableGroupSize.glDispatchComputeGroupSizeARB(num_groups_x,
      num_groups_y, num_groups_z, group_size_x, group_size_y, group_size_z)
}
