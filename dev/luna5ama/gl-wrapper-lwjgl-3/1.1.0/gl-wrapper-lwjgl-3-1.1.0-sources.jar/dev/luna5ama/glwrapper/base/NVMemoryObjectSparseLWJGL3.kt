package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVMemoryObjectSparseLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVMemoryObjectSparse {
  override fun glTexturePageCommitmentMemNV(
    texture: Int,
    layer: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    memory: Int,
    offset: Long,
    commit: Boolean,
  ): Unit = org.lwjgl.opengl.NVMemoryObjectSparse.glTexturePageCommitmentMemNV(texture, layer,
      level, xoffset, yoffset, zoffset, width, height, depth, memory, offset, commit)

  override fun glBufferPageCommitmentMemNV(
    target: Int,
    offset: Long,
    size: Long,
    memory: Int,
    memOffset: Long,
    commit: Boolean,
  ): Unit = org.lwjgl.opengl.NVMemoryObjectSparse.glBufferPageCommitmentMemNV(target, offset, size,
      memory, memOffset, commit)

  override fun glNamedBufferPageCommitmentMemNV(
    buffer: Int,
    offset: Long,
    size: Long,
    memory: Int,
    memOffset: Long,
    commit: Boolean,
  ): Unit = org.lwjgl.opengl.NVMemoryObjectSparse.glNamedBufferPageCommitmentMemNV(buffer, offset,
      size, memory, memOffset, commit)

  override fun glTexPageCommitmentMemNV(
    target: Int,
    layer: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    memory: Int,
    offset: Long,
    commit: Boolean,
  ): Unit = org.lwjgl.opengl.NVMemoryObjectSparse.glTexPageCommitmentMemNV(target, layer, level,
      xoffset, yoffset, zoffset, width, height, depth, memory, offset, commit)
}
