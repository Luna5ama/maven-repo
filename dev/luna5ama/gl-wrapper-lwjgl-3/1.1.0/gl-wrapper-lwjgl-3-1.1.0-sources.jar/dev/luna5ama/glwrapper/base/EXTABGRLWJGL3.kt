package dev.luna5ama.glwrapper.base

public class EXTABGRLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTABGR
