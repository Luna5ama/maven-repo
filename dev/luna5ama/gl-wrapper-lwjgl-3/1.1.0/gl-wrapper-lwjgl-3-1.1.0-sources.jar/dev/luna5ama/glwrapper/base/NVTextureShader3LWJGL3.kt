package dev.luna5ama.glwrapper.base

public class NVTextureShader3LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVTextureShader3
