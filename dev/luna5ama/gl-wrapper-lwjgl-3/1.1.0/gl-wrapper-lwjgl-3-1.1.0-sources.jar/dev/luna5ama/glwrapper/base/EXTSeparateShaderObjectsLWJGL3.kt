package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTSeparateShaderObjectsLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTSeparateShaderObjects {
  override fun glActiveProgramEXT(program: Int): Unit =
      org.lwjgl.opengl.EXTSeparateShaderObjects.glActiveProgramEXT(program)

  override fun glUseShaderProgramEXT(type: Int, program: Int): Unit =
      org.lwjgl.opengl.EXTSeparateShaderObjects.glUseShaderProgramEXT(type, program)

  override fun glCreateShaderProgramEXT(type: Int, string: Long): Int =
      org.lwjgl.opengl.EXTSeparateShaderObjects.nglCreateShaderProgramEXT(type, string)

  @PtrParameter([1])
  override fun glCreateShaderProgramEXT(type: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`: Ptr):
      Int = org.lwjgl.opengl.EXTSeparateShaderObjects.nglCreateShaderProgramEXT(type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`.address)
}
