package dev.luna5ama.glwrapper.base

public class EXTTextureCompressionLATCLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureCompressionLATC
