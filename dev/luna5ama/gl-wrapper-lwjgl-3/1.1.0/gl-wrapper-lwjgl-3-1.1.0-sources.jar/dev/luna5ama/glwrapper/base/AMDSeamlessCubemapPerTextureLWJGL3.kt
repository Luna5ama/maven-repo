package dev.luna5ama.glwrapper.base

public class AMDSeamlessCubemapPerTextureLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDSeamlessCubemapPerTexture
