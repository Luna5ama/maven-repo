package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL33C

public class GL33LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL33 {
  @PtrParameter([3])
  override fun glBindFragDataLocationIndexed(
    program: Int,
    colorNumber: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = GL33C.nglBindFragDataLocationIndexed(program, colorNumber, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([2])
  override fun glSamplerParameterfv(
    sampler: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglSamplerParameterfv(sampler, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glVertexAttribP2uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL33C.nglVertexAttribP2uiv(index, type, normalized,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetSamplerParameterIiv(
    sampler: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglGetSamplerParameterIiv(sampler, pname, params)

  override fun glSamplerParameterIuiv(
    sampler: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglSamplerParameterIuiv(sampler, pname, params)

  @PtrParameter([2])
  override fun glGetSamplerParameterIiv(
    sampler: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglGetSamplerParameterIiv(sampler, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glGenSamplers(count: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-samplers$0`: Ptr): Unit =
      GL33C.nglGenSamplers(count, `$v$c$dev-luna5ama-kmogus-Ptr$-samplers$0`.address)

  override fun glGetSamplerParameteriv(
    sampler: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglGetSamplerParameteriv(sampler, pname, params)

  @PtrParameter([2])
  override fun glGetQueryObjectui64v(
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglGetQueryObjectui64v(id, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetQueryObjectui64v(
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglGetQueryObjectui64v(id, pname, params)

  @PtrParameter([3])
  override fun glVertexAttribP4uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL33C.nglVertexAttribP4uiv(index, type, normalized,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glGetQueryObjecti64v(
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglGetQueryObjecti64v(id, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glSamplerParameteri(
    sampler: Int,
    pname: Int,
    `param`: Int,
  ): Unit = GL33C.glSamplerParameteri(sampler, pname, `param`)

  override fun glVertexAttribP3uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Long,
  ): Unit = GL33C.nglVertexAttribP3uiv(index, type, normalized, `value`)

  override fun glSamplerParameterfv(
    sampler: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglSamplerParameterfv(sampler, pname, params)

  @PtrParameter([2])
  override fun glSamplerParameterIuiv(
    sampler: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglSamplerParameterIuiv(sampler, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glSamplerParameterIiv(
    sampler: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglSamplerParameterIiv(sampler, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glSamplerParameterf(
    sampler: Int,
    pname: Int,
    `param`: Float,
  ): Unit = GL33C.glSamplerParameterf(sampler, pname, `param`)

  override fun glSamplerParameteriv(
    sampler: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglSamplerParameteriv(sampler, pname, params)

  @PtrParameter([2])
  override fun glGetSamplerParameterIuiv(
    sampler: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglGetSamplerParameterIuiv(sampler, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glVertexAttribP4uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Long,
  ): Unit = GL33C.nglVertexAttribP4uiv(index, type, normalized, `value`)

  @PtrParameter([2])
  override fun glGetSamplerParameteriv(
    sampler: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglGetSamplerParameteriv(sampler, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetSamplerParameterIuiv(
    sampler: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglGetSamplerParameterIuiv(sampler, pname, params)

  override fun glVertexAttribDivisor(index: Int, divisor: Int): Unit =
      GL33C.glVertexAttribDivisor(index, divisor)

  @PtrParameter([1])
  override fun glDeleteSamplers(count: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-samplers$0`: Ptr): Unit =
      GL33C.nglDeleteSamplers(count, `$v$c$dev-luna5ama-kmogus-Ptr$-samplers$0`.address)

  override fun glVertexAttribP1uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Long,
  ): Unit = GL33C.nglVertexAttribP1uiv(index, type, normalized, `value`)

  @PtrParameter([2])
  override fun glGetSamplerParameterfv(
    sampler: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglGetSamplerParameterfv(sampler, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glBindFragDataLocationIndexed(
    program: Int,
    colorNumber: Int,
    index: Int,
    name: Long,
  ): Unit = GL33C.nglBindFragDataLocationIndexed(program, colorNumber, index, name)

  override fun glGetSamplerParameterfv(
    sampler: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglGetSamplerParameterfv(sampler, pname, params)

  @PtrParameter([3])
  override fun glVertexAttribP3uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL33C.nglVertexAttribP3uiv(index, type, normalized,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glVertexAttribP2uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Long,
  ): Unit = GL33C.nglVertexAttribP2uiv(index, type, normalized, `value`)

  @PtrParameter([1])
  override fun glGetFragDataIndex(program: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr): Int =
      GL33C.nglGetFragDataIndex(program, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([2])
  override fun glSamplerParameteriv(
    sampler: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL33C.nglSamplerParameteriv(sampler, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetQueryObjecti64v(
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglGetQueryObjecti64v(id, pname, params)

  override fun glSamplerParameterIiv(
    sampler: Int,
    pname: Int,
    params: Long,
  ): Unit = GL33C.nglSamplerParameterIiv(sampler, pname, params)

  @PtrParameter([3])
  override fun glVertexAttribP1uiv(
    index: Int,
    type: Int,
    normalized: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL33C.nglVertexAttribP1uiv(index, type, normalized,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glVertexAttribP2ui(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Int,
  ): Unit = GL33C.glVertexAttribP2ui(index, type, normalized, `value`)

  override fun glQueryCounter(id: Int, target: Int): Unit = GL33C.glQueryCounter(id, target)

  override fun glBindSampler(unit: Int, sampler: Int): Unit = GL33C.glBindSampler(unit, sampler)

  override fun glIsSampler(sampler: Int): Boolean = GL33C.glIsSampler(sampler)

  override fun glVertexAttribP4ui(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Int,
  ): Unit = GL33C.glVertexAttribP4ui(index, type, normalized, `value`)

  override fun glGenSamplers(count: Int, samplers: Long): Unit = GL33C.nglGenSamplers(count,
      samplers)

  override fun glGetFragDataIndex(program: Int, name: Long): Int =
      GL33C.nglGetFragDataIndex(program, name)

  override fun glVertexAttribP3ui(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Int,
  ): Unit = GL33C.glVertexAttribP3ui(index, type, normalized, `value`)

  override fun glDeleteSamplers(sampler: Int): Unit = GL33C.glDeleteSamplers(sampler)

  override fun glDeleteSamplers(count: Int, samplers: Long): Unit = GL33C.nglDeleteSamplers(count,
      samplers)

  override fun glVertexAttribP1ui(
    index: Int,
    type: Int,
    normalized: Boolean,
    `value`: Int,
  ): Unit = GL33C.glVertexAttribP1ui(index, type, normalized, `value`)
}
