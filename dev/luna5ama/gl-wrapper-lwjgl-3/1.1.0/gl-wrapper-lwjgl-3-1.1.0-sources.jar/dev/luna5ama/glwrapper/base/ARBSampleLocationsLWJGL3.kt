package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBSampleLocationsLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBSampleLocations {
  override fun glNamedFramebufferSampleLocationsfvARB(
    framebuffer: Int,
    start: Int,
    count: Int,
    v: Long,
  ): Unit = org.lwjgl.opengl.ARBSampleLocations.nglNamedFramebufferSampleLocationsfvARB(framebuffer,
      start, count, v)

  @PtrParameter([3])
  override fun glNamedFramebufferSampleLocationsfvARB(
    framebuffer: Int,
    start: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBSampleLocations.nglNamedFramebufferSampleLocationsfvARB(framebuffer,
      start, count, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([3])
  override fun glFramebufferSampleLocationsfvARB(
    target: Int,
    start: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBSampleLocations.nglFramebufferSampleLocationsfvARB(target, start,
      count, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glFramebufferSampleLocationsfvARB(
    target: Int,
    start: Int,
    count: Int,
    v: Long,
  ): Unit = org.lwjgl.opengl.ARBSampleLocations.nglFramebufferSampleLocationsfvARB(target, start,
      count, v)

  override fun glEvaluateDepthValuesARB(): Unit =
      org.lwjgl.opengl.ARBSampleLocations.glEvaluateDepthValuesARB()
}
