package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class NVAlphaToCoverageDitherControlLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVAlphaToCoverageDitherControl {
  override fun glAlphaToCoverageDitherControlNV(mode: Int): Unit =
      org.lwjgl.opengl.NVAlphaToCoverageDitherControl.glAlphaToCoverageDitherControlNV(mode)
}
