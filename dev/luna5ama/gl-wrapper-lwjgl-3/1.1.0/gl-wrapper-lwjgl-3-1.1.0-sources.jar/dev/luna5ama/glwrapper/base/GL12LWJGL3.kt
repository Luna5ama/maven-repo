package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL12C

public class GL12LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL12 {
  override fun glTexImage3D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL12C.nglTexImage3D(target, level, internalformat, width, height, depth, border, format,
      type, pixels)

  override fun glTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL12C.nglTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth,
      format, type, pixels)

  @PtrParameter([9])
  override fun glTexImage3D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL12C.nglTexImage3D(target, level, internalformat, width, height, depth, border, format,
      type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([10])
  override fun glTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL12C.nglTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth,
      format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([5])
  override fun glDrawRangeElements(
    mode: Int,
    start: Int,
    end: Int,
    count: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
  ): Unit = GL12C.nglDrawRangeElements(mode, start, end, count, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address)

  override fun glCopyTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = GL12C.glCopyTexSubImage3D(target, level, xoffset, yoffset, zoffset, x, y, width, height)

  override fun glDrawRangeElements(
    mode: Int,
    start: Int,
    end: Int,
    count: Int,
    type: Int,
    indices: Long,
  ): Unit = GL12C.nglDrawRangeElements(mode, start, end, count, type, indices)
}
