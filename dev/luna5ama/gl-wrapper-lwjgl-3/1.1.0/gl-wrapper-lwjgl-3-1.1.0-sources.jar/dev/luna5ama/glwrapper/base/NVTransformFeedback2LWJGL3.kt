package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVTransformFeedback2LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVTransformFeedback2 {
  @PtrParameter([1])
  override fun glDeleteTransformFeedbacksNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr):
      Unit = org.lwjgl.opengl.NVTransformFeedback2.nglDeleteTransformFeedbacksNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address)

  override fun glIsTransformFeedbackNV(id: Int): Boolean =
      org.lwjgl.opengl.NVTransformFeedback2.glIsTransformFeedbackNV(id)

  override fun glBindTransformFeedbackNV(target: Int, id: Int): Unit =
      org.lwjgl.opengl.NVTransformFeedback2.glBindTransformFeedbackNV(target, id)

  override fun glPauseTransformFeedbackNV(): Unit =
      org.lwjgl.opengl.NVTransformFeedback2.glPauseTransformFeedbackNV()

  override fun glResumeTransformFeedbackNV(): Unit =
      org.lwjgl.opengl.NVTransformFeedback2.glResumeTransformFeedbackNV()

  override fun glGenTransformFeedbacksNV(n: Int, ids: Long): Unit =
      org.lwjgl.opengl.NVTransformFeedback2.nglGenTransformFeedbacksNV(n, ids)

  override fun glDrawTransformFeedbackNV(mode: Int, id: Int): Unit =
      org.lwjgl.opengl.NVTransformFeedback2.glDrawTransformFeedbackNV(mode, id)

  override fun glDeleteTransformFeedbacksNV(n: Int, ids: Long): Unit =
      org.lwjgl.opengl.NVTransformFeedback2.nglDeleteTransformFeedbacksNV(n, ids)

  @PtrParameter([1])
  override fun glGenTransformFeedbacksNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr): Unit =
      org.lwjgl.opengl.NVTransformFeedback2.nglGenTransformFeedbacksNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address)
}
