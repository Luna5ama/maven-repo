package dev.luna5ama.glwrapper.base

public class EXT422PixelsLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXT422Pixels
