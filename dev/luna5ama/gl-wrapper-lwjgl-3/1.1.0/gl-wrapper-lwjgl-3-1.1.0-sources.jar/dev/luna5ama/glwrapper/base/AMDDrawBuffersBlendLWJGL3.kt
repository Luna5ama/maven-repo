package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class AMDDrawBuffersBlendLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDDrawBuffersBlend {
  override fun glBlendFuncIndexedAMD(
    buf: Int,
    src: Int,
    dst: Int,
  ): Unit = org.lwjgl.opengl.AMDDrawBuffersBlend.glBlendFuncIndexedAMD(buf, src, dst)

  override fun glBlendFuncSeparateIndexedAMD(
    buf: Int,
    srcRGB: Int,
    dstRGB: Int,
    srcAlpha: Int,
    dstAlpha: Int,
  ): Unit = org.lwjgl.opengl.AMDDrawBuffersBlend.glBlendFuncSeparateIndexedAMD(buf, srcRGB, dstRGB,
      srcAlpha, dstAlpha)

  override fun glBlendEquationSeparateIndexedAMD(
    buf: Int,
    modeRGB: Int,
    modeAlpha: Int,
  ): Unit = org.lwjgl.opengl.AMDDrawBuffersBlend.glBlendEquationSeparateIndexedAMD(buf, modeRGB,
      modeAlpha)

  override fun glBlendEquationIndexedAMD(buf: Int, mode: Int): Unit =
      org.lwjgl.opengl.AMDDrawBuffersBlend.glBlendEquationIndexedAMD(buf, mode)
}
