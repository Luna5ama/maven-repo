package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class NVFramebufferMultisampleCoverageLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVFramebufferMultisampleCoverage {
  override fun glRenderbufferStorageMultisampleCoverageNV(
    target: Int,
    coverageSamples: Int,
    colorSamples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit =
      org.lwjgl.opengl.NVFramebufferMultisampleCoverage.glRenderbufferStorageMultisampleCoverageNV(target,
      coverageSamples, colorSamples, internalformat, width, height)
}
