package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Unit

public class AMDVertexShaderTessellatorLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDVertexShaderTessellator {
  override fun glTessellationModeAMD(mode: Int): Unit =
      org.lwjgl.opengl.AMDVertexShaderTessellator.glTessellationModeAMD(mode)

  override fun glTessellationFactorAMD(factor: Float): Unit =
      org.lwjgl.opengl.AMDVertexShaderTessellator.glTessellationFactorAMD(factor)
}
