package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVVertexAttribInteger64bitLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVVertexAttribInteger64bit {
  override fun glVertexAttribL1i64vNV(index: Int, v: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL1i64vNV(index, v)

  @PtrParameter([1])
  override fun glVertexAttribL3i64vNV(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL3i64vNV(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL3i64vNV(index: Int, v: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL3i64vNV(index, v)

  @PtrParameter([1])
  override fun glVertexAttribL4i64vNV(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL4i64vNV(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL2i64vNV(index: Int, v: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL2i64vNV(index, v)

  override fun glVertexAttribL4i64vNV(index: Int, v: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL4i64vNV(index, v)

  override fun glVertexAttribL1ui64NV(index: Int, x: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.glVertexAttribL1ui64NV(index, x)

  override fun glVertexAttribL2ui64NV(
    index: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.glVertexAttribL2ui64NV(index, x, y)

  override fun glVertexAttribL3ui64NV(
    index: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.glVertexAttribL3ui64NV(index, x, y, z)

  override fun glVertexAttribL4ui64NV(
    index: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.glVertexAttribL4ui64NV(index, x, y, z, w)

  @PtrParameter([1])
  override fun glVertexAttribL1ui64vNV(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL1ui64vNV(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL1ui64vNV(index: Int, v: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL1ui64vNV(index, v)

  @PtrParameter([1])
  override fun glVertexAttribL2ui64vNV(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL2ui64vNV(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL2i64NV(
    index: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.glVertexAttribL2i64NV(index, x, y)

  override fun glVertexAttribL3i64NV(
    index: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.glVertexAttribL3i64NV(index, x, y, z)

  override fun glVertexAttribL4i64NV(
    index: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.glVertexAttribL4i64NV(index, x, y, z, w)

  @PtrParameter([1])
  override fun glVertexAttribL1i64vNV(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL1i64vNV(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL1i64NV(index: Int, x: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.glVertexAttribL1i64NV(index, x)

  @PtrParameter([1])
  override fun glVertexAttribL2i64vNV(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL2i64vNV(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glGetVertexAttribLui64vNV(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.nglGetVertexAttribLui64vNV(index, pname,
      params)

  override fun glVertexAttribL4ui64vNV(index: Int, v: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL4ui64vNV(index, v)

  @PtrParameter([2])
  override fun glGetVertexAttribLi64vNV(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.nglGetVertexAttribLi64vNV(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glVertexAttribL3ui64vNV(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL3ui64vNV(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL2ui64vNV(index: Int, v: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL2ui64vNV(index, v)

  @PtrParameter([2])
  override fun glGetVertexAttribLui64vNV(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.nglGetVertexAttribLui64vNV(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glVertexAttribLFormatNV(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.glVertexAttribLFormatNV(index, size, type,
      stride)

  override fun glGetVertexAttribLi64vNV(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVVertexAttribInteger64bit.nglGetVertexAttribLi64vNV(index, pname,
      params)

  @PtrParameter([1])
  override fun glVertexAttribL4ui64vNV(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL4ui64vNV(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL3ui64vNV(index: Int, v: Long): Unit =
      org.lwjgl.opengl.NVVertexAttribInteger64bit.nglVertexAttribL3ui64vNV(index, v)
}
