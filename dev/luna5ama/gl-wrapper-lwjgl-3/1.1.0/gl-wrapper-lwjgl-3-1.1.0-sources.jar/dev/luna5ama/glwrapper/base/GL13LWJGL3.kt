package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL13C

public class GL13LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL13 {
  override fun glSampleCoverage(`value`: Float, invert: Boolean): Unit =
      GL13C.glSampleCoverage(`value`, invert)

  override fun glActiveTexture(texture: Int): Unit = GL13C.glActiveTexture(texture)

  @PtrParameter([8])
  override fun glCompressedTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL13C.nglCompressedTexSubImage2D(target, level, xoffset, yoffset, width, height, format,
      imageSize, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([6])
  override fun glCompressedTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL13C.nglCompressedTexSubImage1D(target, level, xoffset, width, format, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([2])
  override fun glGetCompressedTexImage(
    target: Int,
    level: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL13C.nglGetCompressedTexImage(target, level,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([6])
  override fun glCompressedTexImage1D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL13C.nglCompressedTexImage1D(target, level, internalformat, width, border, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glCompressedTexImage1D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = GL13C.nglCompressedTexImage1D(target, level, internalformat, width, border, imageSize,
      `data`)

  override fun glCompressedTexImage2D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = GL13C.nglCompressedTexImage2D(target, level, internalformat, width, height, border,
      imageSize, `data`)

  override fun glCompressedTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = GL13C.nglCompressedTexSubImage1D(target, level, xoffset, width, format, imageSize,
      `data`)

  @PtrParameter([10])
  override fun glCompressedTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL13C.nglCompressedTexSubImage3D(target, level, xoffset, yoffset, zoffset, width,
      height, depth, format, imageSize, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([8])
  override fun glCompressedTexImage3D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL13C.nglCompressedTexImage3D(target, level, internalformat, width, height, depth,
      border, imageSize, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glCompressedTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = GL13C.nglCompressedTexSubImage2D(target, level, xoffset, yoffset, width, height, format,
      imageSize, `data`)

  override fun glCompressedTexImage3D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    border: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = GL13C.nglCompressedTexImage3D(target, level, internalformat, width, height, depth,
      border, imageSize, `data`)

  override fun glGetCompressedTexImage(
    target: Int,
    level: Int,
    pixels: Long,
  ): Unit = GL13C.nglGetCompressedTexImage(target, level, pixels)

  @PtrParameter([7])
  override fun glCompressedTexImage2D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL13C.nglCompressedTexImage2D(target, level, internalformat, width, height, border,
      imageSize, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glCompressedTexSubImage3D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = GL13C.nglCompressedTexSubImage3D(target, level, xoffset, yoffset, zoffset, width,
      height, depth, format, imageSize, `data`)
}
