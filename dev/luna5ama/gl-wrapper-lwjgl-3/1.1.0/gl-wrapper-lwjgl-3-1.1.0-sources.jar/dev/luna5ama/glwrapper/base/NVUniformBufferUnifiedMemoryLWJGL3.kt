package dev.luna5ama.glwrapper.base

public class NVUniformBufferUnifiedMemoryLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVUniformBufferUnifiedMemory
