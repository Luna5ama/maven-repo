package dev.luna5ama.glwrapper.base

public class NVFogDistanceLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVFogDistance
