package dev.luna5ama.glwrapper.base

public class NVBlendMinmaxFactorLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVBlendMinmaxFactor
