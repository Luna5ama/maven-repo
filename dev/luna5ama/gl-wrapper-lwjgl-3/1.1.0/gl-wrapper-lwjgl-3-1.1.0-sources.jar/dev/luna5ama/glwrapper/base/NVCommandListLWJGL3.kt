package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Short
import kotlin.Unit

public class NVCommandListLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVCommandList {
  @PtrParameter([0, 1, 2, 3])
  override fun glDrawCommandsStatesAddressNV(
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-fbos$0`: Ptr,
    count: Int,
  ): Unit =
      org.lwjgl.opengl.NVCommandList.nglDrawCommandsStatesAddressNV(`$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-fbos$0`.address, count)

  @PtrParameter([2, 3, 4, 5])
  override fun glListDrawCommandsStatesClientNV(
    list: Int,
    segment: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-fbos$0`: Ptr,
    count: Int,
  ): Unit = org.lwjgl.opengl.NVCommandList.nglListDrawCommandsStatesClientNV(list, segment,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-fbos$0`.address, count)

  override fun glDeleteCommandListsNV(n: Int, lists: Long): Unit =
      org.lwjgl.opengl.NVCommandList.nglDeleteCommandListsNV(n, lists)

  override fun glDrawCommandsAddressNV(
    primitiveMode: Int,
    indirects: Long,
    sizes: Long,
    count: Int,
  ): Unit = org.lwjgl.opengl.NVCommandList.nglDrawCommandsAddressNV(primitiveMode, indirects, sizes,
      count)

  @PtrParameter([1])
  override fun glDeleteCommandListsNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-lists$0`: Ptr): Unit =
      org.lwjgl.opengl.NVCommandList.nglDeleteCommandListsNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-lists$0`.address)

  override fun glCompileCommandListNV(list: Int): Unit =
      org.lwjgl.opengl.NVCommandList.glCompileCommandListNV(list)

  override fun glCallCommandListNV(list: Int): Unit =
      org.lwjgl.opengl.NVCommandList.glCallCommandListNV(list)

  override fun glCommandListSegmentsNV(list: Int, segments: Int): Unit =
      org.lwjgl.opengl.NVCommandList.glCommandListSegmentsNV(list, segments)

  override fun glGetCommandHeaderNV(tokenID: Int, size: Int): Int =
      org.lwjgl.opengl.NVCommandList.glGetCommandHeaderNV(tokenID, size)

  override fun glCreateCommandListsNV(n: Int, lists: Long): Unit =
      org.lwjgl.opengl.NVCommandList.nglCreateCommandListsNV(n, lists)

  @PtrParameter([1])
  override fun glCreateStatesNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`: Ptr): Unit =
      org.lwjgl.opengl.NVCommandList.nglCreateStatesNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`.address)

  override fun glDrawCommandsStatesAddressNV(
    indirects: Long,
    sizes: Long,
    states: Long,
    fbos: Long,
    count: Int,
  ): Unit = org.lwjgl.opengl.NVCommandList.nglDrawCommandsStatesAddressNV(indirects, sizes, states,
      fbos, count)

  @PtrParameter([1, 2])
  override fun glDrawCommandsAddressNV(
    primitiveMode: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`: Ptr,
    count: Int,
  ): Unit = org.lwjgl.opengl.NVCommandList.nglDrawCommandsAddressNV(primitiveMode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`.address, count)

  @PtrParameter([1])
  override fun glCreateCommandListsNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-lists$0`: Ptr): Unit =
      org.lwjgl.opengl.NVCommandList.nglCreateCommandListsNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-lists$0`.address)

  @PtrParameter([2, 3])
  override fun glDrawCommandsNV(
    primitiveMode: Int,
    buffer: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`: Ptr,
    count: Int,
  ): Unit = org.lwjgl.opengl.NVCommandList.nglDrawCommandsNV(primitiveMode, buffer,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`.address, count)

  @PtrParameter([1, 2, 3, 4])
  override fun glDrawCommandsStatesNV(
    buffer: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-fbos$0`: Ptr,
    count: Int,
  ): Unit = org.lwjgl.opengl.NVCommandList.nglDrawCommandsStatesNV(buffer,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirects$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-sizes$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-fbos$0`.address, count)

  override fun glListDrawCommandsStatesClientNV(
    list: Int,
    segment: Int,
    indirects: Long,
    sizes: Long,
    states: Long,
    fbos: Long,
    count: Int,
  ): Unit = org.lwjgl.opengl.NVCommandList.nglListDrawCommandsStatesClientNV(list, segment,
      indirects, sizes, states, fbos, count)

  @PtrParameter([1])
  override fun glDeleteStatesNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`: Ptr): Unit =
      org.lwjgl.opengl.NVCommandList.nglDeleteStatesNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-states$0`.address)

  override fun glDrawCommandsStatesNV(
    buffer: Int,
    indirects: Long,
    sizes: Long,
    states: Long,
    fbos: Long,
    count: Int,
  ): Unit = org.lwjgl.opengl.NVCommandList.nglDrawCommandsStatesNV(buffer, indirects, sizes, states,
      fbos, count)

  override fun glIsStateNV(state: Int): Boolean = org.lwjgl.opengl.NVCommandList.glIsStateNV(state)

  override fun glCreateStatesNV(n: Int, states: Long): Unit =
      org.lwjgl.opengl.NVCommandList.nglCreateStatesNV(n, states)

  override fun glDeleteStatesNV(n: Int, states: Long): Unit =
      org.lwjgl.opengl.NVCommandList.nglDeleteStatesNV(n, states)

  override fun glGetStageIndexNV(shadertype: Int): Short =
      org.lwjgl.opengl.NVCommandList.glGetStageIndexNV(shadertype)

  override fun glDrawCommandsNV(
    primitiveMode: Int,
    buffer: Int,
    indirects: Long,
    sizes: Long,
    count: Int,
  ): Unit = org.lwjgl.opengl.NVCommandList.nglDrawCommandsNV(primitiveMode, buffer, indirects,
      sizes, count)

  override fun glStateCaptureNV(state: Int, mode: Int): Unit =
      org.lwjgl.opengl.NVCommandList.glStateCaptureNV(state, mode)

  override fun glIsCommandListNV(list: Int): Boolean =
      org.lwjgl.opengl.NVCommandList.glIsCommandListNV(list)
}
