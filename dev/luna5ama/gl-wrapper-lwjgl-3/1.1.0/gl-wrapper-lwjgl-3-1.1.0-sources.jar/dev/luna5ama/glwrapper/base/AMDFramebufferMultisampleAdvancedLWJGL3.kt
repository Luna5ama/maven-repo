package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class AMDFramebufferMultisampleAdvancedLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDFramebufferMultisampleAdvanced {
  override fun glRenderbufferStorageMultisampleAdvancedAMD(
    target: Int,
    samples: Int,
    storageSamples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit =
      org.lwjgl.opengl.AMDFramebufferMultisampleAdvanced.glRenderbufferStorageMultisampleAdvancedAMD(target,
      samples, storageSamples, internalformat, width, height)

  override fun glNamedRenderbufferStorageMultisampleAdvancedAMD(
    renderbuffer: Int,
    samples: Int,
    storageSamples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit =
      org.lwjgl.opengl.AMDFramebufferMultisampleAdvanced.glNamedRenderbufferStorageMultisampleAdvancedAMD(renderbuffer,
      samples, storageSamples, internalformat, width, height)
}
