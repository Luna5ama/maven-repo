package dev.luna5ama.glwrapper.base

public class EXTTextureSRGBRG8LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureSRGBRG8
