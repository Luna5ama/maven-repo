package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class AMDDebugOutputLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDDebugOutput {
  override fun glDebugMessageEnableAMD(
    category: Int,
    severity: Int,
    count: Int,
    ids: Long,
    enabled: Boolean,
  ): Unit = org.lwjgl.opengl.AMDDebugOutput.nglDebugMessageEnableAMD(category, severity, count, ids,
      enabled)

  @PtrParameter([1])
  override fun glDebugMessageCallbackAMD(callback: Long,
      `$v$c$dev-luna5ama-kmogus-Ptr$-userParam$0`: Ptr): Unit =
      org.lwjgl.opengl.AMDDebugOutput.nglDebugMessageCallbackAMD(callback,
      `$v$c$dev-luna5ama-kmogus-Ptr$-userParam$0`.address)

  override fun glGetDebugMessageLogAMD(
    count: Int,
    bufsize: Int,
    categories: Long,
    severities: Long,
    ids: Long,
    lengths: Long,
    messageLog: Long,
  ): Int = org.lwjgl.opengl.AMDDebugOutput.nglGetDebugMessageLogAMD(count, bufsize, categories,
      severities, ids, lengths, messageLog)

  override fun glDebugMessageCallbackAMD(callback: Long, userParam: Long): Unit =
      org.lwjgl.opengl.AMDDebugOutput.nglDebugMessageCallbackAMD(callback, userParam)

  @PtrParameter([4])
  override fun glDebugMessageInsertAMD(
    category: Int,
    severity: Int,
    id: Int,
    length: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-buf$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDDebugOutput.nglDebugMessageInsertAMD(category, severity, id, length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-buf$0`.address)

  override fun glDebugMessageInsertAMD(
    category: Int,
    severity: Int,
    id: Int,
    length: Int,
    buf: Long,
  ): Unit = org.lwjgl.opengl.AMDDebugOutput.nglDebugMessageInsertAMD(category, severity, id, length,
      buf)

  @PtrParameter([3])
  override fun glDebugMessageEnableAMD(
    category: Int,
    severity: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr,
    enabled: Boolean,
  ): Unit = org.lwjgl.opengl.AMDDebugOutput.nglDebugMessageEnableAMD(category, severity, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address, enabled)

  @PtrParameter([2, 3, 4, 5, 6])
  override fun glGetDebugMessageLogAMD(
    count: Int,
    bufsize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-categories$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-severities$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-lengths$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-messageLog$0`: Ptr,
  ): Int = org.lwjgl.opengl.AMDDebugOutput.nglGetDebugMessageLogAMD(count, bufsize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-categories$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-severities$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-lengths$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-messageLog$0`.address)
}
