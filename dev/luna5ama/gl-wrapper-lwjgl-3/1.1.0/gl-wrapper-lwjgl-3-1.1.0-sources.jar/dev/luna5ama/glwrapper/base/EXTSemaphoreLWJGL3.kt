package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTSemaphoreLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTSemaphore {
  override fun glGenSemaphoresEXT(n: Int, semaphores: Long): Unit =
      org.lwjgl.opengl.EXTSemaphore.nglGenSemaphoresEXT(n, semaphores)

  override fun glWaitSemaphoreEXT(
    semaphore: Int,
    numBufferBarriers: Int,
    buffers: Long,
    numTextureBarriers: Int,
    textures: Long,
    srcLayouts: Long,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglWaitSemaphoreEXT(semaphore, numBufferBarriers, buffers,
      numTextureBarriers, textures, srcLayouts)

  override fun glIsSemaphoreEXT(semaphore: Int): Boolean =
      org.lwjgl.opengl.EXTSemaphore.glIsSemaphoreEXT(semaphore)

  @PtrParameter([2])
  override fun glSemaphoreParameterui64vEXT(
    semaphore: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglSemaphoreParameterui64vEXT(semaphore, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetSemaphoreParameterui64vEXT(
    semaphore: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglGetSemaphoreParameterui64vEXT(semaphore, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetUnsignedBytei_vEXT(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglGetUnsignedBytei_vEXT(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glGetUnsignedBytei_vEXT(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglGetUnsignedBytei_vEXT(target, index, `data`)

  override fun glGetUnsignedBytevEXT(pname: Int, `data`: Long): Unit =
      org.lwjgl.opengl.EXTSemaphore.nglGetUnsignedBytevEXT(pname, `data`)

  @PtrParameter([1])
  override fun glGetUnsignedBytevEXT(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr): Unit
      = org.lwjgl.opengl.EXTSemaphore.nglGetUnsignedBytevEXT(pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glSemaphoreParameterui64vEXT(
    semaphore: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglSemaphoreParameterui64vEXT(semaphore, pname, params)

  @PtrParameter([1])
  override fun glGenSemaphoresEXT(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-semaphores$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTSemaphore.nglGenSemaphoresEXT(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-semaphores$0`.address)

  @PtrParameter([2, 4, 5])
  override fun glWaitSemaphoreEXT(
    semaphore: Int,
    numBufferBarriers: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`: Ptr,
    numTextureBarriers: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-srcLayouts$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglWaitSemaphoreEXT(semaphore, numBufferBarriers,
      `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`.address, numTextureBarriers,
      `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-srcLayouts$0`.address)

  override fun glSignalSemaphoreEXT(
    semaphore: Int,
    numBufferBarriers: Int,
    buffers: Long,
    numTextureBarriers: Int,
    textures: Long,
    dstLayouts: Long,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglSignalSemaphoreEXT(semaphore, numBufferBarriers,
      buffers, numTextureBarriers, textures, dstLayouts)

  override fun glDeleteSemaphoresEXT(n: Int, semaphores: Long): Unit =
      org.lwjgl.opengl.EXTSemaphore.nglDeleteSemaphoresEXT(n, semaphores)

  override fun glGetSemaphoreParameterui64vEXT(
    semaphore: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglGetSemaphoreParameterui64vEXT(semaphore, pname, params)

  @PtrParameter([1])
  override fun glDeleteSemaphoresEXT(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-semaphores$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTSemaphore.nglDeleteSemaphoresEXT(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-semaphores$0`.address)

  @PtrParameter([2, 4, 5])
  override fun glSignalSemaphoreEXT(
    semaphore: Int,
    numBufferBarriers: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`: Ptr,
    numTextureBarriers: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-dstLayouts$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTSemaphore.nglSignalSemaphoreEXT(semaphore, numBufferBarriers,
      `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`.address, numTextureBarriers,
      `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-dstLayouts$0`.address)
}
