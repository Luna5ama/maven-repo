package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class NVViewportSwizzleLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVViewportSwizzle {
  override fun glViewportSwizzleNV(
    index: Int,
    swizzlex: Int,
    swizzley: Int,
    swizzlez: Int,
    swizzlew: Int,
  ): Unit = org.lwjgl.opengl.NVViewportSwizzle.glViewportSwizzleNV(index, swizzlex, swizzley,
      swizzlez, swizzlew)
}
