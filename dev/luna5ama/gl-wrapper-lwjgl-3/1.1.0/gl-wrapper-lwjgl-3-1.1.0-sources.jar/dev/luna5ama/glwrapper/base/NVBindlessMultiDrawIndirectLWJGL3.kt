package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVBindlessMultiDrawIndirectLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVBindlessMultiDrawIndirect {
  @PtrParameter([1])
  override fun glMultiDrawArraysIndirectBindlessNV(
    mode: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr,
    drawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
  ): Unit = org.lwjgl.opengl.NVBindlessMultiDrawIndirect.nglMultiDrawArraysIndirectBindlessNV(mode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address, drawCount, stride, vertexBufferCount)

  override fun glMultiDrawArraysIndirectBindlessNV(
    mode: Int,
    indirect: Long,
    drawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
  ): Unit = org.lwjgl.opengl.NVBindlessMultiDrawIndirect.nglMultiDrawArraysIndirectBindlessNV(mode,
      indirect, drawCount, stride, vertexBufferCount)

  @PtrParameter([2])
  override fun glMultiDrawElementsIndirectBindlessNV(
    mode: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr,
    drawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
  ): Unit =
      org.lwjgl.opengl.NVBindlessMultiDrawIndirect.nglMultiDrawElementsIndirectBindlessNV(mode,
      type, `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address, drawCount, stride,
      vertexBufferCount)

  override fun glMultiDrawElementsIndirectBindlessNV(
    mode: Int,
    type: Int,
    indirect: Long,
    drawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
  ): Unit =
      org.lwjgl.opengl.NVBindlessMultiDrawIndirect.nglMultiDrawElementsIndirectBindlessNV(mode,
      type, indirect, drawCount, stride, vertexBufferCount)
}
