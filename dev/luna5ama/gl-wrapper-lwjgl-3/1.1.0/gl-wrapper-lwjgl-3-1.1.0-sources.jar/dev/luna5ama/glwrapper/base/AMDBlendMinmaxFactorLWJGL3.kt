package dev.luna5ama.glwrapper.base

public class AMDBlendMinmaxFactorLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDBlendMinmaxFactor
