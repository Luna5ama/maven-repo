package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL14C

public class GL14LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL14 {
  override fun glBlendColor(
    red: Float,
    green: Float,
    blue: Float,
    alpha: Float,
  ): Unit = GL14C.glBlendColor(red, green, blue, alpha)

  override fun glPointParameterfv(pname: Int, params: Long): Unit = GL14C.nglPointParameterfv(pname,
      params)

  override fun glMultiDrawArrays(
    mode: Int,
    first: Long,
    count: Long,
    drawcount: Int,
  ): Unit = GL14C.nglMultiDrawArrays(mode, first, count, drawcount)

  override fun glPointParameteri(pname: Int, `param`: Int): Unit = GL14C.glPointParameteri(pname,
      `param`)

  override fun glBlendEquation(mode: Int): Unit = GL14C.glBlendEquation(mode)

  override fun glPointParameterf(pname: Int, `param`: Float): Unit = GL14C.glPointParameterf(pname,
      `param`)

  override fun glPointParameteriv(pname: Int, params: Long): Unit = GL14C.nglPointParameteriv(pname,
      params)

  @PtrParameter([1, 3])
  override fun glMultiDrawElements(
    mode: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-count$0`: Ptr,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
    drawcount: Int,
  ): Unit = GL14C.nglMultiDrawElements(mode, `$v$c$dev-luna5ama-kmogus-Ptr$-count$0`.address, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address, drawcount)

  @PtrParameter([1, 2])
  override fun glMultiDrawArrays(
    mode: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-first$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-count$0`: Ptr,
    drawcount: Int,
  ): Unit = GL14C.nglMultiDrawArrays(mode, `$v$c$dev-luna5ama-kmogus-Ptr$-first$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-count$0`.address, drawcount)

  @PtrParameter([1])
  override fun glPointParameterfv(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr): Unit =
      GL14C.nglPointParameterfv(pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glPointParameteriv(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr): Unit =
      GL14C.nglPointParameteriv(pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glMultiDrawElements(
    mode: Int,
    count: Long,
    type: Int,
    indices: Long,
    drawcount: Int,
  ): Unit = GL14C.nglMultiDrawElements(mode, count, type, indices, drawcount)

  override fun glBlendFuncSeparate(
    sfactorRGB: Int,
    dfactorRGB: Int,
    sfactorAlpha: Int,
    dfactorAlpha: Int,
  ): Unit = GL14C.glBlendFuncSeparate(sfactorRGB, dfactorRGB, sfactorAlpha, dfactorAlpha)
}
