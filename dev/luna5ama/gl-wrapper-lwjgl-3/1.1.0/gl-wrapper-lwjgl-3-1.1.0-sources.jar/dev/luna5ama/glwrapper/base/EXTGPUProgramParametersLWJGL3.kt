package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTGPUProgramParametersLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTGPUProgramParameters {
  @PtrParameter([3])
  override fun glProgramEnvParameters4fvEXT(
    target: Int,
    index: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUProgramParameters.nglProgramEnvParameters4fvEXT(target, index,
      count, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glProgramLocalParameters4fvEXT(
    target: Int,
    index: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTGPUProgramParameters.nglProgramLocalParameters4fvEXT(target, index,
      count, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glProgramEnvParameters4fvEXT(
    target: Int,
    index: Int,
    count: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUProgramParameters.nglProgramEnvParameters4fvEXT(target, index,
      count, params)

  override fun glProgramLocalParameters4fvEXT(
    target: Int,
    index: Int,
    count: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTGPUProgramParameters.nglProgramLocalParameters4fvEXT(target, index,
      count, params)
}
