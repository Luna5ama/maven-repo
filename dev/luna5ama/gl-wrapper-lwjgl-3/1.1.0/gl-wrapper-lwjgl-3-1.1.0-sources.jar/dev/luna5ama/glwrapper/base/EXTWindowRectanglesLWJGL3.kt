package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTWindowRectanglesLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTWindowRectangles {
  @PtrParameter([2])
  override fun glWindowRectanglesEXT(
    mode: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-box$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTWindowRectangles.nglWindowRectanglesEXT(mode, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-box$0`.address)

  override fun glWindowRectanglesEXT(
    mode: Int,
    count: Int,
    box: Long,
  ): Unit = org.lwjgl.opengl.EXTWindowRectangles.nglWindowRectanglesEXT(mode, count, box)
}
