package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVTransformFeedbackLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVTransformFeedback {
  @PtrParameter([1, 3])
  override fun glTransformFeedbackStreamAttribsNV(
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-attribs$0`: Ptr,
    nbuffers: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-bufstreams$0`: Ptr,
    bufferMode: Int,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglTransformFeedbackStreamAttribsNV(count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-attribs$0`.address, nbuffers,
      `$v$c$dev-luna5ama-kmogus-Ptr$-bufstreams$0`.address, bufferMode)

  @PtrParameter([2])
  override fun glTransformFeedbackVaryingsNV(
    program: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-locations$0`: Ptr,
    bufferMode: Int,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglTransformFeedbackVaryingsNV(program, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-locations$0`.address, bufferMode)

  @PtrParameter([1])
  override fun glTransformFeedbackAttribsNV(
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-attribs$0`: Ptr,
    bufferMode: Int,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglTransformFeedbackAttribsNV(count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-attribs$0`.address, bufferMode)

  @PtrParameter([2])
  override fun glGetTransformFeedbackVaryingNV(
    program: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-location$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglGetTransformFeedbackVaryingNV(program, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-location$0`.address)

  @PtrParameter([3, 4, 5, 6])
  override fun glGetActiveVaryingNV(
    program: Int,
    index: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglGetActiveVaryingNV(program, index, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glGetVaryingLocationNV(program: Int, name: Long): Int =
      org.lwjgl.opengl.NVTransformFeedback.nglGetVaryingLocationNV(program, name)

  override fun glBindBufferRangeNV(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
    size: Long,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.glBindBufferRangeNV(target, index, buffer, offset,
      size)

  override fun glTransformFeedbackVaryingsNV(
    program: Int,
    count: Int,
    locations: Long,
    bufferMode: Int,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglTransformFeedbackVaryingsNV(program, count,
      locations, bufferMode)

  override fun glTransformFeedbackAttribsNV(
    count: Int,
    attribs: Long,
    bufferMode: Int,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglTransformFeedbackAttribsNV(count, attribs,
      bufferMode)

  override fun glGetTransformFeedbackVaryingNV(
    program: Int,
    index: Int,
    location: Long,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglGetTransformFeedbackVaryingNV(program, index,
      location)

  override fun glGetActiveVaryingNV(
    program: Int,
    index: Int,
    bufSize: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglGetActiveVaryingNV(program, index, bufSize,
      length, size, type, name)

  override fun glBeginTransformFeedbackNV(primitiveMode: Int): Unit =
      org.lwjgl.opengl.NVTransformFeedback.glBeginTransformFeedbackNV(primitiveMode)

  override fun glEndTransformFeedbackNV(): Unit =
      org.lwjgl.opengl.NVTransformFeedback.glEndTransformFeedbackNV()

  override fun glBindBufferOffsetNV(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.glBindBufferOffsetNV(target, index, buffer, offset)

  @PtrParameter([1])
  override fun glGetVaryingLocationNV(program: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr):
      Int = org.lwjgl.opengl.NVTransformFeedback.nglGetVaryingLocationNV(program,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glTransformFeedbackStreamAttribsNV(
    count: Int,
    attribs: Long,
    nbuffers: Int,
    bufstreams: Long,
    bufferMode: Int,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.nglTransformFeedbackStreamAttribsNV(count, attribs,
      nbuffers, bufstreams, bufferMode)

  @PtrParameter([1])
  override fun glActiveVaryingNV(program: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr): Unit =
      org.lwjgl.opengl.NVTransformFeedback.nglActiveVaryingNV(program,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glBindBufferBaseNV(
    target: Int,
    index: Int,
    buffer: Int,
  ): Unit = org.lwjgl.opengl.NVTransformFeedback.glBindBufferBaseNV(target, index, buffer)

  override fun glActiveVaryingNV(program: Int, name: Long): Unit =
      org.lwjgl.opengl.NVTransformFeedback.nglActiveVaryingNV(program, name)
}
