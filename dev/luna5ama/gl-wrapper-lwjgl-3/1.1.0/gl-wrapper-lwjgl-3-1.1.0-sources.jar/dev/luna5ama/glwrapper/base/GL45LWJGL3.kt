package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL45C

public class GL45LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL45 {
  @PtrParameter([6])
  override fun glCompressedTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL45C.nglCompressedTextureSubImage1D(texture, level, xoffset, width, format, imageSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([3])
  override fun glGetVertexArrayIndexed64iv(
    vaobj: Int,
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = GL45C.nglGetVertexArrayIndexed64iv(vaobj, index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrParameter([3])
  override fun glGetCompressedTextureImage(
    texture: Int,
    level: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL45C.nglGetCompressedTextureImage(texture, level, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([2])
  override fun glGetNamedBufferParameteriv(
    buffer: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetNamedBufferParameteriv(buffer, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetNamedBufferParameteri64v(
    buffer: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetNamedBufferParameteri64v(buffer, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetNamedRenderbufferParameteriv(
    renderbuffer: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetNamedRenderbufferParameteriv(renderbuffer, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([8])
  override fun glCompressedTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL45C.nglCompressedTextureSubImage2D(texture, level, xoffset, yoffset, width, height,
      format, imageSize, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([2])
  override fun glNamedFramebufferDrawBuffers(
    framebuffer: Int,
    n: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-bufs$0`: Ptr,
  ): Unit = GL45C.nglNamedFramebufferDrawBuffers(framebuffer, n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-bufs$0`.address)

  @PtrParameter([10])
  override fun glCompressedTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL45C.nglCompressedTextureSubImage3D(texture, level, xoffset, yoffset, zoffset, width,
      height, depth, format, imageSize, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([9])
  override fun glGetCompressedTextureSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL45C.nglGetCompressedTextureSubImage(texture, level, xoffset, yoffset, zoffset, width,
      height, depth, bufSize, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([3])
  override fun glGetNamedFramebufferAttachmentParameteriv(
    framebuffer: Int,
    attachment: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetNamedFramebufferAttachmentParameteriv(framebuffer, attachment, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetTransformFeedbacki64_v(
    xfb: Int,
    pname: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = GL45C.nglGetTransformFeedbacki64_v(xfb, pname, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrParameter([2])
  override fun glInvalidateNamedFramebufferData(
    framebuffer: Int,
    numAttachments: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-attachments$0`: Ptr,
  ): Unit = GL45C.nglInvalidateNamedFramebufferData(framebuffer, numAttachments,
      `$v$c$dev-luna5ama-kmogus-Ptr$-attachments$0`.address)

  override fun glNamedRenderbufferStorageMultisample(
    renderbuffer: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = GL45C.glNamedRenderbufferStorageMultisample(renderbuffer, samples, internalformat,
      width, height)

  @PtrParameter([3])
  override fun glGetTextureLevelParameteriv(
    texture: Int,
    level: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetTextureLevelParameteriv(texture, level, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetNamedFramebufferParameteriv(
    framebuffer: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetNamedFramebufferParameteriv(framebuffer, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetNamedFramebufferAttachmentParameteriv(
    framebuffer: Int,
    attachment: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetNamedFramebufferAttachmentParameteriv(framebuffer, attachment, pname,
      params)

  @PtrParameter([2])
  override fun glInvalidateNamedFramebufferSubData(
    framebuffer: Int,
    numAttachments: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-attachments$0`: Ptr,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = GL45C.nglInvalidateNamedFramebufferSubData(framebuffer, numAttachments,
      `$v$c$dev-luna5ama-kmogus-Ptr$-attachments$0`.address, x, y, width, height)

  override fun glInvalidateNamedFramebufferSubData(
    framebuffer: Int,
    numAttachments: Int,
    attachments: Long,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = GL45C.nglInvalidateNamedFramebufferSubData(framebuffer, numAttachments, attachments, x,
      y, width, height)

  @PtrParameter([3])
  override fun glGetTextureLevelParameterfv(
    texture: Int,
    level: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetTextureLevelParameterfv(texture, level, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glClipControl(origin: Int, depth: Int): Unit = GL45C.glClipControl(origin, depth)

  override fun glUnmapNamedBuffer(buffer: Int): Boolean = GL45C.glUnmapNamedBuffer(buffer)

  override fun glNamedBufferData(
    buffer: Int,
    size: Long,
    `data`: Long,
    usage: Int,
  ): Unit = GL45C.nglNamedBufferData(buffer, size, `data`, usage)

  override fun glCreateBuffers(): Int = GL45C.glCreateBuffers()

  override fun glCreateBuffers(n: Int, buffers: Long): Unit = GL45C.nglCreateBuffers(n, buffers)

  override fun glTextureStorage3D(
    texture: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
  ): Unit = GL45C.glTextureStorage3D(texture, levels, internalformat, width, height, depth)

  override fun glTextureBuffer(
    texture: Int,
    internalformat: Int,
    buffer: Int,
  ): Unit = GL45C.glTextureBuffer(texture, internalformat, buffer)

  override fun glBindTextureUnit(unit: Int, texture: Int): Unit = GL45C.glBindTextureUnit(unit,
      texture)

  override fun glTextureStorage2D(
    texture: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = GL45C.glTextureStorage2D(texture, levels, internalformat, width, height)

  override fun glTextureStorage1D(
    texture: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
  ): Unit = GL45C.glTextureStorage1D(texture, levels, internalformat, width)

  override fun glGetTextureImage(
    texture: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    pixels: Long,
  ): Unit = GL45C.nglGetTextureImage(texture, level, format, type, bufSize, pixels)

  override fun glCreateTextures(target: Int): Int = GL45C.glCreateTextures(target)

  override fun glCreateTextures(
    target: Int,
    n: Int,
    textures: Long,
  ): Unit = GL45C.nglCreateTextures(target, n, textures)

  override fun glTextureBarrier(): Unit = GL45C.glTextureBarrier()

  override fun glCreateQueries(
    target: Int,
    n: Int,
    ids: Long,
  ): Unit = GL45C.nglCreateQueries(target, n, ids)

  override fun glCreateQueries(target: Int): Int = GL45C.glCreateQueries(target)

  override fun glGetnUniformfv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = GL45C.nglGetnUniformfv(program, location, bufSize, params)

  override fun glGetnUniformdv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = GL45C.nglGetnUniformdv(program, location, bufSize, params)

  override fun glGetnUniformiv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = GL45C.nglGetnUniformiv(program, location, bufSize, params)

  override fun glGetnUniformuiv(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = GL45C.nglGetnUniformuiv(program, location, bufSize, params)

  override fun glCreateSamplers(n: Int, samplers: Long): Unit = GL45C.nglCreateSamplers(n, samplers)

  override fun glCreateSamplers(): Int = GL45C.glCreateSamplers()

  override fun glGetnTexImage(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    img: Long,
  ): Unit = GL45C.nglGetnTexImage(tex, level, format, type, bufSize, img)

  override fun glReadnPixels(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    pixels: Long,
  ): Unit = GL45C.nglReadnPixels(x, y, width, height, format, type, bufSize, pixels)

  override fun glGetVertexArrayiv(
    vaobj: Int,
    pname: Int,
    `param`: Long,
  ): Unit = GL45C.nglGetVertexArrayiv(vaobj, pname, `param`)

  override fun glCreateTransformFeedbacks(n: Int, ids: Long): Unit =
      GL45C.nglCreateTransformFeedbacks(n, ids)

  override fun glCreateTransformFeedbacks(): Int = GL45C.glCreateTransformFeedbacks()

  @PtrReturn
  override fun glMapNamedBuffer(buffer: Int, access: Int): Ptr = Ptr(GL45C.nglMapNamedBuffer(buffer,
      access))

  override fun glGetNamedBufferParameteriv(
    buffer: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetNamedBufferParameteriv(buffer, pname, params)

  @PtrParameter([2])
  override fun glNamedBufferStorage(
    buffer: Int,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
    flags: Int,
  ): Unit = GL45C.nglNamedBufferStorage(buffer, size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address, flags)

  override fun glGetNamedBufferParameteri64v(
    buffer: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetNamedBufferParameteri64v(buffer, pname, params)

  @PtrParameter([1])
  override fun glCreateFramebuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`: Ptr):
      Unit = GL45C.nglCreateFramebuffers(n, `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`.address)

  override fun glCreateFramebuffers(): Int = GL45C.glCreateFramebuffers()

  override fun glCreateFramebuffers(n: Int, framebuffers: Long): Unit =
      GL45C.nglCreateFramebuffers(n, framebuffers)

  override fun glNamedFramebufferRenderbuffer(
    framebuffer: Int,
    attachment: Int,
    renderbuffertarget: Int,
    renderbuffer: Int,
  ): Unit = GL45C.glNamedFramebufferRenderbuffer(framebuffer, attachment, renderbuffertarget,
      renderbuffer)

  @PtrParameter([2])
  override fun glGetTransformFeedbackiv(
    xfb: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = GL45C.nglGetTransformFeedbackiv(xfb, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrParameter([4])
  override fun glClearNamedBufferData(
    buffer: Int,
    internalformat: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL45C.nglClearNamedBufferData(buffer, internalformat, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glClearNamedBufferData(
    buffer: Int,
    internalformat: Int,
    format: Int,
    type: Int,
    `data`: Long,
  ): Unit = GL45C.nglClearNamedBufferData(buffer, internalformat, format, type, `data`)

  override fun glNamedFramebufferParameteri(
    framebuffer: Int,
    pname: Int,
    `param`: Int,
  ): Unit = GL45C.glNamedFramebufferParameteri(framebuffer, pname, `param`)

  override fun glCopyNamedBufferSubData(
    readBuffer: Int,
    writeBuffer: Int,
    readOffset: Long,
    writeOffset: Long,
    size: Long,
  ): Unit = GL45C.glCopyNamedBufferSubData(readBuffer, writeBuffer, readOffset, writeOffset, size)

  override fun glNamedFramebufferTexture(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
  ): Unit = GL45C.glNamedFramebufferTexture(framebuffer, attachment, texture, level)

  override fun glNamedBufferStorage(
    buffer: Int,
    size: Long,
    `data`: Long,
    flags: Int,
  ): Unit = GL45C.nglNamedBufferStorage(buffer, size, `data`, flags)

  override fun glGetNamedBufferSubData(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
  ): Unit = GL45C.nglGetNamedBufferSubData(buffer, offset, size, `data`)

  @PtrParameter([6])
  override fun glClearNamedBufferSubData(
    buffer: Int,
    internalformat: Int,
    offset: Long,
    size: Long,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL45C.nglClearNamedBufferSubData(buffer, internalformat, offset, size, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glTextureParameteriv(
    texture: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglTextureParameteriv(texture, pname, params)

  override fun glGetTransformFeedbackiv(
    xfb: Int,
    pname: Int,
    `param`: Long,
  ): Unit = GL45C.nglGetTransformFeedbackiv(xfb, pname, `param`)

  override fun glNamedFramebufferTextureLayer(
    framebuffer: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    layer: Int,
  ): Unit = GL45C.glNamedFramebufferTextureLayer(framebuffer, attachment, texture, level, layer)

  override fun glNamedFramebufferDrawBuffer(framebuffer: Int, buf: Int): Unit =
      GL45C.glNamedFramebufferDrawBuffer(framebuffer, buf)

  override fun glTransformFeedbackBufferRange(
    xfb: Int,
    index: Int,
    buffer: Int,
    offset: Long,
    size: Long,
  ): Unit = GL45C.glTransformFeedbackBufferRange(xfb, index, buffer, offset, size)

  override fun glNamedFramebufferDrawBuffers(
    framebuffer: Int,
    n: Int,
    bufs: Long,
  ): Unit = GL45C.nglNamedFramebufferDrawBuffers(framebuffer, n, bufs)

  @PtrParameter([3])
  override fun glGetTransformFeedbacki_v(
    xfb: Int,
    pname: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = GL45C.nglGetTransformFeedbacki_v(xfb, pname, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrParameter([2])
  override fun glNamedBufferData(
    buffer: Int,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
    usage: Int,
  ): Unit = GL45C.nglNamedBufferData(buffer, size, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address,
      usage)

  @PtrParameter([3])
  override fun glNamedBufferSubData(
    buffer: Int,
    offset: Long,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL45C.nglNamedBufferSubData(buffer, offset, size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glGetTransformFeedbacki64_v(
    xfb: Int,
    pname: Int,
    index: Int,
    `param`: Long,
  ): Unit = GL45C.nglGetTransformFeedbacki64_v(xfb, pname, index, `param`)

  @PtrParameter([2])
  override fun glGetNamedBufferPointerv(
    buffer: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetNamedBufferPointerv(buffer, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glTextureParameterfv(
    texture: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglTextureParameterfv(texture, pname, params)

  override fun glGetTransformFeedbacki_v(
    xfb: Int,
    pname: Int,
    index: Int,
    `param`: Long,
  ): Unit = GL45C.nglGetTransformFeedbacki_v(xfb, pname, index, `param`)

  override fun glGetNamedBufferPointerv(
    buffer: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetNamedBufferPointerv(buffer, pname, params)

  @PtrParameter([3])
  override fun glGetNamedBufferSubData(
    buffer: Int,
    offset: Long,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL45C.nglGetNamedBufferSubData(buffer, offset, size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([1])
  override fun glCreateBuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`: Ptr): Unit =
      GL45C.nglCreateBuffers(n, `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`.address)

  override fun glNamedBufferSubData(
    buffer: Int,
    offset: Long,
    size: Long,
    `data`: Long,
  ): Unit = GL45C.nglNamedBufferSubData(buffer, offset, size, `data`)

  override fun glClearNamedBufferSubData(
    buffer: Int,
    internalformat: Int,
    offset: Long,
    size: Long,
    format: Int,
    type: Int,
    `data`: Long,
  ): Unit = GL45C.nglClearNamedBufferSubData(buffer, internalformat, offset, size, format, type,
      `data`)

  @PtrParameter([1])
  override fun glCreateTransformFeedbacks(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr): Unit
      = GL45C.nglCreateTransformFeedbacks(n, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address)

  override fun glTransformFeedbackBufferBase(
    xfb: Int,
    index: Int,
    buffer: Int,
  ): Unit = GL45C.glTransformFeedbackBufferBase(xfb, index, buffer)

  override fun glFlushMappedNamedBufferRange(
    buffer: Int,
    offset: Long,
    length: Long,
  ): Unit = GL45C.glFlushMappedNamedBufferRange(buffer, offset, length)

  override fun glNamedRenderbufferStorage(
    renderbuffer: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = GL45C.glNamedRenderbufferStorage(renderbuffer, internalformat, width, height)

  override fun glClearNamedFramebufferiv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
  ): Unit = GL45C.nglClearNamedFramebufferiv(framebuffer, buffer, drawbuffer, `value`)

  @PtrParameter([2])
  override fun glCreateTextures(
    target: Int,
    n: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`: Ptr,
  ): Unit = GL45C.nglCreateTextures(target, n, `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`.address)

  override fun glGetTextureLevelParameteriv(
    texture: Int,
    level: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetTextureLevelParameteriv(texture, level, pname, params)

  @PtrParameter([1])
  override fun glCreateRenderbuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`: Ptr):
      Unit = GL45C.nglCreateRenderbuffers(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`.address)

  override fun glTextureBufferRange(
    texture: Int,
    internalformat: Int,
    buffer: Int,
    offset: Long,
    size: Long,
  ): Unit = GL45C.glTextureBufferRange(texture, internalformat, buffer, offset, size)

  @PtrParameter([6])
  override fun glTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL45C.nglTextureSubImage1D(texture, level, xoffset, width, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glTextureParameteri(
    texture: Int,
    pname: Int,
    `param`: Int,
  ): Unit = GL45C.glTextureParameteri(texture, pname, `param`)

  @PtrParameter([2])
  override fun glTextureParameterIuiv(
    texture: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglTextureParameterIuiv(texture, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetNamedRenderbufferParameteriv(
    renderbuffer: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetNamedRenderbufferParameteriv(renderbuffer, pname, params)

  override fun glNamedFramebufferReadBuffer(framebuffer: Int, src: Int): Unit =
      GL45C.glNamedFramebufferReadBuffer(framebuffer, src)

  @PtrParameter([2])
  override fun glGetTextureParameterIuiv(
    texture: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetTextureParameterIuiv(texture, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glClearNamedFramebufferfv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
  ): Unit = GL45C.nglClearNamedFramebufferfv(framebuffer, buffer, drawbuffer, `value`)

  @PtrParameter([2])
  override fun glTextureParameterfv(
    texture: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglTextureParameterfv(texture, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetTextureParameteriv(
    texture: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetTextureParameteriv(texture, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3, 4, 5])
  override fun glVertexArrayVertexBuffers(
    vaobj: Int,
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-offsets$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-strides$0`: Ptr,
  ): Unit = GL45C.nglVertexArrayVertexBuffers(vaobj, first, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-offsets$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-strides$0`.address)

  @PtrParameter([3])
  override fun glClearNamedFramebufferfv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL45C.nglClearNamedFramebufferfv(framebuffer, buffer, drawbuffer,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([5])
  override fun glGetTextureImage(
    texture: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL45C.nglGetTextureImage(texture, level, format, type, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glVertexArrayVertexBuffers(
    vaobj: Int,
    first: Int,
    count: Int,
    buffers: Long,
    offsets: Long,
    strides: Long,
  ): Unit = GL45C.nglVertexArrayVertexBuffers(vaobj, first, count, buffers, offsets, strides)

  override fun glTextureStorage3DMultisample(
    texture: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedsamplelocations: Boolean,
  ): Unit = GL45C.glTextureStorage3DMultisample(texture, samples, internalformat, width, height,
      depth, fixedsamplelocations)

  override fun glGetTextureParameterIuiv(
    texture: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetTextureParameterIuiv(texture, pname, params)

  override fun glVertexArrayAttribFormat(
    vaobj: Int,
    attribindex: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    relativeoffset: Int,
  ): Unit = GL45C.glVertexArrayAttribFormat(vaobj, attribindex, size, type, normalized,
      relativeoffset)

  override fun glVertexArrayAttribIFormat(
    vaobj: Int,
    attribindex: Int,
    size: Int,
    type: Int,
    relativeoffset: Int,
  ): Unit = GL45C.glVertexArrayAttribIFormat(vaobj, attribindex, size, type, relativeoffset)

  override fun glVertexArrayAttribLFormat(
    vaobj: Int,
    attribindex: Int,
    size: Int,
    type: Int,
    relativeoffset: Int,
  ): Unit = GL45C.glVertexArrayAttribLFormat(vaobj, attribindex, size, type, relativeoffset)

  @PtrParameter([2])
  override fun glGetTextureParameterIiv(
    texture: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetTextureParameterIiv(texture, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glDisableVertexArrayAttrib(vaobj: Int, index: Int): Unit =
      GL45C.glDisableVertexArrayAttrib(vaobj, index)

  override fun glGenerateTextureMipmap(texture: Int): Unit = GL45C.glGenerateTextureMipmap(texture)

  override fun glGetNamedFramebufferParameteriv(
    framebuffer: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetNamedFramebufferParameteriv(framebuffer, pname, params)

  override fun glBlitNamedFramebuffer(
    readFramebuffer: Int,
    drawFramebuffer: Int,
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    mask: Int,
    filter: Int,
  ): Unit = GL45C.glBlitNamedFramebuffer(readFramebuffer, drawFramebuffer, srcX0, srcY0, srcX1,
      srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter)

  override fun glTextureStorage2DMultisample(
    texture: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    fixedsamplelocations: Boolean,
  ): Unit = GL45C.glTextureStorage2DMultisample(texture, samples, internalformat, width, height,
      fixedsamplelocations)

  override fun glTextureParameterIuiv(
    texture: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglTextureParameterIuiv(texture, pname, params)

  override fun glClearNamedFramebufferfi(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    depth: Float,
    stencil: Int,
  ): Unit = GL45C.glClearNamedFramebufferfi(framebuffer, buffer, drawbuffer, depth, stencil)

  @PtrParameter([2])
  override fun glGetTextureParameterfv(
    texture: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetTextureParameterfv(texture, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL45C.nglTextureSubImage2D(texture, level, xoffset, yoffset, width, height, format,
      type, pixels)

  @PtrParameter([1])
  override fun glCreateVertexArrays(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-arrays$0`: Ptr): Unit =
      GL45C.nglCreateVertexArrays(n, `$v$c$dev-luna5ama-kmogus-Ptr$-arrays$0`.address)

  override fun glCompressedTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = GL45C.nglCompressedTextureSubImage3D(texture, level, xoffset, yoffset, zoffset, width,
      height, depth, format, imageSize, `data`)

  override fun glCreateRenderbuffers(): Int = GL45C.glCreateRenderbuffers()

  override fun glCreateRenderbuffers(n: Int, renderbuffers: Long): Unit =
      GL45C.nglCreateRenderbuffers(n, renderbuffers)

  override fun glTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL45C.nglTextureSubImage1D(texture, level, xoffset, width, format, type, pixels)

  override fun glGetTextureParameterfv(
    texture: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetTextureParameterfv(texture, pname, params)

  override fun glTextureParameterf(
    texture: Int,
    pname: Int,
    `param`: Float,
  ): Unit = GL45C.glTextureParameterf(texture, pname, `param`)

  override fun glTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL45C.nglTextureSubImage3D(texture, level, xoffset, yoffset, zoffset, width, height,
      depth, format, type, pixels)

  @PtrParameter([10])
  override fun glTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL45C.nglTextureSubImage3D(texture, level, xoffset, yoffset, zoffset, width, height,
      depth, format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glCheckNamedFramebufferStatus(framebuffer: Int, target: Int): Int =
      GL45C.glCheckNamedFramebufferStatus(framebuffer, target)

  @PtrParameter([3])
  override fun glClearNamedFramebufferiv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL45C.nglClearNamedFramebufferiv(framebuffer, buffer, drawbuffer,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glCopyTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    x: Int,
    y: Int,
    width: Int,
  ): Unit = GL45C.glCopyTextureSubImage1D(texture, level, xoffset, x, y, width)

  override fun glInvalidateNamedFramebufferData(
    framebuffer: Int,
    numAttachments: Int,
    attachments: Long,
  ): Unit = GL45C.nglInvalidateNamedFramebufferData(framebuffer, numAttachments, attachments)

  override fun glCopyTextureSubImage3D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = GL45C.glCopyTextureSubImage3D(texture, level, xoffset, yoffset, zoffset, x, y, width,
      height)

  override fun glTextureParameterIiv(
    texture: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglTextureParameterIiv(texture, pname, params)

  @PtrParameter([8])
  override fun glTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL45C.nglTextureSubImage2D(texture, level, xoffset, yoffset, width, height, format,
      type, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glClearNamedFramebufferuiv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
  ): Unit = GL45C.nglClearNamedFramebufferuiv(framebuffer, buffer, drawbuffer, `value`)

  @PtrParameter([2])
  override fun glTextureParameteriv(
    texture: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglTextureParameteriv(texture, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glClearNamedFramebufferuiv(
    framebuffer: Int,
    buffer: Int,
    drawbuffer: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL45C.nglClearNamedFramebufferuiv(framebuffer, buffer, drawbuffer,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetCompressedTextureImage(
    texture: Int,
    level: Int,
    bufSize: Int,
    pixels: Long,
  ): Unit = GL45C.nglGetCompressedTextureImage(texture, level, bufSize, pixels)

  override fun glGetTextureLevelParameterfv(
    texture: Int,
    level: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetTextureLevelParameterfv(texture, level, pname, params)

  override fun glGetTextureParameteriv(
    texture: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetTextureParameteriv(texture, pname, params)

  override fun glCopyTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = GL45C.glCopyTextureSubImage2D(texture, level, xoffset, yoffset, x, y, width, height)

  @PtrParameter([2])
  override fun glTextureParameterIiv(
    texture: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglTextureParameterIiv(texture, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glCompressedTextureSubImage2D(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = GL45C.nglCompressedTextureSubImage2D(texture, level, xoffset, yoffset, width, height,
      format, imageSize, `data`)

  override fun glCompressedTextureSubImage1D(
    texture: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    imageSize: Int,
    `data`: Long,
  ): Unit = GL45C.nglCompressedTextureSubImage1D(texture, level, xoffset, width, format, imageSize,
      `data`)

  override fun glGetTextureParameterIiv(
    texture: Int,
    pname: Int,
    params: Long,
  ): Unit = GL45C.nglGetTextureParameterIiv(texture, pname, params)

  override fun glCreateVertexArrays(n: Int, arrays: Long): Unit = GL45C.nglCreateVertexArrays(n,
      arrays)

  override fun glCreateVertexArrays(): Int = GL45C.glCreateVertexArrays()

  override fun glEnableVertexArrayAttrib(vaobj: Int, index: Int): Unit =
      GL45C.glEnableVertexArrayAttrib(vaobj, index)

  override fun glVertexArrayElementBuffer(vaobj: Int, buffer: Int): Unit =
      GL45C.glVertexArrayElementBuffer(vaobj, buffer)

  override fun glVertexArrayVertexBuffer(
    vaobj: Int,
    bindingindex: Int,
    buffer: Int,
    offset: Long,
    stride: Int,
  ): Unit = GL45C.glVertexArrayVertexBuffer(vaobj, bindingindex, buffer, offset, stride)

  override fun glCreateProgramPipelines(n: Int, pipelines: Long): Unit =
      GL45C.nglCreateProgramPipelines(n, pipelines)

  override fun glCreateProgramPipelines(): Int = GL45C.glCreateProgramPipelines()

  override fun glVertexArrayBindingDivisor(
    vaobj: Int,
    bindingindex: Int,
    divisor: Int,
  ): Unit = GL45C.glVertexArrayBindingDivisor(vaobj, bindingindex, divisor)

  @PtrParameter([3])
  override fun glGetnUniformiv(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetnUniformiv(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetTextureSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    pixels: Long,
  ): Unit = GL45C.nglGetTextureSubImage(texture, level, xoffset, yoffset, zoffset, width, height,
      depth, format, type, bufSize, pixels)

  @PtrParameter([7])
  override fun glReadnPixels(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL45C.nglReadnPixels(x, y, width, height, format, type, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([2])
  override fun glCreateQueries(
    target: Int,
    n: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr,
  ): Unit = GL45C.nglCreateQueries(target, n, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address)

  @PtrParameter([5])
  override fun glGetnTexImage(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`: Ptr,
  ): Unit = GL45C.nglGetnTexImage(tex, level, format, type, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`.address)

  override fun glVertexArrayAttribBinding(
    vaobj: Int,
    attribindex: Int,
    bindingindex: Int,
  ): Unit = GL45C.glVertexArrayAttribBinding(vaobj, attribindex, bindingindex)

  override fun glGetQueryBufferObjectui64v(
    id: Int,
    buffer: Int,
    pname: Int,
    offset: Long,
  ): Unit = GL45C.glGetQueryBufferObjectui64v(id, buffer, pname, offset)

  override fun glGetVertexArrayIndexed64iv(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Long,
  ): Unit = GL45C.nglGetVertexArrayIndexed64iv(vaobj, index, pname, `param`)

  override fun glGetQueryBufferObjectuiv(
    id: Int,
    buffer: Int,
    pname: Int,
    offset: Long,
  ): Unit = GL45C.glGetQueryBufferObjectuiv(id, buffer, pname, offset)

  @PtrParameter([3])
  override fun glGetnCompressedTexImage(
    target: Int,
    level: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`: Ptr,
  ): Unit = GL45C.nglGetnCompressedTexImage(target, level, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`.address)

  @PtrParameter([3])
  override fun glGetnUniformuiv(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetnUniformuiv(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetQueryBufferObjecti64v(
    id: Int,
    buffer: Int,
    pname: Int,
    offset: Long,
  ): Unit = GL45C.glGetQueryBufferObjecti64v(id, buffer, pname, offset)

  @PtrParameter([1])
  override fun glCreateSamplers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-samplers$0`: Ptr): Unit =
      GL45C.nglCreateSamplers(n, `$v$c$dev-luna5ama-kmogus-Ptr$-samplers$0`.address)

  @PtrParameter([2])
  override fun glGetVertexArrayiv(
    vaobj: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = GL45C.nglGetVertexArrayiv(vaobj, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  @PtrReturn
  override fun nglMapNamedBufferRange(
    buffer: Int,
    offset: Long,
    length: Long,
    access: Int,
  ): Ptr = Ptr(GL45C.nglMapNamedBufferRange(buffer, offset, length, access))

  override fun glGetQueryBufferObjectiv(
    id: Int,
    buffer: Int,
    pname: Int,
    offset: Long,
  ): Unit = GL45C.glGetQueryBufferObjectiv(id, buffer, pname, offset)

  @PtrParameter([3])
  override fun glGetnUniformfv(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetnUniformfv(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetVertexArrayIndexediv(
    vaobj: Int,
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`: Ptr,
  ): Unit = GL45C.nglGetVertexArrayIndexediv(vaobj, index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-param$0`.address)

  override fun glGetnCompressedTexImage(
    target: Int,
    level: Int,
    bufSize: Int,
    img: Long,
  ): Unit = GL45C.nglGetnCompressedTexImage(target, level, bufSize, img)

  override fun glGetVertexArrayIndexediv(
    vaobj: Int,
    index: Int,
    pname: Int,
    `param`: Long,
  ): Unit = GL45C.nglGetVertexArrayIndexediv(vaobj, index, pname, `param`)

  @PtrParameter([3])
  override fun glGetnUniformdv(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL45C.nglGetnUniformdv(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glMemoryBarrierByRegion(barriers: Int): Unit =
      GL45C.glMemoryBarrierByRegion(barriers)

  @PtrParameter([1])
  override fun glCreateProgramPipelines(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-pipelines$0`: Ptr):
      Unit = GL45C.nglCreateProgramPipelines(n, `$v$c$dev-luna5ama-kmogus-Ptr$-pipelines$0`.address)

  override fun glGetCompressedTextureSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    bufSize: Int,
    pixels: Long,
  ): Unit = GL45C.nglGetCompressedTextureSubImage(texture, level, xoffset, yoffset, zoffset, width,
      height, depth, bufSize, pixels)

  override fun glGetGraphicsResetStatus(): Int = GL45C.glGetGraphicsResetStatus()

  @PtrParameter([11])
  override fun glGetTextureSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL45C.nglGetTextureSubImage(texture, level, xoffset, yoffset, zoffset, width, height,
      depth, format, type, bufSize, `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)
}
