package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBMatrixPaletteLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBMatrixPalette {
  override fun glMatrixIndexubvARB(size: Int, indices: Long): Unit =
      org.lwjgl.opengl.ARBMatrixPalette.nglMatrixIndexubvARB(size, indices)

  override fun glMatrixIndexuivARB(size: Int, indices: Long): Unit =
      org.lwjgl.opengl.ARBMatrixPalette.nglMatrixIndexuivARB(size, indices)

  @PtrParameter([3])
  override fun glMatrixIndexPointerARB(
    size: Int,
    type: Int,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBMatrixPalette.nglMatrixIndexPointerARB(size, type, stride,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  override fun glMatrixIndexusvARB(size: Int, indices: Long): Unit =
      org.lwjgl.opengl.ARBMatrixPalette.nglMatrixIndexusvARB(size, indices)

  @PtrParameter([1])
  override fun glMatrixIndexubvARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr): Unit
      = org.lwjgl.opengl.ARBMatrixPalette.nglMatrixIndexubvARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address)

  override fun glCurrentPaletteMatrixARB(index: Int): Unit =
      org.lwjgl.opengl.ARBMatrixPalette.glCurrentPaletteMatrixARB(index)

  @PtrParameter([1])
  override fun glMatrixIndexuivARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr): Unit
      = org.lwjgl.opengl.ARBMatrixPalette.nglMatrixIndexuivARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address)

  @PtrParameter([1])
  override fun glMatrixIndexusvARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr): Unit
      = org.lwjgl.opengl.ARBMatrixPalette.nglMatrixIndexusvARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address)

  override fun glMatrixIndexPointerARB(
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
  ): Unit = org.lwjgl.opengl.ARBMatrixPalette.nglMatrixIndexPointerARB(size, type, stride, pointer)
}
