package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBVertexBlendLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBVertexBlend {
  override fun glWeightsvARB(size: Int, weights: Long): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightsvARB(size, weights)

  override fun glWeightuivARB(size: Int, weights: Long): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightuivARB(size, weights)

  override fun glWeightdvARB(size: Int, weights: Long): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightdvARB(size, weights)

  override fun glWeightusvARB(size: Int, weights: Long): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightusvARB(size, weights)

  override fun glWeightivARB(size: Int, weights: Long): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightivARB(size, weights)

  override fun glWeightbvARB(size: Int, weights: Long): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightbvARB(size, weights)

  override fun glWeightubvARB(size: Int, weights: Long): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightubvARB(size, weights)

  override fun glWeightfvARB(size: Int, weights: Long): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightfvARB(size, weights)

  @PtrParameter([1])
  override fun glWeightusvARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightusvARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`.address)

  @PtrParameter([1])
  override fun glWeightdvARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightdvARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`.address)

  @PtrParameter([1])
  override fun glWeightfvARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightfvARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`.address)

  @PtrParameter([1])
  override fun glWeightuivARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightuivARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`.address)

  @PtrParameter([1])
  override fun glWeightubvARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightubvARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`.address)

  @PtrParameter([1])
  override fun glWeightbvARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightbvARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`.address)

  @PtrParameter([3])
  override fun glWeightPointerARB(
    size: Int,
    type: Int,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexBlend.nglWeightPointerARB(size, type, stride,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  @PtrParameter([1])
  override fun glWeightsvARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightsvARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`.address)

  @PtrParameter([1])
  override fun glWeightivARB(size: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexBlend.nglWeightivARB(size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-weights$0`.address)

  override fun glVertexBlendARB(count: Int): Unit =
      org.lwjgl.opengl.ARBVertexBlend.glVertexBlendARB(count)

  override fun glWeightPointerARB(
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexBlend.nglWeightPointerARB(size, type, stride, pointer)
}
