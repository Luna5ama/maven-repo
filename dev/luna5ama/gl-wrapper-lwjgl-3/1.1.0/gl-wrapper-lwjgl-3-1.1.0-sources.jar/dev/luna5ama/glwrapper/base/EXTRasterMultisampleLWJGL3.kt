package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Unit

public class EXTRasterMultisampleLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTRasterMultisample {
  override fun glRasterSamplesEXT(samples: Int, fixedsamplelocations: Boolean): Unit =
      org.lwjgl.opengl.EXTRasterMultisample.glRasterSamplesEXT(samples, fixedsamplelocations)
}
