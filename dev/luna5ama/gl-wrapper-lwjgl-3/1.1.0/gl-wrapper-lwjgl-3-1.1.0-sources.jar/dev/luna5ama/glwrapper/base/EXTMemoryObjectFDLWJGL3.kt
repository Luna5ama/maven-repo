package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTMemoryObjectFDLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTMemoryObjectFD {
  override fun glImportMemoryFdEXT(
    memory: Int,
    size: Long,
    handleType: Int,
    fd: Int,
  ): Unit = org.lwjgl.opengl.EXTMemoryObjectFD.glImportMemoryFdEXT(memory, size, handleType, fd)
}
