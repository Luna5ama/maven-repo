package dev.luna5ama.glwrapper.base

public class NVShaderBufferStoreLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVShaderBufferStore
