package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVMeshShaderLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVMeshShader {
  override fun glMultiDrawMeshTasksIndirectCountNV(
    indirect: Long,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
  ): Unit = org.lwjgl.opengl.NVMeshShader.glMultiDrawMeshTasksIndirectCountNV(indirect, drawcount,
      maxdrawcount, stride)

  override fun glMultiDrawMeshTasksIndirectNV(
    indirect: Long,
    drawcount: Int,
    stride: Int,
  ): Unit = org.lwjgl.opengl.NVMeshShader.glMultiDrawMeshTasksIndirectNV(indirect, drawcount,
      stride)

  override fun glDrawMeshTasksIndirectNV(indirect: Long): Unit =
      org.lwjgl.opengl.NVMeshShader.glDrawMeshTasksIndirectNV(indirect)

  override fun glDrawMeshTasksNV(first: Int, count: Int): Unit =
      org.lwjgl.opengl.NVMeshShader.glDrawMeshTasksNV(first, count)
}
