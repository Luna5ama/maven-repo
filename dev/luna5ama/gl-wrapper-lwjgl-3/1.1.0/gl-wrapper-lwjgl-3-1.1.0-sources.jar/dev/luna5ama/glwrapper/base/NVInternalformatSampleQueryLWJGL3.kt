package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVInternalformatSampleQueryLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVInternalformatSampleQuery {
  @PtrParameter([5])
  override fun glGetInternalformatSampleivNV(
    target: Int,
    internalformat: Int,
    samples: Int,
    pname: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVInternalformatSampleQuery.nglGetInternalformatSampleivNV(target,
      internalformat, samples, pname, bufSize, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetInternalformatSampleivNV(
    target: Int,
    internalformat: Int,
    samples: Int,
    pname: Int,
    bufSize: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVInternalformatSampleQuery.nglGetInternalformatSampleivNV(target,
      internalformat, samples, pname, bufSize, params)
}
