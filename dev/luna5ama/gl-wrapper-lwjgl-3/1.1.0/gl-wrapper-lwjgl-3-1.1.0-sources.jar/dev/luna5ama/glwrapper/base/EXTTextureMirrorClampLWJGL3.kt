package dev.luna5ama.glwrapper.base

public class EXTTextureMirrorClampLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureMirrorClamp
