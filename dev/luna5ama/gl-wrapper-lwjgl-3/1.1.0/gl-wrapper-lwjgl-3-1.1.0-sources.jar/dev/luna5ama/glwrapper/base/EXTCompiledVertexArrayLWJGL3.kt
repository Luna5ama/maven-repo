package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTCompiledVertexArrayLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTCompiledVertexArray {
  override fun glUnlockArraysEXT(): Unit =
      org.lwjgl.opengl.EXTCompiledVertexArray.glUnlockArraysEXT()

  override fun glLockArraysEXT(first: Int, count: Int): Unit =
      org.lwjgl.opengl.EXTCompiledVertexArray.glLockArraysEXT(first, count)
}
