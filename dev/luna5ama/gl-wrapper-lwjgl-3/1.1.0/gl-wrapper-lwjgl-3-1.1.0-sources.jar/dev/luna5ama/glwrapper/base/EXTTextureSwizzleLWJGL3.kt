package dev.luna5ama.glwrapper.base

public class EXTTextureSwizzleLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureSwizzle
