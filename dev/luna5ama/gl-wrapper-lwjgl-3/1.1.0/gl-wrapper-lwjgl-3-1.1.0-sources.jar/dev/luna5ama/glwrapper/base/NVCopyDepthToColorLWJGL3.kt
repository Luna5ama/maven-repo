package dev.luna5ama.glwrapper.base

public class NVCopyDepthToColorLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVCopyDepthToColor
