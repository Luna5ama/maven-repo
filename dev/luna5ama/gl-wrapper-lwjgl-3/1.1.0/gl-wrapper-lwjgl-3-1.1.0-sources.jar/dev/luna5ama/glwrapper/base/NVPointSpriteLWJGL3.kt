package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVPointSpriteLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVPointSprite {
  override fun glPointParameteriNV(pname: Int, `param`: Int): Unit =
      org.lwjgl.opengl.NVPointSprite.glPointParameteriNV(pname, `param`)

  override fun glPointParameterivNV(pname: Int, params: Long): Unit =
      org.lwjgl.opengl.NVPointSprite.nglPointParameterivNV(pname, params)

  @PtrParameter([1])
  override fun glPointParameterivNV(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr): Unit
      = org.lwjgl.opengl.NVPointSprite.nglPointParameterivNV(pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)
}
