package dev.luna5ama.glwrapper.base

public class ARBTextureRGLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBTextureRG
