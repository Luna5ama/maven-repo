package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class AMDOcclusionQueryEventLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDOcclusionQueryEvent {
  override fun glQueryObjectParameteruiAMD(
    target: Int,
    id: Int,
    pname: Int,
    `param`: Int,
  ): Unit = org.lwjgl.opengl.AMDOcclusionQueryEvent.glQueryObjectParameteruiAMD(target, id, pname,
      `param`)
}
