package dev.luna5ama.glwrapper.base

public class ARBTextureCompressionRGTCLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBTextureCompressionRGTC
