package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Unit

public class EXTShaderImageLoadStoreLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTShaderImageLoadStore {
  override fun glMemoryBarrierEXT(barriers: Int): Unit =
      org.lwjgl.opengl.EXTShaderImageLoadStore.glMemoryBarrierEXT(barriers)

  override fun glBindImageTextureEXT(
    index: Int,
    texture: Int,
    level: Int,
    layered: Boolean,
    layer: Int,
    access: Int,
    format: Int,
  ): Unit = org.lwjgl.opengl.EXTShaderImageLoadStore.glBindImageTextureEXT(index, texture, level,
      layered, layer, access, format)
}
