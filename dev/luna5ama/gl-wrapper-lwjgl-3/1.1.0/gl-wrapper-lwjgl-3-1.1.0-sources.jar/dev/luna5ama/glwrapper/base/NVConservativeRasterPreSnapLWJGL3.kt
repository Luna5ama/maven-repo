package dev.luna5ama.glwrapper.base

public class NVConservativeRasterPreSnapLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVConservativeRasterPreSnap
