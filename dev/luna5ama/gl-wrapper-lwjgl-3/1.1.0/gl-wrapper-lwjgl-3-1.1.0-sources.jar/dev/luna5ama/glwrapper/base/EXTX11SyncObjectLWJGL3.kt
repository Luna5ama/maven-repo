package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long

public class EXTX11SyncObjectLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTX11SyncObject {
  override fun glImportSyncEXT(
    external_sync_type: Int,
    external_sync: Long,
    flags: Int,
  ): Long = org.lwjgl.opengl.EXTX11SyncObject.glImportSyncEXT(external_sync_type, external_sync,
      flags)
}
