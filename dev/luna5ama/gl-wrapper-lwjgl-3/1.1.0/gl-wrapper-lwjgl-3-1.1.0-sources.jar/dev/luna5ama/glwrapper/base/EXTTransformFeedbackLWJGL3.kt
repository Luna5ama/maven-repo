package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTTransformFeedbackLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTransformFeedback {
  override fun glGetBooleanIndexedvEXT(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.nglGetBooleanIndexedvEXT(target, index, `data`)

  @PtrParameter([2])
  override fun glGetBooleanIndexedvEXT(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.nglGetBooleanIndexedvEXT(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glGetIntegerIndexedvEXT(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.nglGetIntegerIndexedvEXT(target, index, `data`)

  @PtrParameter([2])
  override fun glGetIntegerIndexedvEXT(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.nglGetIntegerIndexedvEXT(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([2])
  override fun glTransformFeedbackVaryingsEXT(
    program: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-varyings$0`: Ptr,
    bufferMode: Int,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.nglTransformFeedbackVaryingsEXT(program, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-varyings$0`.address, bufferMode)

  @PtrParameter([3, 4, 5, 6])
  override fun glGetTransformFeedbackVaryingEXT(
    program: Int,
    index: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.nglGetTransformFeedbackVaryingEXT(program, index,
      bufSize, `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glBindBufferBaseEXT(
    target: Int,
    index: Int,
    buffer: Int,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.glBindBufferBaseEXT(target, index, buffer)

  override fun glBindBufferOffsetEXT(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.glBindBufferOffsetEXT(target, index, buffer,
      offset)

  override fun glGetTransformFeedbackVaryingEXT(
    program: Int,
    index: Int,
    bufSize: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.nglGetTransformFeedbackVaryingEXT(program, index,
      bufSize, length, size, type, name)

  override fun glBeginTransformFeedbackEXT(primitiveMode: Int): Unit =
      org.lwjgl.opengl.EXTTransformFeedback.glBeginTransformFeedbackEXT(primitiveMode)

  override fun glBindBufferRangeEXT(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
    size: Long,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.glBindBufferRangeEXT(target, index, buffer,
      offset, size)

  override fun glEndTransformFeedbackEXT(): Unit =
      org.lwjgl.opengl.EXTTransformFeedback.glEndTransformFeedbackEXT()

  override fun glTransformFeedbackVaryingsEXT(
    program: Int,
    count: Int,
    varyings: Long,
    bufferMode: Int,
  ): Unit = org.lwjgl.opengl.EXTTransformFeedback.nglTransformFeedbackVaryingsEXT(program, count,
      varyings, bufferMode)
}
