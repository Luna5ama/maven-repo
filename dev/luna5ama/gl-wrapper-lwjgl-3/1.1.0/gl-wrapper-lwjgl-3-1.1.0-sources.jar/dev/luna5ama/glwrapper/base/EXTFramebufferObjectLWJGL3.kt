package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTFramebufferObjectLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTFramebufferObject {
  @PtrParameter([3])
  override fun glGetFramebufferAttachmentParameterivEXT(
    target: Int,
    attachment: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTFramebufferObject.nglGetFramebufferAttachmentParameterivEXT(target,
      attachment, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetRenderbufferParameterivEXT(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTFramebufferObject.nglGetRenderbufferParameterivEXT(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetFramebufferAttachmentParameterivEXT(
    target: Int,
    attachment: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTFramebufferObject.nglGetFramebufferAttachmentParameterivEXT(target,
      attachment, pname, params)

  override fun glIsFramebufferEXT(framebuffer: Int): Boolean =
      org.lwjgl.opengl.EXTFramebufferObject.glIsFramebufferEXT(framebuffer)

  override fun glDeleteRenderbuffersEXT(n: Int, renderbuffers: Long): Unit =
      org.lwjgl.opengl.EXTFramebufferObject.nglDeleteRenderbuffersEXT(n, renderbuffers)

  override fun glRenderbufferStorageEXT(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.EXTFramebufferObject.glRenderbufferStorageEXT(target, internalformat,
      width, height)

  override fun glIsRenderbufferEXT(renderbuffer: Int): Boolean =
      org.lwjgl.opengl.EXTFramebufferObject.glIsRenderbufferEXT(renderbuffer)

  override fun glBindRenderbufferEXT(target: Int, renderbuffer: Int): Unit =
      org.lwjgl.opengl.EXTFramebufferObject.glBindRenderbufferEXT(target, renderbuffer)

  @PtrParameter([1])
  override fun glGenRenderbuffersEXT(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTFramebufferObject.nglGenRenderbuffersEXT(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`.address)

  @PtrParameter([1])
  override fun glDeleteRenderbuffersEXT(n: Int,
      `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTFramebufferObject.nglDeleteRenderbuffersEXT(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`.address)

  @PtrParameter([1])
  override fun glDeleteFramebuffersEXT(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTFramebufferObject.nglDeleteFramebuffersEXT(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`.address)

  override fun glGenRenderbuffersEXT(n: Int, renderbuffers: Long): Unit =
      org.lwjgl.opengl.EXTFramebufferObject.nglGenRenderbuffersEXT(n, renderbuffers)

  override fun glGetRenderbufferParameterivEXT(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTFramebufferObject.nglGetRenderbufferParameterivEXT(target, pname,
      params)

  override fun glBindFramebufferEXT(target: Int, framebuffer: Int): Unit =
      org.lwjgl.opengl.EXTFramebufferObject.glBindFramebufferEXT(target, framebuffer)

  override fun glCheckFramebufferStatusEXT(target: Int): Int =
      org.lwjgl.opengl.EXTFramebufferObject.glCheckFramebufferStatusEXT(target)

  override fun glFramebufferRenderbufferEXT(
    target: Int,
    attachment: Int,
    renderbuffertarget: Int,
    renderbuffer: Int,
  ): Unit = org.lwjgl.opengl.EXTFramebufferObject.glFramebufferRenderbufferEXT(target, attachment,
      renderbuffertarget, renderbuffer)

  override fun glFramebufferTexture3DEXT(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
    zoffset: Int,
  ): Unit = org.lwjgl.opengl.EXTFramebufferObject.glFramebufferTexture3DEXT(target, attachment,
      textarget, texture, level, zoffset)

  override fun glFramebufferTexture1DEXT(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
  ): Unit = org.lwjgl.opengl.EXTFramebufferObject.glFramebufferTexture1DEXT(target, attachment,
      textarget, texture, level)

  override fun glDeleteFramebuffersEXT(n: Int, framebuffers: Long): Unit =
      org.lwjgl.opengl.EXTFramebufferObject.nglDeleteFramebuffersEXT(n, framebuffers)

  @PtrParameter([1])
  override fun glGenFramebuffersEXT(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`: Ptr):
      Unit = org.lwjgl.opengl.EXTFramebufferObject.nglGenFramebuffersEXT(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`.address)

  override fun glGenerateMipmapEXT(target: Int): Unit =
      org.lwjgl.opengl.EXTFramebufferObject.glGenerateMipmapEXT(target)

  override fun glFramebufferTexture2DEXT(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
  ): Unit = org.lwjgl.opengl.EXTFramebufferObject.glFramebufferTexture2DEXT(target, attachment,
      textarget, texture, level)

  override fun glGenFramebuffersEXT(n: Int, framebuffers: Long): Unit =
      org.lwjgl.opengl.EXTFramebufferObject.nglGenFramebuffersEXT(n, framebuffers)
}
