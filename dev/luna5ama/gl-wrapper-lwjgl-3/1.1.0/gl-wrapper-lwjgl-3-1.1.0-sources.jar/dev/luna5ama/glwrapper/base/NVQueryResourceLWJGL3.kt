package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long

public class NVQueryResourceLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVQueryResource {
  @PtrParameter([3])
  override fun glQueryResourceNV(
    queryType: Int,
    pname: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-buffer$0`: Ptr,
  ): Int = org.lwjgl.opengl.NVQueryResource.nglQueryResourceNV(queryType, pname, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-buffer$0`.address)

  override fun glQueryResourceNV(
    queryType: Int,
    pname: Int,
    bufSize: Int,
    buffer: Long,
  ): Int = org.lwjgl.opengl.NVQueryResource.nglQueryResourceNV(queryType, pname, bufSize, buffer)
}
