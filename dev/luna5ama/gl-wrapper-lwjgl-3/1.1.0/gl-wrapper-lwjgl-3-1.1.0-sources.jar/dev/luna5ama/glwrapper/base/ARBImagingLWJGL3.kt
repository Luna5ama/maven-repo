package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBImagingLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBImaging {
  @PtrParameter([5])
  override fun glConvolutionFilter1D(
    target: Int,
    internalformat: Int,
    width: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglConvolutionFilter1D(target, internalformat, width,
      format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([5])
  override fun glColorSubTable(
    target: Int,
    start: Int,
    count: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglColorSubTable(target, start, count, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glColorTableParameterfv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglColorTableParameterfv(target, pname, params)

  @PtrParameter([3])
  override fun glGetColorTable(
    target: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-table$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetColorTable(target, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-table$0`.address)

  override fun glGetColorTableParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetColorTableParameteriv(target, pname, params)

  override fun glColorTableParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglColorTableParameteriv(target, pname, params)

  override fun glConvolutionFilter2D(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglConvolutionFilter2D(target, internalformat, width,
      height, format, type, `data`)

  @PtrParameter([2])
  override fun glColorTableParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglColorTableParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glColorTableParameterfv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglColorTableParameterfv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetColorTableParameterfv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetColorTableParameterfv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glCopyConvolutionFilter1D(
    target: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
  ): Unit = org.lwjgl.opengl.ARBImaging.glCopyConvolutionFilter1D(target, internalformat, x, y,
      width)

  @PtrParameter([2])
  override fun glGetColorTableParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetColorTableParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetColorTableParameterfv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetColorTableParameterfv(target, pname, params)

  override fun glCopyColorSubTable(
    target: Int,
    start: Int,
    x: Int,
    y: Int,
    width: Int,
  ): Unit = org.lwjgl.opengl.ARBImaging.glCopyColorSubTable(target, start, x, y, width)

  override fun glConvolutionFilter1D(
    target: Int,
    internalformat: Int,
    width: Int,
    format: Int,
    type: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglConvolutionFilter1D(target, internalformat, width,
      format, type, `data`)

  @PtrParameter([5])
  override fun glColorTable(
    target: Int,
    internalformat: Int,
    width: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-table$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglColorTable(target, internalformat, width, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-table$0`.address)

  @PtrParameter([6])
  override fun glConvolutionFilter2D(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglConvolutionFilter2D(target, internalformat, width,
      height, format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glCopyConvolutionFilter2D(
    target: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.ARBImaging.glCopyConvolutionFilter2D(target, internalformat, x, y,
      width, height)

  @PtrParameter([3])
  override fun glGetConvolutionFilter(
    target: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-image$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetConvolutionFilter(target, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-image$0`.address)

  @PtrParameter([2])
  override fun glConvolutionParameterfv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglConvolutionParameterfv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetConvolutionFilter(
    target: Int,
    format: Int,
    type: Int,
    image: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetConvolutionFilter(target, format, type, image)

  @PtrParameter([2])
  override fun glConvolutionParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglConvolutionParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glConvolutionParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglConvolutionParameteriv(target, pname, params)

  override fun glGetHistogramParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetHistogramParameteriv(target, pname, params)

  override fun glGetMinmaxParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetMinmaxParameteriv(target, pname, params)

  override fun glGetConvolutionParameterfv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetConvolutionParameterfv(target, pname, params)

  @PtrParameter([2])
  override fun glGetMinmaxParameterfv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetMinmaxParameterfv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glConvolutionParameterf(
    target: Int,
    pname: Int,
    `param`: Float,
  ): Unit = org.lwjgl.opengl.ARBImaging.glConvolutionParameterf(target, pname, `param`)

  override fun glConvolutionParameterfv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglConvolutionParameterfv(target, pname, params)

  override fun glGetConvolutionParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetConvolutionParameteriv(target, pname, params)

  @PtrParameter([3, 4, 5])
  override fun glGetSeparableFilter(
    target: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-row$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-column$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-span$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetSeparableFilter(target, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-row$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-column$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-span$0`.address)

  @PtrParameter([4])
  override fun glGetMinmax(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetMinmax(target, reset, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  @PtrParameter([6, 7])
  override fun glSeparableFilter2D(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-row$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-column$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglSeparableFilter2D(target, internalformat, width, height,
      format, type, `$v$c$dev-luna5ama-kmogus-Ptr$-row$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-column$0`.address)

  override fun glGetSeparableFilter(
    target: Int,
    format: Int,
    type: Int,
    row: Long,
    column: Long,
    span: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetSeparableFilter(target, format, type, row, column,
      span)

  override fun glConvolutionParameteri(
    target: Int,
    pname: Int,
    `param`: Int,
  ): Unit = org.lwjgl.opengl.ARBImaging.glConvolutionParameteri(target, pname, `param`)

  @PtrParameter([4])
  override fun glGetHistogram(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetHistogram(target, reset, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  override fun glSeparableFilter2D(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    row: Long,
    column: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglSeparableFilter2D(target, internalformat, width, height,
      format, type, row, column)

  @PtrParameter([2])
  override fun glGetHistogramParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetHistogramParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetHistogramParameterfv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetHistogramParameterfv(target, pname, params)

  @PtrParameter([2])
  override fun glGetMinmaxParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetMinmaxParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetMinmaxParameterfv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetMinmaxParameterfv(target, pname, params)

  @PtrParameter([2])
  override fun glGetHistogramParameterfv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetHistogramParameterfv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetConvolutionParameterfv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetConvolutionParameterfv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetConvolutionParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetConvolutionParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glColorTable(
    target: Int,
    internalformat: Int,
    width: Int,
    format: Int,
    type: Int,
    table: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglColorTable(target, internalformat, width, format, type,
      table)

  override fun glGetColorTable(
    target: Int,
    format: Int,
    type: Int,
    table: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetColorTable(target, format, type, table)

  override fun glColorSubTable(
    target: Int,
    start: Int,
    count: Int,
    format: Int,
    type: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglColorSubTable(target, start, count, format, type, `data`)

  override fun glCopyColorTable(
    target: Int,
    internalformat: Int,
    x: Int,
    y: Int,
    width: Int,
  ): Unit = org.lwjgl.opengl.ARBImaging.glCopyColorTable(target, internalformat, x, y, width)

  override fun glHistogram(
    target: Int,
    width: Int,
    internalformat: Int,
    sink: Boolean,
  ): Unit = org.lwjgl.opengl.ARBImaging.glHistogram(target, width, internalformat, sink)

  override fun glMinmax(
    target: Int,
    internalformat: Int,
    sink: Boolean,
  ): Unit = org.lwjgl.opengl.ARBImaging.glMinmax(target, internalformat, sink)

  override fun glResetMinmax(target: Int): Unit = org.lwjgl.opengl.ARBImaging.glResetMinmax(target)

  override fun glGetHistogram(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    values: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetHistogram(target, reset, format, type, values)

  override fun glResetHistogram(target: Int): Unit =
      org.lwjgl.opengl.ARBImaging.glResetHistogram(target)

  override fun glGetMinmax(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    values: Long,
  ): Unit = org.lwjgl.opengl.ARBImaging.nglGetMinmax(target, reset, format, type, values)
}
