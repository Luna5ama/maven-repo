package dev.luna5ama.glwrapper.base

import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBSparseBufferLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBSparseBuffer {
  override fun glNamedBufferPageCommitmentEXT(
    buffer: Int,
    offset: Long,
    size: Long,
    commit: Boolean,
  ): Unit = org.lwjgl.opengl.ARBSparseBuffer.glNamedBufferPageCommitmentEXT(buffer, offset, size,
      commit)

  override fun glBufferPageCommitmentARB(
    target: Int,
    offset: Long,
    size: Long,
    commit: Boolean,
  ): Unit = org.lwjgl.opengl.ARBSparseBuffer.glBufferPageCommitmentARB(target, offset, size, commit)

  override fun glNamedBufferPageCommitmentARB(
    buffer: Int,
    offset: Long,
    size: Long,
    commit: Boolean,
  ): Unit = org.lwjgl.opengl.ARBSparseBuffer.glNamedBufferPageCommitmentARB(buffer, offset, size,
      commit)
}
