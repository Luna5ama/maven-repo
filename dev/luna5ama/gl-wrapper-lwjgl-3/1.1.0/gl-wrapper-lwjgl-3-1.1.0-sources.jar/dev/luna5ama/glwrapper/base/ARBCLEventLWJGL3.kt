package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long

public class ARBCLEventLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBCLEvent {
  override fun glCreateSyncFromCLeventARB(
    context: Long,
    event: Long,
    flags: Int,
  ): Long = org.lwjgl.opengl.ARBCLEvent.nglCreateSyncFromCLeventARB(context, event, flags)
}
