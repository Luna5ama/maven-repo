package dev.luna5ama.glwrapper.base

public class NVFloatBufferLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVFloatBuffer
