package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class NVBlendEquationAdvancedLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVBlendEquationAdvanced {
  override fun glBlendParameteriNV(pname: Int, `value`: Int): Unit =
      org.lwjgl.opengl.NVBlendEquationAdvanced.glBlendParameteriNV(pname, `value`)

  override fun glBlendBarrierNV(): Unit =
      org.lwjgl.opengl.NVBlendEquationAdvanced.glBlendBarrierNV()
}
