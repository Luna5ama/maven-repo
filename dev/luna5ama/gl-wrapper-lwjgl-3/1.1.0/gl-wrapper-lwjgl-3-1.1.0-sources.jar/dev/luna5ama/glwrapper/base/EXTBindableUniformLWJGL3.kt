package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTBindableUniformLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTBindableUniform {
  override fun glGetUniformBufferSizeEXT(program: Int, location: Int): Int =
      org.lwjgl.opengl.EXTBindableUniform.glGetUniformBufferSizeEXT(program, location)

  override fun glGetUniformOffsetEXT(program: Int, location: Int): Long =
      org.lwjgl.opengl.EXTBindableUniform.glGetUniformOffsetEXT(program, location)

  override fun glUniformBufferEXT(
    program: Int,
    location: Int,
    buffer: Int,
  ): Unit = org.lwjgl.opengl.EXTBindableUniform.glUniformBufferEXT(program, location, buffer)
}
