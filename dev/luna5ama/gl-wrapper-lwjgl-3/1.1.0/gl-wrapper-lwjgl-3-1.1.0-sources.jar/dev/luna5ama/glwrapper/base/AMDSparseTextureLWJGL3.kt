package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class AMDSparseTextureLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDSparseTexture {
  override fun glTextureStorageSparseAMD(
    texture: Int,
    target: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    layers: Int,
    flags: Int,
  ): Unit = org.lwjgl.opengl.AMDSparseTexture.glTextureStorageSparseAMD(texture, target,
      internalFormat, width, height, depth, layers, flags)

  override fun glTexStorageSparseAMD(
    target: Int,
    internalFormat: Int,
    width: Int,
    height: Int,
    depth: Int,
    layers: Int,
    flags: Int,
  ): Unit = org.lwjgl.opengl.AMDSparseTexture.glTexStorageSparseAMD(target, internalFormat, width,
      height, depth, layers, flags)
}
