package dev.luna5ama.glwrapper.base

import kotlin.Double
import kotlin.Unit

public class EXTDepthBoundsTestLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTDepthBoundsTest {
  override fun glDepthBoundsEXT(zmin: Double, zmax: Double): Unit =
      org.lwjgl.opengl.EXTDepthBoundsTest.glDepthBoundsEXT(zmin, zmax)
}
