package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVFramebufferMixedSamplesLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVFramebufferMixedSamples {
  @PtrParameter([1])
  override fun glCoverageModulationTableNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVFramebufferMixedSamples.nglCoverageModulationTableNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glGetCoverageModulationTableNV(bufsize: Int,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.NVFramebufferMixedSamples.nglGetCoverageModulationTableNV(bufsize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glCoverageModulationTableNV(n: Int, v: Long): Unit =
      org.lwjgl.opengl.NVFramebufferMixedSamples.nglCoverageModulationTableNV(n, v)

  override fun glCoverageModulationNV(components: Int): Unit =
      org.lwjgl.opengl.NVFramebufferMixedSamples.glCoverageModulationNV(components)

  override fun glGetCoverageModulationTableNV(bufsize: Int, v: Long): Unit =
      org.lwjgl.opengl.NVFramebufferMixedSamples.nglGetCoverageModulationTableNV(bufsize, v)
}
