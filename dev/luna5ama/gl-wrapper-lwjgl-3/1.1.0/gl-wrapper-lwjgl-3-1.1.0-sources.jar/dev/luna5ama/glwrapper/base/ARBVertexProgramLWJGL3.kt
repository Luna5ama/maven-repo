package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBVertexProgramLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBVertexProgram {
  @PtrParameter([2])
  override fun glGetProgramLocalParameterdvARB(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramLocalParameterdvARB(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetProgramEnvParameterdvARB(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramEnvParameterdvARB(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glProgramLocalParameter4fvARB(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramLocalParameter4fvARB(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glProgramLocalParameter4dvARB(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramLocalParameter4dvARB(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glProgramEnvParameter4fvARB(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramEnvParameter4fvARB(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetProgramEnvParameterfvARB(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramEnvParameterfvARB(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glProgramEnvParameter4dvARB(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramEnvParameter4dvARB(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetVertexAttribPointervARB(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetVertexAttribPointervARB(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  @PtrParameter([2])
  override fun glGetProgramLocalParameterfvARB(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramLocalParameterfvARB(target, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4ivARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4ivARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib2dvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib2dvARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib4bvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4bvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib4ivARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4ivARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib4ubvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4ubvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib3fvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib3fvARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib2svARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib2svARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib1svARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib1svARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib1svARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib1svARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib1fvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib1fvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib2svARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib2svARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib2fvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib2fvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib3fvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib3fvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib1dvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib1dvARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib3dvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib3dvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib3dvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib3dvARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib2dvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib2dvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4fvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4fvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib4fvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4fvARB(index, v)

  override fun glVertexAttrib3svARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib3svARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib1dvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib1dvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib3svARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib3svARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib4bvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4bvARB(index, v)

  override fun glVertexAttrib1fvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib1fvARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib4svARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4svARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib2fvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib2fvARB(index, v)

  override fun glVertexAttrib4svARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4svARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib4NivARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NivARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glGetProgramStringARB(
    target: Int,
    pname: Int,
    string: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramStringARB(target, pname, string)

  @PtrParameter([1])
  override fun glVertexAttrib4NbvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NbvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib4NbvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NbvARB(index, v)

  override fun glProgramEnvParameter4dARB(
    target: Int,
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.glProgramEnvParameter4dARB(target, index, x, y, z, w)

  override fun glProgramEnvParameter4fvARB(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramEnvParameter4fvARB(target, index, params)

  override fun glVertexAttrib4ubvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4ubvARB(index, v)

  override fun glProgramEnvParameter4dvARB(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramEnvParameter4dvARB(target, index, params)

  override fun glProgramLocalParameter4dvARB(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramLocalParameter4dvARB(target, index, params)

  override fun glProgramLocalParameter4fARB(
    target: Int,
    index: Int,
    x: Float,
    y: Float,
    z: Float,
    w: Float,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.glProgramLocalParameter4fARB(target, index, x, y, z,
      w)

  override fun glGetProgramLocalParameterfvARB(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramLocalParameterfvARB(target, index,
      params)

  @PtrParameter([1])
  override fun glVertexAttrib4dvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4dvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glGenProgramsARB(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-programs$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglGenProgramsARB(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-programs$0`.address)

  override fun glGetProgramEnvParameterfvARB(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramEnvParameterfvARB(target, index, params)

  @PtrParameter([1])
  override fun glVertexAttrib4uivARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4uivARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4NubvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NubvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glProgramLocalParameter4dARB(
    target: Int,
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.glProgramLocalParameter4dARB(target, index, x, y, z,
      w)

  @PtrParameter([2])
  override fun glGetProgramivARB(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramivARB(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetVertexAttribdvARB(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetVertexAttribdvARB(index, pname, params)

  override fun glGetVertexAttribPointervARB(
    index: Int,
    pname: Int,
    pointer: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetVertexAttribPointervARB(index, pname, pointer)

  override fun glDeleteProgramsARB(n: Int, programs: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglDeleteProgramsARB(n, programs)

  override fun glVertexAttrib4NivARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NivARB(index, v)

  @PtrParameter([2])
  override fun glGetProgramStringARB(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramStringARB(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`.address)

  override fun glGetVertexAttribivARB(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetVertexAttribivARB(index, pname, params)

  @PtrParameter([5])
  override fun glVertexAttribPointerARB(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglVertexAttribPointerARB(index, size, type,
      normalized, stride, `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4NsvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NsvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glProgramEnvParameter4fARB(
    target: Int,
    index: Int,
    x: Float,
    y: Float,
    z: Float,
    w: Float,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.glProgramEnvParameter4fARB(target, index, x, y, z, w)

  override fun glVertexAttrib4NubvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NubvARB(index, v)

  override fun glVertexAttrib4NusvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NusvARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib4NuivARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NuivARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib4uivARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4uivARB(index, v)

  @PtrParameter([1])
  override fun glVertexAttrib4usvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4usvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glGetVertexAttribfvARB(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetVertexAttribfvARB(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glVertexAttrib4dvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4dvARB(index, v)

  override fun glGetProgramLocalParameterdvARB(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramLocalParameterdvARB(target, index,
      params)

  @PtrParameter([2])
  override fun glGetVertexAttribivARB(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetVertexAttribivARB(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glVertexAttribPointerARB(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    pointer: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglVertexAttribPointerARB(index, size, type,
      normalized, stride, pointer)

  override fun glVertexAttrib4NuivARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NuivARB(index, v)

  override fun glVertexAttrib4usvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4usvARB(index, v)

  @PtrParameter([3])
  override fun glProgramStringARB(
    target: Int,
    format: Int,
    len: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramStringARB(target, format, len,
      `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`.address)

  override fun glProgramLocalParameter4fvARB(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramLocalParameter4fvARB(target, index, params)

  override fun glGetProgramEnvParameterdvARB(
    target: Int,
    index: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramEnvParameterdvARB(target, index, params)

  override fun glGetVertexAttribfvARB(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetVertexAttribfvARB(index, pname, params)

  override fun glVertexAttrib4NsvARB(index: Int, v: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NsvARB(index, v)

  @PtrParameter([1])
  override fun glDeleteProgramsARB(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-programs$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglDeleteProgramsARB(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-programs$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4NusvARB(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglVertexAttrib4NusvARB(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glGetVertexAttribdvARB(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetVertexAttribdvARB(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetProgramivARB(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglGetProgramivARB(target, pname, params)

  override fun glIsProgramARB(program: Int): Boolean =
      org.lwjgl.opengl.ARBVertexProgram.glIsProgramARB(program)

  override fun glProgramStringARB(
    target: Int,
    format: Int,
    len: Int,
    string: Long,
  ): Unit = org.lwjgl.opengl.ARBVertexProgram.nglProgramStringARB(target, format, len, string)

  override fun glGenProgramsARB(n: Int, programs: Long): Unit =
      org.lwjgl.opengl.ARBVertexProgram.nglGenProgramsARB(n, programs)

  override fun glBindProgramARB(target: Int, program: Int): Unit =
      org.lwjgl.opengl.ARBVertexProgram.glBindProgramARB(target, program)
}
