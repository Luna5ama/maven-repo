package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class NVConservativeRasterLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVConservativeRaster {
  override fun glSubpixelPrecisionBiasNV(xbits: Int, ybits: Int): Unit =
      org.lwjgl.opengl.NVConservativeRaster.glSubpixelPrecisionBiasNV(xbits, ybits)
}
