package dev.luna5ama.glwrapper.base

public class ARBHalfFloatVertexLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBHalfFloatVertex
