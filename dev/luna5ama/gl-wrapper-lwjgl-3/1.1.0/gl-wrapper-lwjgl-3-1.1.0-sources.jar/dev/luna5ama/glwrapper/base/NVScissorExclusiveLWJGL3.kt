package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVScissorExclusiveLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVScissorExclusive {
  @PtrParameter([2])
  override fun glScissorExclusiveArrayvNV(
    first: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVScissorExclusive.nglScissorExclusiveArrayvNV(first, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glScissorExclusiveNV(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.NVScissorExclusive.glScissorExclusiveNV(x, y, width, height)

  override fun glScissorExclusiveArrayvNV(
    first: Int,
    count: Int,
    v: Long,
  ): Unit = org.lwjgl.opengl.NVScissorExclusive.nglScissorExclusiveArrayvNV(first, count, v)
}
