package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class NVConservativeRasterPreSnapTrianglesLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVConservativeRasterPreSnapTriangles {
  override fun glConservativeRasterParameteriNV(pname: Int, `param`: Int): Unit =
      org.lwjgl.opengl.NVConservativeRasterPreSnapTriangles.glConservativeRasterParameteriNV(pname,
      `param`)
}
