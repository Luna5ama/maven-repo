package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL30C

public class GL30LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL30 {
  @PtrReturn
  override fun glMapBufferRange(
    target: Int,
    offset: Long,
    length: Long,
    access: Int,
  ): Ptr = Ptr(GL30C.nglMapBufferRange(target, offset, length, access))

  @PtrParameter([2])
  override fun glTransformFeedbackVaryings(
    program: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-varyings$0`: Ptr,
    bufferMode: Int,
  ): Unit = GL30C.nglTransformFeedbackVaryings(program, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-varyings$0`.address, bufferMode)

  @PtrParameter([2])
  override fun glGetRenderbufferParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL30C.nglGetRenderbufferParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetFramebufferAttachmentParameteriv(
    target: Int,
    attachment: Int,
    pname: Int,
    params: Long,
  ): Unit = GL30C.nglGetFramebufferAttachmentParameteriv(target, attachment, pname, params)

  @PtrParameter([3, 4, 5, 6])
  override fun glGetTransformFeedbackVarying(
    program: Int,
    index: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = GL30C.nglGetTransformFeedbackVarying(program, index, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([3])
  override fun glGetFramebufferAttachmentParameteriv(
    target: Int,
    attachment: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL30C.nglGetFramebufferAttachmentParameteriv(target, attachment, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrReturn
  override fun glGetStringi(name: Int, index: Int): Ptr = Ptr(GL30C.nglGetStringi(name, index))

  @PtrParameter([2])
  override fun glClearBufferfv(
    buffer: Int,
    drawbuffer: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL30C.nglClearBufferfv(buffer, drawbuffer,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glClearBufferuiv(
    buffer: Int,
    drawbuffer: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL30C.nglClearBufferuiv(buffer, drawbuffer,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([1])
  override fun glVertexAttribI1iv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI1iv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glClearBufferiv(
    buffer: Int,
    drawbuffer: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL30C.nglClearBufferiv(buffer, drawbuffer,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetTransformFeedbackVarying(
    program: Int,
    index: Int,
    bufSize: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
  ): Unit = GL30C.nglGetTransformFeedbackVarying(program, index, bufSize, length, size, type, name)

  @PtrParameter([2])
  override fun glGetUniformuiv(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL30C.nglGetUniformuiv(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glVertexAttribI4ubv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI4ubv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([4])
  override fun glVertexAttribIPointer(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = GL30C.nglVertexAttribIPointer(index, size, type, stride,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  override fun glVertexAttribI3uiv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI3uiv(index, v)

  override fun glFramebufferTexture2D(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
  ): Unit = GL30C.glFramebufferTexture2D(target, attachment, textarget, texture, level)

  override fun glVertexAttribI1uiv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI1uiv(index, v)

  @PtrParameter([2])
  override fun glUniform2uiv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL30C.nglUniform2uiv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glFlushMappedBufferRange(
    target: Int,
    offset: Long,
    length: Long,
  ): Unit = GL30C.glFlushMappedBufferRange(target, offset, length)

  @PtrParameter([1])
  override fun glGetFragDataLocation(program: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr): Int
      = GL30C.nglGetFragDataLocation(program, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([1])
  override fun glDeleteFramebuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`: Ptr):
      Unit = GL30C.nglDeleteFramebuffers(n, `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`.address)

  override fun glFramebufferTexture3D(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
    layer: Int,
  ): Unit = GL30C.glFramebufferTexture3D(target, attachment, textarget, texture, level, layer)

  override fun glGetVertexAttribIuiv(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = GL30C.nglGetVertexAttribIuiv(index, pname, params)

  override fun glFramebufferRenderbuffer(
    target: Int,
    attachment: Int,
    renderbuffertarget: Int,
    renderbuffer: Int,
  ): Unit = GL30C.glFramebufferRenderbuffer(target, attachment, renderbuffertarget, renderbuffer)

  @PtrParameter([2])
  override fun glGetTexParameterIuiv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL30C.nglGetTexParameterIuiv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetIntegeri_v(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL30C.nglGetIntegeri_v(target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([2])
  override fun glTexParameterIiv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL30C.nglTexParameterIiv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glDeleteVertexArrays(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-arrays$0`: Ptr): Unit =
      GL30C.nglDeleteVertexArrays(n, `$v$c$dev-luna5ama-kmogus-Ptr$-arrays$0`.address)

  @PtrParameter([1])
  override fun glGenFramebuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`: Ptr): Unit
      = GL30C.nglGenFramebuffers(n, `$v$c$dev-luna5ama-kmogus-Ptr$-framebuffers$0`.address)

  override fun glVertexAttribI4usv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI4usv(index, v)

  @PtrParameter([2])
  override fun glBindFragDataLocation(
    program: Int,
    colorNumber: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = GL30C.nglBindFragDataLocation(program, colorNumber,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([1])
  override fun glDeleteRenderbuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`: Ptr):
      Unit = GL30C.nglDeleteRenderbuffers(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`.address)

  override fun glFramebufferTextureLayer(
    target: Int,
    attachment: Int,
    texture: Int,
    level: Int,
    layer: Int,
  ): Unit = GL30C.glFramebufferTextureLayer(target, attachment, texture, level, layer)

  @PtrParameter([2])
  override fun glUniform4uiv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL30C.nglUniform4uiv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glBeginConditionalRender(id: Int, mode: Int): Unit =
      GL30C.glBeginConditionalRender(id, mode)

  @PtrParameter([1])
  override fun glVertexAttribI2iv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI2iv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttribI1uiv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI1uiv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glUniform1uiv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL30C.nglUniform1uiv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetTexParameterIuiv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL30C.nglGetTexParameterIuiv(target, pname, params)

  @PtrParameter([1])
  override fun glVertexAttribI4usv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI4usv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI4uiv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI4uiv(index, v)

  @PtrParameter([1])
  override fun glGenRenderbuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`: Ptr):
      Unit = GL30C.nglGenRenderbuffers(n, `$v$c$dev-luna5ama-kmogus-Ptr$-renderbuffers$0`.address)

  @PtrParameter([2])
  override fun glGetVertexAttribIuiv(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL30C.nglGetVertexAttribIuiv(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetTexParameterIiv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL30C.nglGetTexParameterIiv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glVertexAttribI2uiv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI2uiv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttribI4uiv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI4uiv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glGetBooleani_v(
    target: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL30C.nglGetBooleani_v(target, index, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glTransformFeedbackVaryings(
    program: Int,
    count: Int,
    varyings: Long,
    bufferMode: Int,
  ): Unit = GL30C.nglTransformFeedbackVaryings(program, count, varyings, bufferMode)

  override fun glGetRenderbufferParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL30C.nglGetRenderbufferParameteriv(target, pname, params)

  @PtrParameter([2])
  override fun glTexParameterIuiv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL30C.nglTexParameterIuiv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glDeleteFramebuffers(n: Int, framebuffers: Long): Unit =
      GL30C.nglDeleteFramebuffers(n, framebuffers)

  override fun glDeleteFramebuffers(framebuffer: Int): Unit =
      GL30C.glDeleteFramebuffers(framebuffer)

  override fun glVertexAttribIPointer(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
  ): Unit = GL30C.nglVertexAttribIPointer(index, size, type, stride, pointer)

  override fun glBindFragDataLocation(
    program: Int,
    colorNumber: Int,
    name: Long,
  ): Unit = GL30C.nglBindFragDataLocation(program, colorNumber, name)

  override fun glGetTexParameterIiv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL30C.nglGetTexParameterIiv(target, pname, params)

  @PtrParameter([2])
  override fun glUniform3uiv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL30C.nglUniform3uiv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glEndTransformFeedback(): Unit = GL30C.glEndTransformFeedback()

  override fun glDeleteRenderbuffers(renderbuffer: Int): Unit =
      GL30C.glDeleteRenderbuffers(renderbuffer)

  override fun glDeleteRenderbuffers(n: Int, renderbuffers: Long): Unit =
      GL30C.nglDeleteRenderbuffers(n, renderbuffers)

  @PtrParameter([1])
  override fun glVertexAttribI3uiv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI3uiv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glRenderbufferStorageMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = GL30C.glRenderbufferStorageMultisample(target, samples, internalformat, width, height)

  @PtrParameter([1])
  override fun glVertexAttribI4sv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI4sv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glDeleteVertexArrays(array: Int): Unit = GL30C.glDeleteVertexArrays(array)

  override fun glDeleteVertexArrays(n: Int, arrays: Long): Unit = GL30C.nglDeleteVertexArrays(n,
      arrays)

  @PtrParameter([2])
  override fun glGetVertexAttribIiv(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL30C.nglGetVertexAttribIiv(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetFragDataLocation(program: Int, name: Long): Int =
      GL30C.nglGetFragDataLocation(program, name)

  override fun glVertexAttribI2uiv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI2uiv(index, v)

  override fun glEndConditionalRender(): Unit = GL30C.glEndConditionalRender()

  @PtrParameter([1])
  override fun glVertexAttribI4bv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI4bv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glGetVertexAttribIiv(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = GL30C.nglGetVertexAttribIiv(index, pname, params)

  @PtrParameter([1])
  override fun glVertexAttribI3iv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI3iv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribI4ubv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI4ubv(index, v)

  override fun glCheckFramebufferStatus(target: Int): Int = GL30C.glCheckFramebufferStatus(target)

  override fun glFramebufferTexture1D(
    target: Int,
    attachment: Int,
    textarget: Int,
    texture: Int,
    level: Int,
  ): Unit = GL30C.glFramebufferTexture1D(target, attachment, textarget, texture, level)

  override fun glBeginTransformFeedback(primitiveMode: Int): Unit =
      GL30C.glBeginTransformFeedback(primitiveMode)

  @PtrParameter([1])
  override fun glVertexAttribI4iv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL30C.nglVertexAttribI4iv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glRenderbufferStorage(
    target: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = GL30C.glRenderbufferStorage(target, internalformat, width, height)

  @PtrParameter([1])
  override fun glGenVertexArrays(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-arrays$0`: Ptr): Unit =
      GL30C.nglGenVertexArrays(n, `$v$c$dev-luna5ama-kmogus-Ptr$-arrays$0`.address)

  override fun glVertexAttribI2ui(
    index: Int,
    x: Int,
    y: Int,
  ): Unit = GL30C.glVertexAttribI2ui(index, x, y)

  override fun glVertexAttribI1ui(index: Int, x: Int): Unit = GL30C.glVertexAttribI1ui(index, x)

  override fun glClearBufferfv(
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
  ): Unit = GL30C.nglClearBufferfv(buffer, drawbuffer, `value`)

  override fun glClearBufferiv(
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
  ): Unit = GL30C.nglClearBufferiv(buffer, drawbuffer, `value`)

  override fun glVertexAttribI2iv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI2iv(index, v)

  override fun glVertexAttribI1iv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI1iv(index, v)

  override fun glClearBufferfi(
    buffer: Int,
    drawbuffer: Int,
    depth: Float,
    stencil: Int,
  ): Unit = GL30C.glClearBufferfi(buffer, drawbuffer, depth, stencil)

  override fun glVertexAttribI3ui(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
  ): Unit = GL30C.glVertexAttribI3ui(index, x, y, z)

  override fun glVertexAttribI3iv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI3iv(index, v)

  override fun glVertexAttribI1i(index: Int, x: Int): Unit = GL30C.glVertexAttribI1i(index, x)

  override fun glClearBufferuiv(
    buffer: Int,
    drawbuffer: Int,
    `value`: Long,
  ): Unit = GL30C.nglClearBufferuiv(buffer, drawbuffer, `value`)

  override fun glVertexAttribI4ui(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
  ): Unit = GL30C.glVertexAttribI4ui(index, x, y, z, w)

  override fun glVertexAttribI3i(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
  ): Unit = GL30C.glVertexAttribI3i(index, x, y, z)

  override fun glVertexAttribI4i(
    index: Int,
    x: Int,
    y: Int,
    z: Int,
    w: Int,
  ): Unit = GL30C.glVertexAttribI4i(index, x, y, z, w)

  override fun glVertexAttribI4iv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI4iv(index, v)

  override fun glVertexAttribI2i(
    index: Int,
    x: Int,
    y: Int,
  ): Unit = GL30C.glVertexAttribI2i(index, x, y)

  override fun glBindRenderbuffer(target: Int, renderbuffer: Int): Unit =
      GL30C.glBindRenderbuffer(target, renderbuffer)

  override fun glUniform1ui(location: Int, v0: Int): Unit = GL30C.glUniform1ui(location, v0)

  override fun glVertexAttribI4sv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI4sv(index, v)

  override fun glUniform2ui(
    location: Int,
    v0: Int,
    v1: Int,
  ): Unit = GL30C.glUniform2ui(location, v0, v1)

  override fun glClampColor(target: Int, clamp: Int): Unit = GL30C.glClampColor(target, clamp)

  override fun glVertexAttribI4bv(index: Int, v: Long): Unit = GL30C.nglVertexAttribI4bv(index, v)

  override fun glIsRenderbuffer(renderbuffer: Int): Boolean = GL30C.glIsRenderbuffer(renderbuffer)

  override fun glGenRenderbuffers(n: Int, renderbuffers: Long): Unit = GL30C.nglGenRenderbuffers(n,
      renderbuffers)

  override fun glUniform2uiv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL30C.nglUniform2uiv(location, count, `value`)

  override fun glUniform1uiv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL30C.nglUniform1uiv(location, count, `value`)

  override fun glUniform3uiv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL30C.nglUniform3uiv(location, count, `value`)

  override fun glUniform4uiv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL30C.nglUniform4uiv(location, count, `value`)

  override fun glGetUniformuiv(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = GL30C.nglGetUniformuiv(program, location, params)

  override fun glUniform4ui(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
  ): Unit = GL30C.glUniform4ui(location, v0, v1, v2, v3)

  override fun glUniform3ui(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
  ): Unit = GL30C.glUniform3ui(location, v0, v1, v2)

  override fun glBindBufferRange(
    target: Int,
    index: Int,
    buffer: Int,
    offset: Long,
    size: Long,
  ): Unit = GL30C.glBindBufferRange(target, index, buffer, offset, size)

  override fun glEnablei(cap: Int, index: Int): Unit = GL30C.glEnablei(cap, index)

  override fun glBindVertexArray(array: Int): Unit = GL30C.glBindVertexArray(array)

  override fun glIsEnabledi(target: Int, index: Int): Boolean = GL30C.glIsEnabledi(target, index)

  override fun glBindBufferBase(
    target: Int,
    index: Int,
    buffer: Int,
  ): Unit = GL30C.glBindBufferBase(target, index, buffer)

  override fun glColorMaski(
    buf: Int,
    r: Boolean,
    g: Boolean,
    b: Boolean,
    a: Boolean,
  ): Unit = GL30C.glColorMaski(buf, r, g, b, a)

  override fun glGenerateMipmap(target: Int): Unit = GL30C.glGenerateMipmap(target)

  override fun glTexParameterIiv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL30C.nglTexParameterIiv(target, pname, params)

  override fun glTexParameterIuiv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL30C.nglTexParameterIuiv(target, pname, params)

  override fun glGenFramebuffers(n: Int, framebuffers: Long): Unit = GL30C.nglGenFramebuffers(n,
      framebuffers)

  override fun glBindFramebuffer(target: Int, framebuffer: Int): Unit =
      GL30C.glBindFramebuffer(target, framebuffer)

  override fun glBlitFramebuffer(
    srcX0: Int,
    srcY0: Int,
    srcX1: Int,
    srcY1: Int,
    dstX0: Int,
    dstY0: Int,
    dstX1: Int,
    dstY1: Int,
    mask: Int,
    filter: Int,
  ): Unit = GL30C.glBlitFramebuffer(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask,
      filter)

  override fun glIsFramebuffer(framebuffer: Int): Boolean = GL30C.glIsFramebuffer(framebuffer)

  override fun glDisablei(target: Int, index: Int): Unit = GL30C.glDisablei(target, index)

  override fun glGetIntegeri_v(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = GL30C.nglGetIntegeri_v(target, index, `data`)

  override fun glGetBooleani_v(
    target: Int,
    index: Int,
    `data`: Long,
  ): Unit = GL30C.nglGetBooleani_v(target, index, `data`)

  override fun glIsVertexArray(array: Int): Boolean = GL30C.glIsVertexArray(array)

  override fun glGenVertexArrays(n: Int, arrays: Long): Unit = GL30C.nglGenVertexArrays(n, arrays)
}
