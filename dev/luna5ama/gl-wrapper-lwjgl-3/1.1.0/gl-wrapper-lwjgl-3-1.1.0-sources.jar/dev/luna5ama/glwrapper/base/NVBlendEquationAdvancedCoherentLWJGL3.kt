package dev.luna5ama.glwrapper.base

public class NVBlendEquationAdvancedCoherentLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVBlendEquationAdvancedCoherent
