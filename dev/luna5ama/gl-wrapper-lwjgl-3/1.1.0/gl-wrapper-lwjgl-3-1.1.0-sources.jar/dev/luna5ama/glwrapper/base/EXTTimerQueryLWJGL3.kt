package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTTimerQueryLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTimerQuery {
  @PtrParameter([2])
  override fun glGetQueryObjecti64vEXT(
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTTimerQuery.nglGetQueryObjecti64vEXT(id, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetQueryObjecti64vEXT(
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTTimerQuery.nglGetQueryObjecti64vEXT(id, pname, params)

  override fun glGetQueryObjectui64vEXT(
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTTimerQuery.nglGetQueryObjectui64vEXT(id, pname, params)

  @PtrParameter([2])
  override fun glGetQueryObjectui64vEXT(
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTTimerQuery.nglGetQueryObjectui64vEXT(id, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)
}
