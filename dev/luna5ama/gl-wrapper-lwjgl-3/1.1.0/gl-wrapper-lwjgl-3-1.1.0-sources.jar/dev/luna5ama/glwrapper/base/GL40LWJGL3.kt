package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.CharSequence
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL40C

public class GL40LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL40 {
  @PtrParameter([2])
  override fun glGetSubroutineUniformLocation(
    program: Int,
    shadertype: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Int = GL40C.nglGetSubroutineUniformLocation(program, shadertype,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([4, 5])
  override fun glGetActiveSubroutineUniformName(
    program: Int,
    shadertype: Int,
    index: Int,
    bufsize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = GL40C.nglGetActiveSubroutineUniformName(program, shadertype, index, bufsize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([4])
  override fun glGetActiveSubroutineUniformiv(
    program: Int,
    shadertype: Int,
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = GL40C.nglGetActiveSubroutineUniformiv(program, shadertype, index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  override fun glBlendFuncSeparatei(
    buf: Int,
    srcRGB: Int,
    dstRGB: Int,
    srcAlpha: Int,
    dstAlpha: Int,
  ): Unit = GL40C.glBlendFuncSeparatei(buf, srcRGB, dstRGB, srcAlpha, dstAlpha)

  @PtrParameter([2])
  override fun glDrawElementsIndirect(
    mode: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr,
  ): Unit = GL40C.nglDrawElementsIndirect(mode, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniformMatrix4dv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix2x3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniformMatrix2x3dv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glBlendEquationSeparatei(
    buf: Int,
    modeRGB: Int,
    modeAlpha: Int,
  ): Unit = GL40C.glBlendEquationSeparatei(buf, modeRGB, modeAlpha)

  @PtrParameter([1])
  override fun glDrawArraysIndirect(mode: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr):
      Unit = GL40C.nglDrawArraysIndirect(mode, `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address)

  @PtrParameter([2])
  override fun glUniform1dv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniform1dv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform3dv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniform3dv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniformMatrix3dv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix2x4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniformMatrix2x4dv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniformMatrix2x4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL40C.nglUniformMatrix2x4dv(location, count, transpose, `value`)

  override fun glUniformMatrix3x2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL40C.nglUniformMatrix3x2dv(location, count, transpose, `value`)

  @PtrParameter([2])
  override fun glUniform2dv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniform2dv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix3x4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniformMatrix3x4dv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniformMatrix2dv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniformMatrix2x3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL40C.nglUniformMatrix2x3dv(location, count, transpose, `value`)

  override fun glUniformMatrix3x4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL40C.nglUniformMatrix3x4dv(location, count, transpose, `value`)

  @PtrParameter([3])
  override fun glUniformMatrix4x2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniformMatrix4x2dv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniformMatrix4x2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL40C.nglUniformMatrix4x2dv(location, count, transpose, `value`)

  @PtrParameter([2])
  override fun glUniform4dv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniform4dv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glDrawElementsIndirect(
    mode: Int,
    type: Int,
    indirect: Long,
  ): Unit = GL40C.nglDrawElementsIndirect(mode, type, indirect)

  @PtrParameter([3])
  override fun glUniformMatrix3x2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniformMatrix3x2dv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glDrawArraysIndirect(mode: Int, indirect: Long): Unit =
      GL40C.nglDrawArraysIndirect(mode, indirect)

  @PtrParameter([3])
  override fun glUniformMatrix4x3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL40C.nglUniformMatrix4x3dv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniformMatrix4x3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL40C.nglUniformMatrix4x3dv(location, count, transpose, `value`)

  @PtrParameter([2])
  override fun glGetUniformdv(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL40C.nglGetUniformdv(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetSubroutineUniformLocation(
    program: Int,
    shadertype: Int,
    name: Long,
  ): Int = GL40C.nglGetSubroutineUniformLocation(program, shadertype, name)

  @PtrParameter([3])
  override fun glGetQueryIndexediv(
    target: Int,
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL40C.nglGetQueryIndexediv(target, index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glResumeTransformFeedback(): Unit = GL40C.glResumeTransformFeedback()

  override fun glUniformSubroutinesuiv(
    shadertype: Int,
    count: Int,
    indices: Long,
  ): Unit = GL40C.nglUniformSubroutinesuiv(shadertype, count, indices)

  override fun glDeleteTransformFeedbacks(n: Int, ids: Long): Unit =
      GL40C.nglDeleteTransformFeedbacks(n, ids)

  override fun glDeleteTransformFeedbacks(transformFeedback: Int): Unit =
      GL40C.glDeleteTransformFeedbacks(transformFeedback)

  @PtrParameter([3])
  override fun glGetProgramStageiv(
    program: Int,
    shadertype: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = GL40C.nglGetProgramStageiv(program, shadertype, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  @PtrParameter([2])
  override fun glUniformSubroutinesuiv(
    shadertype: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
  ): Unit = GL40C.nglUniformSubroutinesuiv(shadertype, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address)

  override fun glBindTransformFeedback(target: Int, id: Int): Unit =
      GL40C.glBindTransformFeedback(target, id)

  override fun glGetQueryIndexediv(
    target: Int,
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = GL40C.nglGetQueryIndexediv(target, index, pname, params)

  @PtrParameter([1])
  override fun glDeleteTransformFeedbacks(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr): Unit
      = GL40C.nglDeleteTransformFeedbacks(n, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address)

  override fun glBeginQueryIndexed(
    target: Int,
    index: Int,
    id: Int,
  ): Unit = GL40C.glBeginQueryIndexed(target, index, id)

  @PtrParameter([1])
  override fun glPatchParameterfv(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr): Unit =
      GL40C.nglPatchParameterfv(pname, `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  override fun glGetProgramStageiv(
    program: Int,
    shadertype: Int,
    pname: Int,
    values: Long,
  ): Unit = GL40C.nglGetProgramStageiv(program, shadertype, pname, values)

  override fun glDrawTransformFeedback(mode: Int, id: Int): Unit =
      GL40C.glDrawTransformFeedback(mode, id)

  override fun glGetSubroutineIndex(
    program: Int,
    shadertype: Int,
    name: CharSequence,
  ): Int = GL40C.glGetSubroutineIndex(program, shadertype, name)

  override fun glGetSubroutineIndex(
    program: Int,
    shadertype: Int,
    name: Long,
  ): Int = GL40C.nglGetSubroutineIndex(program, shadertype, name)

  override fun glDrawTransformFeedbackStream(
    mode: Int,
    id: Int,
    stream: Int,
  ): Unit = GL40C.glDrawTransformFeedbackStream(mode, id, stream)

  override fun glGetActiveSubroutineName(
    program: Int,
    shadertype: Int,
    index: Int,
    bufsize: Int,
    length: Long,
    name: Long,
  ): Unit = GL40C.nglGetActiveSubroutineName(program, shadertype, index, bufsize, length, name)

  @PtrParameter([1])
  override fun glGenTransformFeedbacks(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr): Unit =
      GL40C.nglGenTransformFeedbacks(n, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address)

  override fun glGetActiveSubroutineUniformiv(
    program: Int,
    shadertype: Int,
    index: Int,
    pname: Int,
    values: Long,
  ): Unit = GL40C.nglGetActiveSubroutineUniformiv(program, shadertype, index, pname, values)

  @PtrParameter([4, 5])
  override fun glGetActiveSubroutineName(
    program: Int,
    shadertype: Int,
    index: Int,
    bufsize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = GL40C.nglGetActiveSubroutineName(program, shadertype, index, bufsize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glGetUniformSubroutineuiv(
    shadertype: Int,
    location: Int,
    params: Long,
  ): Unit = GL40C.nglGetUniformSubroutineuiv(shadertype, location, params)

  override fun glIsTransformFeedback(id: Int): Boolean = GL40C.glIsTransformFeedback(id)

  override fun glPauseTransformFeedback(): Unit = GL40C.glPauseTransformFeedback()

  override fun glGetActiveSubroutineUniformName(
    program: Int,
    shadertype: Int,
    index: Int,
    bufsize: Int,
    length: Long,
    name: Long,
  ): Unit = GL40C.nglGetActiveSubroutineUniformName(program, shadertype, index, bufsize, length,
      name)

  @PtrParameter([2])
  override fun glGetUniformSubroutineuiv(
    shadertype: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL40C.nglGetUniformSubroutineuiv(shadertype, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetSubroutineIndex(
    program: Int,
    shadertype: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Int = GL40C.nglGetSubroutineIndex(program, shadertype,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glGenTransformFeedbacks(n: Int, ids: Long): Unit = GL40C.nglGenTransformFeedbacks(n,
      ids)

  override fun glUniform1d(location: Int, x: Double): Unit = GL40C.glUniform1d(location, x)

  override fun glUniform3dv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL40C.nglUniform3dv(location, count, `value`)

  override fun glUniform4dv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL40C.nglUniform4dv(location, count, `value`)

  override fun glBlendEquationi(buf: Int, mode: Int): Unit = GL40C.glBlendEquationi(buf, mode)

  override fun glUniform4d(
    location: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
  ): Unit = GL40C.glUniform4d(location, x, y, z, w)

  override fun glUniform2dv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL40C.nglUniform2dv(location, count, `value`)

  override fun glUniform1dv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL40C.nglUniform1dv(location, count, `value`)

  override fun glBlendFunci(
    buf: Int,
    sfactor: Int,
    dfactor: Int,
  ): Unit = GL40C.glBlendFunci(buf, sfactor, dfactor)

  override fun glUniform3d(
    location: Int,
    x: Double,
    y: Double,
    z: Double,
  ): Unit = GL40C.glUniform3d(location, x, y, z)

  override fun glUniformMatrix2dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL40C.nglUniformMatrix2dv(location, count, transpose, `value`)

  override fun glUniform2d(
    location: Int,
    x: Double,
    y: Double,
  ): Unit = GL40C.glUniform2d(location, x, y)

  override fun glUniformMatrix4dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL40C.nglUniformMatrix4dv(location, count, transpose, `value`)

  override fun glPatchParameterfv(pname: Int, values: Long): Unit = GL40C.nglPatchParameterfv(pname,
      values)

  override fun glEndQueryIndexed(target: Int, index: Int): Unit = GL40C.glEndQueryIndexed(target,
      index)

  override fun glGetUniformdv(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = GL40C.nglGetUniformdv(program, location, params)

  override fun glPatchParameteri(pname: Int, `value`: Int): Unit = GL40C.glPatchParameteri(pname,
      `value`)

  override fun glMinSampleShading(`value`: Float): Unit = GL40C.glMinSampleShading(`value`)

  override fun glUniformMatrix3dv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL40C.nglUniformMatrix3dv(location, count, transpose, `value`)
}
