package dev.luna5ama.glwrapper.base

import kotlin.Int

public class GLWrapperInitializerLWJGL3 : GLWrapperInitializer {
  override val priority: Int = 0

  override fun createWrapperInstance(): GLWrapper = GLWrapper(AMDBlendMinmaxFactor =
      ::AMDBlendMinmaxFactorLWJGL3, AMDDebugOutput = ::AMDDebugOutputLWJGL3, AMDDepthClampSeparate =
      ::AMDDepthClampSeparateLWJGL3, AMDDrawBuffersBlend = ::AMDDrawBuffersBlendLWJGL3,
      AMDFramebufferMultisampleAdvanced = ::AMDFramebufferMultisampleAdvancedLWJGL3,
      AMDGPUShaderHalfFloat = ::AMDGPUShaderHalfFloatLWJGL3, AMDGPUShaderHalfFloatFetch =
      ::AMDGPUShaderHalfFloatFetchLWJGL3, AMDGPUShaderInt64 = ::AMDGPUShaderInt64LWJGL3,
      AMDInterleavedElements = ::AMDInterleavedElementsLWJGL3, AMDOcclusionQueryEvent =
      ::AMDOcclusionQueryEventLWJGL3, AMDPerformanceMonitor = ::AMDPerformanceMonitorLWJGL3,
      AMDPinnedMemory = ::AMDPinnedMemoryLWJGL3, AMDQueryBufferObject =
      ::AMDQueryBufferObjectLWJGL3, AMDSamplePositions = ::AMDSamplePositionsLWJGL3,
      AMDSeamlessCubemapPerTexture = ::AMDSeamlessCubemapPerTextureLWJGL3, AMDSparseTexture =
      ::AMDSparseTextureLWJGL3, AMDStencilOperationExtended = ::AMDStencilOperationExtendedLWJGL3,
      AMDTransformFeedback4 = ::AMDTransformFeedback4LWJGL3, AMDVertexShaderTessellator =
      ::AMDVertexShaderTessellatorLWJGL3, ARBBindlessTexture = ::ARBBindlessTextureLWJGL3,
      ARBCLEvent = ::ARBCLEventLWJGL3, ARBComputeVariableGroupSize =
      ::ARBComputeVariableGroupSizeLWJGL3, ARBDebugOutput = ::ARBDebugOutputLWJGL3,
      ARBDepthBufferFloat = ::ARBDepthBufferFloatLWJGL3, ARBES32Compatibility =
      ::ARBES32CompatibilityLWJGL3, ARBFragmentProgram = ::ARBFragmentProgramLWJGL3,
      ARBFramebufferSRGB = ::ARBFramebufferSRGBLWJGL3, ARBGPUShaderInt64 =
      ::ARBGPUShaderInt64LWJGL3, ARBHalfFloatPixel = ::ARBHalfFloatPixelLWJGL3, ARBHalfFloatVertex =
      ::ARBHalfFloatVertexLWJGL3, ARBImaging = ::ARBImagingLWJGL3, ARBMapBufferRange =
      ::ARBMapBufferRangeLWJGL3, ARBMatrixPalette = ::ARBMatrixPaletteLWJGL3,
      ARBParallelShaderCompile = ::ARBParallelShaderCompileLWJGL3, ARBRobustness =
      ::ARBRobustnessLWJGL3, ARBSampleLocations = ::ARBSampleLocationsLWJGL3,
      ARBSeamlessCubemapPerTexture = ::ARBSeamlessCubemapPerTextureLWJGL3, ARBShadingLanguageInclude
      = ::ARBShadingLanguageIncludeLWJGL3, ARBShadowAmbient = ::ARBShadowAmbientLWJGL3,
      ARBSparseBuffer = ::ARBSparseBufferLWJGL3, ARBSparseTexture = ::ARBSparseTextureLWJGL3,
      ARBTextureCompressionRGTC = ::ARBTextureCompressionRGTCLWJGL3, ARBTextureFilterMinmax =
      ::ARBTextureFilterMinmaxLWJGL3, ARBTextureRG = ::ARBTextureRGLWJGL3, ARBVertexBlend =
      ::ARBVertexBlendLWJGL3, ARBVertexProgram = ::ARBVertexProgramLWJGL3, EXT422Pixels =
      ::EXT422PixelsLWJGL3, EXTABGR = ::EXTABGRLWJGL3, EXTBindableUniform =
      ::EXTBindableUniformLWJGL3, EXTBlendEquationSeparate = ::EXTBlendEquationSeparateLWJGL3,
      EXTClipVolumeHint = ::EXTClipVolumeHintLWJGL3, EXTCompiledVertexArray =
      ::EXTCompiledVertexArrayLWJGL3, EXTDebugLabel = ::EXTDebugLabelLWJGL3, EXTDebugMarker =
      ::EXTDebugMarkerLWJGL3, EXTDepthBoundsTest = ::EXTDepthBoundsTestLWJGL3, EXTDirectStateAccess
      = ::EXTDirectStateAccessLWJGL3, EXTDrawInstanced = ::EXTDrawInstancedLWJGL3,
      EXTEGLImageStorage = ::EXTEGLImageStorageLWJGL3, EXTExternalBuffer =
      ::EXTExternalBufferLWJGL3, EXTFramebufferBlit = ::EXTFramebufferBlitLWJGL3,
      EXTFramebufferBlitLayers = ::EXTFramebufferBlitLayersLWJGL3, EXTFramebufferMultisample =
      ::EXTFramebufferMultisampleLWJGL3, EXTFramebufferMultisampleBlitScaled =
      ::EXTFramebufferMultisampleBlitScaledLWJGL3, EXTFramebufferObject =
      ::EXTFramebufferObjectLWJGL3, EXTGeometryShader4 = ::EXTGeometryShader4LWJGL3,
      EXTGPUProgramParameters = ::EXTGPUProgramParametersLWJGL3, EXTGPUShader4 =
      ::EXTGPUShader4LWJGL3, EXTMemoryObject = ::EXTMemoryObjectLWJGL3, EXTMemoryObjectFD =
      ::EXTMemoryObjectFDLWJGL3, EXTMemoryObjectWin32 = ::EXTMemoryObjectWin32LWJGL3,
      EXTPackedDepthStencil = ::EXTPackedDepthStencilLWJGL3, EXTPixelBufferObject =
      ::EXTPixelBufferObjectLWJGL3, EXTPointParameters = ::EXTPointParametersLWJGL3,
      EXTPolygonOffsetClamp = ::EXTPolygonOffsetClampLWJGL3, EXTProvokingVertex =
      ::EXTProvokingVertexLWJGL3, EXTRasterMultisample = ::EXTRasterMultisampleLWJGL3, EXTSemaphore
      = ::EXTSemaphoreLWJGL3, EXTSemaphoreFD = ::EXTSemaphoreFDLWJGL3, EXTSemaphoreWin32 =
      ::EXTSemaphoreWin32LWJGL3, EXTSeparateShaderObjects = ::EXTSeparateShaderObjectsLWJGL3,
      EXTShaderFramebufferFetch = ::EXTShaderFramebufferFetchLWJGL3,
      EXTShaderFramebufferFetchNonCoherent = ::EXTShaderFramebufferFetchNonCoherentLWJGL3,
      EXTShaderImageLoadStore = ::EXTShaderImageLoadStoreLWJGL3, EXTSharedTexturePalette =
      ::EXTSharedTexturePaletteLWJGL3, EXTStencilClearTag = ::EXTStencilClearTagLWJGL3,
      EXTTextureBufferObject = ::EXTTextureBufferObjectLWJGL3, EXTTextureCompressionLATC =
      ::EXTTextureCompressionLATCLWJGL3, EXTTextureCompressionS3TC =
      ::EXTTextureCompressionS3TCLWJGL3, EXTTextureFilterAnisotropic =
      ::EXTTextureFilterAnisotropicLWJGL3, EXTTextureFilterMinmax = ::EXTTextureFilterMinmaxLWJGL3,
      EXTTextureMirrorClamp = ::EXTTextureMirrorClampLWJGL3, EXTTextureSnorm =
      ::EXTTextureSnormLWJGL3, EXTTextureSRGBDecode = ::EXTTextureSRGBDecodeLWJGL3, EXTTextureSRGBR8
      = ::EXTTextureSRGBR8LWJGL3, EXTTextureSRGBRG8 = ::EXTTextureSRGBRG8LWJGL3, EXTTextureStorage =
      ::EXTTextureStorageLWJGL3, EXTTextureSwizzle = ::EXTTextureSwizzleLWJGL3, EXTTimerQuery =
      ::EXTTimerQueryLWJGL3, EXTTransformFeedback = ::EXTTransformFeedbackLWJGL3,
      EXTVertexAttrib64bit = ::EXTVertexAttrib64bitLWJGL3, EXTWin32KeyedMutex =
      ::EXTWin32KeyedMutexLWJGL3, EXTWindowRectangles = ::EXTWindowRectanglesLWJGL3,
      EXTX11SyncObject = ::EXTX11SyncObjectLWJGL3, GL11 = ::GL11LWJGL3, GL12 = ::GL12LWJGL3, GL13 =
      ::GL13LWJGL3, GL14 = ::GL14LWJGL3, GL15 = ::GL15LWJGL3, GL20 = ::GL20LWJGL3, GL21 =
      ::GL21LWJGL3, GL30 = ::GL30LWJGL3, GL31 = ::GL31LWJGL3, GL32 = ::GL32LWJGL3, GL33 =
      ::GL33LWJGL3, GL40 = ::GL40LWJGL3, GL41 = ::GL41LWJGL3, GL42 = ::GL42LWJGL3, GL43 =
      ::GL43LWJGL3, GL44 = ::GL44LWJGL3, GL45 = ::GL45LWJGL3, GL46 = ::GL46LWJGL3,
      KHRBlendEquationAdvanced = ::KHRBlendEquationAdvancedLWJGL3, KHRBlendEquationAdvancedCoherent
      = ::KHRBlendEquationAdvancedCoherentLWJGL3, KHRContextFlushControl =
      ::KHRContextFlushControlLWJGL3, KHRParallelShaderCompile = ::KHRParallelShaderCompileLWJGL3,
      KHRShaderSubgroup = ::KHRShaderSubgroupLWJGL3, KHRTextureCompressionASTCLDR =
      ::KHRTextureCompressionASTCLDRLWJGL3, NVAlphaToCoverageDitherControl =
      ::NVAlphaToCoverageDitherControlLWJGL3, NVBindlessMultiDrawIndirect =
      ::NVBindlessMultiDrawIndirectLWJGL3, NVBindlessMultiDrawIndirectCount =
      ::NVBindlessMultiDrawIndirectCountLWJGL3, NVBindlessTexture = ::NVBindlessTextureLWJGL3,
      NVBlendEquationAdvanced = ::NVBlendEquationAdvancedLWJGL3, NVBlendEquationAdvancedCoherent =
      ::NVBlendEquationAdvancedCoherentLWJGL3, NVBlendMinmaxFactor = ::NVBlendMinmaxFactorLWJGL3,
      NVClipSpaceWScaling = ::NVClipSpaceWScalingLWJGL3, NVCommandList = ::NVCommandListLWJGL3,
      NVConservativeRaster = ::NVConservativeRasterLWJGL3, NVConservativeRasterDilate =
      ::NVConservativeRasterDilateLWJGL3, NVConservativeRasterPreSnap =
      ::NVConservativeRasterPreSnapLWJGL3, NVConservativeRasterPreSnapTriangles =
      ::NVConservativeRasterPreSnapTrianglesLWJGL3, NVCopyDepthToColor = ::NVCopyDepthToColorLWJGL3,
      NVCopyImage = ::NVCopyImageLWJGL3, NVDeepTexture3D = ::NVDeepTexture3DLWJGL3,
      NVDepthBufferFloat = ::NVDepthBufferFloatLWJGL3, NVDepthClamp = ::NVDepthClampLWJGL3,
      NVDrawTexture = ::NVDrawTextureLWJGL3, NVDrawVulkanImage = ::NVDrawVulkanImageLWJGL3,
      NVExplicitMultisample = ::NVExplicitMultisampleLWJGL3, NVFence = ::NVFenceLWJGL3,
      NVFillRectangle = ::NVFillRectangleLWJGL3, NVFloatBuffer = ::NVFloatBufferLWJGL3,
      NVFogDistance = ::NVFogDistanceLWJGL3, NVFragmentCoverageToColor =
      ::NVFragmentCoverageToColorLWJGL3, NVFramebufferMixedSamples =
      ::NVFramebufferMixedSamplesLWJGL3, NVFramebufferMultisampleCoverage =
      ::NVFramebufferMultisampleCoverageLWJGL3, NVGPUMulticast = ::NVGPUMulticastLWJGL3,
      NVGPUShader5 = ::NVGPUShader5LWJGL3, NVInternalformatSampleQuery =
      ::NVInternalformatSampleQueryLWJGL3, NVLightMaxExponent = ::NVLightMaxExponentLWJGL3,
      NVMemoryAttachment = ::NVMemoryAttachmentLWJGL3, NVMemoryObjectSparse =
      ::NVMemoryObjectSparseLWJGL3, NVMeshShader = ::NVMeshShaderLWJGL3, NVMultisampleCoverage =
      ::NVMultisampleCoverageLWJGL3, NVMultisampleFilterHint = ::NVMultisampleFilterHintLWJGL3,
      NVPackedDepthStencil = ::NVPackedDepthStencilLWJGL3, NVPathRendering =
      ::NVPathRenderingLWJGL3, NVPathRenderingSharedEdge = ::NVPathRenderingSharedEdgeLWJGL3,
      NVPixelDataRange = ::NVPixelDataRangeLWJGL3, NVPointSprite = ::NVPointSpriteLWJGL3,
      NVPrimitiveShadingRate = ::NVPrimitiveShadingRateLWJGL3, NVQueryResource =
      ::NVQueryResourceLWJGL3, NVQueryResourceTag = ::NVQueryResourceTagLWJGL3,
      NVRepresentativeFragmentTest = ::NVRepresentativeFragmentTestLWJGL3,
      NVRobustnessVideoMemoryPurge = ::NVRobustnessVideoMemoryPurgeLWJGL3, NVSampleLocations =
      ::NVSampleLocationsLWJGL3, NVScissorExclusive = ::NVScissorExclusiveLWJGL3, NVShaderBufferLoad
      = ::NVShaderBufferLoadLWJGL3, NVShaderBufferStore = ::NVShaderBufferStoreLWJGL3,
      NVShaderSubgroupPartitioned = ::NVShaderSubgroupPartitionedLWJGL3, NVShaderThreadGroup =
      ::NVShaderThreadGroupLWJGL3, NVShadingRateImage = ::NVShadingRateImageLWJGL3,
      NVTexgenReflection = ::NVTexgenReflectionLWJGL3, NVTextureBarrier = ::NVTextureBarrierLWJGL3,
      NVTextureMultisample = ::NVTextureMultisampleLWJGL3, NVTextureShader =
      ::NVTextureShaderLWJGL3, NVTextureShader2 = ::NVTextureShader2LWJGL3, NVTextureShader3 =
      ::NVTextureShader3LWJGL3, NVTimelineSemaphore = ::NVTimelineSemaphoreLWJGL3,
      NVTransformFeedback = ::NVTransformFeedbackLWJGL3, NVTransformFeedback2 =
      ::NVTransformFeedback2LWJGL3, NVUniformBufferUnifiedMemory =
      ::NVUniformBufferUnifiedMemoryLWJGL3, NVVertexArrayRange = ::NVVertexArrayRangeLWJGL3,
      NVVertexArrayRange2 = ::NVVertexArrayRange2LWJGL3, NVVertexAttribInteger64bit =
      ::NVVertexAttribInteger64bitLWJGL3, NVVertexBufferUnifiedMemory =
      ::NVVertexBufferUnifiedMemoryLWJGL3, NVViewportSwizzle = ::NVViewportSwizzleLWJGL3, )
}
