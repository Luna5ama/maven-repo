package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTDrawInstancedLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTDrawInstanced {
  @PtrParameter([3])
  override fun glDrawElementsInstancedEXT(
    mode: Int,
    count: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
    primcount: Int,
  ): Unit = org.lwjgl.opengl.EXTDrawInstanced.nglDrawElementsInstancedEXT(mode, count, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address, primcount)

  override fun glDrawElementsInstancedEXT(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
  ): Unit = org.lwjgl.opengl.EXTDrawInstanced.nglDrawElementsInstancedEXT(mode, count, type,
      indices, primcount)

  override fun glDrawArraysInstancedEXT(
    mode: Int,
    start: Int,
    count: Int,
    primcount: Int,
  ): Unit = org.lwjgl.opengl.EXTDrawInstanced.glDrawArraysInstancedEXT(mode, start, count,
      primcount)
}
