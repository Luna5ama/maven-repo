package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBShadingLanguageIncludeLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBShadingLanguageInclude {
  override fun glNamedStringARB(
    type: Int,
    namelen: Int,
    name: Long,
    stringlen: Int,
    string: Long,
  ): Unit = org.lwjgl.opengl.ARBShadingLanguageInclude.nglNamedStringARB(type, namelen, name,
      stringlen, string)

  override fun glIsNamedStringARB(namelen: Int, name: Long): Boolean =
      org.lwjgl.opengl.ARBShadingLanguageInclude.nglIsNamedStringARB(namelen, name)

  @PtrParameter([1, 3, 4])
  override fun glGetNamedStringARB(
    namelen: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-stringlen$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBShadingLanguageInclude.nglGetNamedStringARB(namelen,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-stringlen$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`.address)

  override fun glDeleteNamedStringARB(namelen: Int, name: Long): Unit =
      org.lwjgl.opengl.ARBShadingLanguageInclude.nglDeleteNamedStringARB(namelen, name)

  @PtrParameter([2, 4])
  override fun glNamedStringARB(
    type: Int,
    namelen: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
    stringlen: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBShadingLanguageInclude.nglNamedStringARB(type, namelen,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address, stringlen,
      `$v$c$dev-luna5ama-kmogus-Ptr$-string$0`.address)

  @PtrParameter([1, 3])
  override fun glGetNamedStringivARB(
    namelen: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBShadingLanguageInclude.nglGetNamedStringivARB(namelen,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glIsNamedStringARB(namelen: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr):
      Boolean = org.lwjgl.opengl.ARBShadingLanguageInclude.nglIsNamedStringARB(namelen,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glGetNamedStringARB(
    namelen: Int,
    name: Long,
    bufSize: Int,
    stringlen: Long,
    string: Long,
  ): Unit = org.lwjgl.opengl.ARBShadingLanguageInclude.nglGetNamedStringARB(namelen, name, bufSize,
      stringlen, string)

  @PtrParameter([2, 3])
  override fun glCompileShaderIncludeARB(
    shader: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-path$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBShadingLanguageInclude.nglCompileShaderIncludeARB(shader, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-path$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address)

  override fun glCompileShaderIncludeARB(
    shader: Int,
    count: Int,
    path: Long,
    length: Long,
  ): Unit = org.lwjgl.opengl.ARBShadingLanguageInclude.nglCompileShaderIncludeARB(shader, count,
      path, length)

  override fun glGetNamedStringivARB(
    namelen: Int,
    name: Long,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBShadingLanguageInclude.nglGetNamedStringivARB(namelen, name, pname,
      params)

  @PtrParameter([1])
  override fun glDeleteNamedStringARB(namelen: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr):
      Unit = org.lwjgl.opengl.ARBShadingLanguageInclude.nglDeleteNamedStringARB(namelen,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)
}
