package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.CharSequence
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL43C

public class GL43LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL43 {
  @PtrParameter([2])
  override fun glGetProgramResourceLocation(
    program: Int,
    programInterface: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Int = GL43C.nglGetProgramResourceLocation(program, programInterface,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([2])
  override fun glGetFramebufferParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL43C.nglGetFramebufferParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetProgramResourceLocationIndex(
    program: Int,
    programInterface: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Int = GL43C.nglGetProgramResourceLocationIndex(program, programInterface,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([2])
  override fun glMultiDrawElementsIndirect(
    mode: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr,
    drawcount: Int,
    stride: Int,
  ): Unit = GL43C.nglMultiDrawElementsIndirect(mode, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address, drawcount, stride)

  @PtrParameter([4])
  override fun glClearBufferData(
    target: Int,
    internalformat: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL43C.nglClearBufferData(target, internalformat, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([6])
  override fun glClearBufferSubData(
    target: Int,
    internalformat: Int,
    offset: Long,
    size: Long,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL43C.nglClearBufferSubData(target, internalformat, offset, size, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glDispatchComputeIndirect(indirect: Long): Unit =
      GL43C.glDispatchComputeIndirect(indirect)

  @PtrParameter([4])
  override fun glDebugMessageControl(
    source: Int,
    type: Int,
    severity: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr,
    enabled: Boolean,
  ): Unit = GL43C.nglDebugMessageControl(source, type, severity, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address, enabled)

  override fun glClearBufferSubData(
    target: Int,
    internalformat: Int,
    offset: Long,
    size: Long,
    format: Int,
    type: Int,
    `data`: Long,
  ): Unit = GL43C.nglClearBufferSubData(target, internalformat, offset, size, format, type, `data`)

  override fun glShaderStorageBlockBinding(
    program: Int,
    storageBlockIndex: Int,
    storageBlockBinding: Int,
  ): Unit = GL43C.glShaderStorageBlockBinding(program, storageBlockIndex, storageBlockBinding)

  override fun glGetProgramResourceIndex(
    program: Int,
    programInterface: Int,
    name: Long,
  ): Int = GL43C.nglGetProgramResourceIndex(program, programInterface, name)

  override fun glGetProgramResourceIndex(
    program: Int,
    programInterface: Int,
    name: CharSequence,
  ): Int = GL43C.glGetProgramResourceIndex(program, programInterface, name)

  @PtrParameter([3])
  override fun glGetProgramInterfaceiv(
    program: Int,
    programInterface: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL43C.nglGetProgramInterfaceiv(program, programInterface, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glDebugMessageInsert(
    source: Int,
    type: Int,
    id: Int,
    severity: Int,
    length: Int,
    message: Long,
  ): Unit = GL43C.nglDebugMessageInsert(source, type, id, severity, length, message)

  override fun glInvalidateSubFramebuffer(
    target: Int,
    numAttachments: Int,
    attachments: Long,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = GL43C.nglInvalidateSubFramebuffer(target, numAttachments, attachments, x, y, width,
      height)

  override fun glGetProgramResourceiv(
    program: Int,
    programInterface: Int,
    index: Int,
    propCount: Int,
    props: Long,
    bufSize: Int,
    length: Long,
    params: Long,
  ): Unit = GL43C.nglGetProgramResourceiv(program, programInterface, index, propCount, props,
      bufSize, length, params)

  override fun glVertexAttribIFormat(
    attribindex: Int,
    size: Int,
    type: Int,
    relativeoffset: Int,
  ): Unit = GL43C.glVertexAttribIFormat(attribindex, size, type, relativeoffset)

  override fun glTexStorage3DMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
    fixedsamplelocations: Boolean,
  ): Unit = GL43C.glTexStorage3DMultisample(target, samples, internalformat, width, height, depth,
      fixedsamplelocations)

  @PtrParameter([2])
  override fun glInvalidateSubFramebuffer(
    target: Int,
    numAttachments: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-attachments$0`: Ptr,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = GL43C.nglInvalidateSubFramebuffer(target, numAttachments,
      `$v$c$dev-luna5ama-kmogus-Ptr$-attachments$0`.address, x, y, width, height)

  @PtrParameter([3])
  override fun glObjectLabel(
    identifier: Int,
    name: Int,
    length: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`: Ptr,
  ): Unit = GL43C.nglObjectLabel(identifier, name, length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`.address)

  override fun glGetProgramResourceLocationIndex(
    program: Int,
    programInterface: Int,
    name: Long,
  ): Int = GL43C.nglGetProgramResourceLocationIndex(program, programInterface, name)

  override fun glVertexAttribBinding(attribindex: Int, bindingindex: Int): Unit =
      GL43C.glVertexAttribBinding(attribindex, bindingindex)

  override fun glFramebufferParameteri(
    target: Int,
    pname: Int,
    `param`: Int,
  ): Unit = GL43C.glFramebufferParameteri(target, pname, `param`)

  override fun glInvalidateBufferSubData(
    buffer: Int,
    offset: Long,
    length: Long,
  ): Unit = GL43C.glInvalidateBufferSubData(buffer, offset, length)

  override fun glMultiDrawElementsIndirect(
    mode: Int,
    type: Int,
    indirect: Long,
    drawcount: Int,
    stride: Int,
  ): Unit = GL43C.nglMultiDrawElementsIndirect(mode, type, indirect, drawcount, stride)

  @PtrParameter([5])
  override fun glDebugMessageInsert(
    source: Int,
    type: Int,
    id: Int,
    severity: Int,
    length: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-message$0`: Ptr,
  ): Unit = GL43C.nglDebugMessageInsert(source, type, id, severity, length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-message$0`.address)

  @PtrParameter([2])
  override fun glInvalidateFramebuffer(
    target: Int,
    numAttachments: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-attachments$0`: Ptr,
  ): Unit = GL43C.nglInvalidateFramebuffer(target, numAttachments,
      `$v$c$dev-luna5ama-kmogus-Ptr$-attachments$0`.address)

  override fun glGetProgramResourceName(
    program: Int,
    programInterface: Int,
    index: Int,
    bufSize: Int,
    length: Long,
    name: Long,
  ): Unit = GL43C.nglGetProgramResourceName(program, programInterface, index, bufSize, length, name)

  override fun glTexStorage2DMultisample(
    target: Int,
    samples: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    fixedsamplelocations: Boolean,
  ): Unit = GL43C.glTexStorage2DMultisample(target, samples, internalformat, width, height,
      fixedsamplelocations)

  override fun glMultiDrawArraysIndirect(
    mode: Int,
    indirect: Long,
    drawcount: Int,
    stride: Int,
  ): Unit = GL43C.nglMultiDrawArraysIndirect(mode, indirect, drawcount, stride)

  @PtrParameter([4, 5])
  override fun glGetProgramResourceName(
    program: Int,
    programInterface: Int,
    index: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = GL43C.nglGetProgramResourceName(program, programInterface, index, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([1])
  override fun glDebugMessageCallback(callback: Long,
      `$v$c$dev-luna5ama-kmogus-Ptr$-userParam$0`: Ptr): Unit =
      GL43C.nglDebugMessageCallback(callback, `$v$c$dev-luna5ama-kmogus-Ptr$-userParam$0`.address)

  override fun glVertexAttribLFormat(
    attribindex: Int,
    size: Int,
    type: Int,
    relativeoffset: Int,
  ): Unit = GL43C.glVertexAttribLFormat(attribindex, size, type, relativeoffset)

  override fun glGetObjectPtrLabel(
    ptr: Long,
    bufSize: Int,
    length: Long,
    label: Long,
  ): Unit = GL43C.nglGetObjectPtrLabel(ptr, bufSize, length, label)

  override fun glGetDebugMessageLog(
    count: Int,
    bufsize: Int,
    sources: Long,
    types: Long,
    ids: Long,
    severities: Long,
    lengths: Long,
    messageLog: Long,
  ): Int = GL43C.nglGetDebugMessageLog(count, bufsize, sources, types, ids, severities, lengths,
      messageLog)

  @PtrParameter([3, 4])
  override fun glGetObjectLabel(
    identifier: Int,
    name: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`: Ptr,
  ): Unit = GL43C.nglGetObjectLabel(identifier, name, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`.address)

  @PtrParameter([2, 3, 4, 5, 6, 7])
  override fun glGetDebugMessageLog(
    count: Int,
    bufsize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-sources$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-types$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-severities$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-lengths$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-messageLog$0`: Ptr,
  ): Int = GL43C.nglGetDebugMessageLog(count, bufsize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-sources$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-types$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-severities$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-lengths$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-messageLog$0`.address)

  override fun glDebugMessageCallback(callback: Long, userParam: Long): Unit =
      GL43C.nglDebugMessageCallback(callback, userParam)

  override fun glGetInternalformati64v(
    target: Int,
    internalformat: Int,
    pname: Int,
    bufSize: Int,
    params: Long,
  ): Unit = GL43C.nglGetInternalformati64v(target, internalformat, pname, bufSize, params)

  override fun glInvalidateBufferData(buffer: Int): Unit = GL43C.glInvalidateBufferData(buffer)

  @PtrParameter([2])
  override fun glGetProgramResourceIndex(
    program: Int,
    programInterface: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Int = GL43C.nglGetProgramResourceIndex(program, programInterface,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glVertexAttribFormat(
    attribindex: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    relativeoffset: Int,
  ): Unit = GL43C.glVertexAttribFormat(attribindex, size, type, normalized, relativeoffset)

  override fun glInvalidateFramebuffer(
    target: Int,
    numAttachments: Int,
    attachments: Long,
  ): Unit = GL43C.nglInvalidateFramebuffer(target, numAttachments, attachments)

  override fun glInvalidateTexImage(texture: Int, level: Int): Unit =
      GL43C.glInvalidateTexImage(texture, level)

  @PtrParameter([0, 2])
  override fun glObjectPtrLabel(
    `$v$c$dev-luna5ama-kmogus-Ptr$-ptr$0`: Ptr,
    length: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`: Ptr,
  ): Unit = GL43C.nglObjectPtrLabel(`$v$c$dev-luna5ama-kmogus-Ptr$-ptr$0`.address, length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`.address)

  override fun glGetProgramInterfaceiv(
    program: Int,
    programInterface: Int,
    pname: Int,
    params: Long,
  ): Unit = GL43C.nglGetProgramInterfaceiv(program, programInterface, pname, params)

  override fun glDebugMessageControl(
    source: Int,
    type: Int,
    severity: Int,
    count: Int,
    ids: Long,
    enabled: Boolean,
  ): Unit = GL43C.nglDebugMessageControl(source, type, severity, count, ids, enabled)

  @PtrParameter([4, 6, 7])
  override fun glGetProgramResourceiv(
    program: Int,
    programInterface: Int,
    index: Int,
    propCount: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-props$0`: Ptr,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL43C.nglGetProgramResourceiv(program, programInterface, index, propCount,
      `$v$c$dev-luna5ama-kmogus-Ptr$-props$0`.address, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glMultiDrawArraysIndirect(
    mode: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr,
    drawcount: Int,
    stride: Int,
  ): Unit = GL43C.nglMultiDrawArraysIndirect(mode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address, drawcount, stride)

  @PtrParameter([0, 2, 3])
  override fun glGetObjectPtrLabel(
    `$v$c$dev-luna5ama-kmogus-Ptr$-ptr$0`: Ptr,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`: Ptr,
  ): Unit = GL43C.nglGetObjectPtrLabel(`$v$c$dev-luna5ama-kmogus-Ptr$-ptr$0`.address, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-label$0`.address)

  override fun glGetProgramResourceLocation(
    program: Int,
    programInterface: Int,
    name: Long,
  ): Int = GL43C.nglGetProgramResourceLocation(program, programInterface, name)

  override fun glVertexBindingDivisor(bindingindex: Int, divisor: Int): Unit =
      GL43C.glVertexBindingDivisor(bindingindex, divisor)

  override fun glGetFramebufferParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL43C.nglGetFramebufferParameteriv(target, pname, params)

  @PtrParameter([3])
  override fun glPushDebugGroup(
    source: Int,
    id: Int,
    length: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-message$0`: Ptr,
  ): Unit = GL43C.nglPushDebugGroup(source, id, length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-message$0`.address)

  override fun glInvalidateTexSubImage(
    texture: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    zoffset: Int,
    width: Int,
    height: Int,
    depth: Int,
  ): Unit = GL43C.glInvalidateTexSubImage(texture, level, xoffset, yoffset, zoffset, width, height,
      depth)

  @PtrParameter([4])
  override fun glGetInternalformati64v(
    target: Int,
    internalformat: Int,
    pname: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL43C.nglGetInternalformati64v(target, internalformat, pname, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glClearBufferData(
    target: Int,
    internalformat: Int,
    format: Int,
    type: Int,
    `data`: Long,
  ): Unit = GL43C.nglClearBufferData(target, internalformat, format, type, `data`)

  override fun glDispatchCompute(
    num_groups_x: Int,
    num_groups_y: Int,
    num_groups_z: Int,
  ): Unit = GL43C.glDispatchCompute(num_groups_x, num_groups_y, num_groups_z)

  override fun glPushDebugGroup(
    source: Int,
    id: Int,
    message: CharSequence,
  ): Unit = GL43C.glPushDebugGroup(source, id, message)

  override fun glPushDebugGroup(
    source: Int,
    id: Int,
    length: Int,
    message: Long,
  ): Unit = GL43C.nglPushDebugGroup(source, id, length, message)

  override fun glCopyImageSubData(
    srcName: Int,
    srcTarget: Int,
    srcLevel: Int,
    srcX: Int,
    srcY: Int,
    srcZ: Int,
    dstName: Int,
    dstTarget: Int,
    dstLevel: Int,
    dstX: Int,
    dstY: Int,
    dstZ: Int,
    srcWidth: Int,
    srcHeight: Int,
    srcDepth: Int,
  ): Unit = GL43C.glCopyImageSubData(srcName, srcTarget, srcLevel, srcX, srcY, srcZ, dstName,
      dstTarget, dstLevel, dstX, dstY, dstZ, srcWidth, srcHeight, srcDepth)

  override fun glPopDebugGroup(): Unit = GL43C.glPopDebugGroup()

  override fun glGetObjectLabel(
    identifier: Int,
    name: Int,
    bufSize: Int,
    length: Long,
    label: Long,
  ): Unit = GL43C.nglGetObjectLabel(identifier, name, bufSize, length, label)

  override fun glObjectPtrLabel(
    ptr: Long,
    length: Int,
    label: Long,
  ): Unit = GL43C.nglObjectPtrLabel(ptr, length, label)

  override fun glObjectLabel(
    identifier: Int,
    name: Int,
    label: CharSequence,
  ): Unit = GL43C.glObjectLabel(identifier, name, label)

  override fun glObjectLabel(
    identifier: Int,
    name: Int,
    length: Int,
    label: Long,
  ): Unit = GL43C.nglObjectLabel(identifier, name, length, label)

  override fun glTexBufferRange(
    target: Int,
    internalformat: Int,
    buffer: Int,
    offset: Long,
    size: Long,
  ): Unit = GL43C.glTexBufferRange(target, internalformat, buffer, offset, size)

  override fun glTextureView(
    texture: Int,
    target: Int,
    origtexture: Int,
    internalformat: Int,
    minlevel: Int,
    numlevels: Int,
    minlayer: Int,
    numlayers: Int,
  ): Unit = GL43C.glTextureView(texture, target, origtexture, internalformat, minlevel, numlevels,
      minlayer, numlayers)

  override fun glBindVertexBuffer(
    bindingindex: Int,
    buffer: Int,
    offset: Long,
    stride: Int,
  ): Unit = GL43C.glBindVertexBuffer(bindingindex, buffer, offset, stride)
}
