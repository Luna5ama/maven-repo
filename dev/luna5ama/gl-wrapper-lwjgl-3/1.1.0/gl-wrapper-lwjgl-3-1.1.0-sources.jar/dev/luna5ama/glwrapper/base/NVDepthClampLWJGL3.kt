package dev.luna5ama.glwrapper.base

public class NVDepthClampLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVDepthClamp
