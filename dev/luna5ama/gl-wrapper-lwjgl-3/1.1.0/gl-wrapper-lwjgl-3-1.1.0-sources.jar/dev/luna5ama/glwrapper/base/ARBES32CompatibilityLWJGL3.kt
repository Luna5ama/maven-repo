package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Unit

public class ARBES32CompatibilityLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBES32Compatibility {
  override fun glPrimitiveBoundingBoxARB(
    minX: Float,
    minY: Float,
    minZ: Float,
    minW: Float,
    maxX: Float,
    maxY: Float,
    maxZ: Float,
    maxW: Float,
  ): Unit = org.lwjgl.opengl.ARBES32Compatibility.glPrimitiveBoundingBoxARB(minX, minY, minZ, minW,
      maxX, maxY, maxZ, maxW)
}
