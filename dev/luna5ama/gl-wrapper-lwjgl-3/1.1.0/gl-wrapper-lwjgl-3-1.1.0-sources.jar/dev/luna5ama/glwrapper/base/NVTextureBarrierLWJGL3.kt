package dev.luna5ama.glwrapper.base

import kotlin.Unit

public class NVTextureBarrierLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVTextureBarrier {
  override fun glTextureBarrierNV(): Unit = org.lwjgl.opengl.NVTextureBarrier.glTextureBarrierNV()
}
