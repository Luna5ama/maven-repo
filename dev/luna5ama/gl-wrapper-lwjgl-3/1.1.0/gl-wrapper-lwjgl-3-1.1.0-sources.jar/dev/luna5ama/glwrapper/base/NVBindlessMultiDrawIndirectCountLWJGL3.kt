package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVBindlessMultiDrawIndirectCountLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVBindlessMultiDrawIndirectCount {
  override fun glMultiDrawArraysIndirectBindlessCountNV(
    mode: Int,
    indirect: Long,
    drawCount: Long,
    maxDrawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
  ): Unit =
      org.lwjgl.opengl.NVBindlessMultiDrawIndirectCount.nglMultiDrawArraysIndirectBindlessCountNV(mode,
      indirect, drawCount, maxDrawCount, stride, vertexBufferCount)

  override fun glMultiDrawElementsIndirectBindlessCountNV(
    mode: Int,
    type: Int,
    indirect: Long,
    drawCount: Long,
    maxDrawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
  ): Unit =
      org.lwjgl.opengl.NVBindlessMultiDrawIndirectCount.nglMultiDrawElementsIndirectBindlessCountNV(mode,
      type, indirect, drawCount, maxDrawCount, stride, vertexBufferCount)

  @PtrParameter([1])
  override fun glMultiDrawArraysIndirectBindlessCountNV(
    mode: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr,
    drawCount: Long,
    maxDrawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
  ): Unit =
      org.lwjgl.opengl.NVBindlessMultiDrawIndirectCount.nglMultiDrawArraysIndirectBindlessCountNV(mode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address, drawCount, maxDrawCount, stride,
      vertexBufferCount)

  @PtrParameter([2])
  override fun glMultiDrawElementsIndirectBindlessCountNV(
    mode: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr,
    drawCount: Long,
    maxDrawCount: Int,
    stride: Int,
    vertexBufferCount: Int,
  ): Unit =
      org.lwjgl.opengl.NVBindlessMultiDrawIndirectCount.nglMultiDrawElementsIndirectBindlessCountNV(mode,
      type, `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address, drawCount, maxDrawCount, stride,
      vertexBufferCount)
}
