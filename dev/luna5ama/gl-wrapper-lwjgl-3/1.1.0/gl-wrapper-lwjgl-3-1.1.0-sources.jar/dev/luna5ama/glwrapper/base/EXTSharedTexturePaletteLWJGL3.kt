package dev.luna5ama.glwrapper.base

public class EXTSharedTexturePaletteLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTSharedTexturePalette
