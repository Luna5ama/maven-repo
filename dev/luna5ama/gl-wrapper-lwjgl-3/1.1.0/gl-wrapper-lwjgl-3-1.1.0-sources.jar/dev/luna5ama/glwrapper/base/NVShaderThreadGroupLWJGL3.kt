package dev.luna5ama.glwrapper.base

public class NVShaderThreadGroupLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVShaderThreadGroup
