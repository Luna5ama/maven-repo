package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTTextureStorageLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureStorage {
  override fun glTexStorage2DEXT(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.EXTTextureStorage.glTexStorage2DEXT(target, levels, internalformat,
      width, height)

  override fun glTexStorage1DEXT(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
  ): Unit = org.lwjgl.opengl.EXTTextureStorage.glTexStorage1DEXT(target, levels, internalformat,
      width)

  override fun glTexStorage3DEXT(
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
  ): Unit = org.lwjgl.opengl.EXTTextureStorage.glTexStorage3DEXT(target, levels, internalformat,
      width, height, depth)

  override fun glTextureStorage1DEXT(
    texture: Int,
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
  ): Unit = org.lwjgl.opengl.EXTTextureStorage.glTextureStorage1DEXT(texture, target, levels,
      internalformat, width)

  override fun glTextureStorage3DEXT(
    texture: Int,
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    depth: Int,
  ): Unit = org.lwjgl.opengl.EXTTextureStorage.glTextureStorage3DEXT(texture, target, levels,
      internalformat, width, height, depth)

  override fun glTextureStorage2DEXT(
    texture: Int,
    target: Int,
    levels: Int,
    internalformat: Int,
    width: Int,
    height: Int,
  ): Unit = org.lwjgl.opengl.EXTTextureStorage.glTextureStorage2DEXT(texture, target, levels,
      internalformat, width, height)
}
