package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class AMDPerformanceMonitorLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDPerformanceMonitor {
  override fun glGetPerfMonitorCountersAMD(
    group: Int,
    numCounters: Long,
    maxActiveCounters: Long,
    counterSize: Int,
    counters: Long,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorCountersAMD(group, numCounters,
      maxActiveCounters, counterSize, counters)

  @PtrParameter([0, 2])
  override fun glGetPerfMonitorGroupsAMD(
    `$v$c$dev-luna5ama-kmogus-Ptr$-numGroups$0`: Ptr,
    groupsSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-groups$0`: Ptr,
  ): Unit =
      org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorGroupsAMD(`$v$c$dev-luna5ama-kmogus-Ptr$-numGroups$0`.address,
      groupsSize, `$v$c$dev-luna5ama-kmogus-Ptr$-groups$0`.address)

  override fun glGetPerfMonitorGroupStringAMD(
    group: Int,
    bufSize: Int,
    length: Long,
    groupString: Long,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorGroupStringAMD(group, bufSize,
      length, groupString)

  override fun glGenPerfMonitorsAMD(n: Int, monitors: Long): Unit =
      org.lwjgl.opengl.AMDPerformanceMonitor.nglGenPerfMonitorsAMD(n, monitors)

  override fun glGetPerfMonitorCounterInfoAMD(
    group: Int,
    counter: Int,
    pname: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorCounterInfoAMD(group, counter,
      pname, `data`)

  @PtrParameter([1])
  override fun glGenPerfMonitorsAMD(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-monitors$0`: Ptr): Unit =
      org.lwjgl.opengl.AMDPerformanceMonitor.nglGenPerfMonitorsAMD(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-monitors$0`.address)

  override fun glBeginPerfMonitorAMD(monitor: Int): Unit =
      org.lwjgl.opengl.AMDPerformanceMonitor.glBeginPerfMonitorAMD(monitor)

  override fun glGetPerfMonitorGroupsAMD(
    numGroups: Long,
    groupsSize: Int,
    groups: Long,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorGroupsAMD(numGroups, groupsSize,
      groups)

  @PtrParameter([1])
  override fun glDeletePerfMonitorsAMD(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-monitors$0`: Ptr):
      Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglDeletePerfMonitorsAMD(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-monitors$0`.address)

  override fun glEndPerfMonitorAMD(monitor: Int): Unit =
      org.lwjgl.opengl.AMDPerformanceMonitor.glEndPerfMonitorAMD(monitor)

  override fun glDeletePerfMonitorsAMD(n: Int, monitors: Long): Unit =
      org.lwjgl.opengl.AMDPerformanceMonitor.nglDeletePerfMonitorsAMD(n, monitors)

  override fun glGetPerfMonitorCounterStringAMD(
    group: Int,
    counter: Int,
    bufSize: Int,
    length: Long,
    counterString: Long,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorCounterStringAMD(group, counter,
      bufSize, length, counterString)

  override fun glSelectPerfMonitorCountersAMD(
    monitor: Int,
    enable: Boolean,
    group: Int,
    numCounters: Int,
    counterList: Long,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglSelectPerfMonitorCountersAMD(monitor, enable,
      group, numCounters, counterList)

  override fun glGetPerfMonitorCounterDataAMD(
    monitor: Int,
    pname: Int,
    dataSize: Int,
    `data`: Long,
    bytesWritten: Long,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorCounterDataAMD(monitor, pname,
      dataSize, `data`, bytesWritten)

  @PtrParameter([3, 4])
  override fun glGetPerfMonitorCounterStringAMD(
    group: Int,
    counter: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-counterString$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorCounterStringAMD(group, counter,
      bufSize, `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-counterString$0`.address)

  @PtrParameter([2, 3])
  override fun glGetPerfMonitorGroupStringAMD(
    group: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-groupString$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorGroupStringAMD(group, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-groupString$0`.address)

  @PtrParameter([1, 2, 4])
  override fun glGetPerfMonitorCountersAMD(
    group: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-numCounters$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-maxActiveCounters$0`: Ptr,
    counterSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-counters$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorCountersAMD(group,
      `$v$c$dev-luna5ama-kmogus-Ptr$-numCounters$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-maxActiveCounters$0`.address, counterSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-counters$0`.address)

  @PtrParameter([3])
  override fun glGetPerfMonitorCounterInfoAMD(
    group: Int,
    counter: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorCounterInfoAMD(group, counter,
      pname, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([4])
  override fun glSelectPerfMonitorCountersAMD(
    monitor: Int,
    enable: Boolean,
    group: Int,
    numCounters: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-counterList$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglSelectPerfMonitorCountersAMD(monitor, enable,
      group, numCounters, `$v$c$dev-luna5ama-kmogus-Ptr$-counterList$0`.address)

  @PtrParameter([3, 4])
  override fun glGetPerfMonitorCounterDataAMD(
    monitor: Int,
    pname: Int,
    dataSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-bytesWritten$0`: Ptr,
  ): Unit = org.lwjgl.opengl.AMDPerformanceMonitor.nglGetPerfMonitorCounterDataAMD(monitor, pname,
      dataSize, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-bytesWritten$0`.address)
}
