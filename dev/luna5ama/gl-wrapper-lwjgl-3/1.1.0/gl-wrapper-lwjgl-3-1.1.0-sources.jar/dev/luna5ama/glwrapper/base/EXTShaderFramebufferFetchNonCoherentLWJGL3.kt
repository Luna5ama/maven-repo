package dev.luna5ama.glwrapper.base

import kotlin.Unit

public class EXTShaderFramebufferFetchNonCoherentLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTShaderFramebufferFetchNonCoherent {
  override fun glFramebufferFetchBarrierEXT(): Unit =
      org.lwjgl.opengl.EXTShaderFramebufferFetchNonCoherent.glFramebufferFetchBarrierEXT()
}
