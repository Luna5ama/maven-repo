package dev.luna5ama.glwrapper.base

public class KHRContextFlushControlLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : KHRContextFlushControl
