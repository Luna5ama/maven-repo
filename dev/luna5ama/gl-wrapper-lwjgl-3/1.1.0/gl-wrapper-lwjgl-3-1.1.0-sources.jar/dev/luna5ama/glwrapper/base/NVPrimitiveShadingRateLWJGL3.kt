package dev.luna5ama.glwrapper.base

public class NVPrimitiveShadingRateLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVPrimitiveShadingRate
