package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBGPUShaderInt64LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBGPUShaderInt64 {
  override fun glGetUniformi64vARB(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglGetUniformi64vARB(program, location, params)

  override fun glProgramUniform1ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform1ui64vARB(program, location, count,
      `value`)

  @PtrParameter([3])
  override fun glProgramUniform4ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform4ui64vARB(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform3ui64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glProgramUniform3ui64ARB(program, location, x, y, z)

  @PtrParameter([2])
  override fun glUniform4ui64vARB(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform4ui64vARB(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform4i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform4i64vARB(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform4i64vARB(program, location, count,
      `value`)

  @PtrParameter([2])
  override fun glUniform3i64vARB(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform3i64vARB(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform2ui64vARB(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform2ui64vARB(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glProgramUniform3ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform3ui64vARB(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform3ui64vARB(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform3ui64vARB(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glGetnUniformi64vARB(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglGetnUniformi64vARB(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetnUniformi64vARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglGetnUniformi64vARB(program, location, bufSize,
      params)

  override fun glGetnUniformui64vARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglGetnUniformui64vARB(program, location, bufSize,
      params)

  @PtrParameter([3])
  override fun glProgramUniform1i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform1i64vARB(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform2i64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glProgramUniform2i64ARB(program, location, x, y)

  @PtrParameter([3])
  override fun glProgramUniform3i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform3i64vARB(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform2i64vARB(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform2i64vARB(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform3i64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glProgramUniform3i64ARB(program, location, x, y, z)

  @PtrParameter([3])
  override fun glProgramUniform1ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform1ui64vARB(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4i64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glProgramUniform4i64ARB(program, location, x, y, z,
      w)

  @PtrParameter([3])
  override fun glProgramUniform2i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform2i64vARB(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glGetnUniformui64vARB(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglGetnUniformui64vARB(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glProgramUniform4ui64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glProgramUniform4ui64ARB(program, location, x, y, z,
      w)

  override fun glProgramUniform1ui64ARB(
    program: Int,
    location: Int,
    x: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glProgramUniform1ui64ARB(program, location, x)

  override fun glProgramUniform1i64ARB(
    program: Int,
    location: Int,
    x: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glProgramUniform1i64ARB(program, location, x)

  override fun glProgramUniform3i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform3i64vARB(program, location, count,
      `value`)

  override fun glProgramUniform2ui64ARB(
    program: Int,
    location: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glProgramUniform2ui64ARB(program, location, x, y)

  @PtrParameter([3])
  override fun glProgramUniform2ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform2ui64vARB(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform3ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform3ui64vARB(program, location, count,
      `value`)

  @PtrParameter([2])
  override fun glUniform4i64vARB(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform4i64vARB(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniform4ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform4ui64vARB(program, location, count,
      `value`)

  @PtrParameter([2])
  override fun glGetUniformi64vARB(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglGetUniformi64vARB(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetUniformui64vARB(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglGetUniformui64vARB(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glUniform1ui64vARB(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform1ui64vARB(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glGetUniformui64vARB(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglGetUniformui64vARB(program, location, params)

  override fun glProgramUniform1i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform1i64vARB(program, location, count,
      `value`)

  override fun glProgramUniform2i64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform2i64vARB(program, location, count,
      `value`)

  override fun glProgramUniform2ui64vARB(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglProgramUniform2ui64vARB(program, location, count,
      `value`)

  @PtrParameter([2])
  override fun glUniform1i64vARB(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform1i64vARB(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniform3i64ARB(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glUniform3i64ARB(location, x, y, z)

  override fun glUniform4i64ARB(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glUniform4i64ARB(location, x, y, z, w)

  override fun glUniform2i64ARB(
    location: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glUniform2i64ARB(location, x, y)

  override fun glUniform4i64vARB(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform4i64vARB(location, count, `value`)

  override fun glUniform1i64vARB(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform1i64vARB(location, count, `value`)

  override fun glUniform2i64vARB(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform2i64vARB(location, count, `value`)

  override fun glUniform3i64vARB(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform3i64vARB(location, count, `value`)

  override fun glUniform1i64ARB(location: Int, x: Long): Unit =
      org.lwjgl.opengl.ARBGPUShaderInt64.glUniform1i64ARB(location, x)

  override fun glUniform1ui64ARB(location: Int, x: Long): Unit =
      org.lwjgl.opengl.ARBGPUShaderInt64.glUniform1ui64ARB(location, x)

  override fun glUniform3ui64ARB(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glUniform3ui64ARB(location, x, y, z)

  override fun glUniform3ui64vARB(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform3ui64vARB(location, count, `value`)

  override fun glUniform4ui64vARB(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform4ui64vARB(location, count, `value`)

  override fun glUniform1ui64vARB(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform1ui64vARB(location, count, `value`)

  override fun glUniform4ui64ARB(
    location: Int,
    x: Long,
    y: Long,
    z: Long,
    w: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glUniform4ui64ARB(location, x, y, z, w)

  override fun glUniform2ui64ARB(
    location: Int,
    x: Long,
    y: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.glUniform2ui64ARB(location, x, y)

  override fun glUniform2ui64vARB(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.ARBGPUShaderInt64.nglUniform2ui64vARB(location, count, `value`)
}
