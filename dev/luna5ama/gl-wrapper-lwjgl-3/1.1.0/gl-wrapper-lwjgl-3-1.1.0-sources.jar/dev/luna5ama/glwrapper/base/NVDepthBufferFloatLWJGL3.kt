package dev.luna5ama.glwrapper.base

import kotlin.Double
import kotlin.Unit

public class NVDepthBufferFloatLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVDepthBufferFloat {
  override fun glDepthRangedNV(zNear: Double, zFar: Double): Unit =
      org.lwjgl.opengl.NVDepthBufferFloat.glDepthRangedNV(zNear, zFar)

  override fun glClearDepthdNV(depth: Double): Unit =
      org.lwjgl.opengl.NVDepthBufferFloat.glClearDepthdNV(depth)

  override fun glDepthBoundsdNV(zmin: Double, zmax: Double): Unit =
      org.lwjgl.opengl.NVDepthBufferFloat.glDepthBoundsdNV(zmin, zmax)
}
