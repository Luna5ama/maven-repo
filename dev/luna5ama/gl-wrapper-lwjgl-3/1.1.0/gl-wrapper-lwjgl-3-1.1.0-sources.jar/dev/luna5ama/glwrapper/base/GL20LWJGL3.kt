package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Byte
import kotlin.CharSequence
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Short
import kotlin.String
import kotlin.Unit
import org.lwjgl.opengl.GL20C

public class GL20LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL20 {
  override fun glUniform1i(location: Int, v0: Int): Unit = GL20C.glUniform1i(location, v0)

  override fun glValidateProgram(program: Int): Unit = GL20C.glValidateProgram(program)

  override fun glUniform3i(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
  ): Unit = GL20C.glUniform3i(location, v0, v1, v2)

  override fun glIsProgram(program: Int): Boolean = GL20C.glIsProgram(program)

  override fun glUniform4f(
    location: Int,
    v0: Float,
    v1: Float,
    v2: Float,
    v3: Float,
  ): Unit = GL20C.glUniform4f(location, v0, v1, v2, v3)

  override fun glDeleteProgram(program: Int): Unit = GL20C.glDeleteProgram(program)

  override fun glCreateShader(type: Int): Int = GL20C.glCreateShader(type)

  override fun glLinkProgram(program: Int): Unit = GL20C.glLinkProgram(program)

  override fun glUniform2f(
    location: Int,
    v0: Float,
    v1: Float,
  ): Unit = GL20C.glUniform2f(location, v0, v1)

  override fun glUniform2i(
    location: Int,
    v0: Int,
    v1: Int,
  ): Unit = GL20C.glUniform2i(location, v0, v1)

  override fun glAttachShader(program: Int, shader: Int): Unit = GL20C.glAttachShader(program,
      shader)

  override fun glUniform4i(
    location: Int,
    v0: Int,
    v1: Int,
    v2: Int,
    v3: Int,
  ): Unit = GL20C.glUniform4i(location, v0, v1, v2, v3)

  override fun glCreateProgram(): Int = GL20C.glCreateProgram()

  override fun glUniform1fv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL20C.nglUniform1fv(location, count, `value`)

  override fun glDetachShader(program: Int, shader: Int): Unit = GL20C.glDetachShader(program,
      shader)

  override fun glCompileShader(shader: Int): Unit = GL20C.glCompileShader(shader)

  override fun glShaderSource(shader: Int, string: CharSequence): Unit =
      GL20C.glShaderSource(shader, string)

  override fun glShaderSource(
    shader: Int,
    count: Int,
    strings: Long,
    length: Long,
  ): Unit = GL20C.nglShaderSource(shader, count, strings, length)

  override fun glUseProgram(program: Int): Unit = GL20C.glUseProgram(program)

  override fun glUniform1f(location: Int, v0: Float): Unit = GL20C.glUniform1f(location, v0)

  override fun glIsShader(shader: Int): Boolean = GL20C.glIsShader(shader)

  override fun glDeleteShader(shader: Int): Unit = GL20C.glDeleteShader(shader)

  override fun glUniform3f(
    location: Int,
    v0: Float,
    v1: Float,
    v2: Float,
  ): Unit = GL20C.glUniform3f(location, v0, v1, v2)

  override fun glUniformMatrix4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL20C.nglUniformMatrix4fv(location, count, transpose, `value`)

  override fun glUniform3iv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL20C.nglUniform3iv(location, count, `value`)

  override fun glUniformMatrix3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL20C.nglUniformMatrix3fv(location, count, transpose, `value`)

  override fun glUniform1iv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL20C.nglUniform1iv(location, count, `value`)

  override fun glUniform4iv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL20C.nglUniform4iv(location, count, `value`)

  override fun glUniform2fv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL20C.nglUniform2fv(location, count, `value`)

  override fun glGetActiveUniform(
    program: Int,
    index: Int,
    maxLength: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
  ): Unit = GL20C.nglGetActiveUniform(program, index, maxLength, length, size, type, name)

  override fun glGetUniformfv(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = GL20C.nglGetUniformfv(program, location, params)

  override fun glGetProgramiv(
    program: Int,
    pname: Int,
    params: Long,
  ): Unit = GL20C.nglGetProgramiv(program, pname, params)

  override fun glUniform3fv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL20C.nglUniform3fv(location, count, `value`)

  override fun glGetShaderInfoLog(shader: Int, maxLength: Int): String =
      GL20C.glGetShaderInfoLog(shader, maxLength)

  override fun glGetShaderInfoLog(
    shader: Int,
    maxLength: Int,
    length: Long,
    infoLog: Long,
  ): Unit = GL20C.nglGetShaderInfoLog(shader, maxLength, length, infoLog)

  override fun glGetShaderiv(
    shader: Int,
    pname: Int,
    params: Long,
  ): Unit = GL20C.nglGetShaderiv(shader, pname, params)

  override fun glGetUniformiv(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = GL20C.nglGetUniformiv(program, location, params)

  override fun glUniform2iv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL20C.nglUniform2iv(location, count, `value`)

  override fun glUniformMatrix2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL20C.nglUniformMatrix2fv(location, count, transpose, `value`)

  override fun glUniform4fv(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = GL20C.nglUniform4fv(location, count, `value`)

  override fun glVertexAttrib2sv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib2sv(index, v)

  override fun glVertexAttrib2dv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib2dv(index, v)

  override fun glVertexAttrib4s(
    index: Int,
    v0: Short,
    v1: Short,
    v2: Short,
    v3: Short,
  ): Unit = GL20C.glVertexAttrib4s(index, v0, v1, v2, v3)

  override fun glVertexAttrib1fv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib1fv(index, v)

  override fun glGetShaderSource(
    shader: Int,
    maxLength: Int,
    length: Long,
    source: Long,
  ): Unit = GL20C.nglGetShaderSource(shader, maxLength, length, source)

  override fun glVertexAttrib3fv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib3fv(index, v)

  override fun glVertexAttrib3sv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib3sv(index, v)

  override fun glVertexAttrib2fv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib2fv(index, v)

  override fun glVertexAttrib4d(
    index: Int,
    v0: Double,
    v1: Double,
    v2: Double,
    v3: Double,
  ): Unit = GL20C.glVertexAttrib4d(index, v0, v1, v2, v3)

  override fun glVertexAttrib1f(index: Int, v0: Float): Unit = GL20C.glVertexAttrib1f(index, v0)

  override fun glVertexAttrib4Nub(
    index: Int,
    x: Byte,
    y: Byte,
    z: Byte,
    w: Byte,
  ): Unit = GL20C.glVertexAttrib4Nub(index, x, y, z, w)

  override fun glVertexAttrib2s(
    index: Int,
    v0: Short,
    v1: Short,
  ): Unit = GL20C.glVertexAttrib2s(index, v0, v1)

  override fun glVertexAttrib3f(
    index: Int,
    v0: Float,
    v1: Float,
    v2: Float,
  ): Unit = GL20C.glVertexAttrib3f(index, v0, v1, v2)

  override fun glVertexAttrib3s(
    index: Int,
    v0: Short,
    v1: Short,
    v2: Short,
  ): Unit = GL20C.glVertexAttrib3s(index, v0, v1, v2)

  override fun glVertexAttrib1sv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib1sv(index, v)

  override fun glVertexAttrib1s(index: Int, v0: Short): Unit = GL20C.glVertexAttrib1s(index, v0)

  override fun glVertexAttrib1d(index: Int, v0: Double): Unit = GL20C.glVertexAttrib1d(index, v0)

  override fun glVertexAttrib2f(
    index: Int,
    v0: Float,
    v1: Float,
  ): Unit = GL20C.glVertexAttrib2f(index, v0, v1)

  override fun glVertexAttrib2d(
    index: Int,
    v0: Double,
    v1: Double,
  ): Unit = GL20C.glVertexAttrib2d(index, v0, v1)

  override fun glVertexAttrib3d(
    index: Int,
    v0: Double,
    v1: Double,
    v2: Double,
  ): Unit = GL20C.glVertexAttrib3d(index, v0, v1, v2)

  override fun glVertexAttrib4f(
    index: Int,
    v0: Float,
    v1: Float,
    v2: Float,
    v3: Float,
  ): Unit = GL20C.glVertexAttrib4f(index, v0, v1, v2, v3)

  override fun glVertexAttrib1dv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib1dv(index, v)

  override fun glVertexAttrib4iv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4iv(index, v)

  override fun glVertexAttrib4Niv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4Niv(index, v)

  override fun glVertexAttrib4ubv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4ubv(index, v)

  override fun glVertexAttrib4uiv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4uiv(index, v)

  override fun glVertexAttrib4usv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4usv(index, v)

  override fun glGetActiveAttrib(
    program: Int,
    index: Int,
    maxLength: Int,
    length: Long,
    size: Long,
    type: Long,
    name: Long,
  ): Unit = GL20C.nglGetActiveAttrib(program, index, maxLength, length, size, type, name)

  override fun glVertexAttrib4Nsv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4Nsv(index, v)

  override fun glVertexAttrib4sv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4sv(index, v)

  override fun glVertexAttrib4Nbv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4Nbv(index, v)

  override fun glVertexAttrib4bv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4bv(index, v)

  override fun glDrawBuffers(n: Int, bufs: Long): Unit = GL20C.nglDrawBuffers(n, bufs)

  override fun glVertexAttrib3dv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib3dv(index, v)

  override fun glVertexAttrib4fv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4fv(index, v)

  override fun glVertexAttrib4dv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4dv(index, v)

  @PtrParameter([2])
  override fun glGetUniformiv(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL20C.nglGetUniformiv(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2, 3])
  override fun glGetShaderSource(
    shader: Int,
    maxLength: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-source$0`: Ptr,
  ): Unit = GL20C.nglGetShaderSource(shader, maxLength,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-source$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib2fv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib2fv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4Nbv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4Nbv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4Nubv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4Nubv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([5])
  override fun glVertexAttribPointer(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = GL20C.nglVertexAttribPointer(index, size, type, normalized, stride,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4fv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4fv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glEnableVertexAttribArray(index: Int): Unit = GL20C.glEnableVertexAttribArray(index)

  override fun glDisableVertexAttribArray(index: Int): Unit =
      GL20C.glDisableVertexAttribArray(index)

  @PtrParameter([1])
  override fun glVertexAttrib2sv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib2sv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([3, 4, 5, 6])
  override fun glGetActiveAttrib(
    program: Int,
    index: Int,
    maxLength: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = GL20C.nglGetActiveAttrib(program, index, maxLength,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glVertexAttrib4Nuiv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4Nuiv(index, v)

  override fun glGetVertexAttribdv(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = GL20C.nglGetVertexAttribdv(index, pname, params)

  @PtrParameter([1])
  override fun glVertexAttrib4Nusv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4Nusv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4ubv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4ubv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glGetAttribLocation(program: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr): Int =
      GL20C.nglGetAttribLocation(program, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4sv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4sv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib1dv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib1dv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib3fv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib3fv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4uiv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4uiv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glBindAttribLocation(
    program: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = GL20C.nglBindAttribLocation(program, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib1sv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib1sv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4usv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4usv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib2dv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib2dv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4Nuiv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4Nuiv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glGetAttribLocation(program: Int, name: Long): Int =
      GL20C.nglGetAttribLocation(program, name)

  override fun glGetVertexAttribiv(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = GL20C.nglGetVertexAttribiv(index, pname, params)

  @PtrParameter([2])
  override fun glGetVertexAttribfv(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL20C.nglGetVertexAttribfv(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetVertexAttribPointerv(
    index: Int,
    pname: Int,
    pointer: Long,
  ): Unit = GL20C.nglGetVertexAttribPointerv(index, pname, pointer)

  override fun glBlendEquationSeparate(modeRGB: Int, modeAlpha: Int): Unit =
      GL20C.glBlendEquationSeparate(modeRGB, modeAlpha)

  @PtrParameter([2])
  override fun glGetVertexAttribdv(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL20C.nglGetVertexAttribdv(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetVertexAttribfv(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = GL20C.nglGetVertexAttribfv(index, pname, params)

  override fun glVertexAttribPointer(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
    pointer: Long,
  ): Unit = GL20C.nglVertexAttribPointer(index, size, type, normalized, stride, pointer)

  @PtrParameter([1])
  override fun glVertexAttrib3dv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib3dv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4iv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4iv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4Niv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4Niv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glStencilOpSeparate(
    face: Int,
    sfail: Int,
    dpfail: Int,
    dppass: Int,
  ): Unit = GL20C.glStencilOpSeparate(face, sfail, dpfail, dppass)

  override fun glStencilMaskSeparate(face: Int, mask: Int): Unit = GL20C.glStencilMaskSeparate(face,
      mask)

  @PtrParameter([1])
  override fun glVertexAttrib4bv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4bv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttrib4Nusv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4Nusv(index, v)

  override fun glVertexAttrib4Nubv(index: Int, v: Long): Unit = GL20C.nglVertexAttrib4Nubv(index, v)

  override fun glStencilFuncSeparate(
    face: Int,
    func: Int,
    ref: Int,
    mask: Int,
  ): Unit = GL20C.glStencilFuncSeparate(face, func, ref, mask)

  @PtrParameter([1])
  override fun glVertexAttrib4Nsv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4Nsv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glBindAttribLocation(
    program: Int,
    index: Int,
    name: Long,
  ): Unit = GL20C.nglBindAttribLocation(program, index, name)

  @PtrParameter([2])
  override fun glGetVertexAttribPointerv(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = GL20C.nglGetVertexAttribPointerv(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  @PtrParameter([1])
  override fun glDrawBuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-bufs$0`: Ptr): Unit =
      GL20C.nglDrawBuffers(n, `$v$c$dev-luna5ama-kmogus-Ptr$-bufs$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib4dv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib4dv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glGetVertexAttribiv(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL20C.nglGetVertexAttribiv(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glVertexAttrib3sv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib3sv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([2])
  override fun glUniform3fv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniform3fv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform4fv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniform4fv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform1iv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniform1iv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2, 3])
  override fun glShaderSource(
    shader: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-strings$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
  ): Unit = GL20C.nglShaderSource(shader, count, `$v$c$dev-luna5ama-kmogus-Ptr$-strings$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address)

  @PtrParameter([2])
  override fun glUniform1fv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniform1fv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform2iv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniform2iv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform2fv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniform2fv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniformMatrix3fv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([1])
  override fun glGetUniformLocation(program: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr): Int
      = GL20C.nglGetUniformLocation(program, `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([2, 3])
  override fun glGetAttachedShaders(
    program: Int,
    maxCount: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-count$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-shaders$0`: Ptr,
  ): Unit = GL20C.nglGetAttachedShaders(program, maxCount,
      `$v$c$dev-luna5ama-kmogus-Ptr$-count$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-shaders$0`.address)

  override fun glGetAttachedShaders(
    program: Int,
    maxCount: Int,
    count: Long,
    shaders: Long,
  ): Unit = GL20C.nglGetAttachedShaders(program, maxCount, count, shaders)

  override fun glGetUniformLocation(program: Int, name: CharSequence): Int =
      GL20C.glGetUniformLocation(program, name)

  override fun glGetUniformLocation(program: Int, name: Long): Int =
      GL20C.nglGetUniformLocation(program, name)

  @PtrParameter([2, 3])
  override fun glGetShaderInfoLog(
    shader: Int,
    maxLength: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-infoLog$0`: Ptr,
  ): Unit = GL20C.nglGetShaderInfoLog(shader, maxLength,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-infoLog$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniformMatrix4fv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3, 4, 5, 6])
  override fun glGetActiveUniform(
    program: Int,
    index: Int,
    maxLength: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = GL20C.nglGetActiveUniform(program, index, maxLength,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-size$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-type$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  @PtrParameter([2, 3])
  override fun glGetProgramInfoLog(
    program: Int,
    maxLength: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-infoLog$0`: Ptr,
  ): Unit = GL20C.nglGetProgramInfoLog(program, maxLength,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-infoLog$0`.address)

  @PtrParameter([2])
  override fun glGetUniformfv(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL20C.nglGetUniformfv(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glUniform3iv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniform3iv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glUniform4iv(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniform4iv(location, count, `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL20C.nglUniformMatrix2fv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([2])
  override fun glGetProgramiv(
    program: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL20C.nglGetProgramiv(program, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetShaderiv(
    shader: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL20C.nglGetShaderiv(shader, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetProgramInfoLog(
    program: Int,
    maxLength: Int,
    length: Long,
    infoLog: Long,
  ): Unit = GL20C.nglGetProgramInfoLog(program, maxLength, length, infoLog)

  override fun glGetProgramInfoLog(program: Int, maxLength: Int): String =
      GL20C.glGetProgramInfoLog(program, maxLength)

  @PtrParameter([1])
  override fun glVertexAttrib1fv(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      GL20C.nglVertexAttrib1fv(index, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)
}
