package dev.luna5ama.glwrapper.base

public class NVDeepTexture3DLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVDeepTexture3D
