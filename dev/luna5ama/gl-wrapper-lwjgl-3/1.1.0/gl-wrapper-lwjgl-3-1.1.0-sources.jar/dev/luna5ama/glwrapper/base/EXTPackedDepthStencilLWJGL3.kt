package dev.luna5ama.glwrapper.base

public class EXTPackedDepthStencilLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTPackedDepthStencil
