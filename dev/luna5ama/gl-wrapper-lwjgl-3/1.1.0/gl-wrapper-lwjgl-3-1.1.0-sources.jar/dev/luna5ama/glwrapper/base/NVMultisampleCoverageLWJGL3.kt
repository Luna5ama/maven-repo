package dev.luna5ama.glwrapper.base

public class NVMultisampleCoverageLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVMultisampleCoverage
