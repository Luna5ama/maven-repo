package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVFenceLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVFence {
  @PtrParameter([2])
  override fun glGetFenceivNV(
    fence: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVFence.nglGetFenceivNV(fence, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glDeleteFencesNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-fences$0`: Ptr): Unit =
      org.lwjgl.opengl.NVFence.nglDeleteFencesNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-fences$0`.address)

  @PtrParameter([1])
  override fun glGenFencesNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-fences$0`: Ptr): Unit =
      org.lwjgl.opengl.NVFence.nglGenFencesNV(n, `$v$c$dev-luna5ama-kmogus-Ptr$-fences$0`.address)

  override fun glIsFenceNV(fence: Int): Boolean = org.lwjgl.opengl.NVFence.glIsFenceNV(fence)

  override fun glGenFencesNV(n: Int, fences: Long): Unit =
      org.lwjgl.opengl.NVFence.nglGenFencesNV(n, fences)

  override fun glFinishFenceNV(fence: Int): Unit = org.lwjgl.opengl.NVFence.glFinishFenceNV(fence)

  override fun glSetFenceNV(fence: Int, condition: Int): Unit =
      org.lwjgl.opengl.NVFence.glSetFenceNV(fence, condition)

  override fun glTestFenceNV(fence: Int): Boolean = org.lwjgl.opengl.NVFence.glTestFenceNV(fence)

  override fun glGetFenceivNV(
    fence: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVFence.nglGetFenceivNV(fence, pname, params)

  override fun glDeleteFencesNV(n: Int, fences: Long): Unit =
      org.lwjgl.opengl.NVFence.nglDeleteFencesNV(n, fences)
}
