package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVVertexBufferUnifiedMemoryLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVVertexBufferUnifiedMemory {
  override fun glSecondaryColorFormatNV(
    size: Int,
    type: Int,
    stride: Int,
  ): Unit = org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glSecondaryColorFormatNV(size, type,
      stride)

  override fun glBufferAddressRangeNV(
    pname: Int,
    index: Int,
    address: Long,
    length: Long,
  ): Unit = org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glBufferAddressRangeNV(pname, index,
      address, length)

  @PtrParameter([2])
  override fun glGetIntegerui64i_vNV(
    `value`: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-result$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVVertexBufferUnifiedMemory.nglGetIntegerui64i_vNV(`value`, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-result$0`.address)

  override fun glVertexAttribFormatNV(
    index: Int,
    size: Int,
    type: Int,
    normalized: Boolean,
    stride: Int,
  ): Unit = org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glVertexAttribFormatNV(index, size, type,
      normalized, stride)

  override fun glVertexAttribIFormatNV(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
  ): Unit = org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glVertexAttribIFormatNV(index, size, type,
      stride)

  override fun glGetIntegerui64i_vNV(
    `value`: Int,
    index: Int,
    result: Long,
  ): Unit = org.lwjgl.opengl.NVVertexBufferUnifiedMemory.nglGetIntegerui64i_vNV(`value`, index,
      result)

  override fun glVertexFormatNV(
    size: Int,
    type: Int,
    stride: Int,
  ): Unit = org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glVertexFormatNV(size, type, stride)

  override fun glTexCoordFormatNV(
    size: Int,
    type: Int,
    stride: Int,
  ): Unit = org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glTexCoordFormatNV(size, type, stride)

  override fun glColorFormatNV(
    size: Int,
    type: Int,
    stride: Int,
  ): Unit = org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glColorFormatNV(size, type, stride)

  override fun glEdgeFlagFormatNV(stride: Int): Unit =
      org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glEdgeFlagFormatNV(stride)

  override fun glNormalFormatNV(type: Int, stride: Int): Unit =
      org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glNormalFormatNV(type, stride)

  override fun glFogCoordFormatNV(type: Int, stride: Int): Unit =
      org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glFogCoordFormatNV(type, stride)

  override fun glIndexFormatNV(type: Int, stride: Int): Unit =
      org.lwjgl.opengl.NVVertexBufferUnifiedMemory.glIndexFormatNV(type, stride)
}
