package dev.luna5ama.glwrapper.base

public class EXTTextureFilterAnisotropicLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureFilterAnisotropic
