package dev.luna5ama.glwrapper.base

public class ARBShadowAmbientLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBShadowAmbient
