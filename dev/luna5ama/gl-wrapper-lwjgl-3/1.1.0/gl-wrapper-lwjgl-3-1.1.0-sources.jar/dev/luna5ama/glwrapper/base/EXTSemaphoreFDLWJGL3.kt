package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTSemaphoreFDLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTSemaphoreFD {
  override fun glImportSemaphoreFdEXT(
    semaphore: Int,
    handleType: Int,
    fd: Int,
  ): Unit = org.lwjgl.opengl.EXTSemaphoreFD.glImportSemaphoreFdEXT(semaphore, handleType, fd)
}
