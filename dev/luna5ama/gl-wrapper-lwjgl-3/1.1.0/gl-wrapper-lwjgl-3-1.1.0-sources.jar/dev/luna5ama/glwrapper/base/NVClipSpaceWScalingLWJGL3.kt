package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Unit

public class NVClipSpaceWScalingLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVClipSpaceWScaling {
  override fun glViewportPositionWScaleNV(
    index: Int,
    xcoeff: Float,
    ycoeff: Float,
  ): Unit = org.lwjgl.opengl.NVClipSpaceWScaling.glViewportPositionWScaleNV(index, xcoeff, ycoeff)
}
