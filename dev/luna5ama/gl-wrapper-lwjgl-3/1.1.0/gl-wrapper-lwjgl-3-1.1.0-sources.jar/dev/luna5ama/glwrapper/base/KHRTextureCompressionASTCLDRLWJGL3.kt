package dev.luna5ama.glwrapper.base

public class KHRTextureCompressionASTCLDRLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : KHRTextureCompressionASTCLDR
