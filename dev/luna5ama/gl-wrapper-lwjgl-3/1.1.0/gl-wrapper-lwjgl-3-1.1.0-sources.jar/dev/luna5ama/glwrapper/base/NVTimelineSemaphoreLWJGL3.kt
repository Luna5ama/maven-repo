package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVTimelineSemaphoreLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVTimelineSemaphore {
  @PtrParameter([2])
  override fun glGetSemaphoreParameterivNV(
    semaphore: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVTimelineSemaphore.nglGetSemaphoreParameterivNV(semaphore, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glSemaphoreParameterivNV(
    semaphore: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVTimelineSemaphore.nglSemaphoreParameterivNV(semaphore, pname, params)

  override fun glGetSemaphoreParameterivNV(
    semaphore: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVTimelineSemaphore.nglGetSemaphoreParameterivNV(semaphore, pname,
      params)

  @PtrParameter([1])
  override fun glCreateSemaphoresNV(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-semaphores$0`: Ptr): Unit
      = org.lwjgl.opengl.NVTimelineSemaphore.nglCreateSemaphoresNV(n,
      `$v$c$dev-luna5ama-kmogus-Ptr$-semaphores$0`.address)

  @PtrParameter([2])
  override fun glSemaphoreParameterivNV(
    semaphore: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVTimelineSemaphore.nglSemaphoreParameterivNV(semaphore, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glCreateSemaphoresNV(n: Int, semaphores: Long): Unit =
      org.lwjgl.opengl.NVTimelineSemaphore.nglCreateSemaphoresNV(n, semaphores)
}
