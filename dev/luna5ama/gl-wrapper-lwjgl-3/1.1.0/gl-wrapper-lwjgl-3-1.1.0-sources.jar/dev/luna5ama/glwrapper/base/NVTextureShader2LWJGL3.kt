package dev.luna5ama.glwrapper.base

public class NVTextureShader2LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVTextureShader2
