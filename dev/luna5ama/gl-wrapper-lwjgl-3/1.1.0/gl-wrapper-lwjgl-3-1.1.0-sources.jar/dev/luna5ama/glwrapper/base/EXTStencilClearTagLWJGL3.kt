package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class EXTStencilClearTagLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTStencilClearTag {
  override fun glStencilClearTagEXT(stencilTagBits: Int, stencilClearTag: Int): Unit =
      org.lwjgl.opengl.EXTStencilClearTag.glStencilClearTagEXT(stencilTagBits, stencilClearTag)
}
