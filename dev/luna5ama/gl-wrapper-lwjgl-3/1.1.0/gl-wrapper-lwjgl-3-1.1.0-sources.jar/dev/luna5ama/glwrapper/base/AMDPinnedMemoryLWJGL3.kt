package dev.luna5ama.glwrapper.base

public class AMDPinnedMemoryLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDPinnedMemory
