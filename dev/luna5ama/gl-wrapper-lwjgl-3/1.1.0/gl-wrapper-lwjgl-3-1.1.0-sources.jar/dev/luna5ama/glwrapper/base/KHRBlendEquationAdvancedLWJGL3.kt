package dev.luna5ama.glwrapper.base

import kotlin.Unit

public class KHRBlendEquationAdvancedLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : KHRBlendEquationAdvanced {
  override fun glBlendBarrierKHR(): Unit =
      org.lwjgl.opengl.KHRBlendEquationAdvanced.glBlendBarrierKHR()
}
