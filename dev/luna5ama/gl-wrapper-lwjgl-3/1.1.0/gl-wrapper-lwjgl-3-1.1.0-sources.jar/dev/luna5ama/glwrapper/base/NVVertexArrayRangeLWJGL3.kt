package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVVertexArrayRangeLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVVertexArrayRange {
  @PtrParameter([1])
  override fun glVertexArrayRangeNV(length: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr):
      Unit = org.lwjgl.opengl.NVVertexArrayRange.nglVertexArrayRangeNV(length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  override fun glFlushVertexArrayRangeNV(): Unit =
      org.lwjgl.opengl.NVVertexArrayRange.glFlushVertexArrayRangeNV()

  override fun glVertexArrayRangeNV(length: Int, pointer: Long): Unit =
      org.lwjgl.opengl.NVVertexArrayRange.nglVertexArrayRangeNV(length, pointer)
}
