package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBRobustnessLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBRobustness {
  override fun glGetGraphicsResetStatusARB(): Int =
      org.lwjgl.opengl.ARBRobustness.glGetGraphicsResetStatusARB()

  @PtrParameter([3])
  override fun glGetnMapfvARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnMapfvARB(target, query, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([3])
  override fun glGetnMapivARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnMapivARB(target, query, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([3])
  override fun glGetnMapdvARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnMapdvARB(target, query, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([2])
  override fun glGetnPixelMapfvARB(
    map: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnPixelMapfvARB(map, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([3])
  override fun glGetnCompressedTexImageARB(
    target: Int,
    level: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnCompressedTexImageARB(target, level, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`.address)

  override fun glGetnMapivARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnMapivARB(target, query, bufSize, `data`)

  override fun glReadnPixelsARB(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglReadnPixelsARB(x, y, width, height, format, type,
      bufSize, `data`)

  override fun glGetnMapfvARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnMapfvARB(target, query, bufSize, `data`)

  override fun glGetnTexImageARB(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    img: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnTexImageARB(tex, level, format, type, bufSize,
      img)

  override fun glGetnMapdvARB(
    target: Int,
    query: Int,
    bufSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnMapdvARB(target, query, bufSize, `data`)

  override fun glGetnHistogramARB(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    bufSize: Int,
    values: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnHistogramARB(target, reset, format, type, bufSize,
      values)

  override fun glGetnMinmaxARB(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    bufSize: Int,
    values: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnMinmaxARB(target, reset, format, type, bufSize,
      values)

  override fun glGetnUniformivARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnUniformivARB(program, location, bufSize, params)

  override fun glGetnUniformdvARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnUniformdvARB(program, location, bufSize, params)

  override fun glGetnUniformfvARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnUniformfvARB(program, location, bufSize, params)

  override fun glGetnPolygonStippleARB(bufSize: Int, pattern: Long): Unit =
      org.lwjgl.opengl.ARBRobustness.nglGetnPolygonStippleARB(bufSize, pattern)

  @PtrParameter([2])
  override fun glGetnPixelMapusvARB(
    map: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnPixelMapusvARB(map, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([7])
  override fun glReadnPixelsARB(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglReadnPixelsARB(x, y, width, height, format, type,
      bufSize, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([4])
  override fun glGetnConvolutionFilterARB(
    target: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-image$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnConvolutionFilterARB(target, format, type,
      bufSize, `$v$c$dev-luna5ama-kmogus-Ptr$-image$0`.address)

  @PtrParameter([2])
  override fun glGetnPixelMapuivARB(
    map: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnPixelMapuivARB(map, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glGetnConvolutionFilterARB(
    target: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    image: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnConvolutionFilterARB(target, format, type,
      bufSize, image)

  @PtrParameter([4])
  override fun glGetnColorTableARB(
    target: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-table$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnColorTableARB(target, format, type, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-table$0`.address)

  @PtrParameter([5])
  override fun glGetnMinmaxARB(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnMinmaxARB(target, reset, format, type, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  override fun glGetnColorTableARB(
    target: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    table: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnColorTableARB(target, format, type, bufSize,
      table)

  override fun glGetnUniformuivARB(
    program: Int,
    location: Int,
    bufSize: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnUniformuivARB(program, location, bufSize, params)

  override fun glGetnPixelMapuivARB(
    map: Int,
    bufSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnPixelMapuivARB(map, bufSize, `data`)

  @PtrParameter([3])
  override fun glGetnUniformuivARB(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnUniformuivARB(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetnPixelMapusvARB(
    map: Int,
    bufSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnPixelMapusvARB(map, bufSize, `data`)

  @PtrParameter([3])
  override fun glGetnUniformfvARB(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnUniformfvARB(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetnUniformdvARB(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnUniformdvARB(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetnSeparableFilterARB(
    target: Int,
    format: Int,
    type: Int,
    rowBufSize: Int,
    row: Long,
    columnBufSize: Int,
    column: Long,
    span: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnSeparableFilterARB(target, format, type,
      rowBufSize, row, columnBufSize, column, span)

  @PtrParameter([4, 6, 7])
  override fun glGetnSeparableFilterARB(
    target: Int,
    format: Int,
    type: Int,
    rowBufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-row$0`: Ptr,
    columnBufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-column$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-span$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnSeparableFilterARB(target, format, type,
      rowBufSize, `$v$c$dev-luna5ama-kmogus-Ptr$-row$0`.address, columnBufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-column$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-span$0`.address)

  @PtrParameter([1])
  override fun glGetnPolygonStippleARB(bufSize: Int,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pattern$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBRobustness.nglGetnPolygonStippleARB(bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pattern$0`.address)

  @PtrParameter([3])
  override fun glGetnUniformivARB(
    program: Int,
    location: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnUniformivARB(program, location, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([5])
  override fun glGetnTexImageARB(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnTexImageARB(tex, level, format, type, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-img$0`.address)

  override fun glGetnCompressedTexImageARB(
    target: Int,
    level: Int,
    bufSize: Int,
    img: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnCompressedTexImageARB(target, level, bufSize, img)

  @PtrParameter([5])
  override fun glGetnHistogramARB(
    target: Int,
    reset: Boolean,
    format: Int,
    type: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnHistogramARB(target, reset, format, type, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-values$0`.address)

  override fun glGetnPixelMapfvARB(
    map: Int,
    bufSize: Int,
    `data`: Long,
  ): Unit = org.lwjgl.opengl.ARBRobustness.nglGetnPixelMapfvARB(map, bufSize, `data`)
}
