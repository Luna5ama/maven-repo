package dev.luna5ama.glwrapper.base

public class NVVertexArrayRange2LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVVertexArrayRange2
