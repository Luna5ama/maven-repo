package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Double
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTVertexAttrib64bitLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTVertexAttrib64bit {
  override fun glVertexAttribL1dEXT(index: Int, x: Double): Unit =
      org.lwjgl.opengl.EXTVertexAttrib64bit.glVertexAttribL1dEXT(index, x)

  override fun glVertexAttribL2dEXT(
    index: Int,
    x: Double,
    y: Double,
  ): Unit = org.lwjgl.opengl.EXTVertexAttrib64bit.glVertexAttribL2dEXT(index, x, y)

  @PtrParameter([1])
  override fun glVertexAttribL2dvEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribL2dvEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL3dvEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribL3dvEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribL4dvEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribL4dvEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL4dvEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribL4dvEXT(index, v)

  @PtrParameter([1])
  override fun glVertexAttribL3dvEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribL3dvEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  @PtrParameter([4])
  override fun glVertexAttribLPointerEXT(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribLPointerEXT(index, size, type,
      stride, `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  override fun glVertexAttribL4dEXT(
    index: Int,
    x: Double,
    y: Double,
    z: Double,
    w: Double,
  ): Unit = org.lwjgl.opengl.EXTVertexAttrib64bit.glVertexAttribL4dEXT(index, x, y, z, w)

  override fun glVertexAttribL3dEXT(
    index: Int,
    x: Double,
    y: Double,
    z: Double,
  ): Unit = org.lwjgl.opengl.EXTVertexAttrib64bit.glVertexAttribL3dEXT(index, x, y, z)

  @PtrParameter([1])
  override fun glVertexAttribL1dvEXT(index: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`: Ptr): Unit =
      org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribL1dvEXT(index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-v$0`.address)

  override fun glVertexAttribL2dvEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribL2dvEXT(index, v)

  override fun glVertexAttribL1dvEXT(index: Int, v: Long): Unit =
      org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribL1dvEXT(index, v)

  @PtrParameter([2])
  override fun glGetVertexAttribLdvEXT(
    index: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTVertexAttrib64bit.nglGetVertexAttribLdvEXT(index, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetVertexAttribLdvEXT(
    index: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.EXTVertexAttrib64bit.nglGetVertexAttribLdvEXT(index, pname, params)

  override fun glVertexAttribLPointerEXT(
    index: Int,
    size: Int,
    type: Int,
    stride: Int,
    pointer: Long,
  ): Unit = org.lwjgl.opengl.EXTVertexAttrib64bit.nglVertexAttribLPointerEXT(index, size, type,
      stride, pointer)
}
