package dev.luna5ama.glwrapper.base

public class EXTTextureCompressionS3TCLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTTextureCompressionS3TC
