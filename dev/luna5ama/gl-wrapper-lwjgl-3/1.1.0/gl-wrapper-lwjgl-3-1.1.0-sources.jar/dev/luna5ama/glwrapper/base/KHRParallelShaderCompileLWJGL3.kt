package dev.luna5ama.glwrapper.base

import kotlin.Int
import kotlin.Unit

public class KHRParallelShaderCompileLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : KHRParallelShaderCompile {
  override fun glMaxShaderCompilerThreadsKHR(count: Int): Unit =
      org.lwjgl.opengl.KHRParallelShaderCompile.glMaxShaderCompilerThreadsKHR(count)
}
