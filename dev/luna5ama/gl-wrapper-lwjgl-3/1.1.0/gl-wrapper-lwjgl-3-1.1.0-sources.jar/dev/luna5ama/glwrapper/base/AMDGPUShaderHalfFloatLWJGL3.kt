package dev.luna5ama.glwrapper.base

public class AMDGPUShaderHalfFloatLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDGPUShaderHalfFloat
