package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Unit
import org.lwjgl.opengl.GL11C

public class GL11LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL11 {
  override fun glEnable(target: Int): Unit = GL11C.glEnable(target)

  override fun glBlendFunc(sfactor: Int, dfactor: Int): Unit = GL11C.glBlendFunc(sfactor, dfactor)

  override fun glClearColor(
    red: Float,
    green: Float,
    blue: Float,
    alpha: Float,
  ): Unit = GL11C.glClearColor(red, green, blue, alpha)

  override fun glBindTexture(target: Int, texture: Int): Unit = GL11C.glBindTexture(target, texture)

  override fun glClear(mask: Int): Unit = GL11C.glClear(mask)

  override fun glDisable(target: Int): Unit = GL11C.glDisable(target)

  override fun glGetFloatv(pname: Int, params: Long): Unit = GL11C.nglGetFloatv(pname, params)

  override fun glColorMask(
    red: Boolean,
    green: Boolean,
    blue: Boolean,
    alpha: Boolean,
  ): Unit = GL11C.glColorMask(red, green, blue, alpha)

  override fun glDepthMask(flag: Boolean): Unit = GL11C.glDepthMask(flag)

  override fun glClearStencil(s: Int): Unit = GL11C.glClearStencil(s)

  override fun glGenTextures(): Int = GL11C.glGenTextures()

  override fun glGenTextures(n: Int, textures: Long): Unit = GL11C.nglGenTextures(n, textures)

  override fun glDrawBuffer(buf: Int): Unit = GL11C.glDrawBuffer(buf)

  override fun glDrawElements(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
  ): Unit = GL11C.nglDrawElements(mode, count, type, indices)

  override fun glGetDoublev(pname: Int, params: Long): Unit = GL11C.nglGetDoublev(pname, params)

  override fun glDepthFunc(func: Int): Unit = GL11C.glDepthFunc(func)

  override fun glGetBooleanv(pname: Int, params: Long): Unit = GL11C.nglGetBooleanv(pname, params)

  override fun glGetIntegerv(pname: Int, params: Long): Unit = GL11C.nglGetIntegerv(pname, params)

  override fun glFrontFace(dir: Int): Unit = GL11C.glFrontFace(dir)

  override fun glCullFace(mode: Int): Unit = GL11C.glCullFace(mode)

  override fun glDrawArrays(
    mode: Int,
    first: Int,
    count: Int,
  ): Unit = GL11C.glDrawArrays(mode, first, count)

  override fun glGetError(): Int = GL11C.glGetError()

  override fun glGetTexImage(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL11C.nglGetTexImage(tex, level, format, type, pixels)

  override fun glDepthRange(zNear: Double, zFar: Double): Unit = GL11C.glDepthRange(zNear, zFar)

  override fun glDeleteTextures(texture: Int): Unit = GL11C.glDeleteTextures(texture)

  override fun glDeleteTextures(n: Int, textures: Long): Unit = GL11C.nglDeleteTextures(n, textures)

  override fun glClearDepth(depth: Double): Unit = GL11C.glClearDepth(depth)

  override fun glGetPointerv(pname: Int, params: Long): Unit = GL11C.nglGetPointerv(pname, params)

  override fun glFinish(): Unit = GL11C.glFinish()

  override fun glFlush(): Unit = GL11C.glFlush()

  override fun glIsEnabled(cap: Int): Boolean = GL11C.glIsEnabled(cap)

  override fun glTexParameterf(
    target: Int,
    pname: Int,
    `param`: Float,
  ): Unit = GL11C.glTexParameterf(target, pname, `param`)

  override fun glPointSize(size: Float): Unit = GL11C.glPointSize(size)

  override fun glScissor(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = GL11C.glScissor(x, y, width, height)

  override fun glPixelStoref(pname: Int, `param`: Float): Unit = GL11C.glPixelStoref(pname, `param`)

  override fun glPolygonMode(face: Int, mode: Int): Unit = GL11C.glPolygonMode(face, mode)

  override fun glCopyTexImage1D(
    target: Int,
    level: Int,
    internalFormat: Int,
    x: Int,
    y: Int,
    width: Int,
    border: Int,
  ): Unit = GL11C.glCopyTexImage1D(target, level, internalFormat, x, y, width, border)

  override fun glHint(target: Int, hint: Int): Unit = GL11C.glHint(target, hint)

  override fun glTexImage1D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL11C.nglTexImage1D(target, level, internalformat, width, border, format, type, pixels)

  override fun glTexParameteri(
    target: Int,
    pname: Int,
    `param`: Int,
  ): Unit = GL11C.glTexParameteri(target, pname, `param`)

  override fun glPixelStorei(pname: Int, `param`: Int): Unit = GL11C.glPixelStorei(pname, `param`)

  override fun glStencilFunc(
    func: Int,
    ref: Int,
    mask: Int,
  ): Unit = GL11C.glStencilFunc(func, ref, mask)

  override fun glTexParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL11C.nglTexParameteriv(target, pname, params)

  override fun glIsTexture(texture: Int): Boolean = GL11C.glIsTexture(texture)

  override fun glReadPixels(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL11C.nglReadPixels(x, y, width, height, format, type, pixels)

  override fun glStencilMask(mask: Int): Unit = GL11C.glStencilMask(mask)

  override fun glStencilOp(
    sfail: Int,
    dpfail: Int,
    dppass: Int,
  ): Unit = GL11C.glStencilOp(sfail, dpfail, dppass)

  override fun glLineWidth(width: Float): Unit = GL11C.glLineWidth(width)

  override fun glTexImage2D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL11C.nglTexImage2D(target, level, internalformat, width, height, border, format, type,
      pixels)

  override fun glCopyTexImage2D(
    target: Int,
    level: Int,
    internalFormat: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    border: Int,
  ): Unit = GL11C.glCopyTexImage2D(target, level, internalFormat, x, y, width, height, border)

  override fun glLogicOp(op: Int): Unit = GL11C.glLogicOp(op)

  override fun glPolygonOffset(factor: Float, units: Float): Unit = GL11C.glPolygonOffset(factor,
      units)

  override fun glReadBuffer(src: Int): Unit = GL11C.glReadBuffer(src)

  @NullableReturn
  override fun glGetString(name: Int): String? = GL11C.glGetString(name)

  override fun glViewport(
    x: Int,
    y: Int,
    w: Int,
    h: Int,
  ): Unit = GL11C.glViewport(x, y, w, h)

  override fun glTexParameterfv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL11C.nglTexParameterfv(target, pname, params)

  override fun glTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL11C.nglTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type,
      pixels)

  override fun glTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    pixels: Long,
  ): Unit = GL11C.nglTexSubImage1D(target, level, xoffset, width, format, type, pixels)

  override fun glGetTexParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL11C.nglGetTexParameteriv(target, pname, params)

  @PtrParameter([3])
  override fun glDrawElements(
    mode: Int,
    count: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
  ): Unit = GL11C.nglDrawElements(mode, count, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address)

  @PtrParameter([4])
  override fun glGetTexImage(
    tex: Int,
    level: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL11C.nglGetTexImage(tex, level, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([2])
  override fun glGetTexParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL11C.nglGetTexParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glTexParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL11C.nglTexParameteriv(target, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glTexParameterfv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL11C.nglTexParameterfv(target, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glCopyTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    x: Int,
    y: Int,
    width: Int,
  ): Unit = GL11C.glCopyTexSubImage1D(target, level, xoffset, x, y, width)

  @PtrParameter([1])
  override fun glGetDoublev(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr): Unit =
      GL11C.nglGetDoublev(pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([3])
  override fun glGetTexLevelParameterfv(
    target: Int,
    level: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL11C.nglGetTexLevelParameterfv(target, level, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([6])
  override fun glReadPixels(
    x: Int,
    y: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL11C.nglReadPixels(x, y, width, height, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glGetTexParameterfv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL11C.nglGetTexParameterfv(target, pname, params)

  @PtrParameter([3])
  override fun glGetTexLevelParameteriv(
    target: Int,
    level: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL11C.nglGetTexLevelParameteriv(target, level, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([6])
  override fun glTexSubImage1D(
    target: Int,
    level: Int,
    xoffset: Int,
    width: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL11C.nglTexSubImage1D(target, level, xoffset, width, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([1])
  override fun glDeleteTextures(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`: Ptr): Unit =
      GL11C.nglDeleteTextures(n, `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`.address)

  @PtrParameter([1])
  override fun glGenTextures(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`: Ptr): Unit =
      GL11C.nglGenTextures(n, `$v$c$dev-luna5ama-kmogus-Ptr$-textures$0`.address)

  @PtrParameter([1])
  override fun glGetBooleanv(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr): Unit =
      GL11C.nglGetBooleanv(pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glGetFloatv(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr): Unit =
      GL11C.nglGetFloatv(pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetTexLevelParameterfv(
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
  ): Unit = GL11C.nglGetTexLevelParameterfv(target, level, pname, params)

  override fun glCopyTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    x: Int,
    y: Int,
    width: Int,
    height: Int,
  ): Unit = GL11C.glCopyTexSubImage2D(target, level, xoffset, yoffset, x, y, width, height)

  @PtrParameter([1])
  override fun glGetIntegerv(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr): Unit =
      GL11C.nglGetIntegerv(pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glGetPointerv(pname: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr): Unit =
      GL11C.nglGetPointerv(pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([7])
  override fun glTexImage1D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    border: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL11C.nglTexImage1D(target, level, internalformat, width, border, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  override fun glGetTexLevelParameteriv(
    target: Int,
    level: Int,
    pname: Int,
    params: Long,
  ): Unit = GL11C.nglGetTexLevelParameteriv(target, level, pname, params)

  @PtrParameter([2])
  override fun glGetTexParameterfv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL11C.nglGetTexParameterfv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([8])
  override fun glTexImage2D(
    target: Int,
    level: Int,
    internalformat: Int,
    width: Int,
    height: Int,
    border: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL11C.nglTexImage2D(target, level, internalformat, width, height, border, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)

  @PtrParameter([8])
  override fun glTexSubImage2D(
    target: Int,
    level: Int,
    xoffset: Int,
    yoffset: Int,
    width: Int,
    height: Int,
    format: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`: Ptr,
  ): Unit = GL11C.nglTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pixels$0`.address)
}
