package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class ARBDebugOutputLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBDebugOutput {
  override fun glDebugMessageControlARB(
    source: Int,
    type: Int,
    severity: Int,
    count: Int,
    ids: Long,
    enabled: Boolean,
  ): Unit = org.lwjgl.opengl.ARBDebugOutput.nglDebugMessageControlARB(source, type, severity, count,
      ids, enabled)

  @PtrParameter([1])
  override fun glDebugMessageCallbackARB(callback: Long,
      `$v$c$dev-luna5ama-kmogus-Ptr$-userParam$0`: Ptr): Unit =
      org.lwjgl.opengl.ARBDebugOutput.nglDebugMessageCallbackARB(callback,
      `$v$c$dev-luna5ama-kmogus-Ptr$-userParam$0`.address)

  @PtrParameter([5])
  override fun glDebugMessageInsertARB(
    source: Int,
    type: Int,
    id: Int,
    severity: Int,
    length: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-buf$0`: Ptr,
  ): Unit = org.lwjgl.opengl.ARBDebugOutput.nglDebugMessageInsertARB(source, type, id, severity,
      length, `$v$c$dev-luna5ama-kmogus-Ptr$-buf$0`.address)

  override fun glDebugMessageInsertARB(
    source: Int,
    type: Int,
    id: Int,
    severity: Int,
    length: Int,
    buf: Long,
  ): Unit = org.lwjgl.opengl.ARBDebugOutput.nglDebugMessageInsertARB(source, type, id, severity,
      length, buf)

  @PtrParameter([4])
  override fun glDebugMessageControlARB(
    source: Int,
    type: Int,
    severity: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr,
    enabled: Boolean,
  ): Unit = org.lwjgl.opengl.ARBDebugOutput.nglDebugMessageControlARB(source, type, severity, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address, enabled)

  @PtrParameter([2, 3, 4, 5, 6, 7])
  override fun glGetDebugMessageLogARB(
    count: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-sources$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-types$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-severities$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-lengths$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-messageLog$0`: Ptr,
  ): Int = org.lwjgl.opengl.ARBDebugOutput.nglGetDebugMessageLogARB(count, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-sources$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-types$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-severities$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-lengths$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-messageLog$0`.address)

  override fun glGetDebugMessageLogARB(
    count: Int,
    bufSize: Int,
    sources: Long,
    types: Long,
    ids: Long,
    severities: Long,
    lengths: Long,
    messageLog: Long,
  ): Int = org.lwjgl.opengl.ARBDebugOutput.nglGetDebugMessageLogARB(count, bufSize, sources, types,
      ids, severities, lengths, messageLog)

  override fun glDebugMessageCallbackARB(callback: Long, userParam: Long): Unit =
      org.lwjgl.opengl.ARBDebugOutput.nglDebugMessageCallbackARB(callback, userParam)
}
