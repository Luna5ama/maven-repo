package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class EXTSemaphoreWin32LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTSemaphoreWin32 {
  @PtrParameter([2])
  override fun glImportSemaphoreWin32HandleEXT(
    semaphore: Int,
    handleType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-handle$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTSemaphoreWin32.nglImportSemaphoreWin32HandleEXT(semaphore,
      handleType, `$v$c$dev-luna5ama-kmogus-Ptr$-handle$0`.address)

  @PtrParameter([2])
  override fun glImportSemaphoreWin32NameEXT(
    semaphore: Int,
    handleType: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`: Ptr,
  ): Unit = org.lwjgl.opengl.EXTSemaphoreWin32.nglImportSemaphoreWin32NameEXT(semaphore, handleType,
      `$v$c$dev-luna5ama-kmogus-Ptr$-name$0`.address)

  override fun glImportSemaphoreWin32HandleEXT(
    semaphore: Int,
    handleType: Int,
    handle: Long,
  ): Unit = org.lwjgl.opengl.EXTSemaphoreWin32.nglImportSemaphoreWin32HandleEXT(semaphore,
      handleType, handle)

  override fun glImportSemaphoreWin32NameEXT(
    semaphore: Int,
    handleType: Int,
    name: Long,
  ): Unit = org.lwjgl.opengl.EXTSemaphoreWin32.nglImportSemaphoreWin32NameEXT(semaphore, handleType,
      name)
}
