package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Unit

public class EXTPolygonOffsetClampLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : EXTPolygonOffsetClamp {
  override fun glPolygonOffsetClampEXT(
    factor: Float,
    units: Float,
    clamp: Float,
  ): Unit = org.lwjgl.opengl.EXTPolygonOffsetClamp.glPolygonOffsetClampEXT(factor, units, clamp)
}
