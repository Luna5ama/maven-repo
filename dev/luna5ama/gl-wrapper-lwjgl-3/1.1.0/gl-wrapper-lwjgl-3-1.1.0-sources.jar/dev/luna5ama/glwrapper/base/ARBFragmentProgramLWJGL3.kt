package dev.luna5ama.glwrapper.base

public class ARBFragmentProgramLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBFragmentProgram
