package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVShaderBufferLoadLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVShaderBufferLoad {
  @PtrParameter([2])
  override fun glGetUniformui64vNV(
    program: Int,
    location: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglGetUniformui64vNV(program, location,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetUniformui64vNV(
    program: Int,
    location: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglGetUniformui64vNV(program, location, params)

  @PtrParameter([2])
  override fun glGetBufferParameterui64vNV(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglGetBufferParameterui64vNV(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetNamedBufferParameterui64vNV(
    buffer: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglGetNamedBufferParameterui64vNV(buffer, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glMakeBufferNonResidentNV(target: Int): Unit =
      org.lwjgl.opengl.NVShaderBufferLoad.glMakeBufferNonResidentNV(target)

  override fun glGetBufferParameterui64vNV(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglGetBufferParameterui64vNV(target, pname, params)

  override fun glIsNamedBufferResidentNV(buffer: Int): Boolean =
      org.lwjgl.opengl.NVShaderBufferLoad.glIsNamedBufferResidentNV(buffer)

  @PtrParameter([1])
  override fun glGetIntegerui64vNV(`value`: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-result$0`: Ptr):
      Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglGetIntegerui64vNV(`value`,
      `$v$c$dev-luna5ama-kmogus-Ptr$-result$0`.address)

  override fun glGetIntegerui64vNV(`value`: Int, result: Long): Unit =
      org.lwjgl.opengl.NVShaderBufferLoad.nglGetIntegerui64vNV(`value`, result)

  @PtrParameter([2])
  override fun glUniformui64vNV(
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglUniformui64vNV(location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniformui64NV(
    program: Int,
    location: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.glProgramUniformui64NV(program, location, `value`)

  @PtrParameter([3])
  override fun glProgramUniformui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglProgramUniformui64vNV(program, location, count,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glProgramUniformui64vNV(
    program: Int,
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglProgramUniformui64vNV(program, location, count,
      `value`)

  override fun glIsBufferResidentNV(target: Int): Boolean =
      org.lwjgl.opengl.NVShaderBufferLoad.glIsBufferResidentNV(target)

  override fun glMakeBufferResidentNV(target: Int, access: Int): Unit =
      org.lwjgl.opengl.NVShaderBufferLoad.glMakeBufferResidentNV(target, access)

  override fun glMakeNamedBufferNonResidentNV(buffer: Int): Unit =
      org.lwjgl.opengl.NVShaderBufferLoad.glMakeNamedBufferNonResidentNV(buffer)

  override fun glGetNamedBufferParameterui64vNV(
    buffer: Int,
    pname: Int,
    params: Long,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglGetNamedBufferParameterui64vNV(buffer, pname,
      params)

  override fun glMakeNamedBufferResidentNV(buffer: Int, access: Int): Unit =
      org.lwjgl.opengl.NVShaderBufferLoad.glMakeNamedBufferResidentNV(buffer, access)

  override fun glUniformui64NV(location: Int, `value`: Long): Unit =
      org.lwjgl.opengl.NVShaderBufferLoad.glUniformui64NV(location, `value`)

  override fun glUniformui64vNV(
    location: Int,
    count: Int,
    `value`: Long,
  ): Unit = org.lwjgl.opengl.NVShaderBufferLoad.nglUniformui64vNV(location, count, `value`)
}
