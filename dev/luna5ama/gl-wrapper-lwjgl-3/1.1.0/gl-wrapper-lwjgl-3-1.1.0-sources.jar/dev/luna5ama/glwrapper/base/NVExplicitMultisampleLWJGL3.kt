package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVExplicitMultisampleLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVExplicitMultisample {
  override fun glSampleMaskIndexedNV(index: Int, mask: Int): Unit =
      org.lwjgl.opengl.NVExplicitMultisample.glSampleMaskIndexedNV(index, mask)

  override fun glGetMultisamplefvNV(
    pname: Int,
    index: Int,
    `val`: Long,
  ): Unit = org.lwjgl.opengl.NVExplicitMultisample.nglGetMultisamplefvNV(pname, index, `val`)

  override fun glTexRenderbufferNV(target: Int, renderbuffer: Int): Unit =
      org.lwjgl.opengl.NVExplicitMultisample.glTexRenderbufferNV(target, renderbuffer)

  @PtrParameter([2])
  override fun glGetMultisamplefvNV(
    pname: Int,
    index: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-val$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVExplicitMultisample.nglGetMultisamplefvNV(pname, index,
      `$v$c$dev-luna5ama-kmogus-Ptr$-val$0`.address)
}
