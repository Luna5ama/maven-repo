package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL21C

public class GL21LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL21 {
  @PtrParameter([3])
  override fun glUniformMatrix3x2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL21C.nglUniformMatrix3x2fv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniformMatrix2x4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL21C.nglUniformMatrix2x4fv(location, count, transpose, `value`)

  override fun glUniformMatrix2x3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL21C.nglUniformMatrix2x3fv(location, count, transpose, `value`)

  @PtrParameter([3])
  override fun glUniformMatrix3x4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL21C.nglUniformMatrix3x4fv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniformMatrix3x4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL21C.nglUniformMatrix3x4fv(location, count, transpose, `value`)

  @PtrParameter([3])
  override fun glUniformMatrix4x2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL21C.nglUniformMatrix4x2fv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniformMatrix3x2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL21C.nglUniformMatrix3x2fv(location, count, transpose, `value`)

  @PtrParameter([3])
  override fun glUniformMatrix2x4fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL21C.nglUniformMatrix2x4fv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix4x3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL21C.nglUniformMatrix4x3fv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  @PtrParameter([3])
  override fun glUniformMatrix2x3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`: Ptr,
  ): Unit = GL21C.nglUniformMatrix2x3fv(location, count, transpose,
      `$v$c$dev-luna5ama-kmogus-Ptr$-value$0`.address)

  override fun glUniformMatrix4x2fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL21C.nglUniformMatrix4x2fv(location, count, transpose, `value`)

  override fun glUniformMatrix4x3fv(
    location: Int,
    count: Int,
    transpose: Boolean,
    `value`: Long,
  ): Unit = GL21C.nglUniformMatrix4x3fv(location, count, transpose, `value`)
}
