package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL15C

public class GL15LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL15 {
  override fun glBufferSubData(
    target: Int,
    offset: Long,
    size: Long,
    `data`: Long,
  ): Unit = GL15C.nglBufferSubData(target, offset, size, `data`)

  override fun glBufferData(
    target: Int,
    size: Long,
    `data`: Long,
    usage: Int,
  ): Unit = GL15C.nglBufferData(target, size, `data`, usage)

  override fun glGetBufferSubData(
    target: Int,
    offset: Long,
    size: Long,
    `data`: Long,
  ): Unit = GL15C.nglGetBufferSubData(target, offset, size, `data`)

  override fun glUnmapBuffer(target: Int): Boolean = GL15C.glUnmapBuffer(target)

  override fun glDeleteBuffers(buffer: Int): Unit = GL15C.glDeleteBuffers(buffer)

  override fun glDeleteBuffers(n: Int, buffers: Long): Unit = GL15C.nglDeleteBuffers(n, buffers)

  override fun glIsBuffer(buffer: Int): Boolean = GL15C.glIsBuffer(buffer)

  override fun glGenBuffers(n: Int, buffers: Long): Unit = GL15C.nglGenBuffers(n, buffers)

  override fun glBindBuffer(target: Int, buffer: Int): Unit = GL15C.glBindBuffer(target, buffer)

  override fun glGetQueryObjectiv(
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = GL15C.nglGetQueryObjectiv(id, pname, params)

  override fun glEndQuery(target: Int): Unit = GL15C.glEndQuery(target)

  override fun glBeginQuery(target: Int, id: Int): Unit = GL15C.glBeginQuery(target, id)

  override fun glGenQueries(n: Int, ids: Long): Unit = GL15C.nglGenQueries(n, ids)

  override fun glDeleteQueries(n: Int, ids: Long): Unit = GL15C.nglDeleteQueries(n, ids)

  override fun glDeleteQueries(query: Int): Unit = GL15C.glDeleteQueries(query)

  override fun glIsQuery(id: Int): Boolean = GL15C.glIsQuery(id)

  override fun glGetQueryiv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL15C.nglGetQueryiv(target, pname, params)

  @PtrParameter([3])
  override fun glBufferSubData(
    target: Int,
    offset: Long,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL15C.nglBufferSubData(target, offset, size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  override fun glGetBufferParameteriv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL15C.nglGetBufferParameteriv(target, pname, params)

  @PtrParameter([1])
  override fun glGenQueries(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr): Unit =
      GL15C.nglGenQueries(n, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address)

  override fun glGetQueryObjectuiv(
    id: Int,
    pname: Int,
    params: Long,
  ): Unit = GL15C.nglGetQueryObjectuiv(id, pname, params)

  @PtrParameter([2])
  override fun glGetBufferPointerv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL15C.nglGetBufferPointerv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetQueryObjectuiv(
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL15C.nglGetQueryObjectuiv(id, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  override fun glGetBufferPointerv(
    target: Int,
    pname: Int,
    params: Long,
  ): Unit = GL15C.nglGetBufferPointerv(target, pname, params)

  @PtrParameter([2])
  override fun glGetBufferParameteriv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL15C.nglGetBufferParameteriv(target, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrReturn
  override fun glMapBuffer(target: Int, access: Int): Ptr = Ptr(GL15C.nglMapBuffer(target, access))

  @PtrParameter([2])
  override fun glBufferData(
    target: Int,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
    usage: Int,
  ): Unit = GL15C.nglBufferData(target, size, `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address, usage)

  @PtrParameter([1])
  override fun glDeleteBuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`: Ptr): Unit =
      GL15C.nglDeleteBuffers(n, `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`.address)

  @PtrParameter([1])
  override fun glGenBuffers(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`: Ptr): Unit =
      GL15C.nglGenBuffers(n, `$v$c$dev-luna5ama-kmogus-Ptr$-buffers$0`.address)

  @PtrParameter([3])
  override fun glGetBufferSubData(
    target: Int,
    offset: Long,
    size: Long,
    `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`: Ptr,
  ): Unit = GL15C.nglGetBufferSubData(target, offset, size,
      `$v$c$dev-luna5ama-kmogus-Ptr$-data$0`.address)

  @PtrParameter([2])
  override fun glGetQueryiv(
    target: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL15C.nglGetQueryiv(target, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2])
  override fun glGetQueryObjectiv(
    id: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL15C.nglGetQueryObjectiv(id, pname, `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glDeleteQueries(n: Int, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`: Ptr): Unit =
      GL15C.nglDeleteQueries(n, `$v$c$dev-luna5ama-kmogus-Ptr$-ids$0`.address)
}
