package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long

public class ARBMapBufferRangeLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : ARBMapBufferRange {
  @PtrReturn
  override fun glMapBufferRange(
    target: Int,
    offset: Long,
    length: Long,
    access: Int,
  ): Ptr = Ptr(org.lwjgl.opengl.ARBMapBufferRange.nglMapBufferRange(target, offset, length, access))
}
