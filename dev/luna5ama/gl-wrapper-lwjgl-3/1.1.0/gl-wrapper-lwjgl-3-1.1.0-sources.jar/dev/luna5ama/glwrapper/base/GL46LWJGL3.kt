package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL46C

public class GL46LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL46 {
  @PtrParameter([1])
  override fun glMultiDrawArraysIndirectCount(
    mode: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
  ): Unit = GL46C.nglMultiDrawArraysIndirectCount(mode,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address, drawcount, maxdrawcount, stride)

  @PtrParameter([2])
  override fun glMultiDrawElementsIndirectCount(
    mode: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`: Ptr,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
  ): Unit = GL46C.nglMultiDrawElementsIndirectCount(mode, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indirect$0`.address, drawcount, maxdrawcount, stride)

  override fun glSpecializeShader(
    shader: Int,
    pEntryPoint: Long,
    numSpecializationConstants: Int,
    pConstantIndex: Long,
    pConstantValue: Long,
  ): Unit = GL46C.nglSpecializeShader(shader, pEntryPoint, numSpecializationConstants,
      pConstantIndex, pConstantValue)

  override fun glMultiDrawElementsIndirectCount(
    mode: Int,
    type: Int,
    indirect: Long,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
  ): Unit = GL46C.nglMultiDrawElementsIndirectCount(mode, type, indirect, drawcount, maxdrawcount,
      stride)

  @PtrParameter([1, 3, 4])
  override fun glSpecializeShader(
    shader: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pEntryPoint$0`: Ptr,
    numSpecializationConstants: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pConstantIndex$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pConstantValue$0`: Ptr,
  ): Unit = GL46C.nglSpecializeShader(shader, `$v$c$dev-luna5ama-kmogus-Ptr$-pEntryPoint$0`.address,
      numSpecializationConstants, `$v$c$dev-luna5ama-kmogus-Ptr$-pConstantIndex$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pConstantValue$0`.address)

  override fun glPolygonOffsetClamp(
    factor: Float,
    units: Float,
    clamp: Float,
  ): Unit = GL46C.glPolygonOffsetClamp(factor, units, clamp)

  override fun glMultiDrawArraysIndirectCount(
    mode: Int,
    indirect: Long,
    drawcount: Long,
    maxdrawcount: Int,
    stride: Int,
  ): Unit = GL46C.nglMultiDrawArraysIndirectCount(mode, indirect, drawcount, maxdrawcount, stride)
}
