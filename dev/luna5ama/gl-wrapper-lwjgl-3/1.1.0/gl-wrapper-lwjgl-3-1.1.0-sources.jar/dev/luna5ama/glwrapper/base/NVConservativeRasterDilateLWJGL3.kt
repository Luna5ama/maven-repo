package dev.luna5ama.glwrapper.base

import kotlin.Float
import kotlin.Int
import kotlin.Unit

public class NVConservativeRasterDilateLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVConservativeRasterDilate {
  override fun glConservativeRasterParameterfNV(pname: Int, `value`: Float): Unit =
      org.lwjgl.opengl.NVConservativeRasterDilate.glConservativeRasterParameterfNV(pname, `value`)
}
