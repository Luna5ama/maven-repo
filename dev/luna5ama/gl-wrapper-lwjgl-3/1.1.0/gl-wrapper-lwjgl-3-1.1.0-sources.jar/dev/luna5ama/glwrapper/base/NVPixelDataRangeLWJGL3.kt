package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit

public class NVPixelDataRangeLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVPixelDataRange {
  override fun glFlushPixelDataRangeNV(target: Int): Unit =
      org.lwjgl.opengl.NVPixelDataRange.glFlushPixelDataRangeNV(target)

  @PtrParameter([2])
  override fun glPixelDataRangeNV(
    target: Int,
    length: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`: Ptr,
  ): Unit = org.lwjgl.opengl.NVPixelDataRange.nglPixelDataRangeNV(target, length,
      `$v$c$dev-luna5ama-kmogus-Ptr$-pointer$0`.address)

  override fun glPixelDataRangeNV(
    target: Int,
    length: Int,
    pointer: Long,
  ): Unit = org.lwjgl.opengl.NVPixelDataRange.nglPixelDataRangeNV(target, length, pointer)
}
