package dev.luna5ama.glwrapper.base

public class AMDTransformFeedback4LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : AMDTransformFeedback4
