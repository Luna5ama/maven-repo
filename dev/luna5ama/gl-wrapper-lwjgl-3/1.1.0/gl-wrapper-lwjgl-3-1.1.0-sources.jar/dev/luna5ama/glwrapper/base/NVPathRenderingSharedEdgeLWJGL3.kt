package dev.luna5ama.glwrapper.base

public class NVPathRenderingSharedEdgeLWJGL3(
  override val glWrapperInstance: GLWrapper,
) : NVPathRenderingSharedEdge
