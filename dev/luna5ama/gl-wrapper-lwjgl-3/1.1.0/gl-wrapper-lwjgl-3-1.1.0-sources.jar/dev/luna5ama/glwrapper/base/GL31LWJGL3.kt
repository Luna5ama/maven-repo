package dev.luna5ama.glwrapper.base

import dev.luna5ama.kmogus.Ptr
import kotlin.Int
import kotlin.Long
import kotlin.Unit
import org.lwjgl.opengl.GL31C

public class GL31LWJGL3(
  override val glWrapperInstance: GLWrapper,
) : GL31 {
  @PtrParameter([3, 4])
  override fun glGetActiveUniformBlockName(
    program: Int,
    uniformBlockIndex: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-uniformBlockName$0`: Ptr,
  ): Unit = GL31C.nglGetActiveUniformBlockName(program, uniformBlockIndex, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-uniformBlockName$0`.address)

  @PtrParameter([2, 4])
  override fun glGetActiveUniformsiv(
    program: Int,
    uniformCount: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-uniformIndices$0`: Ptr,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL31C.nglGetActiveUniformsiv(program, uniformCount,
      `$v$c$dev-luna5ama-kmogus-Ptr$-uniformIndices$0`.address, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([1])
  override fun glGetUniformBlockIndex(program: Int,
      `$v$c$dev-luna5ama-kmogus-Ptr$-uniformBlockName$0`: Ptr): Int =
      GL31C.nglGetUniformBlockIndex(program,
      `$v$c$dev-luna5ama-kmogus-Ptr$-uniformBlockName$0`.address)

  override fun glUniformBlockBinding(
    program: Int,
    uniformBlockIndex: Int,
    uniformBlockBinding: Int,
  ): Unit = GL31C.glUniformBlockBinding(program, uniformBlockIndex, uniformBlockBinding)

  override fun glDrawElementsInstanced(
    mode: Int,
    count: Int,
    type: Int,
    indices: Long,
    primcount: Int,
  ): Unit = GL31C.nglDrawElementsInstanced(mode, count, type, indices, primcount)

  override fun glCopyBufferSubData(
    readTarget: Int,
    writeTarget: Int,
    readOffset: Long,
    writeOffset: Long,
    size: Long,
  ): Unit = GL31C.glCopyBufferSubData(readTarget, writeTarget, readOffset, writeOffset, size)

  @PtrParameter([3])
  override fun glDrawElementsInstanced(
    mode: Int,
    count: Int,
    type: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`: Ptr,
    primcount: Int,
  ): Unit = GL31C.nglDrawElementsInstanced(mode, count, type,
      `$v$c$dev-luna5ama-kmogus-Ptr$-indices$0`.address, primcount)

  override fun glGetActiveUniformsiv(
    program: Int,
    uniformCount: Int,
    uniformIndices: Long,
    pname: Int,
    params: Long,
  ): Unit = GL31C.nglGetActiveUniformsiv(program, uniformCount, uniformIndices, pname, params)

  override fun glGetUniformBlockIndex(program: Int, uniformBlockName: Long): Int =
      GL31C.nglGetUniformBlockIndex(program, uniformBlockName)

  override fun glPrimitiveRestartIndex(index: Int): Unit = GL31C.glPrimitiveRestartIndex(index)

  override fun glGetUniformIndices(
    program: Int,
    uniformCount: Int,
    uniformNames: Long,
    uniformIndices: Long,
  ): Unit = GL31C.nglGetUniformIndices(program, uniformCount, uniformNames, uniformIndices)

  @PtrParameter([3, 4])
  override fun glGetActiveUniformName(
    program: Int,
    uniformIndex: Int,
    bufSize: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-uniformName$0`: Ptr,
  ): Unit = GL31C.nglGetActiveUniformName(program, uniformIndex, bufSize,
      `$v$c$dev-luna5ama-kmogus-Ptr$-length$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-uniformName$0`.address)

  override fun glGetActiveUniformName(
    program: Int,
    uniformIndex: Int,
    bufSize: Int,
    length: Long,
    uniformName: Long,
  ): Unit = GL31C.nglGetActiveUniformName(program, uniformIndex, bufSize, length, uniformName)

  override fun glDrawArraysInstanced(
    mode: Int,
    first: Int,
    count: Int,
    primcount: Int,
  ): Unit = GL31C.glDrawArraysInstanced(mode, first, count, primcount)

  @PtrParameter([3])
  override fun glGetActiveUniformBlockiv(
    program: Int,
    uniformBlockIndex: Int,
    pname: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`: Ptr,
  ): Unit = GL31C.nglGetActiveUniformBlockiv(program, uniformBlockIndex, pname,
      `$v$c$dev-luna5ama-kmogus-Ptr$-params$0`.address)

  @PtrParameter([2, 3])
  override fun glGetUniformIndices(
    program: Int,
    uniformCount: Int,
    `$v$c$dev-luna5ama-kmogus-Ptr$-uniformNames$0`: Ptr,
    `$v$c$dev-luna5ama-kmogus-Ptr$-uniformIndices$0`: Ptr,
  ): Unit = GL31C.nglGetUniformIndices(program, uniformCount,
      `$v$c$dev-luna5ama-kmogus-Ptr$-uniformNames$0`.address,
      `$v$c$dev-luna5ama-kmogus-Ptr$-uniformIndices$0`.address)

  override fun glGetActiveUniformBlockiv(
    program: Int,
    uniformBlockIndex: Int,
    pname: Int,
    params: Long,
  ): Unit = GL31C.nglGetActiveUniformBlockiv(program, uniformBlockIndex, pname, params)

  override fun glGetActiveUniformBlockName(
    program: Int,
    uniformBlockIndex: Int,
    bufSize: Int,
    length: Long,
    uniformBlockName: Long,
  ): Unit = GL31C.nglGetActiveUniformBlockName(program, uniformBlockIndex, bufSize, length,
      uniformBlockName)

  override fun glTexBuffer(
    target: Int,
    internalformat: Int,
    buffer: Int,
  ): Unit = GL31C.glTexBuffer(target, internalformat, buffer)
}
